import { PrismaClient } from '../src/generated/prisma/client';

const prisma = new PrismaClient();

async function main() {
  try {
    const roles = await prisma.$queryRaw`SELECT enum_range(NULL::"Role")`;
    console.log('Current Roles in DB:', roles);
  } catch (e) {
    console.error('Failed to fetch roles:', e);
  } finally {
    await prisma.$disconnect();
  }
}

main();
