
import { PrismaClient } from './src/generated/prisma/client';
const prisma = new PrismaClient();

async function main() {
    const projects = await prisma.project.findMany({
        take: 5,
        select: { id: true, name: true }
    });
    console.log(JSON.stringify(projects, null, 2));
}

main().catch(console.error).finally(() => prisma.$disconnect());
