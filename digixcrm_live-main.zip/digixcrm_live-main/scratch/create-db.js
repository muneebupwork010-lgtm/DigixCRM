const { Client } = require('pg');

async function createDb() {
  const password = '#@#@aDm1n#@#@';
  
  const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: password,
    port: 5432,
  });

  try {
    await client.connect();
    console.log('Connected to postgres using provided password.');
  } catch (err) {
    console.error('Could not connect to postgres:', err.message);
    process.exit(1);
  }

  try {
    await client.query(`CREATE ROLE digixcrm_admin WITH LOGIN PASSWORD '#@#@aDm1n#@#@';`);
    console.log('Created user digixcrm_admin');
  } catch (err) {
    if (err.code === '42710') {
      console.log('User digixcrm_admin already exists, updating password...');
      await client.query(`ALTER ROLE digixcrm_admin WITH LOGIN PASSWORD '#@#@aDm1n#@#@';`);
    } else {
      console.error('Error creating user:', err.message);
    }
  }

  try {
    await client.query(`CREATE DATABASE digixcrm_db OWNER digixcrm_admin;`);
    console.log('Created database digixcrm_db');
  } catch (err) {
    if (err.code === '42P04') {
      console.log('Database digixcrm_db already exists');
    } else {
      console.error('Error creating db:', err.message);
    }
  }

  await client.end();
}

createDb();
