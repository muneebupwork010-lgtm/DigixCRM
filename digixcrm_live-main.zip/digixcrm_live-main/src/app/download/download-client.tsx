"use client";

import { motion } from "framer-motion";
import { Download, ShieldCheck, Smartphone, Zap, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { LandingNav } from "@/components/landing/landing-nav";
import { useState, useEffect } from "react";
import { ServiceModal } from "@/components/landing/service-modal";
import { generateQR } from "@/lib/qr-generator";

export function DownloadClient() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("FREE");
    const [qrUrl, setQrUrl] = useState<string>("");

    useEffect(() => {
        generateQR("https://play.google.com/apps/internaltest/4701378403036982212").then(setQrUrl);
    }, []);

    const onOpenModal = (plan: string) => {
        setSelectedPlan(plan);
        setIsModalOpen(true);
    };

    return (
        <>
            <LandingNav onOpenModal={onOpenModal} />
            
            <main className="pt-24 pb-20">
                {/* Hero Section */}
                <section className="relative px-6 max-w-6xl mx-auto">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                        <motion.div
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.5 }}
                        >
                            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/20 rounded-full mb-6">
                                <Smartphone className="w-4 h-4 text-primary" />
                                <span className="text-[10px] font-black uppercase tracking-widest text-primary">Mobile Power Unleashed</span>
                            </div>
                            
                            <h1 className="text-4xl sm:text-6xl font-black leading-[1.1] tracking-tight mb-6">
                                DigixCRM for <span className="text-primary">Android.</span>
                            </h1>
                            
                            <p className="text-lg text-muted-foreground leading-relaxed mb-10 max-w-lg">
                                Take the full power of your enterprise CRM anywhere. Real-time sync, lightning-fast dashboarding, and total workspace sovereignty—now in your pocket.
                            </p>

                            <div className="flex flex-col sm:flex-row items-center gap-4 mb-12">
                                <Link href="https://play.google.com/apps/internaltest/4701378403036982212" className="w-full sm:w-auto">
                                    <Button className="w-full sm:w-auto h-16 px-10 rounded-2xl bg-primary text-white font-black text-lg gap-4 shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all overflow-hidden relative group">
                                        <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                                        <div className="relative flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
                                                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.61 3,21.09 3,20.5M16.81,15.12L18.66,16.19C19.45,16.63 19.45,17.37 18.66,17.81L4.67,25.89L13.69,16.88L16.81,15.12M14.41,11.23L16.81,12.88L14.41,14.53V11.23M16.81,8.88L13.69,7.12L4.67,1.11L18.66,9.19C19.45,9.63 19.45,10.37 18.66,10.81L16.81,11.88V8.88Z" />
                                                </svg>
                                            </div>
                                            <div className="flex flex-col items-start leading-tight">
                                                <span className="text-[10px] font-bold uppercase tracking-tighter opacity-70">Get it on</span>
                                                <span className="text-xl -mt-0.5">Google Play</span>
                                            </div>
                                        </div>
                                    </Button>
                                </Link>
                                <div className="text-center sm:text-left">
                                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">Official Distribution (v1.2.0)</p>
                                    <p className="text-xs text-muted-foreground italic">Google Play Internal Testing Enabled</p>
                                </div>
                            </div>

                            {/* Desktop QR Code Bridge - Fixed Scannability & Position */}
                            <div className="hidden lg:flex items-center gap-5 p-5 bg-card border border-border rounded-3xl shadow-xl mb-12 w-fit hover:scale-[1.02] transition-transform cursor-help">
                                <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center border border-border/50 p-1.5 overflow-hidden">
                                     {qrUrl ? (
                                        <img src={qrUrl} alt="Play Store QR" className="w-full h-full object-contain" />
                                     ) : (
                                        <div className="w-full h-full bg-muted animate-pulse" />
                                     )}
                                </div>
                                <div>
                                    <h4 className="text-sm font-black uppercase tracking-wider text-foreground mb-1">Testing Bridge</h4>
                                    <p className="text-[10px] text-muted-foreground leading-relaxed max-w-[140px]">Scan to join the internal testing group directly on the Play Store.</p>
                                    <div className="mt-2 text-[9px] font-bold text-primary py-0.5 px-2 bg-primary/10 rounded-full w-fit">PLAY STORE LINK</div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-6 border-t border-border pt-10">
                                <div className="flex flex-col gap-2">
                                    <Zap className="w-6 h-6 text-primary" />
                                    <h3 className="font-bold">Instant Sync</h3>
                                    <p className="text-xs text-muted-foreground">Real-time updates across all your partitions.</p>
                                </div>
                                <div className="flex flex-col gap-2">
                                    <ShieldCheck className="w-6 h-6 text-primary" />
                                    <h3 className="font-bold">PBAC Security</h3>
                                    <p className="text-xs text-muted-foreground">Enterprise-grade isolation on mobile.</p>
                                </div>
                            </div>
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="relative flex justify-center lg:justify-end"
                        >
                            <div className="relative">
                                 {/* Primary Phone Mockup */}
                                <div className="relative z-10 w-[290px] h-[600px] bg-zinc-900 rounded-[3.5rem] border-[10px] border-zinc-800 shadow-[0_0_50px_-12px_rgba(0,0,0,0.5)] overflow-hidden">
                                     <div className="absolute top-0 inset-x-0 h-7 bg-zinc-800 flex justify-center items-center z-20">
                                         <div className="w-16 h-4 bg-black rounded-full" />
                                     </div>
                                     <div className="w-full h-full bg-slate-50 relative p-8 flex flex-col items-center">
                                         {/* Actual Brand Logo - Vertical Variant */}
                                         <img 
                                            src="/logo-vertical-dark.png" 
                                            alt="DigixCRM" 
                                            className="w-40 h-auto object-contain mb-8 group-hover:scale-105 transition-transform duration-500"
                                         />
                                         
                                         <div className="text-center mb-10">
                                            <h4 className="text-2xl font-black text-slate-900 tracking-tight mb-2">Welcome Back</h4>
                                            <p className="text-[10px] text-slate-500 font-medium">Log in to DigixCRM to manage <br/>your leads and sales.</p>
                                         </div>

                                         {/* Mock Form */}
                                         <div className="w-full space-y-4">
                                             <div className="space-y-1.5">
                                                 <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Email Address</label>
                                                 <div className="h-10 w-full bg-white border border-slate-200 rounded-xl shadow-sm flex items-center px-4">
                                                     <span className="text-xs text-slate-300">you@company.com</span>
                                                 </div>
                                             </div>
                                             <div className="space-y-1.5">
                                                 <div className="flex justify-between items-end">
                                                     <label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Password</label>
                                                     <span className="text-[9px] font-bold text-primary">Forgot?</span>
                                                 </div>
                                                 <div className="h-10 w-full bg-white border border-slate-200 rounded-xl shadow-sm flex items-center px-4">
                                                     <span className="text-xs text-slate-300">••••••••••••</span>
                                                 </div>
                                             </div>
                                             <div className="pt-2">
                                                 <div className="h-12 w-full bg-primary rounded-xl shadow-lg shadow-primary/20 flex items-center justify-center">
                                                     <span className="text-white text-xs font-black uppercase tracking-widest">Sign In to Workspace</span>
                                                 </div>
                                             </div>

                                             <div className="flex items-center gap-3 pt-4">
                                                 <div className="h-[1px] flex-1 bg-slate-100" />
                                                 <span className="text-[8px] font-bold text-slate-300 uppercase tracking-widest">Or sign in with</span>
                                                 <div className="h-[1px] flex-1 bg-slate-100" />
                                             </div>

                                             <div className="grid grid-cols-2 gap-3">
                                                 <div className="h-10 rounded-xl border border-slate-200 flex items-center justify-center gap-2">
                                                     <div className="w-4 h-4 rounded-full bg-red-500/10 flex items-center justify-center text-[8px] font-bold text-red-500">G</div>
                                                     <span className="text-[9px] font-bold text-slate-600">Google</span>
                                                 </div>
                                                 <div className="h-10 rounded-xl border border-slate-200 flex items-center justify-center gap-2">
                                                     <div className="w-4 h-4 rounded-full bg-blue-500/10 flex items-center justify-center text-[8px] font-bold text-blue-500">M</div>
                                                     <span className="text-[9px] font-bold text-slate-600">Microsoft</span>
                                                 </div>
                                             </div>

                                             <div className="text-center pt-2">
                                                 <p className="text-[9px] font-bold text-slate-400">Don't have an account? <span className="text-primary">Sign Up</span></p>
                                             </div>
                                         </div>

                                         <div className="mt-auto pb-2 text-center">
                                             <p className="text-[7px] font-bold text-slate-300 uppercase tracking-tighter">Terms & Privacy | DigixCRM v1.2.0</p>
                                         </div>
                                     </div>
                                </div>
                                
                                {/* Floating Success Card - Repositioned to avoid overlap */}
                                <motion.div 
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.8 }}
                                    className="absolute -top-10 -left-20 z-20 p-4 bg-card/90 backdrop-blur-xl border border-border shadow-2xl rounded-2xl flex items-center gap-3 w-48"
                                >
                                    <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                                        <CheckCircle2 className="w-6 h-6 text-green-500" />
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Real-time</p>
                                        <p className="text-sm font-bold text-foreground">Lead Assigned</p>
                                        <p className="text-xs text-primary font-bold">+$2,400.00</p>
                                    </div>
                                </motion.div>

                                {/* Floating Analytics Badge - Positioned at bottom right */}
                                <motion.div 
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 1 }}
                                    className="absolute -bottom-6 -right-12 z-20 p-5 bg-card border border-border rounded-3xl shadow-2xl flex flex-col gap-2 w-40"
                                >
                                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                                        <motion.div 
                                            initial={{ width: 0 }}
                                            animate={{ width: "70%" }}
                                            transition={{ delay: 1.5, duration: 1 }}
                                            className="h-full bg-primary" 
                                        />
                                    </div>
                                    <div className="flex justify-between items-center text-[10px] font-bold">
                                         <span>Daily Goal</span>
                                         <span className="text-primary">70%</span>
                                    </div>
                                </motion.div>
                            </div>
                        </motion.div>
                    </div>
                </section>

                {/* Installation Guide */}
                <section className="bg-muted/30 py-20 mt-20">
                    <div className="max-w-4xl mx-auto px-6">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl font-black tracking-tight mb-4">How to Join the Test</h2>
                            <p className="text-muted-foreground">DigixCRM is currently in moderated internal testing. Follow these steps to install the app via the Google Play Store.</p>
                        </div>

                        <div className="space-y-4">
                            {[
                                { t: "Open the Invite", d: "Click the Download button or scan the QR code to open the internal testing invitation on your Android device." },
                                { t: "Join the Group", d: "You will be prompted to become a tester. Opt-in to get access to the high-velocity CRM build." },
                                { t: "Install from Play Store", d: "Once joined, you will be redirected to the official Google Play listing to download the app securely." },
                                { t: "Launch & Login", d: "Open DigixCRM from your app drawer and sign in with your enterprise credentials." }
                            ].map((step, i) => (
                                <div key={i} className="flex gap-6 p-6 bg-card border border-border rounded-2xl group hover:border-primary/30 transition-colors">
                                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center font-black text-primary shrink-0">
                                        {i + 1}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-lg mb-1">{step.t}</h4>
                                        <p className="text-sm text-muted-foreground leading-relaxed">{step.d}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </main>

            <ServiceModal 
                isOpen={isModalOpen} 
                onClose={() => setIsModalOpen(false)} 
                selectedPlan={selectedPlan} 
            />
        </>
    );
}
