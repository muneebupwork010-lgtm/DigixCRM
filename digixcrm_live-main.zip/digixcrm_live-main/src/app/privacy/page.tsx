import { Metadata } from "next";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { Shield, Eye, Lock, Globe, ArrowRight } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
    title: "Privacy Policy | DigixCRM",
    description: "Detailed information on how DigixCRM handles your data, ensures security, and maintains global privacy compliance.",
};

export default function PrivacyPage() {
    return (
        <>
            <LandingNav />
            <main className="pt-24 min-h-screen bg-background text-foreground">
                <section className="border-b border-border bg-muted/10 py-16 md:py-24">
                    <div className="max-w-4xl mx-auto px-6 text-center">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest mb-6 px-4">
                           <Shield className="w-3.5 h-3.5" /> Data Sovereignty & Privacy
                        </div>
                        <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 mx-auto">
                            Strict <span className="text-primary italic">Data Protection.</span>
                        </h1>
                        <p className="text-lg text-muted-foreground font-bold leading-relaxed max-w-2xl mx-auto">
                            You own your sales data. We just keep it safe. No hidden data-selling and no complex clauses. Just total transparency and security for your revenue operation.
                        </p>
                    </div>
                </section>

                <section className="py-20">
                    <div className="max-w-4xl mx-auto px-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-20">
                            {[
                                { icon: Lock, title: "Encryption", desc: "All data is encrypted at rest (AES-256) and in transit (TLS 1.3)." },
                                { icon: Eye, title: "Transparency", desc: "No hidden data sharing. We act strictly as a processor for your data." },
                                { icon: Globe, title: "Compliance", desc: "Fully GDPR compliant. Data sovereignty available for enterprise plans." }
                            ].map((item) => (
                                <div key={item.title} className="p-8 rounded-3xl bg-background border border-border shadow-sm text-center group hover:border-primary/20 transition-all">
                                    <div className="w-12 h-12 rounded-2xl bg-primary/5 flex items-center justify-center mx-auto mb-6 group-hover:bg-primary/10 transition-colors">
                                        <item.icon className="w-6 h-6 text-primary" />
                                    </div>
                                    <h3 className="font-black text-lg mb-3">{item.title}</h3>
                                    <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                                </div>
                            ))}
                        </div>

                        <div className="max-w-3xl mx-auto space-y-16">
                            <div className="space-y-4">
                                <h2 className="text-3xl font-black text-foreground tracking-tight">Data Collection</h2>
                                <p className="text-muted-foreground leading-relaxed">
                                    We only collect information necessary to provide the CRM service. This includes account credentials, business contact information, and technical logs required for platform security and performance optimization. We **never** browse your sales pipelines or contact databases without explicit support requests.
                                </p>
                            </div>

                            <div className="space-y-4">
                                <h2 className="text-3xl font-black text-foreground tracking-tight">Information Security</h2>
                                <p className="text-muted-foreground leading-relaxed">
                                    DigixCRM employs an isolated, multi-tenant architecture. This ensures that your workspace data is logically separated from all other users. We perform regular penetration testing and vulnerability scans to ensure our infrastructure remains bulletproof.
                                </p>
                            </div>

                            <div className="space-y-4">
                                <h2 className="text-3xl font-black text-foreground tracking-tight">Third-Party Processors</h2>
                                <p className="text-muted-foreground leading-relaxed">
                                    We use a minimal set of trusted third-party processors (such as AWS for hosting and Stripe for billing). Each provider is vetted for compliance with global security standards including SOC2 and ISO 27001. A full list of sub-processors is available to Enterprise clients upon request.
                                </p>
                            </div>

                            <div className="p-10 rounded-[2.5rem] bg-foreground text-background relative overflow-hidden">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-[60px]" />
                                <h3 className="text-2xl font-black mb-4 relative z-10">Data Portability</h3>
                                <p className="text-background/70 leading-relaxed mb-6 relative z-10">
                                    You can export 100% of your data at any time in standard CSV or JSON formats. We believe in building loyalty through quality, not by locking your data in a cage.
                                </p>
                                <Link href="/contact" className="inline-flex items-center gap-2 text-primary font-black uppercase text-xs tracking-widest hover:gap-3 transition-all">
                                    Request Security Briefing <ArrowRight className="w-4 h-4" />
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <LandingFooter />
        </>
    );
}
