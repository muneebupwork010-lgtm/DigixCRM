"use client";

import { useState } from "react";
import Link from "next/link";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { ContactForm } from "@/components/landing/contact-form";
import { ServiceModal } from "@/components/landing/service-modal";
import {
    Clock, Users, Database, Globe, ChevronDown, ChevronUp,
    ArrowRight, Star, CheckCircle2, Mail, MessageSquare, FileText,
    Zap, ShieldCheck, Target
} from "lucide-react";

const faqs = [
    {
        q: "What happens after I fill out the form?",
        a: "A Solution Architect will review your requirements and reach out within 24 hours to schedule a deep-dive demo or a custom migration assessment based on your needs.",
    },
    {
        q: "How fast can we migrate from our current CRM?",
        a: "Most migrations from Salesforce, HubSpot, or Zoho are completed within 48-72 hours with zero downtime using our automated white-glove transfer system.",
    },
    {
        q: "Do you offer custom enterprise pricing?",
        a: "Yes. For teams of 20+, we offer tailored agreements with custom seat pricing, dedicated database infrastructure, and custom SLA support.",
    },
];

const trustStats = [
    { icon: Clock, value: "< 24h", label: "Response" },
    { icon: Users, value: "500+", label: "Teams" },
    { icon: Database, value: "99.9%", label: "Uptime" },
];

export function ContactPageClient() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("FREE");
    const [openFaq, setOpenFaq] = useState<number | null>(null);

    const openModal = (plan: string) => {
        setSelectedPlan(plan);
        setIsModalOpen(true);
    };

    return (
        <>
            <LandingNav onOpenModal={openModal} />

            <main className="bg-background min-h-screen">
                {/* 🚀 HYPER-CONVERSION HERO SECTION */}
                <section className="pt-24 md:pt-32 pb-16 border-b border-border bg-gradient-to-b from-primary/[0.03] to-background overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/[0.02] blur-[150px] -translate-y-1/2 translate-x-1/2 rounded-full" />
                    
                    <div className="max-w-6xl mx-auto px-6 relative">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
                            
                            {/* LEFT SIDE: Value Prop & Trust */}
                            <div className="lg:col-span-6 space-y-10">
                                <div className="space-y-6">
                                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest">
                                        <Target className="w-3.5 h-3.5" /> High-Velocity Sales Solutions
                                    </div>
                                    <h1 className="text-4xl md:text-7xl font-black text-foreground tracking-tighter leading-[1.05]">
                                        Scale Your <br />
                                        <span className="text-primary italic">Revenue Engine.</span>
                                    </h1>
                                    <p className="text-xl text-muted-foreground font-medium leading-relaxed max-w-lg">
                                        Talk to a solution architect about your data migration, custom workflows, or getting your first 1,000 leads into a high-velocity pipeline.
                                    </p>
                                </div>

                                {/* Dynamic Trust Row */}
                                <div className="grid grid-cols-3 gap-4">
                                    {trustStats.map(({ icon: Icon, value, label }) => (
                                        <div key={label} className="p-4 rounded-2xl bg-background border border-border shadow-sm group hover:border-primary/30 transition-all">
                                            <div className="w-10 h-10 rounded-xl bg-muted/50 flex items-center justify-center mb-3 group-hover:bg-primary/5">
                                                <Icon className="w-4 h-4 text-primary" />
                                            </div>
                                            <p className="text-xl font-black text-foreground">{value}</p>
                                            <p className="text-[10px] font-black text-muted-foreground/60 uppercase tracking-widest">{label}</p>
                                        </div>
                                    ))}
                                </div>

                                {/* Client Feedback snippet */}
                                <div className="p-6 rounded-3xl bg-muted/20 border border-border/60 relative">
                                    <div className="flex gap-1 mb-4">
                                        {[1,2,3,4,5].map(i => <Star key={i} className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />)}
                                    </div>
                                    <p className="text-sm italic font-medium text-foreground leading-relaxed mb-4">
                                        "The migration support was literally life-saving. We moved 50k leads from Salesforce in 48 hours without losing a single activity log."
                                    </p>
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-blue-500" />
                                        <div>
                                            <p className="text-xs font-black text-foreground">Marcus Sterling</p>
                                            <p className="text-[10px] font-bold text-muted-foreground uppercase opacity-60">VP Sales, CloudScale Inc.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* RIGHT SIDE: The Ultimate Lead Capture Form */}
                            <div className="lg:col-span-6 relative">
                                <div className="absolute -inset-4 bg-primary/10 blur-3xl opacity-30 rounded-full" />
                                <div className="relative">
                                    <ContactForm hideInfo={true} />
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                {/* 🛠️ QUICK HELP & RESOURCES */}
                <section className="py-20 bg-muted/5">
                    <div className="max-w-6xl mx-auto px-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            {[
                                {
                                    icon: ShieldCheck, title: "Enterprise Grade",
                                    desc: "Ask about our SOC2-Ready infrastructure and dedicated workspace environments.",
                                    cta: "View Security", href: "/docs"
                                },
                                {
                                    icon: Mail, title: "Direct Sales Access",
                                    desc: "Prefer a direct line? Our team is available for deep technical queries.",
                                    cta: "digicarehouse.sales@gmail.com", href: "mailto:digicarehouse.sales@gmail.com"
                                },
                                {
                                    icon: Zap, title: "Speed to Launch",
                                    desc: "Read how we onboard teams in under 48 hours in our latest case study.",
                                    cta: "Read Blog", href: "/blog"
                                }
                            ].map(({ icon: Icon, title, desc, cta, href }) => (
                                <Link href={href} key={title} className="group p-8 rounded-[2rem] bg-background border border-border hover:border-primary/20 hover:shadow-2xl hover:shadow-primary/5 transition-all flex flex-col items-center text-center">
                                    <div className="w-14 h-14 rounded-2xl bg-muted/50 flex items-center justify-center mb-6 py-2">
                                        <Icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
                                    </div>
                                    <h3 className="text-xl font-black text-foreground mb-3">{title}</h3>
                                    <p className="text-sm text-muted-foreground font-medium flex-1 mb-6 leading-relaxed">{desc}</p>
                                    <span className="text-[11px] font-black uppercase text-primary tracking-[0.15em] flex items-center gap-2 group-hover:gap-3 transition-all">
                                        {cta} <ArrowRight className="w-3.5 h-3.5" />
                                    </span>
                                </Link>
                            ))}
                        </div>
                    </div>
                </section>

                {/* FAQ SECTION */}
                <section className="py-24 border-t border-border">
                    <div className="max-w-3xl mx-auto px-6">
                        <div className="text-center mb-16 space-y-4">
                            <h2 className="text-3xl md:text-5xl font-black text-foreground tracking-tighter">Everything else.</h2>
                            <p className="text-lg text-muted-foreground font-medium leading-relaxed">
                                Quick answers for high-speed teams. Still stuck? Reach out anytime.
                            </p>
                        </div>

                        <div className="space-y-4">
                            {faqs.map((faq, i) => (
                                <div key={i} className="group rounded-[1.5rem] border border-border bg-background hover:bg-muted/[0.02] transition-all">
                                    <button
                                        onClick={() => setOpenFaq(openFaq === i ? null : i)}
                                        className="w-full flex items-center justify-between p-7 text-left"
                                        aria-expanded={openFaq === i}
                                    >
                                        <span className="text-lg font-black text-foreground group-hover:text-primary transition-colors">{faq.q}</span>
                                        <div className={`w-8 h-8 rounded-full border border-border flex items-center justify-center transition-all ${openFaq === i ? 'bg-primary border-primary rotate-180' : ''}`}>
                                            <ChevronDown className={`w-4 h-4 transition-colors ${openFaq === i ? 'text-white' : 'text-muted-foreground'}`} />
                                        </div>
                                    </button>
                                    {openFaq === i && (
                                        <div className="px-7 pb-8 text-muted-foreground font-medium leading-relaxed text-sm animate-in fade-in slide-in-from-top-2 duration-300">
                                            {faq.a}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </main>

            <LandingFooter />

            <ServiceModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                selectedPlan={selectedPlan}
            />
        </>
    );
}
