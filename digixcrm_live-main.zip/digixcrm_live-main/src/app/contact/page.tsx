import { Metadata } from "next";
import { ContactPageClient } from "./contact-page-client";

export const metadata: Metadata = {
    title: "Contact Sales | Talk to a DigixCRM Expert",
    description: "Schedule a personalized demo with DigixCRM's solution architects. We help startups and enterprise teams build scalable, action-oriented sales pipelines.",
    keywords: [
        "Contact DigixCRM", "CRM Demo Request", "Sales Consultation",
        "Enterprise CRM Support", "Digital CRM Expert", "Schedule CRM Demo",
        "CRM Migration Help", "Sales Infrastructure Consultation"
    ],
    alternates: {
        canonical: "https://digixcrm.com/contact",
    },
    openGraph: {
        type: "website",
        locale: "en_US",
        url: "https://digixcrm.com/contact",
        title: "Talk to a DigixCRM Expert | Request a Demo",
        description: "Our solution architects are ready to walk you through a personalized demo, custom pricing, and a migration plan tailored to your business.",
        siteName: "DigixCRM",
        images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "DigixCRM Contact Sales" }],
    },
    twitter: {
        card: "summary_large_image",
        title: "Contact DigixCRM Sales | Get a Personalized Demo",
        description: "Schedule time with our enterprise CRM experts. Custom demos, migration support, and tailored pricing for every team size.",
        images: ["/og-image.png"],
    },
};

const contactJsonLd = {
    "@context": "https://schema.org",
    "@graph": [
        {
            "@type": "ContactPage",
            "name": "Contact DigixCRM Sales",
            "url": "https://digixcrm.com/contact",
            "description": "Contact the DigixCRM sales and solution architecture team for demos, pricing, and migration support.",
            "breadcrumb": {
                "@type": "BreadcrumbList",
                "itemListElement": [
                    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://digixcrm.com" },
                    { "@type": "ListItem", "position": 2, "name": "Contact", "item": "https://digixcrm.com/contact" }
                ]
            }
        },
        {
            "@type": "Organization",
            "name": "DigixCRM",
            "url": "https://digixcrm.com",
            "logo": "https://digixcrm.com/logo-emblem-dark.png",
            "contactPoint": [
                {
                    "@type": "ContactPoint",
                    "contactType": "sales",
                    "email": "digicarehouse.sales@gmail.com",
                    "availableLanguage": ["English"],
                    "areaServed": "Worldwide",
                    "contactOption": "TollFree"
                },
                {
                    "@type": "ContactPoint",
                    "contactType": "customer support",
                    "url": "https://digixcrm.com/docs",
                    "availableLanguage": ["English"],
                    "areaServed": "Worldwide"
                }
            ]
        },
        {
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": "How do I request a DigixCRM demo?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Fill in the contact form on this page with your name, business email, and a brief description of your team's needs. Our solution architects will respond within 24 hours to schedule a personalized demo."
                    }
                },
                {
                    "@type": "Question",
                    "name": "How long does CRM onboarding take with DigixCRM?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Most teams are fully operational within 48 hours. We provide a guided onboarding wizard, data import tools, and dedicated support during migration from legacy systems."
                    }
                },
                {
                    "@type": "Question",
                    "name": "Does DigixCRM support enterprise contracts and custom pricing?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Yes. DigixCRM offers fully custom Enterprise agreements including negotiated SLAs, dedicated infrastructure, and volume-based pricing. Contact our sales team to discuss your requirements."
                    }
                },
                {
                    "@type": "Question",
                    "name": "Can I migrate from Salesforce or HubSpot to DigixCRM?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Absolutely. Our team provides a comprehensive migration service that transfers your contacts, deals, and historical data with zero downtime. We support imports from Salesforce, HubSpot, Zoho, and CSV-based systems."
                    }
                }
            ]
        }
    ]
};

export default function ContactPage() {
    return (
        <>
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{ __html: JSON.stringify(contactJsonLd) }}
            />
            <div className="min-h-screen bg-background text-foreground font-sans overflow-x-hidden">
                <ContactPageClient />
            </div>
        </>
    );
}
