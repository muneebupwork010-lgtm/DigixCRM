import { notFound } from "next/navigation";
import { getAllPosts, getPostBySlug, markdownToHtml } from "@/lib/blog";
import { BlogPostClient } from "../blog-post-client";
import type { Metadata } from "next";

export const revalidate = 60; // Revalidate every minute

interface Props {
    params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
    const posts = getAllPosts();
    return posts.map(p => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
    const { slug } = await params;
    const post = getPostBySlug(slug);
    if (!post) return {};

    return {
        title: post.title,
        description: post.excerpt,
        keywords: post.tags,
        alternates: { canonical: `https://digixcrm.com/blog/${post.slug}` },
        openGraph: {
            type: "article",
            url: `https://digixcrm.com/blog/${post.slug}`,
            title: post.title,
            description: post.excerpt,
            publishedTime: post.date,
            authors: [post.author],
            tags: post.tags,
            images: post.coverImage
                ? [{ url: post.coverImage, width: 1200, height: 630, alt: post.title }]
                : [{ url: "/og-image.png", width: 1200, height: 630 }],
        },
        twitter: {
            card: "summary_large_image",
            title: post.title,
            description: post.excerpt,
        },
    };
}

export default async function BlogPostPage({ params }: Props) {
    const { slug } = await params;
    const post = getPostBySlug(slug);
    if (!post) notFound();

    const contentHtml = markdownToHtml(post.content);
    const allPosts = getAllPosts();
    const related = allPosts
        .filter(p => p.slug !== post.slug && (p.category === post.category || p.tags.some(t => post.tags.includes(t))))
        .slice(0, 3);

    // JSON-LD for the article
    const articleJsonLd = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": post.title,
        "description": post.excerpt,
        "datePublished": post.date,
        "dateModified": post.date,
        "author": { "@type": "Organization", "name": post.author },
        "publisher": {
            "@type": "Organization",
            "name": "DigixCRM",
            "logo": { "@type": "ImageObject", "url": "https://digixcrm.com/logo-emblem-dark.png" }
        },
        "mainEntityOfPage": { "@type": "WebPage", "@id": `https://digixcrm.com/blog/${post.slug}` },
        "keywords": post.tags.join(", "),
        "articleSection": post.category,
    };

    return (
        <>
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{ __html: JSON.stringify(articleJsonLd) }}
            />
            <BlogPostClient post={post} contentHtml={contentHtml} related={related} />
        </>
    );
}
