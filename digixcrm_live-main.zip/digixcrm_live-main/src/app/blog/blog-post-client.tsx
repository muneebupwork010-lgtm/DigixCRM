"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { ServiceModal } from "@/components/landing/service-modal";
import { BlogPost } from "@/lib/blog";
import {
    Clock, BookOpen, Tag, ArrowLeft, ArrowRight,
    ChevronRight, Share2, Twitter, Linkedin, Link2, 
    CheckCircle2, List, HelpCircle, User, MessageSquare, Star,
    ShieldCheck, Sparkles, Zap
} from "lucide-react";

const categoryColors: Record<string, string> = {
    "Sales Strategy": "bg-blue-500/10 text-blue-600 border-blue-500/20",
    "Migration": "bg-orange-500/10 text-orange-600 border-orange-500/20",
    "Automation": "bg-green-500/10 text-green-600 border-green-500/20",
    "General": "bg-purple-500/10 text-purple-600 border-purple-500/20",
};

function getCategoryStyle(category: string) {
    return categoryColors[category] || "bg-primary/10 text-primary border-primary/20";
}

function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

interface BlogPostClientProps {
    post: BlogPost;
    contentHtml: string;
    related: BlogPost[];
}

export function BlogPostClient({ post, contentHtml, related }: BlogPostClientProps) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("FREE");
    const [copied, setCopied] = useState(false);
    const [toc, setToc] = useState<{ id: string; title: string; level: number }[]>([]);

    useEffect(() => {
        // Extract headers for ToC from markdown content
        const headerMatches = post.content.match(/^##+ (.*$)/gim);
        if (headerMatches) {
            const items = headerMatches.map(match => {
                const level = (match.match(/^#+/)?.[0].length || 2);
                const title = match.replace(/^#+ /, "");
                const id = title.toLowerCase().replace(/[^\w]+/g, "-");
                return { id, title, level };
            });
            setToc(items);
        }
    }, [post.content]);

    const openModal = (plan: string) => { setSelectedPlan(plan); setIsModalOpen(true); };

    const handleCopyLink = () => {
        navigator.clipboard.writeText(window.location.href);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const shareOnTwitter = () => {
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(window.location.href)}`, "_blank");
    };
    
    const shareOnLinkedIn = () => {
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`, "_blank");
    };

    return (
        <>
            <LandingNav onOpenModal={openModal} />

            <main className="pt-24 min-h-screen bg-background">
                {/* Article Header */}
                <header className="border-b border-border bg-muted/5 pb-12">
                    <div className="max-w-6xl mx-auto px-6 pt-12 md:pt-16 text-center">
                        <div className="max-w-4xl mx-auto">
                            {/* Category Badge */}
                            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border mb-6 bg-background">
                                <span className={`w-2 h-2 rounded-full ${getCategoryStyle(post.category).split(' ')[0].replace('bg-', 'bg-')}`} />
                                <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{post.category}</span>
                            </div>

                            <h1 className="text-3xl md:text-6xl font-black text-foreground tracking-tight mb-8 leading-[1.05]">
                                {post.title}
                            </h1>

                            <div className="flex flex-wrap items-center justify-center gap-6 text-[11px] font-bold text-muted-foreground uppercase tracking-wider">
                                <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" />{post.author}</span>
                                <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{post.readTime}</span>
                                <span>{formatDate(post.date)}</span>
                            </div>
                        </div>

                        {/* Hero Image */}
                        {post.coverImage && (
                            <div className="mt-16 max-w-5xl mx-auto rounded-[2.5rem] overflow-hidden border border-border/50 shadow-2xl relative">
                                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
                                <img 
                                    src={post.coverImage} 
                                    alt={post.title} 
                                    className="w-full h-auto aspect-[21/9] object-cover" 
                                />
                            </div>
                        )}
                    </div>
                </header>

                {/* Article Content with Sticky Interaction Bar */}
                <div className="max-w-7xl mx-auto px-6 py-20 relative">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
                        
                        {/* LEFT COLUMN: Sticky Utility Bar */}
                        <aside className="hidden lg:block lg:col-span-3 sticky top-28 space-y-12">
                            {/* Share Bar */}
                            <div className="space-y-4">
                                <h4 className="text-[10px] font-black uppercase text-muted-foreground/60 tracking-widest pl-3 mb-2">Share Article</h4>
                                <div className="flex flex-col gap-2">
                                    <button onClick={shareOnTwitter} className="group flex items-center gap-3 w-full p-3 rounded-2xl bg-muted/30 border border-border hover:bg-muted/50 hover:border-primary/20 transition-all">
                                        <div className="w-8 h-8 rounded-xl bg-background flex items-center justify-center border border-border group-hover:bg-primary/5 group-hover:border-primary/20"><Twitter className="w-3.5 h-3.5" /></div>
                                        <span className="text-xs font-bold">X (Twitter)</span>
                                    </button>
                                    <button onClick={shareOnLinkedIn} className="group flex items-center gap-3 w-full p-3 rounded-2xl bg-muted/30 border border-border hover:bg-muted/50 hover:border-primary/20 transition-all">
                                        <div className="w-8 h-8 rounded-xl bg-background flex items-center justify-center border border-border group-hover:bg-primary/5 group-hover:border-primary/20"><Linkedin className="w-3.5 h-3.5" /></div>
                                        <span className="text-xs font-bold">LinkedIn</span>
                                    </button>
                                    <button onClick={handleCopyLink} className="group flex items-center gap-3 w-full p-3 rounded-2xl bg-muted/30 border border-border hover:bg-muted/50 hover:border-primary/20 transition-all">
                                        <div className="w-8 h-8 rounded-xl bg-background flex items-center justify-center border border-border group-hover:bg-primary/5 group-hover:border-primary/20">
                                            {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> : <Link2 className="w-3.5 h-3.5" />}
                                        </div>
                                        <span className="text-xs font-bold">{copied ? "Link Copied!" : "Copy Link"}</span>
                                    </button>
                                </div>
                            </div>

                            {/* Table of Contents */}
                            <div className="p-8 rounded-3xl bg-muted/20 border border-border shadow-sm">
                                <h4 className="text-[10px] font-black uppercase text-primary tracking-widest mb-6 flex items-center gap-2">
                                    <List className="w-3.5 h-3.5" /> On this page
                                </h4>
                                <nav className="space-y-1.5">
                                    {toc.map((item, idx) => (
                                        <a 
                                            key={idx} 
                                            href={`#${item.id}`}
                                            className={`block text-[11px] font-extrabold py-2 px-3 rounded-xl hover:bg-primary/5 hover:text-primary transition-all border border-transparent hover:border-primary/10 ${item.level > 2 ? 'ml-4 opacity-70' : ''}`}
                                        >
                                            {item.title}
                                        </a>
                                    ))}
                                </nav>
                                
                                <div className="mt-10 pt-8 border-t border-border">
                                    <div className="bg-primary/5 rounded-2xl p-5 border border-primary/10">
                                        <p className="text-[10px] font-black text-primary uppercase tracking-wider mb-2">Join 500+ teams</p>
                                        <p className="text-[11px] text-muted-foreground font-medium leading-relaxed mb-4">Get the latest sales automation tips delivered weekly.</p>
                                        <input type="email" placeholder="email@company.com" className="w-full px-3 py-2 rounded-lg bg-background border border-border text-xs mb-2 focus:outline-none focus:ring-1 focus:ring-primary/20" />
                                        <button className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-[10px] font-black uppercase tracking-widest">
                                            Subscribe
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </aside>

                        {/* MAIN CONTENT AREA */}
                        <div className="lg:col-span-9 max-w-3xl mx-auto lg:mx-0">
                            {/* Content Body */}
                            <article 
                                className="magazine-content prose prose-neutral dark:prose-invert max-w-none text-lg leading-[1.75]"
                                dangerouslySetInnerHTML={{ __html: contentHtml }}
                            />

                            {/* Tags */}
                            {post.tags.length > 0 && (
                                <div className="flex flex-wrap gap-2 mt-20 pt-10 border-t border-border">
                                    {post.tags.map(tag => (
                                        <span key={tag} className="px-4 py-1.5 rounded-xl bg-muted border border-border text-[10px] font-black text-muted-foreground transition-all hover:border-primary/30 uppercase tracking-widest">
                                            #{tag}
                                        </span>
                                    ))}
                                </div>
                            )}

                            {/* Author Bio Section */}
                            <section className="mt-20 p-10 rounded-[2.5rem] bg-muted/10 border border-border shadow-lg flex flex-col sm:flex-row items-center sm:items-start gap-10">
                                <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shrink-0 rotate-3 p-1 shadow-xl">
                                    <div className="w-full h-full rounded-[1.4rem] bg-background flex items-center justify-center">
                                        <span className="text-3xl font-black text-primary">{post.author.charAt(0)}</span>
                                    </div>
                                </div>
                                <div className="text-center sm:text-left flex-1">
                                    <h4 className="text-[11px] font-black uppercase text-primary tracking-widest mb-1.5">Article Author</h4>
                                    <p className="text-3xl font-black text-foreground mb-4">{post.author}</p>
                                    <p className="text-sm text-muted-foreground leading-relaxed mb-6 font-medium">
                                        Solution Architect at DigixCRM with 10+ years of experience in sales operation optimization and revenue technology. Sameed specializes in building high-velocity CRM workflows for enterprise teams.
                                    </p>
                                    <div className="flex items-center justify-center sm:justify-start gap-4">
                                        <Link href="/contact" className="text-xs font-black text-foreground flex items-center gap-2 group p-2 pr-4 bg-background rounded-full border border-border hover:border-primary/30 transition-all">
                                            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center"><MessageSquare className="w-3 h-3 text-primary" /></div>
                                            Book a call with {post.author.split(' ')[0]}
                                        </Link>
                                    </div>
                                </div>
                            </section>

                            {/* In-Post FAQ Section */}
                            {post.faq && post.faq.length > 0 && (
                                <section className="mt-20 bg-primary/[0.02] border border-primary/10 rounded-[2.5rem] p-10">
                                    <div className="flex items-center gap-3 mb-10">
                                        <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center"><HelpCircle className="w-5 h-5 text-primary" /></div>
                                        <h3 className="text-2xl font-black text-foreground">Common Questions</h3>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        {post.faq.map((item, idx) => (
                                            <div key={idx} className="p-6 rounded-2xl bg-background border border-border/60 hover:border-primary/20 transition-all">
                                                <p className="font-black text-foreground text-sm mb-3 flex gap-2 leading-tight">
                                                    <span className="text-primary tracking-tighter shrink-0 select-none">Q:</span> {item.q}
                                                </p>
                                                <p className="text-[13px] text-muted-foreground leading-relaxed pl-5 border-l-2 border-primary/10">
                                                    {item.a}
                                                </p>
                                            </div>
                                        ))}
                                    </div>
                                </section>
                            )}
                        </div>
                    </div>
                </div>

                {/* BOTTOM CONVERSION BANNER (OnePage Style) */}
                <section className="mx-6 mb-20">
                    <div className="max-w-6xl mx-auto rounded-[3rem] bg-primary overflow-hidden relative group">
                        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary to-blue-600 opacity-90 transition-opacity" />
                        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-white/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none" />
                        
                        <div className="relative px-8 py-20 text-center">
                            <h2 className="text-3xl md:text-5xl font-black text-white tracking-tighter mb-6 leading-[1.1]">
                                Stop managing data. <br className="hidden md:block"/> Start closing deals.
                            </h2>
                            <p className="text-lg text-white/80 font-medium mb-10 max-w-xl mx-auto">
                                Join the high-velocity teams using DigixCRM to automate their entire follow-up process.
                            </p>
                            <div className="flex flex-wrap items-center justify-center gap-4">
                                <button onClick={() => openModal("FREE")} className="px-8 py-4 rounded-2xl bg-white text-primary font-black text-sm uppercase tracking-widest shadow-xl shadow-black/10 hover:scale-[1.05] transition-all active:scale-95">
                                    Get Started Free 
                                </button>
                                <Link href="/contact" className="px-8 py-4 rounded-2xl bg-primary-foreground/10 text-white border border-white/20 font-black text-sm uppercase tracking-widest hover:bg-white/5 transition-all">
                                    Schedule Demo
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Related Posts */}
                {related.length > 0 && (
                    <section className="border-t border-border py-24 bg-muted/5">
                        <div className="max-w-6xl mx-auto px-6">
                            <div className="flex items-center justify-between mb-12">
                                <hgroup>
                                    <h4 className="text-[10px] font-black uppercase text-primary tracking-widest mb-1">More Insights</h4>
                                    <h2 className="text-3xl font-black text-foreground tracking-tight">Keep Reading</h2>
                                </hgroup>
                                <Link href="/blog" className="text-xs font-black uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors">Browse all insights →</Link>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                {related.map(rp => (
                                    <Link key={rp.slug} href={`/blog/${rp.slug}`} className="group block">
                                        <article className="h-full bg-background rounded-3xl border border-border p-5 flex flex-col hover:border-primary/40 hover:shadow-2xl hover:shadow-primary/5 transition-all transform hover:-translate-y-1">
                                            {rp.coverImage && (
                                                <div className="rounded-2xl overflow-hidden aspect-video border border-border mb-6">
                                                    <img src={rp.coverImage} alt={rp.title} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500" />
                                                </div>
                                            )}
                                            <div className="px-1 flex-1 flex flex-col">
                                                <span className={`inline-block px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest border mb-4 self-start ${getCategoryStyle(rp.category)}`}>
                                                    {rp.category}
                                                </span>
                                                <h3 className="font-black text-foreground text-lg group-hover:text-primary transition-colors mb-4 leading-[1.2]">
                                                    {rp.title}
                                                </h3>
                                                <p className="text-xs text-muted-foreground line-clamp-2 mb-6 leading-relaxed font-medium">{rp.excerpt}</p>
                                                <div className="mt-auto flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-muted-foreground pt-5 border-t border-border">
                                                    <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{rp.readTime}</span>
                                                    <span className="text-primary group-hover:underline flex items-center gap-1">Read <ArrowRight className="w-3 h-3" /></span>
                                                </div>
                                            </div>
                                        </article>
                                    </Link>
                                ))}
                            </div>
                        </div>
                    </section>
                )}
            </main>

            <LandingFooter />

            <ServiceModal 
                isOpen={isModalOpen} 
                onClose={() => setIsModalOpen(false)} 
                selectedPlan={selectedPlan} 
            />
        </>
    );
}
