import { Metadata } from "next";
import { getAllPosts, getAllCategories } from "@/lib/blog";
import { BlogListingClient } from "./blog-listing-client";

export const revalidate = 60; // Revalidate every minute

export const metadata: Metadata = {
    title: "Blog | Sales Strategy, CRM Tips & Growth Insights",
    description: "Read the DigixCRM blog for actionable sales strategy, CRM tutorials, automation guides, and growth insights for high-velocity sales teams.",
    keywords: [
        "CRM Blog", "Sales Strategy", "CRM Tips", "Sales Automation Guide",
        "Pipeline Management", "B2B Sales", "Sales Ops", "Revenue Operations"
    ],
    alternates: { canonical: "https://digixcrm.com/blog" },
    openGraph: {
        type: "website",
        url: "https://digixcrm.com/blog",
        title: "DigixCRM Blog | Sales Strategy & CRM Insights",
        description: "Actionable content for modern sales teams. From CRM migrations to AI-powered automation — stay ahead of the curve.",
        siteName: "DigixCRM",
        images: [{ url: "/og-image.png", width: 1200, height: 630 }],
    },
};

export default function BlogPage() {
    const posts = getAllPosts();
    const categories = getAllCategories();
    return <BlogListingClient posts={posts} categories={categories} />;
}
