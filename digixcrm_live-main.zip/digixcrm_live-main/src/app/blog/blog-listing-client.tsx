"use client";

import { useState } from "react";
import Link from "next/link";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { ServiceModal } from "@/components/landing/service-modal";
import { BlogPost } from "@/lib/blog";
import {
    BookOpen, Clock, Tag, ChevronRight, Search,
    Rss, ArrowRight, TrendingUp, Star, Zap, Sparkles
} from "lucide-react";

const categoryColors: Record<string, string> = {
    "Sales Strategy": "bg-blue-500/10 text-blue-600 border-blue-500/20",
    "Migration": "bg-orange-500/10 text-orange-600 border-orange-500/20",
    "Automation": "bg-green-500/10 text-green-600 border-green-500/20",
    "General": "bg-purple-500/10 text-purple-600 border-purple-500/20",
};

function getCategoryStyle(category: string) {
    return categoryColors[category] || "bg-primary/10 text-primary border-primary/20";
}

function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString("en-US", {
        year: "numeric", month: "long", day: "numeric"
    });
}

interface BlogListingClientProps {
    posts: BlogPost[];
    categories: string[];
}

export function BlogListingClient({ posts, categories }: BlogListingClientProps) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("FREE");
    const [activeCategory, setActiveCategory] = useState("All");
    const [searchQuery, setSearchQuery] = useState("");

    const openModal = (plan: string) => { setSelectedPlan(plan); setIsModalOpen(true); };

    const filteredPosts = posts.filter(p => {
        const matchCat = activeCategory === "All" || p.category === activeCategory;
        const matchSearch = !searchQuery ||
            p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchCat && matchSearch;
    });

    const featuredPost = posts.find(p => p.featured) || posts[0];
    const restPosts = filteredPosts.filter(p => p.slug !== featuredPost?.slug);

    return (
        <>
            <LandingNav onOpenModal={openModal} />

            <main className="pt-16 min-h-screen bg-background">
                {/* REFINED MAGAZINE HEADER */}
                <section className="border-b border-border bg-muted/5 py-12 overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/5 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" />
                    <div className="max-w-6xl mx-auto px-6 relative">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                            <div>
                                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-background border border-border text-primary text-[10px] font-black uppercase tracking-[0.15em] mb-6 shadow-sm">
                                    <Sparkles className="w-3.5 h-3.5" /> Direct from the Sales Floor
                                </div>
                                <h1 className="text-4xl md:text-6xl font-black text-foreground tracking-tighter mb-5 leading-[1.1]">
                                    Sales Intelligence <br/> <span className="text-primary italic">built for</span> Leaders
                                </h1>
                                <p className="text-lg text-muted-foreground max-w-xl mb-8 font-medium leading-relaxed">
                                    Real-world field notes on scaling revenue, migrating high-value data, and building automation that actually works. No fluff. Just results.
                                </p>

                                {/* Search Bar V3 - Tightened */}
                                <div className="relative max-w-lg group">
                                    <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                                    <input
                                        type="text"
                                        placeholder="Find answers to your CRM questions..."
                                        value={searchQuery}
                                        onChange={e => setSearchQuery(e.target.value)}
                                        className="w-full pl-12 pr-6 py-4 rounded-2xl bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-4 focus:ring-primary/5 focus:border-primary transition-all shadow-xl shadow-black/[0.02]"
                                    />
                                </div>
                            </div>

                            {/* 3D GRAPHIC ELEMENT */}
                            <div className="hidden lg:block relative perspective-1000">
                                <div className="relative rounded-3xl overflow-hidden border border-border shadow-2xl animate-float">
                                    <img 
                                        src="/images/blog-hero.png" 
                                        alt="Sales Pipeline Visualization" 
                                        className="w-full h-auto object-cover"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                                </div>
                                {/* Floating Badge */}
                                <div className="absolute -bottom-6 -left-6 bg-background p-4 rounded-2xl border border-border shadow-2xl animate-bounce-slow">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                                            <Zap className="w-5 h-5 text-green-500" />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Team Efficiency</p>
                                            <p className="text-lg font-black text-foreground">+84%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <div className="max-w-6xl mx-auto px-6 py-12">
                    {/* Category Tabs - Spacing Tightened */}
                    <div className="flex flex-wrap gap-2 mb-12">
                        {["All", ...categories].map(cat => (
                            <button
                                key={cat}
                                onClick={() => setActiveCategory(cat)}
                                className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                                    activeCategory === cat
                                        ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20"
                                        : "bg-background text-muted-foreground border-border hover:border-primary/30 hover:text-foreground"
                                }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>

                    {/* FEATURED HERO POST - Fixed Image Logic */}
                    {featuredPost && activeCategory === "All" && !searchQuery && (
                        <Link href={`/blog/${featuredPost.slug}`} className="group block mb-16">
                            <article className="relative overflow-hidden rounded-[2.5rem] border border-border bg-background hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500">
                                <div className="grid grid-cols-1 lg:grid-cols-2 items-stretch">
                                    <div className="h-full min-h-[300px] overflow-hidden border-b lg:border-b-0 lg:border-r border-border bg-muted/20">
                                        {featuredPost.coverImage ? (
                                            <img 
                                                src={featuredPost.coverImage} 
                                                alt={featuredPost.title} 
                                                className="w-full h-full object-cover group-hover:scale-105 transition-all duration-700"
                                                onError={(e) => {
                                                    // Fallback for broken images
                                                    (e.target as HTMLImageElement).src = "/images/blog-hero.png";
                                                }}
                                            />
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center bg-primary/5">
                                                <Sparkles className="w-12 h-12 text-primary/20" />
                                            </div>
                                        )}
                                    </div>
                                    <div className="p-8 md:p-12 flex flex-col justify-center bg-background">
                                        <div className="flex flex-wrap items-center gap-3 mb-6">
                                            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-600 text-[10px] font-black uppercase tracking-widest">
                                                <Star className="w-3.5 h-3.5 fill-amber-500" /> Must Read
                                            </span>
                                            <span className={`px-3 py-1 rounded-full text-[10px] font-black border uppercase tracking-widest ${getCategoryStyle(featuredPost.category)}`}>
                                                {featuredPost.category}
                                            </span>
                                        </div>
                                        <h2 className="text-3xl md:text-4xl font-black text-foreground group-hover:text-primary transition-colors mb-5 leading-[1.1] tracking-tighter">
                                            {featuredPost.title}
                                        </h2>
                                        <p className="text-lg text-muted-foreground leading-relaxed mb-8 line-clamp-3 font-medium">
                                            {featuredPost.excerpt}
                                        </p>
                                        <div className="flex flex-wrap items-center gap-6 text-[11px] font-black text-muted-foreground uppercase tracking-widest mt-auto pt-6 border-t border-border/50">
                                            <span className="flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-primary" />{featuredPost.readTime}</span>
                                            <span className="inline-flex items-center gap-2 text-primary group-hover:gap-4 transition-all">
                                                Open Article <ArrowRight className="w-4 h-4" />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </Link>
                    )}

                    {/* MAIN POST GRID */}
                    {filteredPosts.length === 0 ? (
                        <div className="text-center py-24 rounded-[3rem] border-2 border-dashed border-border opacity-60">
                            <BookOpen className="w-10 h-10 text-muted-foreground mx-auto mb-4" />
                            <p className="text-lg text-muted-foreground font-bold">No articles match your search.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
                            {(searchQuery || activeCategory !== "All" ? filteredPosts : restPosts).map(post => (
                                <Link key={post.slug} href={`/blog/${post.slug}`} className="group block h-full">
                                    <article className="h-full flex flex-col rounded-[2rem] border border-border bg-background hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-300 overflow-hidden">
                                        <div className="aspect-[16/9] overflow-hidden border-b border-border bg-muted/20">
                                            {post.coverImage ? (
                                                <img 
                                                    src={post.coverImage} 
                                                    alt={post.title} 
                                                    className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
                                                    onError={(e) => {
                                                        (e.target as HTMLImageElement).src = "/images/blog-hero.png";
                                                    }}
                                                />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center">
                                                    <Rss className="w-8 h-8 text-primary/10" />
                                                </div>
                                            )}
                                        </div>
                                        <div className="p-7 flex flex-col flex-1">
                                            <div className="flex items-center gap-2 mb-4">
                                                <span className={`px-2.5 py-1 rounded-full text-[9px] font-black border uppercase tracking-widest ${getCategoryStyle(post.category)}`}>
                                                    {post.category}
                                                </span>
                                            </div>
                                            <h3 className="text-xl font-black text-foreground group-hover:text-primary transition-colors mb-3 leading-[1.3] tracking-tight">
                                                {post.title}
                                            </h3>
                                            <p className="text-sm text-muted-foreground leading-relaxed mb-6 line-clamp-2 font-medium">
                                                {post.excerpt}
                                            </p>
                                            
                                            <div className="mt-auto flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-muted-foreground pt-4 border-t border-border/50">
                                                <span className="flex items-center gap-2"><Clock className="w-3.5 h-3.5" />{post.readTime}</span>
                                                <span className="flex items-center gap-1.5 text-primary group-hover:gap-2.5 transition-all">
                                                    Read <ChevronRight className="w-3.5 h-3.5" />
                                                </span>
                                            </div>
                                        </div>
                                    </article>
                                </Link>
                            ))}
                        </div>
                    )}

                    {/* REFINED NEWSLETTER */}
                    <div className="mt-20 rounded-[2.5rem] bg-foreground p-10 md:p-16 text-center relative overflow-hidden shadow-2xl">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-blue-500/10 opacity-40" />
                        <div className="relative z-10">
                            <h2 className="text-3xl md:text-5xl font-black text-white tracking-tighter mb-4">Ready to scale?</h2>
                            <p className="text-white/60 text-lg mb-8 max-w-xl mx-auto font-medium">
                                Get our field-tested tactics for high-growth teams delivered directly to your inbox.
                            </p>
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                <Link href="/contact" className="w-full sm:w-auto px-10 py-4 bg-primary text-primary-foreground font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-primary/90 transition-all shadow-xl shadow-primary/20">
                                    Join the Inner Circle
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <LandingFooter />
            <ServiceModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} selectedPlan={selectedPlan} />
        </>
    );
}
