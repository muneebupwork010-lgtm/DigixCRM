import { MetadataRoute } from 'next';
import { getAllPosts } from '@/lib/blog';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
    const baseUrl = 'https://digixcrm.com';

    // 1. Static Routes
    const routes = [
        { path: '', priority: 1.0 },
        { path: '/contact', priority: 0.95 },
        { path: '/pricing', priority: 0.9 },
        { path: '/features', priority: 0.9 },
        { path: '/blog', priority: 0.9 },
        { path: '/download', priority: 0.85 },
        { path: '/docs', priority: 0.8 },
        { path: '/features/workflow', priority: 0.8 },
        { path: '/terms', priority: 0.5 },
        { path: '/privacy', priority: 0.5 },
    ].map(({ path, priority }) => ({
        url: `${baseUrl}${path}`,
        lastModified: new Date().toISOString().split('T')[0],
        changeFrequency: 'weekly' as const,
        priority,
    }));

    // 2. Dynamic Blog Posts
    const posts = await getAllPosts();
    const blogRoutes = posts.map((post) => ({
        url: `${baseUrl}/blog/${post.slug}`,
        lastModified: post.date || new Date().toISOString().split('T')[0],
        changeFrequency: 'monthly' as const,
        priority: 0.7,
    }));

    return [...routes, ...blogRoutes];
}
