import { Metadata } from "next";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { Terminal, Code2, Cpu, Globe, ArrowRight, Copy, Check } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
    title: "API Documentation | DigixCRM Developer Hub",
    description: "Build, integrate, and extend DigixCRM. Explore our full REST API, Webhooks, and SDK reference for enterprise engineers.",
};

const technicalFeatures = [
    {
        icon: Globe,
        title: "RESTful Architecture",
        desc: "Native JSON endpoints for Leads, Deals, Contacts, and Activities. Predictive rate-limiting for enterprise scale."
    },
    {
        icon: Cpu,
        title: "Real-time Webhooks",
        desc: "Push data to your stack the millisecond a deal closes or a lead is routed. Support for 256-bit signed payloads."
    },
    {
        icon: Code2,
        title: "Developer SDKs",
        desc: "Pre-built libraries for Node.js, Python, and Go to get your integration running in minutes, not months."
    }
];

export default function DocsPage() {
    return (
        <>
            <LandingNav />
            <main className="pt-24 min-h-screen bg-background">
                {/* Hero Tech Section */}
                <section className="py-20 border-b border-border bg-[#0a0a0b] relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/20 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" />
                    <div className="max-w-6xl mx-auto px-6 relative">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                            <div>
                                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-[0.2em] mb-8">
                                    <Terminal className="w-3.5 h-3.5" /> DigixCRM Developer Hub
                                </div>
                                <h1 className="text-4xl md:text-7xl font-black text-white tracking-tighter mb-8 leading-[1.05]">
                                    Integrate. Build. <br /> <span className="text-primary italic underline decoration-primary/20">Scale fast.</span>
                                </h1>
                                <p className="text-xl text-white/50 font-bold leading-relaxed max-w-lg mb-10">
                                    Our API is built for engineers who value speed and reliability. We provide robust endpoints and simple JSON schemas so you can build with confidence.
                                </p>
                                <div className="flex flex-wrap gap-4">
                                    <Link href="/contact" className="px-8 py-4 bg-primary text-primary-foreground font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-primary/90 shadow-xl shadow-primary/20 transition-all">
                                        Request API Key
                                    </Link>
                                    <button className="px-8 py-4 bg-white/5 border border-white/10 text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-white/10 transition-all flex items-center gap-2">
                                        Explore Reference
                                    </button>
                                </div>
                            </div>
                            
                            {/* Code Sample Visual */}
                            <div className="relative group">
                                <div className="absolute -inset-4 bg-primary/20 blur-3xl opacity-30 rounded-full group-hover:opacity-50 transition-opacity" />
                                <div className="relative rounded-3xl bg-[#121214] border border-white/10 p-6 shadow-2xl overflow-hidden font-mono text-sm leading-relaxed">
                                    <div className="flex items-center gap-2 mb-6 border-b border-white/5 pb-4">
                                        <div className="w-3 h-3 rounded-full bg-red-500/50" />
                                        <div className="w-3 h-3 rounded-full bg-amber-500/50" />
                                        <div className="w-3 h-3 rounded-full bg-green-500/50" />
                                        <span className="text-white/20 ml-2 text-xs">POST /v1/deals</span>
                                    </div>
                                    <div className="space-y-1">
                                        <p className="text-blue-400">{"{"}</p>
                                        <p className="pl-4 text-purple-400">"title"<span className="text-white">:</span> <span className="text-green-400">"Enterprise SaaS Expansion"</span><span className="text-white">,</span></p>
                                        <p className="pl-4 text-purple-400">"value"<span className="text-white">:</span> <span className="text-amber-400">125000</span><span className="text-white">,</span></p>
                                        <p className="pl-4 text-purple-400">"currency"<span className="text-white">:</span> <span className="text-green-400">"USD"</span><span className="text-white">,</span></p>
                                        <p className="pl-4 text-purple-400">"priority"<span className="text-white">:</span> <span className="text-green-400">"HIGH"</span><span className="text-white">,</span></p>
                                        <p className="pl-4 text-purple-400">"metadata"<span className="text-white">:</span> <span className="text-blue-400">{"{"}</span></p>
                                        <p className="pl-8 text-purple-400">"source"<span className="text-white">:</span> <span className="text-green-400">"direct_api"</span></p>
                                        <p className="pl-4 text-blue-400">{"}"}</p>
                                        <p className="text-blue-400">{"}"}</p>
                                    </div>
                                    <div className="absolute bottom-4 right-4 group-hover:scale-110 transition-transform">
                                        <div className="px-3 py-1.5 rounded-lg bg-white/10 border border-white/20 flex items-center gap-2 text-[10px] text-white/60 font-black uppercase tracking-widest">
                                            <Copy className="w-3 h-3" /> Copy Snippet
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Tech Features Grid */}
                <section className="py-24 bg-background">
                    <div className="max-w-6xl mx-auto px-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                            {technicalFeatures.map((t) => (
                                <div key={t.title} className="group">
                                    <div className="w-14 h-14 rounded-2xl bg-primary/5 flex items-center justify-center mb-6 group-hover:bg-primary/10 transition-colors">
                                        <t.icon className="w-6 h-6 text-primary" />
                                    </div>
                                    <h3 className="text-xl font-black text-foreground mb-4">{t.title}</h3>
                                    <p className="text-muted-foreground leading-relaxed font-medium">
                                        {t.desc}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* FINAL CTA TILE */}
                <section className="py-24 border-t border-border">
                    <div className="max-w-4xl mx-auto px-6 text-center">
                        <h2 className="text-3xl md:text-5xl font-black text-foreground tracking-tighter mb-6">
                            Start building <span className="text-primary italic">your mission.</span>
                        </h2>
                        <p className="text-lg text-muted-foreground font-medium mb-12 max-w-xl mx-auto">
                            Whether you're automating a local clinic or integrating an enterprise ERP, our developer playground is ready for you.
                        </p>
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                            <Link href="/contact" className="flex items-center gap-3 text-foreground font-black uppercase text-xs tracking-[0.2em] group border-b-2 border-primary/20 hover:border-primary transition-all pb-1">
                                Talk to an implementation expert <ArrowRight className="w-4 h-4 text-primary group-hover:translate-x-1 transition-transform" />
                            </Link>
                        </div>
                    </div>
                </section>
            </main>
            <LandingFooter />
        </>
    );
}
