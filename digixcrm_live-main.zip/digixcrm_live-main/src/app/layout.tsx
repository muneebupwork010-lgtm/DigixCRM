import type { Metadata } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import { Providers } from "@/components/layout/providers";
import { PremiumChatbot } from "@/components/chat/premium-chatbot";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://digixcrm.com"),
  alternates: {
    canonical: "https://digixcrm.com",
  },
  title: {
    default: "DigixCRM | The Action-Oriented AI CRM for High-Velocity Teams",
    template: "%s | DigixCRM"
  },
  description: "Experience the most robust, action-oriented AI CRM for enterprise sales. Secure multi-tenant architecture with PBAC, built-in payments, and predictive lead insights for high-velocity teams.",
  keywords: [
    "Enterprise CRM", 
    "AI Sales Automation", 
    "Multi-tenant CRM", 
    "PBAC Security CRM", 
    "No-code Sales Workflows", 
    "High-velocity Lead Tracking", 
    "SaaS CRM Architecture",
    "Action-Oriented CRM"
  ],
  authors: [{ name: "DigiCare House" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://digixcrm.com",
    title: "DigixCRM | Future-Proof Your Sales Infrastructure",
    description: "Stop managing leads, start closing deals. Enterprise-grade AI CRM with workflow automation and multi-tenant security.",
    siteName: "DigixCRM",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "DigixCRM - Advanced AI CRM for Enterprise",
      }
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "DigixCRM | Enterprise Scalable AI CRM",
    description: "Multi-tenant, PBAC-secured, and action-oriented sales automation for power teams.",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: [
      { url: "/logo-emblem-dark.png", type: "image/png" },
    ],
    apple: [
      { url: "/logo-emblem-dark.png", type: "image/png" },
    ],
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "SoftwareApplication",
      "name": "DigixCRM",
      "operatingSystem": "Web-based",
      "applicationCategory": "BusinessApplication",
      "offers": { "@type": "Offer", "price": "49.00", "priceCurrency": "USD" },
      "aggregateRating": { "@type": "AggregateRating", "ratingValue": "4.8", "reviewCount": "512" }
    },
    {
      "@type": "Organization",
      "name": "DigixCRM",
      "url": "https://digixcrm.com",
      "logo": "https://digixcrm.com/logo-emblem-dark.png",
      "contactPoint": [
        {
          "@type": "ContactPoint",
          "contactType": "sales",
          "email": "digicarehouse.sales@gmail.com",
          "url": "https://digixcrm.com/contact",
          "availableLanguage": ["English"],
          "areaServed": "Worldwide"
        },
        {
          "@type": "ContactPoint",
          "contactType": "technical support",
          "url": "https://digixcrm.com/docs",
          "availableLanguage": ["English"],
          "areaServed": "Worldwide"
        }
      ],
      "sameAs": [
        "https://twitter.com/digixcrm",
        "https://linkedin.com/company/digixcrm"
      ]
    },
    {
      "@type": "WebSite",
      "name": "DigixCRM",
      "url": "https://digixcrm.com",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://digixcrm.com/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
  ]
};

const navigationJsonLd = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "Platform Navigation",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "item": { "@type": "SiteNavigationElement", "name": "Features", "url": "https://digixcrm.com/features" } },
    { "@type": "ListItem", "position": 2, "item": { "@type": "SiteNavigationElement", "name": "Pricing", "url": "https://digixcrm.com/pricing" } },
    { "@type": "ListItem", "position": 3, "item": { "@type": "SiteNavigationElement", "name": "Blog", "url": "https://digixcrm.com/blog" } },
    { "@type": "ListItem", "position": 4, "item": { "@type": "SiteNavigationElement", "name": "App", "url": "https://digixcrm.com/download" } },
    { "@type": "ListItem", "position": 5, "item": { "@type": "SiteNavigationElement", "name": "Contact", "url": "https://digixcrm.com/contact" } },
    { "@type": "ListItem", "position": 6, "item": { "@type": "SiteNavigationElement", "name": "Login", "url": "https://digixcrm.com/auth/signin" } }
  ]
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What makes DigixCRM different from traditional CRMs?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "DigixCRM is an 'Action-Oriented' platform that surfaces your next best action automatically, focusing teams on closing deals rather than organizing data."
      }
    },
    {
      "@type": "Question",
      "name": "Does DigixCRM support multi-tenant isolation?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Our architecture allows for completely isolated workspaces, providing data sovereignty and enterprise-grade security for teams of any size."
      }
    },
    {
      "@type": "Question",
      "name": "Can I automate my manual sales workflows?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Absolutely. DigixCRM features a robust no-code workflow engine that allows you to automate lead routing, task assignments, and follow-up notifications."
      }
    },
    {
      "@type": "Question",
      "name": "Is there an AI feature for lead reporting?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, DigixCRM includes AI-powered reporting tools that analyze your sales pipeline to provide predictive insights and high-velocity focus areas."
      }
    }
  ]
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(navigationJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://digixcrm.com" },
              { "@type": "ListItem", "position": 2, "name": "Features", "item": "https://digixcrm.com/features" },
              { "@type": "ListItem", "position": 3, "name": "Pricing", "item": "https://digixcrm.com/pricing" },
              { "@type": "ListItem", "position": 4, "name": "Blog", "item": "https://digixcrm.com/blog" },
              { "@type": "ListItem", "position": 5, "name": "Contact", "item": "https://digixcrm.com/contact" }
            ]
          }) }}
        />
        <script dangerouslySetInnerHTML={{ __html: `
          (function() {
            if (navigator.userAgent.indexOf('DigixCRM-Capacitor-Mobile') !== -1) {
              document.documentElement.classList.add('is-mobile-app');
            }
          })();
        `}} />
      </head>
      <body
        className={`${inter.variable} ${geistMono.variable} antialiased bg-background text-foreground transition-colors duration-300`}
        suppressHydrationWarning
      >
        <script dangerouslySetInnerHTML={{ __html: `
          (function() {
            var ua = navigator.userAgent;
            if (ua.indexOf('DigixCRM-Capacitor-Mobile') !== -1 || ua.indexOf('Capacitor') !== -1) {
              document.documentElement.classList.add('is-mobile-app');
              // Force show preloader immediately
              var p = document.getElementById('preloader');
              if (p) p.style.display = 'flex';
            }
          })();
        `}} />
        <style dangerouslySetInnerHTML={{ __html: `
          #preloader {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background-color: #0d1b4b;
            display: none;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            transition: opacity 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            pointer-events: none;
          }
          .is-mobile-app #preloader {
            display: flex;
          }
          .preloader-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
            animation: logoScaleIn 1.2s cubic-bezier(0.34, 1.56, 0.64, 1);
          }
          .preloader-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
          }
          .preloader-spinner-wrapper {
            height: 2px;
            width: 120px;
            background-color: rgba(255,255,255,0.1);
            border-radius: 99px;
            overflow: hidden;
            position: relative;
          }
          .preloader-spinner-bar {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background-color: #3b82f6;
            animation: loadingBar 2.5s infinite ease-in-out;
          }
          @keyframes logoScaleIn {
            from { opacity: 0; transform: scale(0.6); filter: blur(10px); }
            to { opacity: 1; transform: scale(1); filter: blur(0); }
          }
          @keyframes loadingBar {
            from { transform: translateX(-100%); }
            to { transform: translateX(100%); }
          }
          /* Activation strictly for the mobile app context */
          .is-mobile-app #preloader {
            display: flex;
          }
          body.hydrated #preloader, body[data-hydrated="true"] #preloader {
            opacity: 0;
            visibility: hidden;
          }
        `}} />
        {/* High-Performance Pre-hydration Loader with Native Animation - Only shown in Mobile App */}
        <div id="preloader" suppressHydrationWarning>
          <div className="preloader-content">
            <img 
              src="/logo-emblem-light.png" 
              alt="DigixCRM" 
              className="preloader-logo"
            />
            <div className="preloader-spinner-wrapper">
               <div className="preloader-spinner-bar" />
            </div>
        </div>
        </div>
        
        <script dangerouslySetInnerHTML={{ __html: `
          // Fallback to hide preloader even if hydration is delayed
          setTimeout(function() {
            var p = document.getElementById('preloader');
            if (p) { p.style.opacity = '0'; p.style.visibility = 'hidden'; }
          }, 4500);
        `}} />
        <Providers>
          {children}
          {/* Inside Providers so the chatbot can read the session and hide itself when signed out. */}
          <PremiumChatbot />
        </Providers>
      </body>
    </html>
  );
}
