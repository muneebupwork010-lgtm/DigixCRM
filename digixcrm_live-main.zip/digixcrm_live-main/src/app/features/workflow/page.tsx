import { Metadata } from "next";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { Zap, GitMerge, ListTodo, Sparkles, ArrowRight, PlayCircle } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
    title: "Workflow Engine | DigixCRM Automation",
    description: "Automate your sales pipeline with the DigixCRM Workflow Engine. Lead routing, automated follow-ups, and custom trigger-action sequences.",
};

const workFeatures = [
    {
        icon: Zap,
        title: "Intelligent Lead Routing",
        desc: "Automatically assign leads to the right rep based on industry, territory, or deal size within seconds of capture."
    },
    {
        icon: GitMerge,
        title: "Multi-Stage Sequences",
        desc: "Build branching logic that moves deals through stages based on customer actions like email opens or link clicks."
    },
    {
        icon: ListTodo,
        title: "Task Orchestration",
        desc: "Say goodbye to manual to-do lists. DigixCRM auto-generates tasks for your team exactly when they need to take action."
    }
];

export default function WorkflowPage() {
    return (
        <>
            <LandingNav />
            <main className="pt-24 min-h-screen bg-background">
                {/* Hero */}
                <section className="py-20 md:py-32 relative overflow-hidden text-center">
                    <div className="absolute inset-0 bg-primary/[0.03] -z-10" />
                    <div className="max-w-4xl mx-auto px-6">
                        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-[0.2em] mb-8">
                            <Sparkles className="w-3.5 h-3.5" /> High-Velocity Automation
                        </div>
                        <h1 className="text-5xl md:text-8xl font-black text-foreground tracking-tighter mb-8 leading-[0.95]">
                            Stop wasting <br /> <span className="text-primary italic underline decoration-primary/20">time on admin.</span>
                        </h1>
                        <p className="text-xl text-muted-foreground font-bold max-w-2xl mx-auto mb-10 leading-relaxed">
                            Turn your pipeline into a high-speed revenue machine. We help you automate follow-ups and lead routing so your team can focus on closing deals.
                        </p>
                        <div className="flex flex-wrap items-center justify-center gap-4">
                            <Link href="/contact" className="px-8 py-4 bg-primary text-primary-foreground font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-primary/20 hover:scale-105 transition-all">
                                Request a Demo
                            </Link>
                            <Link href="/docs" className="px-8 py-4 bg-background border border-border text-foreground font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-muted/30 transition-all flex items-center gap-2">
                                <PlayCircle className="w-4 h-4" /> Watch it Work
                            </Link>
                        </div>
                    </div>
                </section>

                {/* Features Grid */}
                <section className="py-24 border-t border-border">
                    <div className="max-w-6xl mx-auto px-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            {workFeatures.map((f) => (
                                <div key={f.title} className="p-10 rounded-[2.5rem] bg-card border border-border hover:border-primary/30 hover:shadow-2xl transition-all group">
                                    <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center mb-8 group-hover:bg-primary/5 transition-colors">
                                        <f.icon className="w-8 h-8 text-primary" />
                                    </div>
                                    <h3 className="text-2xl font-black text-foreground mb-4 tracking-tight">{f.title}</h3>
                                    <p className="text-muted-foreground leading-relaxed font-medium mb-8 pl-1 border-l-2 border-primary/10">
                                        {f.desc}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* VISUAL BREAKOUT SECTION */}
                <section className="py-24 bg-foreground overflow-hidden">
                    <div className="max-w-6xl mx-auto px-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                            <div>
                                <h2 className="text-4xl md:text-6xl font-black text-white tracking-tighter mb-8 leading-[1.1]">
                                    Visual Logic for <br/> <span className="text-primary italic">Non-Engineers.</span>
                                </h2>
                                <p className="text-white/60 text-lg mb-10 font-medium leading-relaxed">
                                    You don't need a computer science degree to automate your sales. Our branching logic builder is as simple as drawing on a whiteboard.
                                </p>
                                <ul className="space-y-6">
                                    {[
                                        "Trigger actions based on Deal stages",
                                        "Automated 'Stale Deal' warnings to managers",
                                        "Webhooks for 2,000+ app integrations",
                                        "Time-delayed sequence orchestration"
                                    ].map(item => (
                                        <li key={item} className="flex items-center gap-4 text-white font-bold group">
                                            <div className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                                                <ArrowRight className="w-3.5 h-3.5" />
                                            </div>
                                            {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="relative">
                                <div className="absolute inset-0 bg-primary/20 blur-[120px] rounded-full" />
                                <div className="relative p-8 bg-muted/[0.05] border border-white/10 rounded-[3rem] backdrop-blur-3xl shadow-2xl">
                                    <div className="space-y-6">
                                        <div className="p-5 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-4">
                                            <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center text-green-500">
                                                <Zap className="w-5 h-5" />
                                            </div>
                                            <div>
                                                <p className="text-xs font-black text-white uppercase opacity-40">Trigger</p>
                                                <p className="text-white font-bold">New Lead Created</p>
                                            </div>
                                        </div>
                                        <div className="w-1 h-8 bg-white/10 ml-10" />
                                        <div className="p-5 rounded-2xl bg-primary text-white flex items-center gap-4 shadow-xl shadow-primary/20">
                                            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                                                <ArrowRight className="w-5 h-5" />
                                            </div>
                                            <div>
                                                <p className="text-xs font-black text-white/60 uppercase">Action</p>
                                                <p className="font-bold uppercase tracking-tighter">Route to Top Closer</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <LandingFooter />
        </>
    );
}
