import { NextRequest } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { notificationEmitter } from "@/lib/event-emitter";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
        return new Response("Unauthorized", { status: 401 });
    }

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) {
        return new Response("Unauthorized", { status: 401 });
    }

    const encoder = new TextEncoder();
    const eventName = `notification:${user.id}`;

    const stream = new ReadableStream({
        start(controller) {
            let isClosed = false;

            // Safe wrapper for enqueuing data to handle abrupt connection closures
            const safeEnqueue = (data: string) => {
                if (isClosed) return;
                try {
                    controller.enqueue(encoder.encode(data));
                } catch (e) {
                    isClosed = true;
                    cleanup();
                }
            };

            const sendNotification = (notification: any) => {
                safeEnqueue(`data: ${JSON.stringify(notification)}\n\n`);
            };

            const cleanup = () => {
                if (isClosed) return;
                isClosed = true;
                notificationEmitter.off(eventName, sendNotification);
                clearInterval(keepAlive);
                try {
                    controller.close();
                } catch (e) {
                    // Already closed
                }
            };

            // Confirm connection open successfully
            safeEnqueue(`data: ${JSON.stringify({ type: 'connected' })}\n\n`);

            // Setup listener
            notificationEmitter.on(eventName, sendNotification);

            // Keep connection alive to prevent strict proxy timeouts (like NGINX)
            const keepAlive = setInterval(() => {
                safeEnqueue(`:\n\n`); // SSE empty comment
            }, 15000);

            // Cleanup when connection drops or is closed by browser
            req.signal.addEventListener('abort', cleanup);
        },
        cancel() {
            // Optional: redundant cleanup for stream cancellation
        }
    });

    return new Response(stream, {
        headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no" 
        }
    });
}
