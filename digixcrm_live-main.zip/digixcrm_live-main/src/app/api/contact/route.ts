import { NextRequest, NextResponse } from "next/server";
import { validateTurnstileToken } from "@/lib/turnstile";
import { prisma } from "@/lib/prisma";
import { sendEmail } from "@/lib/mail";

export async function POST(req: NextRequest) {
    try {
        const { name, email, phone, message, location, captchaToken } = await req.json();
        
        // 1. Automatic Location Detection (Server fallback if client fails)
        let detectedLocation = location || "Unknown (Local/VPN)";
        
        if (!location || location === "Local/VPN") {
            try {
                const forwarded = req.headers.get("x-forwarded-for");
                const ip = forwarded ? forwarded.split(",")[0] : "";
                
                if (ip && ip !== "::1" && ip !== "127.0.0.1") {
                    const geoRes = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,country,city`);
                    const geoData = await geoRes.json();
                    if (geoData.status === "success") {
                        detectedLocation = `${geoData.city}, ${geoData.country}`;
                    }
                } else if (!location) {
                    detectedLocation = "Local Development Site";
                }
            } catch (geoErr) {
                console.error("Server-side GeoIP failed:", geoErr);
            }
        }

        // 2. Validate Captcha
        const isHuman = await validateTurnstileToken(captchaToken);
        if (!isHuman) {
            return NextResponse.json({ error: "Security check failed. Bots are not allowed." }, { status: 403 });
        }

        if (!name || !email || !message) {
            return NextResponse.json({ error: "Name, email and message are required." }, { status: 400 });
        }

        // 2. Strict Business Logic Validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneDigits = phone ? phone.replace(/\D/g, "") : "";
        
        // Note: Phone comes as "+XX XXXXXXXXXX", we strip non-digits for length check
        // Real length should be original country code + 9-11 digits. 
        // We'll allow 10-15 total digits after combining code + number.
        if (!emailRegex.test(email)) {
            return NextResponse.json({ error: "Invalid email format." }, { status: 400 });
        }
        
        if (phoneDigits.length < 10 || phoneDigits.length > 15 || /^(\d)\1+$/.test(phoneDigits)) {
            return NextResponse.json({ error: "Invalid or suspicious phone number." }, { status: 400 });
        }

        // 3. Hardcoded Notification Recipients
        const notifyEmails = [
            "digicarehouse.sales@gmail.com",
            "sameed.blackink@gmail.com",
            "s.usmani1001@gmail.com",
            "susmani@bitaccounting.com"
        ];
        
        console.log(`[Contact API] Attempting to send individual emails to: ${notifyEmails.join(", ")}`);
            
            const adminHtml = `
                <div style="font-family: 'Inter', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0f172a; color: #e2e8f0; border-radius: 16px; overflow: hidden;">
                    <div style="background: linear-gradient(135deg, #312e81, #1e3a8a); padding: 32px; text-align: center;">
                        <h1 style="color: white; font-size: 24px; margin: 0; font-weight: 900; letter-spacing: -0.5px;">DigixCRM</h1>
                        <p style="color: #a5b4fc; margin: 8px 0 0; font-size: 14px;">Incoming Sales Inquiry</p>
                    </div>
                    <div style="padding: 32px;">
                        <div style="background: #1e293b; padding: 12px 20px; border-radius: 10px; margin-bottom: 24px; display: inline-block; border-left: 4px solid #818cf8;">
                            <span style="color: #94a3b8; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 1px;">📍 Lead Location:</span>
                            <span style="color: #f1f5f9; font-size: 14px; font-weight: 700; margin-left: 8px;">${detectedLocation}</span>
                        </div>

                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #94a3b8; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; width: 100px;">Name</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #f1f5f9; font-weight: 600;">${name}</td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #94a3b8; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Email</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #818cf8;">${email}</td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #94a3b8; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Phone</td>
                                <td style="padding: 12px 0; border-bottom: 1px solid #1e293b; color: #f1f5f9;">${phone || "Not provided"}</td>
                            </tr>
                            <tr>
                                <td style="padding: 12px 0; color: #94a3b8; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; vertical-align: top;">Message</td>
                                <td style="padding: 12px 0; color: #f1f5f9; line-height: 1.6;">${message.replace(/\n/g, "<br/>")}</td>
                            </tr>
                        </table>
                    </div>
                    <div style="background: #0f172a; border-top: 1px solid #1e293b; padding: 20px 32px; text-align: center;">
                        <p style="color: #475569; font-size: 12px; margin: 0;">DigixCRM — A DigiCare House Product</p>
                    </div>
                </div>
            `;

            try {
                // Send individually to each recipient for maximum reliability
                await Promise.all(notifyEmails.map((to: string) => 
                    sendEmail({
                        to,
                        subject: `🚀 New Lead from DigixCRM: ${name}`,
                        html: adminHtml
                    })
                ));
                console.log(`[Contact API] All emails sent successfully.`);
            } catch (emailErr) {
                console.error("[Contact API] Email dispatch error:", emailErr);
            }

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Contact form error:", error);
        return NextResponse.json({ error: "Failed to send message. Please try again." }, { status: 500 });
    }
}
