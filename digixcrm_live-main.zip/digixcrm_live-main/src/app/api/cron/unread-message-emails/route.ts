import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { sendUnreadMessageEmail } from "@/lib/chat-emails";

export const dynamic = "force-dynamic";

/**
 * Cron Job: Unread Message Email Notifications
 * 
 * Sends ONE email per conversation per recipient, and never sends again
 * until the user reads their messages (lastReadAt advances).
 * 
 * Logic:
 * 1. Find all ConversationParticipants who have unread messages older than 2 min
 * 2. Skip participants who have already been emailed (emailReminderSentAt > lastReadAt)
 * 3. Send one grouped email per participant-conversation pair
 * 4. Set emailReminderSentAt = now() so no more emails are sent until user reads
 * 
 * Scenario:
 *   - Hassan sends msg → 2 min passes → cron sends 1 email → emailReminderSentAt = now
 *   - Hassan sends 5 more msgs → cron runs → emailReminderSentAt > lastReadAt → NO email
 *   - User reads chat → lastReadAt updates to now (past emailReminderSentAt)
 *   - Hassan sends new msg → 2 min passes → emailReminderSentAt < lastReadAt → 1 email sent
 * 
 * Run every 2 minutes:
 *   GET /api/cron/unread-message-emails
 */
export async function GET(req: Request) {
    try {
        // /api/* bypasses middleware, so this scheduled job must authenticate itself.
        const cronSecret = process.env.CRON_SECRET;
        if (!cronSecret) {
            console.error("[CRON_UNREAD_EMAILS] CRON_SECRET is not set — refusing to run");
            return new NextResponse("Cron not configured", { status: 500 });
        }
        if (req.headers.get("authorization") !== `Bearer ${cronSecret}`) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const now = new Date();
        const cutoff = new Date(now.getTime() - 2 * 60 * 1000); // 2 minutes ago

        // Step 1: Find all participants who have unread messages
        // and haven't been emailed yet for the current unread batch
        const participants = await prisma.conversationParticipant.findMany({
            where: {
                user: {
                    email: { not: null }, // Must have an email
                    isActive: true,
                },
            },
            include: {
                user: {
                    select: { id: true, name: true, email: true },
                },
                conversation: {
                    include: {
                        participants: {
                            include: {
                                user: {
                                    select: { id: true, name: true },
                                },
                            },
                        },
                    },
                },
            },
        });

        const appUrl = process.env.NEXTAUTH_URL || "https://digixcrm.com";
        const results: Array<{ participantId: string; success: boolean; error?: string }> = [];
        const participantIdsToUpdate: string[] = [];

        for (const participant of participants) {
            const lastRead = participant.lastReadAt
                ? new Date(participant.lastReadAt)
                : new Date(0);

            // Check: has the user already been emailed since they last read?
            // If emailReminderSentAt exists AND is after lastReadAt, skip
            if (
                participant.emailReminderSentAt &&
                new Date(participant.emailReminderSentAt) > lastRead
            ) {
                continue; // Already emailed for this unread batch
            }

            // Find unread messages in this conversation that are older than 2 minutes
            const unreadMessages = await prisma.message.findMany({
                where: {
                    conversationId: participant.conversationId,
                    isSystemEvent: false,
                    senderId: { not: participant.userId }, // Not sent by this user
                    createdAt: {
                        gt: lastRead,  // After last read
                        lte: cutoff,   // But older than 2 minutes (give time to read in real-time)
                    },
                },
                include: {
                    sender: {
                        select: { id: true, name: true },
                    },
                },
                orderBy: { createdAt: "desc" },
                take: 10,
            });

            // No unread messages old enough → skip
            if (unreadMessages.length === 0) continue;

            // Build the email
            const latestMessage = unreadMessages[0];
            const senderName = latestMessage.sender.name || "Someone";

            // Determine conversation name
            let conversationName = senderName;
            const convType = participant.conversation.type;

            if (convType === "PROJECT") {
                // Try to get the project name
                const convId = participant.conversationId;
                if (convId.startsWith("project-")) {
                    const projectId = convId.replace("project-", "");
                    try {
                        const project = await prisma.project.findUnique({
                            where: { id: projectId },
                            select: { name: true },
                        });
                        conversationName = project?.name || "Project Chat";
                    } catch {
                        conversationName = "Project Chat";
                    }
                } else {
                    conversationName = "Project Chat";
                }
            }

            try {
                await sendUnreadMessageEmail({
                    recipientName: participant.user.name || "User",
                    recipientEmail: participant.user.email!,
                    senderName,
                    messagePreview: latestMessage.content,
                    conversationType: convType as "DIRECT" | "PROJECT" | "GROUP",
                    conversationName,
                    unreadCount: unreadMessages.length,
                    appUrl,
                });

                participantIdsToUpdate.push(participant.id);
                results.push({ participantId: participant.id, success: true });
            } catch (error: any) {
                console.error(
                    `Failed to send unread email for participant ${participant.id}:`,
                    error
                );
                results.push({
                    participantId: participant.id,
                    success: false,
                    error: error.message,
                });
            }
        }

        // Mark all successfully emailed participants
        if (participantIdsToUpdate.length > 0) {
            await prisma.conversationParticipant.updateMany({
                where: { id: { in: participantIdsToUpdate } },
                data: { emailReminderSentAt: now },
            });
        }

        return NextResponse.json({
            success: true,
            emailsSent: results.filter((r) => r.success).length,
            emailsFailed: results.filter((r) => !r.success).length,
            results,
        });
    } catch (error: any) {
        console.error("UNREAD_MESSAGE_CRON_ERROR:", error);
        return NextResponse.json(
            { success: false, error: error.message },
            { status: 500 }
        );
    }
}
