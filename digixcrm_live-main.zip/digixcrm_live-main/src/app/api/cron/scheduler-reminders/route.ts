import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { addMinutes, addHours, isBefore, isAfter } from "date-fns";
import { sendBookingReminderEmail } from "@/lib/scheduler-emails";

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
    try {
        // Simple security: You can add an auth header check here
        // const authHeader = req.headers.get('authorization');
        // if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
        //     return new NextResponse('Unauthorized', { status: 401 });
        // }

        const now = new Date();
        // Look for meetings starting in exactly 60 minutes
        // We use a window to account for cron jitter (e.g., cron runs every 5 mins)
        // Find bookings between 55 and 65 minutes from now.
        const windowStart = addMinutes(now, 55);
        const windowEnd = addMinutes(now, 65);

        const bookings = await (prisma as any).booking.findMany({
            where: {
                status: "CONFIRMED",
                reminderSent: false,
                startTime: {
                    gte: windowStart,
                    lte: windowEnd,
                },
            },
            include: {
                meetingType: true,
                profile: { include: { user: { select: { name: true, email: true } } } },
                workspace: true,
            },
        });

        const results = [];

        for (const booking of bookings) {
            try {
                await sendBookingReminderEmail(booking);
                
                // Mark as sent
                await (prisma as any).booking.update({
                    where: { id: booking.id },
                    data: { reminderSent: true },
                });

                results.push({ id: booking.id, success: true });
            } catch (error: any) {
                console.error(`Failed to send reminder for booking ${booking.id}:`, error);
                results.push({ id: booking.id, success: false, error: error.message });
            }
        }

        return NextResponse.json({ 
            success: true, 
            processed: bookings.length,
            results 
        });

    } catch (error: any) {
        console.error("Cron Error:", error);
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }
}
