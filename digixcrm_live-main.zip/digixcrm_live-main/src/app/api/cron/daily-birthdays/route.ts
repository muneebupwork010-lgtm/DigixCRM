import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@/generated/prisma/client";
import { sendEmail } from "@/lib/mail";

// Force Next.js to not cache this route
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
    try {
        // Simple security: You can pass a secret in the URL like ?secret=YOUR_CRON_SECRET
        const { searchParams } = new URL(req.url);
        const secret = searchParams.get('secret');
        if (secret !== process.env.WP_WEBHOOK_SECRET) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const today = new Date();
        const currentMonth = today.getMonth(); // 0-11
        const currentDay = today.getDate(); // 1-31

        // 1. Get all workspaces that have enabled birthday emails
        const workspaces = await prisma.workspace.findMany({
            where: { enableBirthdayEmails: true },
            select: { id: true, name: true, owner: { select: { name: true, email: true } } }
        });

        const workspaceIds = workspaces.map(w => w.id);
        if (workspaceIds.length === 0) {
            return NextResponse.json({ success: true, message: "No workspaces have birthday emails enabled." });
        }

        let emailsSent = 0;

        const getBirthdayTemplate = (name: string, senderName: string, isChild: boolean = false) => `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Happy Birthday!</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f4f4f5; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table width="100%" max-width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); max-width: 600px; width: 100%;">
                    <!-- Header Image -->
                    <tr>
                        <td align="center" style="background-color: #ffffff;">
                            <img src="${process.env.NEXTAUTH_URL}/birthday-header.png" alt="Happy Birthday Celebration" style="width: 100%; max-width: 600px; height: auto; display: block; border-top-left-radius: 16px; border-top-right-radius: 16px;">
                        </td>
                    </tr>
                    
                    <!-- Content Body -->
                    <tr>
                        <td style="padding: 50px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #111827; font-size: 36px; font-weight: 800; letter-spacing: -0.5px;">${isChild ? `A Special Day! 🎈` : `Happy Birthday! 🎂`}</h1>
                            <p style="margin: 24px 0 0; color: #374151; font-size: 20px; font-weight: 500;">Hi ${name},</p>
                            
                            <p style="margin: 20px 0; color: #4b5563; font-size: 16px; line-height: 1.8;">
                                ${isChild 
                                    ? `We wanted to send a quick note to wish <strong>${name}</strong> a very Happy Birthday today! We hope you all have a wonderful time celebrating this special milestone.` 
                                    : `Wishing you a fantastic birthday! Thank you for being a valued part of <strong>${senderName}</strong>. We hope this year brings you tremendous joy, health, and success.`
                                }
                            </p>
                            
                            <!-- Divider -->
                            <hr style="border: 0; height: 1px; background-color: #e5e7eb; margin: 40px 0;">
                            
                            <p style="margin: 0; color: #111827; font-size: 18px; font-weight: 600;">Warmest regards,</p>
                            <p style="margin: 5px 0 0; color: #6b7280; font-size: 16px;">${senderName}</p>
                        </td>
                    </tr>
                </table>
                
                <!-- Footer -->
                <table width="100%" max-width="600" cellpadding="0" cellspacing="0" border="0" style="max-width: 600px; width: 100%; margin-top: 20px;">
                    <tr>
                        <td align="center" style="padding: 0 20px;">
                            <p style="margin: 0; color: #9ca3af; font-size: 12px; line-height: 1.5;">
                                This is an automated message sent by ${senderName}. 
                                <br>Powered by DigixCRM
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
`;

        // 2. Process Users (System Users / Team Members)
        const users = await prisma.user.findMany({
            where: {
                dob: { not: null },
                isActive: true,
                activeWorkspaceId: { in: workspaceIds }
            }
        });

        for (const user of users) {
            if (!user.dob || !user.email) continue;
            
            if (user.dob.getMonth() === currentMonth && user.dob.getDate() === currentDay) {
                // It's their birthday!
                await sendEmail({
                    to: user.email,
                    subject: `🎉 Happy Birthday, ${user.name}!`,
                    html: getBirthdayTemplate(user.name || "there", "The DigixCRM Team")
                });
                emailsSent++;
            }
        }

        // 3. Process Contacts (Clients)
        const contacts = await prisma.contact.findMany({
            where: {
                workspaceId: { in: workspaceIds },
                OR: [
                    { dob: { not: null } },
                    { familyMembers: { not: Prisma.AnyNull } } // They might have children with birthdays
                ]
            }
        });

        for (const contact of contacts) {
            if (!contact.email) continue;

            const workspace = workspaces.find(w => w.id === contact.workspaceId);
            const senderName = workspace?.name || "Our Team";

            // Check if it's the contact's own birthday
            if (contact.dob && contact.dob.getMonth() === currentMonth && contact.dob.getDate() === currentDay) {
                await sendEmail({
                    to: contact.email,
                    subject: `🎉 Happy Birthday, ${contact.firstName}!`,
                    html: getBirthdayTemplate(contact.firstName, senderName),
                    workspaceId: contact.workspaceId || undefined
                });
                emailsSent++;
            }

            // Check if it's a child or spouse's birthday
            if (contact.familyMembers) {
                try {
                    const family = contact.familyMembers as any;
                    
                    // Check spouse
                    if (family && family.spouse && family.spouse.dob && family.spouse.name) {
                        const spouseDob = new Date(family.spouse.dob);
                        if (spouseDob.getMonth() === currentMonth && spouseDob.getDate() === currentDay) {
                            await sendEmail({
                                to: contact.email,
                                subject: `🎉 Happy Birthday to ${family.spouse.name}!`,
                                html: getBirthdayTemplate(family.spouse.name, senderName, true), // Using child template for simplicity (it says "We wanted to send a quick note to wish...")
                                workspaceId: contact.workspaceId || undefined
                            });
                            emailsSent++;
                        }
                    }

                    // Check children
                    if (family && Array.isArray(family.children)) {
                        for (const child of family.children) {
                            if (!child.dob || !child.name) continue;
                            const childDob = new Date(child.dob);
                            if (childDob.getMonth() === currentMonth && childDob.getDate() === currentDay) {
                                await sendEmail({
                                    to: contact.email,
                                    subject: `🎈 Happy Birthday to ${child.name}!`,
                                    html: getBirthdayTemplate(child.name, senderName, true),
                                    workspaceId: contact.workspaceId || undefined
                                });
                                emailsSent++;
                            }
                        }
                    }
                } catch (e) {
                    console.error("Error parsing family members for contact", contact.id, e);
                }
            }
        }

        return NextResponse.json({ success: true, emailsSent });

    } catch (error) {
        console.error("CRON_BIRTHDAY_ERROR", error);
        return NextResponse.json({ success: false, error: "Failed to process birthday cron" }, { status: 500 });
    }
}
