import { headers } from "next/headers";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { square } from "@/lib/square";
import { WebhooksHelper } from "square";

export async function POST(req: Request) {
    try {
        // Signature must be verified against the RAW body, so read text (not json) first.
        const rawBody = await req.text();
        const signatureHeader = (await headers()).get("x-square-hmacsha256-signature") || "";

        const signatureKey = process.env.SQUARE_WEBHOOK_SIGNATURE_KEY;
        const notificationUrl = process.env.SQUARE_WEBHOOK_NOTIFICATION_URL;

        if (!signatureKey || !notificationUrl) {
            console.error("[SQUARE_WEBHOOK] Missing SQUARE_WEBHOOK_SIGNATURE_KEY or SQUARE_WEBHOOK_NOTIFICATION_URL");
            return new NextResponse("Webhook not configured", { status: 500 });
        }

        const isValid = await WebhooksHelper.verifySignature({
            requestBody: rawBody,
            signatureHeader,
            signatureKey,
            notificationUrl,
        });

        if (!isValid) {
            console.warn("[SQUARE_WEBHOOK] Rejected request with invalid signature");
            return new NextResponse("Invalid signature", { status: 401 });
        }

        const body = JSON.parse(rawBody);
        const eventType = body.type;

        // 1. Payment Created or Success (From Checkout Link)
        if (eventType === "payment.updated") {
            const payment = body.data.object.payment;
            
            // In a real Square webhook, you'd match the 'reference_id' or 'note'
            // For Square Payment Links, the order ID is usually the key.
            const orderId = payment.order_id;
            const status = payment.status;

            if (status === "COMPLETED") {
                // Fetch the order to find the metadata/workspaceId
                const { result } = await (square as any).ordersApi.retrieveOrder(orderId);
                const workspaceId = result.order.metadata?.workspace_id;
                const planTier = result.order.metadata?.plan_tier;

                if (workspaceId) {
                    const workspace = await prisma.workspace.findUnique({
                        where: { id: workspaceId },
                        include: { account: true }
                    });

                    if (workspace?.accountId) {
                        await (prisma as any).subscriptionAccount.update({
                            where: { id: workspace.accountId },
                            data: {
                                planTier: planTier || "FREE",
                                providerCustomerId: payment.customer_id || null,
                                hasPaymentSetup: true,
                                paymentProvider: "SQUARE"
                            }
                        });
                        console.log(`[SQUARE_WEBHOOK] Workspace ${workspaceId} upgraded to ${planTier}`);
                    }
                }
            }
        }

        return new NextResponse("OK", { status: 200 });
    } catch (err: any) {
        console.error("[SQUARE_WEBHOOK_ERROR]", err);
        return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 });
    }
}
