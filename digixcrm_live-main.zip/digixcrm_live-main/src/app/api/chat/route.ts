import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// Guard rails so an authenticated caller can't run up unbounded inference cost.
const MAX_MESSAGES = 30;
const MAX_CHARS_PER_MESSAGE = 4000;
const MAX_TOTAL_CHARS = 20000;

export async function POST(req: Request) {
  try {
    // Auth first: /api/* is excluded from middleware (see src/middleware.ts matcher),
    // so this route has to authenticate itself or it is a public LLM proxy.
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Invalid messages format" }, { status: 400 });
    }

    if (messages.length > MAX_MESSAGES) {
      return NextResponse.json({ error: "Conversation too long" }, { status: 413 });
    }

    let totalChars = 0;
    for (const msg of messages) {
      if (typeof msg?.content !== "string" || (msg.role !== "user" && msg.role !== "ai" && msg.role !== "model")) {
        return NextResponse.json({ error: "Invalid messages format" }, { status: 400 });
      }
      if (msg.content.length > MAX_CHARS_PER_MESSAGE) {
        return NextResponse.json({ error: "Message too long" }, { status: 413 });
      }
      totalChars += msg.content.length;
    }
    if (totalChars > MAX_TOTAL_CHARS) {
      return NextResponse.json({ error: "Conversation too long" }, { status: 413 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "GEMINI_API_KEY is not set" }, { status: 500 });
    }

    // Format messages for Gemini (it expects 'user' and 'model' roles)
    const contents = messages.map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }]
    }));

    // Base System Instruction
    let systemInstruction = "You are Digix AI, an advanced AI assistant embedded in the DigixCRM platform. You help users with sales, workflows, analytics, and CRM tasks. Be concise, professional, and helpful.";

    // ==========================================
    // RAG: Secure Data Retrieval
    // ==========================================
    {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { name: true, activeWorkspaceId: true, activeWorkspace: { select: { name: true } } }
      });

      if (user?.activeWorkspaceId) {
        // Fetch summary metrics
        const totalLeads = await prisma.lead.count({ where: { workspaceId: user.activeWorkspaceId } });
        const totalDeals = await prisma.deal.count({ where: { workspaceId: user.activeWorkspaceId } });

        // Fetch Top 5 Recent Leads
        const recentLeads = await prisma.lead.findMany({
          where: { workspaceId: user.activeWorkspaceId },
          orderBy: { createdAt: 'desc' },
          take: 5,
          select: { firstName: true, lastName: true, status: true, quotation: true }
        });

        // Fetch Top 5 Active Deals
        const activeDeals = await prisma.deal.findMany({
          where: { workspaceId: user.activeWorkspaceId, stage: { notIn: ['WON', 'LOST'] } },
          orderBy: { updatedAt: 'desc' },
          take: 5,
          select: { title: true, value: true, stage: true }
        });

        // Build the Live Context
        systemInstruction += `\n\n--- LIVE DATABASE CONTEXT ---\n`;
        systemInstruction += `You are talking to ${user.name || "the user"}. They are working in the workspace "${user.activeWorkspace?.name || "Unknown"}".\n`;
        systemInstruction += `Workspace Totals: ${totalLeads} Leads, ${totalDeals} Deals.\n\n`;
        
        if (recentLeads.length > 0) {
          systemInstruction += `Recent Leads:\n`;
          recentLeads.forEach(l => systemInstruction += `- ${l.firstName} ${l.lastName} (Status: ${l.status}, Value: $${l.quotation || 0})\n`);
        }

        if (activeDeals.length > 0) {
          systemInstruction += `\nActive Deals:\n`;
          activeDeals.forEach(d => systemInstruction += `- ${d.title} (Stage: ${d.stage}, Value: $${d.value || 0})\n`);
        }

        systemInstruction += `\nUse this data if the user asks about their recent leads, deals, or overall metrics. Do not invent data. If they ask a question outside of this provided context, inform them that you can only see their top recent items right now.`;
      }
    }

    const payload = {
      contents,
      systemInstruction: {
        role: "user",
        parts: [{ text: systemInstruction }]
      },
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 800,
      }
    };

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API Error:", errorText);
      return NextResponse.json({ error: "Failed to generate response from AI" }, { status: response.status });
    }

    const data = await response.json();
    const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text || "I'm sorry, I couldn't formulate a response.";

    return NextResponse.json({ reply: replyText });
  } catch (error) {
    console.error("Chat API Error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
