import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const CONFIG_ID = "SYSTEM_CONFIG";

// Only Super Admin can access these settings
async function checkSuperAdmin() {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return false;
    
    return session.user.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com") || 
           session.user.email === "sameed.blackink@gmail.com"; 
}

export async function GET() {
    if (!await checkSuperAdmin()) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const defaults = {
        adminNotificationEmails: ["sameed.blackink@gmail.com", "s.usmani1001@gmail.com", "susmani@bitaccounting.com"],
        notifyOnLeadForm: true,
        notifyOnOnboarding: true,
    };

    try {
        let settings = await (prisma as any).globalSettings.findUnique({
            where: { id: CONFIG_ID }
        });

        if (!settings || !settings.adminNotificationEmails || settings.adminNotificationEmails.length === 0) {
            // Apply defaults to the object we return immediately
            settings = {
                ...(settings || { id: CONFIG_ID }),
                ...defaults
            };
            
            // Sync to DB in background (no await here to speed up response)
            (prisma as any).globalSettings.upsert({
                where: { id: CONFIG_ID },
                update: defaults,
                create: { id: CONFIG_ID, ...defaults }
            }).catch(console.error);
        }

        return NextResponse.json({ success: true, settings });
    } catch (error) {
        console.error("Fetch settings error:", error);
        return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
    }
}

export async function PATCH(req: Request) {
    if (!await checkSuperAdmin()) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    try {
        const body = await req.json();
        const { adminNotificationEmails, notifyOnLeadForm, notifyOnOnboarding } = body;

        // Use raw SQL to bypass Prisma Client generation issues
        await (prisma as any).$executeRaw`
            INSERT INTO "GlobalSettings" ("id", "adminNotificationEmails", "notifyOnLeadForm", "notifyOnOnboarding", "updatedAt")
            VALUES (${CONFIG_ID}, ${adminNotificationEmails}, ${notifyOnLeadForm}, ${notifyOnOnboarding}, NOW())
            ON CONFLICT ("id") DO UPDATE SET
                "adminNotificationEmails" = EXCLUDED."adminNotificationEmails",
                "notifyOnLeadForm" = EXCLUDED."notifyOnLeadForm",
                "notifyOnOnboarding" = EXCLUDED."notifyOnOnboarding",
                "updatedAt" = NOW()
        `;

        const settings = await (prisma as any).globalSettings.findUnique({
            where: { id: CONFIG_ID }
        });

        return NextResponse.json({ success: true, settings });
    } catch (error) {
        console.error("Failed to update settings:", error);
        return NextResponse.json({ error: "Failed to update settings" }, { status: 500 });
    }
}
