import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getScopeWhere } from "@/lib/permissions-base";

// In-memory cache for user context (avoids re-fetching user+role every keystroke)
const userContextCache = new Map<string, { data: any; expiry: number }>();
const CACHE_TTL = 60_000; // 1 minute

async function getCachedUserContext(userId: string) {
    const cached = userContextCache.get(userId);
    if (cached && Date.now() < cached.expiry) return cached.data;

    const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { id: true, email: true, role: true, activeWorkspaceId: true }
    });

    if (!user) return null;

    // Resolve effective role
    let effectiveRole: string = user.role as string;
    if (user.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com") || user.role === "ADMIN") {
        effectiveRole = "ADMIN";
    } else if (user.activeWorkspaceId) {
        const membership = await (prisma as any).workspaceMember.findUnique({
            where: {
                workspaceId_userId: {
                    workspaceId: user.activeWorkspaceId,
                    userId: user.id
                }
            }
        });
        if (membership?.role) {
            if (((user.role as string) === "ADMIN" || (user.role as string) === "MANAGER") && (!membership || membership.role === "REP" || membership.role === "STAFF")) {
                effectiveRole = user.role;
            } else {
                effectiveRole = membership.role;
            }
        }
    }

    const context = { ...user, effectiveRole };
    userContextCache.set(userId, { data: context, expiry: Date.now() + CACHE_TTL });
    return context;
}

export async function GET(req: NextRequest) {
    const query = req.nextUrl.searchParams.get("q")?.trim();
    if (!query || query.length < 2) {
        return NextResponse.json({ leads: [], deals: [], organizations: [], contacts: [], projects: [], tasks: [] });
    }

    const session = await getServerSession(authOptions);
    if (!session?.user || !(session.user as any).id) {
        return NextResponse.json({ leads: [], deals: [], organizations: [], contacts: [], projects: [], tasks: [] }, { status: 401 });
    }

    const user = await getCachedUserContext((session.user as any).id);
    if (!user) {
        return NextResponse.json({ leads: [], deals: [], organizations: [], contacts: [], projects: [], tasks: [] }, { status: 401 });
    }

    const { effectiveRole, activeWorkspaceId } = user;
    const scopeWhere = getScopeWhere(effectiveRole, user.id, activeWorkspaceId);

    // Security: role-based module access
    const canSearchCRM = effectiveRole !== "STAFF" && effectiveRole !== "PROJECT_MANAGER";
    const canSearchPMS = effectiveRole !== "REP";

    // Run ALL searches in parallel
    const [leads, deals, organizations, contacts, projects, tasks] = await Promise.all([
        // Leads
        canSearchCRM ? prisma.lead.findMany({
            where: {
                ...scopeWhere,
                OR: [
                    { firstName: { contains: query, mode: "insensitive" } },
                    { lastName: { contains: query, mode: "insensitive" } },
                    { email: { contains: query, mode: "insensitive" } },
                    { phone: { contains: query, mode: "insensitive" } },
                ]
            },
            select: { id: true, firstName: true, lastName: true, email: true, status: true, service: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],

        // Deals
        canSearchCRM ? prisma.deal.findMany({
            where: {
                ...scopeWhere,
                OR: [
                    { title: { contains: query, mode: "insensitive" } },
                    { organization: { name: { contains: query, mode: "insensitive" } } },
                ]
            },
            select: { id: true, title: true, value: true, stage: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],

        // Organizations
        canSearchCRM ? prisma.organization.findMany({
            where: {
                ...scopeWhere,
                name: { contains: query, mode: "insensitive" }
            },
            select: { id: true, name: true, website: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],

        // Contacts
        canSearchCRM ? prisma.contact.findMany({
            where: {
                ...scopeWhere,
                OR: [
                    { firstName: { contains: query, mode: "insensitive" } },
                    { lastName: { contains: query, mode: "insensitive" } },
                    { email: { contains: query, mode: "insensitive" } },
                    { phone: { contains: query, mode: "insensitive" } },
                ]
            },
            select: { id: true, firstName: true, lastName: true, email: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],

        // Projects
        canSearchPMS ? prisma.project.findMany({
            where: {
                ...(activeWorkspaceId ? { workspaceId: activeWorkspaceId } : {}),
                OR: [
                    { name: { contains: query, mode: "insensitive" } },
                    { description: { contains: query, mode: "insensitive" } },
                ]
            },
            select: { id: true, name: true, status: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],

        // Tasks
        canSearchPMS ? prisma.task.findMany({
            where: {
                ...(activeWorkspaceId ? { workspaceId: activeWorkspaceId } : {}),
                OR: [
                    { title: { contains: query, mode: "insensitive" } },
                    { description: { contains: query, mode: "insensitive" } },
                ]
            },
            select: { id: true, title: true, status: true, projectId: true },
            take: 5,
            orderBy: { updatedAt: "desc" }
        }) : [],
    ]);

    return NextResponse.json({ leads, deals, organizations, contacts, projects, tasks });
}
