import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
    try {
        // Simple DB Check: Count users
        const userCount = await prisma.user.count();
        
        const memoryUsage = process.memoryUsage();
        
        return NextResponse.json({
            status: "healthy",
            timestamp: new Date().toISOString(),
            database: "connected",
            environment: process.env.NODE_ENV,
            memory: {
                rss: `${Math.round(memoryUsage.rss / 1024 / 1024)}MB`,
                heapUsed: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)}MB`,
            },
            userCount
        }, { status: 200 });

    } catch (error: any) {
        console.error("Health Check Error:", error);
        return NextResponse.json({
            status: "unhealthy",
            timestamp: new Date().toISOString(),
            database: "disconnected",
            error: error.message
        }, { status: 503 });
    }
}
