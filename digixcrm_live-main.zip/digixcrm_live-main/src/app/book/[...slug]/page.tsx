import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { PublicBookingWizard } from "@/components/scheduler/booking-wizard";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string[] }> }) {
    const resolvedParams = await params;
    const [workspaceId, profileSlug] = resolvedParams.slug || [];

    if (!workspaceId || !profileSlug) return { title: "Book a Meeting" };

    const profile = await (prisma as any).schedulerProfile.findFirst({
        where: { workspaceId, slug: profileSlug, isActive: true },
        include: {
            user: { select: { name: true } },
            workspace: { select: { name: true } },
        },
    });

    if (!profile) return { title: "Book a Meeting" };

    return {
        title: `Book with ${profile.displayName || profile.user.name} | ${profile.workspace.name}`,
        description: profile.bio || `Schedule a meeting with ${profile.displayName || profile.user.name}`,
    };
}

export default async function PublicBookingPage({ params }: { params: Promise<{ slug: string[] }> }) {
    const resolvedParams = await params;
    const [workspaceId, profileSlug] = resolvedParams.slug || [];

    if (!workspaceId || !profileSlug) notFound();

    const profile = await (prisma as any).schedulerProfile.findFirst({
        where: { workspaceId, slug: profileSlug, isActive: true },
        include: {
            meetingTypes: { where: { isActive: true }, orderBy: { order: "asc" } },
            user: { select: { name: true, image: true } },
            workspace: { select: { name: true, logo: true } },
        },
    });

    if (!profile) notFound();

    return (
        <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center p-4 sm:p-8">
            <PublicBookingWizard
                profile={JSON.parse(JSON.stringify(profile))}
            />
        </div>
    );
}
