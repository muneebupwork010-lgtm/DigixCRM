import { Metadata } from "next";
import { LandingNav } from "@/components/landing/landing-nav";
import { LandingFooter } from "@/components/landing/landing-footer";
import { ShieldCheck, FileText, Scale, Lock } from "lucide-react";

export const metadata: Metadata = {
    title: "Terms of Service | DigixCRM",
    description: "Legal terms, user responsibilities, and service level agreements (SLA) for the DigixCRM enterprise sales platform.",
};

export default function TermsPage() {
    return (
        <>
            <LandingNav />
            <main className="pt-24 min-h-screen bg-background text-foreground">
                <section className="border-b border-border bg-muted/10 py-16 md:py-24">
                    <div className="max-w-4xl mx-auto px-6">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest mb-6 font-sans">
                           <Scale className="w-3.5 h-3.5" /> Legal Framework
                        </div>
                        <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6">
                            Clean <span className="text-primary italic">Legal Terms.</span>
                        </h1>
                        <p className="text-lg text-muted-foreground font-bold leading-relaxed max-w-2xl">
                            The rules of the road for using DigixCRM. We focus on transparency and fair service levels so you can grow your business without legal surprises.
                        </p>
                    </div>
                </section>

                <section className="py-20">
                    <div className="max-w-4xl mx-auto px-6">
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-16">
                            {/* Sidebar - Quick Navigation */}
                            <div className="md:col-span-4 hidden md:block">
                                <div className="sticky top-32 space-y-4">
                                    {[
                                        "Acceptance of Terms",
                                        "Service Availability (SLA)",
                                        "User Responsibilities",
                                        "Data Ownership",
                                        "Enterprise Compliance",
                                        "Termination"
                                    ].map((item) => (
                                        <div key={item} className="text-sm font-bold text-muted-foreground hover:text-primary transition-colors cursor-pointer flex items-center gap-2">
                                            <div className="w-1 h-1 rounded-full bg-primary/40" /> {item}
                                        </div>
                                    ))}
                                    <div className="mt-10 p-5 rounded-2xl bg-primary/5 border border-primary/20">
                                        <ShieldCheck className="w-6 h-6 text-primary mb-3" />
                                        <p className="text-xs font-black text-foreground uppercase tracking-widest mb-2">SOC2 READY</p>
                                        <p className="text-[10px] text-muted-foreground leading-relaxed">Our infrastructure is built for high-security enterprise environments.</p>
                                    </div>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="md:col-span-8 prose prose-slate max-w-none">
                                <div className="space-y-12">
                                    <div className="space-y-4">
                                        <h2 className="text-2xl font-black text-foreground">1. Acceptance of Terms</h2>
                                        <p className="text-muted-foreground leading-relaxed">
                                            By accessing or using the DigixCRM platform, you agree to be bound by these Terms of Service. If you are using the platform on behalf of an organization, you represent that you have the legal authority to bind that organization to these terms.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        <h2 className="text-2xl font-black text-foreground">2. Service Availability (SLA)</h2>
                                        <p className="text-muted-foreground leading-relaxed">
                                            DigixCRM maintains a 99.9% uptime guarantee for all Enterprise and Strategic plans. Our global distributed database architecture ensures that your sales data is available 24/7/365, barring scheduled maintenance which is communicated 48 hours in advance.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        <h2 className="text-2xl font-black text-foreground">3. User Responsibilities</h2>
                                        <p className="text-muted-foreground leading-relaxed">
                                            Users are responsible for maintaining the confidentiality of their login credentials. Any systematic bulk-scraping or automated stress-testing of our APIs outside of our documentation guidelines is strictly prohibited and may result in immediate suspension.
                                        </p>
                                    </div>

                                    <div className="space-y-4 border-l-4 border-primary/20 pl-6 py-2">
                                        <h2 className="text-2xl font-black text-foreground">4. Data Ownership & Privacy</h2>
                                        <p className="text-muted-foreground leading-relaxed">
                                            You own 100% of the data you input into DigixCRM. We never sell, rent, or share your proprietary sales data with third parties. DigixCRM acts only as a data processor on your behalf.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        <h2 className="text-2xl font-black text-foreground">5. Enterprise Compliance</h2>
                                        <p className="text-muted-foreground leading-relaxed">
                                            DigixCRM integrates PBAC (Policy Based Access Control) at the infrastructure level. Our systems are built to be GDPR compliant and are hosted on SOC2-ready infrastructure to ensure your data meets global enterprise security standards.
                                        </p>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <LandingFooter />
        </>
    );
}
