export default function Loading() {
    return (
        <div className="flex-1 w-full space-y-12 p-6 sm:p-10">
            {/* Header Skeleton */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 pb-8 border-b border-border/40">
                <div className="space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="h-8 w-8 bg-muted rounded-xl animate-pulse"></div>
                        <div className="h-4 w-32 bg-muted/60 rounded-full animate-pulse"></div>
                    </div>
                    <div className="h-12 w-64 sm:w-96 bg-muted rounded-2xl animate-pulse"></div>
                </div>
                <div className="flex gap-3">
                    <div className="h-10 w-32 bg-muted rounded-xl animate-pulse"></div>
                    <div className="h-10 w-32 bg-muted rounded-xl animate-pulse"></div>
                </div>
            </div>

            {/* KPI Tiles Skeleton */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="h-48 bg-muted/30 rounded-[2.5rem] border border-border/40 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-muted/10 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
                        <div className="p-8 space-y-4">
                            <div className="h-10 w-10 bg-muted rounded-xl"></div>
                            <div className="space-y-2">
                                <div className="h-3 w-16 bg-muted/60 rounded-full"></div>
                                <div className="h-8 w-32 bg-muted rounded-lg"></div>
                                <div className="h-3 w-24 bg-muted/40 rounded-full"></div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Bento Grid Skeleton */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 h-[400px] bg-muted/20 rounded-[2.5rem] border border-border/40 animate-pulse"></div>
                <div className="lg:col-span-1 h-[400px] bg-muted/20 rounded-[2.5rem] border border-border/40 animate-pulse"></div>
            </div>
        </div>
    );
}
