import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getEffectiveRole } from "@/lib/permissions";
import { notFound } from "next/navigation";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { DealDetailsView } from "@/components/deals/deal-details-view";

export default async function DealDetailsPage({ params }: { params: Promise<{ id: string }> }) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ where: { email: session?.user?.email || "" } });
    if (!user) return <div>Access Denied</div>;

    const { id } = await params;
    
    // Authorization check
    const effectiveRole = await getEffectiveRole(user);
    const activeWorkspaceId = (user as any).activeWorkspaceId;
    const deal = await prisma.deal.findFirst({
        where: { id, workspaceId: activeWorkspaceId },
        include: {
            organization: { select: { id: true, name: true } },
            owner: { select: { id: true, name: true, email: true } },
            project: { select: { id: true } }
        }
    });

    if (!deal) return notFound();

    // Verify access
    if (effectiveRole !== "ADMIN" && effectiveRole !== "MANAGER" && deal.ownerId !== user.id) {
        return <div className="p-10 text-center">Unauthorized access to this deal.</div>;
    }

    // Fetch required view data
    const organizations = await prisma.organization.findMany({
        where: { workspaceId: activeWorkspaceId },
        select: { id: true, name: true },
        orderBy: { name: "asc" }
    });

    const workspaceMembers = await prisma.workspaceMember.findMany({
        where: { workspaceId: activeWorkspaceId },
        include: { user: { select: { id: true, name: true, image: true } } }
    });
    const users = workspaceMembers.map(m => ({ ...m.user, role: m.role }));

    let activeWorkspace = null;
    if (activeWorkspaceId) {
        activeWorkspace = await prisma.workspace.findUnique({
            where: { id: activeWorkspaceId }
        });
    }
    const dealStages = (activeWorkspace as any)?.dealStages || null;

    return (
        <div className="flex flex-col h-full bg-background overflow-hidden">
             <div className="p-4 border-b border-border bg-card/50 flex items-center justify-between">
                <Link href="/dashboard/deals">
                    <Button variant="ghost" size="sm" className="gap-2 font-semibold">
                         <ChevronLeft className="w-4 h-4" /> Back to Deals
                    </Button>
                </Link>
                <div className="text-xs text-muted-foreground font-mono">
                    ID: {deal.id}
                </div>
             </div>
             <div className="flex-1 overflow-hidden">
                <DealDetailsView 
                    deal={deal as any} 
                    effectiveRole={effectiveRole}
                    users={users as any}
                    organizations={organizations}
                    dealStages={dealStages}
                />
             </div>
        </div>
    );
}
