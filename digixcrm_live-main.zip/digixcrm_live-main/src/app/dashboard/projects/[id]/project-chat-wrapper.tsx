"use client";

import { useEffect, useState } from "react";
import { ChatBox } from "@/components/chat/chat-box";
import { getOrCreateProjectConversation } from "@/lib/actions/chat";

export function ProjectChatWrapper({ projectId }: { projectId: string }) {
    const [ready, setReady] = useState(false);

    useEffect(() => {
        const initChat = async () => {
            await getOrCreateProjectConversation(projectId);
            setReady(true);
        };
        initChat();
    }, [projectId]);

    if (!ready) {
        return <div className="flex h-full items-center justify-center text-muted-foreground animate-pulse">Initializing Project Chat...</div>;
    }

    return <ChatBox conversationId={`project-${projectId}`} />;
}
