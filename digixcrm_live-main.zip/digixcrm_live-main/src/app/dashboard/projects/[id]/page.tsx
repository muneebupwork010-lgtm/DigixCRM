import { prisma } from "@/lib/prisma";
import { getProjectById } from "@/lib/actions/projects";
import { getProjectTasks } from "@/lib/actions/tasks";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { notFound, redirect } from "next/navigation";
import { getEffectiveRole } from "@/lib/permissions";
import { 
    LayoutDashboard, 
    Trello, 
    List, 
    Clock, 
    Settings as SettingsIcon,
    Plus,
    Calendar,
    Users,
    ChevronLeft,
    BarChart3,
    Archive,
    Flag,
    MessageSquare
} from "lucide-react";
import Link from "next/link";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CreateTaskDialog } from "@/components/tasks/create-task-dialog";
import { ImportTasksDialog } from "@/components/tasks/import-tasks-dialog";

import { TaskBoard } from "@/components/tasks/task-board";
import { TaskTable } from "@/components/tasks/task-table";
import { GanttTimeline } from "@/components/tasks/gantt-timeline";
import { ProjectAnalytics } from "@/components/projects/project-analytics";
import { ProjectSettingsDialog } from "@/components/projects/project-settings-dialog";
import { TaskArchive } from "@/components/tasks/task-archive";
import { MilestonesView } from "@/components/projects/milestones-view";
import { ProjectChatWrapper } from "./project-chat-wrapper";

export const dynamic = "force-dynamic";

export default async function ProjectDetailPage({
    params,
    searchParams
}: {
    params: Promise<{ id: string }>;
    searchParams: Promise<{ tab?: string }>;
}) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ 
        where: { email: session?.user?.email || "" } 
    });

    if (!user) return <div>Access Denied</div>;

    const resolvedParams = await params;
    const resolvedSearchParams = await searchParams;
    const tab = resolvedSearchParams.tab || "board";

    let project = await getProjectById(resolvedParams.id);
    
    if (!project) {
        // Smart Routing: Check if the project exists in a different workspace the user has access to
        const globalProject = await prisma.project.findUnique({
            where: { id: resolvedParams.id },
            select: { workspaceId: true }
        });

        if (globalProject && globalProject.workspaceId) {
            const workspaceMembership = await prisma.workspaceMember.findUnique({
                where: {
                    workspaceId_userId: {
                        workspaceId: globalProject.workspaceId,
                        userId: user.id
                    }
                }
            });

            if (workspaceMembership) {
                // User has access! Switch their active workspace
                await prisma.user.update({
                    where: { id: user.id },
                    data: { activeWorkspaceId: globalProject.workspaceId }
                });
                
                // Redirect to reload the page in the context of the new workspace
                redirect(`/dashboard/projects/${resolvedParams.id}`);
            }
        }

        notFound();
    }

    const tasks = await getProjectTasks(resolvedParams.id);
    const workspaceId = (user as any).activeWorkspaceId;

    const workspaceMembers = await prisma.workspaceMember.findMany({
        where: { workspaceId },
        include: { user: { select: { id: true, name: true, image: true } } }
    });
    const allUsers = workspaceMembers.map(m => m.user);

    // Filter to only project-authorized users (Owner + Members)
    const projectMemberIds = new Set([
        project.ownerId,
        ...(project.members?.map((m: any) => m.userId) || [])
    ]);
    const projectUsers = allUsers.filter(u => projectMemberIds.has(u.id));

    const effectiveRole = await getEffectiveRole(user);

    const canManageSettings = ["ADMIN", "MANAGER", "PROJECT_MANAGER"].includes(effectiveRole) || project.ownerId === user.id;
    const isClient = effectiveRole === "CLIENT";

    return (
        <div className="space-y-6 flex flex-col">
            {/* Project Header Navigation */}
            <div className="flex flex-col gap-6 bg-card p-6 sm:p-8 rounded-[2.5rem] border border-border/40 shadow-xl shadow-primary/5 shrink-0">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-3">
                        <Link 
                            href="/dashboard/projects" 
                            className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors mb-2 w-fit"
                        >
                            <ChevronLeft className="w-3.5 h-3.5" />
                            Back to Workspace
                        </Link>
                        <div className="flex items-center gap-4">
                            <h1 className="text-3xl font-black tracking-tight">{project.name}</h1>
                            <Badge variant="outline" className="rounded-full px-3 py-1 font-black uppercase text-[10px] tracking-widest bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
                                {project.status.replace('_', ' ')}
                            </Badge>
                        </div>
                        <div className="flex flex-wrap items-center gap-6 text-sm font-bold text-muted-foreground">
                            <div className="flex items-center gap-2">
                                <Users className="w-4 h-4" />
                                <span>{projectUsers.length} Team Members</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Calendar className="w-4 h-4" />
                                <span>{project.endDate ? `Due ${new Date(project.endDate).toLocaleDateString()}` : "No deadline"}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                <span>{tasks.length} Total Tasks</span>
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center gap-3">
                        {!isClient && <ImportTasksDialog projectId={project.id} projectName={project.name} />}
                        <CreateTaskDialog projectId={project.id} users={projectUsers} />
                        {canManageSettings && (
                            <ProjectSettingsDialog project={project} workspaceUsers={allUsers} />
                        )}
                    </div>
                </div>

                {/* Navigation Tabs */}
                <div className="flex items-center border-t border-border/50 pt-6">
                    <div className="flex items-center gap-8">
                        {[
                            { id: "board", label: "Board", icon: Trello },
                            { id: "list", label: "Table", icon: List },
                            { id: "timeline", label: "Timeline", icon: Clock },
                            { id: "milestones", label: "Milestones", icon: Flag },
                            { id: "analytics", label: "Analytics", icon: BarChart3 },
                            { id: "chat", label: "Chat", icon: MessageSquare },
                            { id: "archive", label: "Archive", icon: Archive }
                        ].map((t) => {
                            const isActive = tab === t.id;
                            const Icon = t.icon;
                            
                            return (
                                <Link
                                    key={t.id}
                                    href={`/dashboard/projects/${project.id}?tab=${t.id}`}
                                    className={cn(
                                        "flex items-center gap-2 pb-4 text-sm font-black uppercase tracking-widest transition-all relative",
                                        isActive 
                                            ? "text-primary after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-primary" 
                                            : "text-muted-foreground hover:text-foreground"
                                    )}
                                >
                                    <Icon className="w-4 h-4" />
                                    <span>{t.label}</span>
                                </Link>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 min-h-0 pb-12">
                {tab === "board" && (
                     <div className="h-full py-2">
                        <TaskBoard projectId={project.id} initialTasks={tasks} users={projectUsers} currentUser={{ id: user.id, role: effectiveRole }} />
                     </div>
                )}
                {tab === "list" && (
                     <div className="h-full py-2">
                        <TaskTable tasks={tasks} users={projectUsers} currentUser={{ id: user.id, role: effectiveRole }} />
                     </div>
                )}
                { tab === "timeline" && (
                    <div className="h-full py-2">
                        <GanttTimeline tasks={tasks} />
                    </div>
                )}
                {tab === "milestones" && (
                    <div className="h-full py-2">
                        <MilestonesView projectId={project.id} users={projectUsers} currentUser={{ id: user.id, role: effectiveRole }} />
                    </div>
                )}
                {tab === "analytics" && (
                    <div className="h-full py-2">
                        <ProjectAnalytics project={project} tasks={tasks} users={projectUsers} />
                    </div>
                )}
                {tab === "chat" && (
                    <div className="h-[600px] py-2">
                        <ProjectChatWrapper projectId={project.id} />
                    </div>
                )}
                {tab === "archive" && (
                    <div className="h-full py-2">
                        <TaskArchive projectId={project.id} />
                    </div>
                )}
            </div>
        </div>
    );
}
