import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getProjects } from "@/lib/actions/projects";
import { canSeeFinancials, getEffectiveRole, canAccessPMS } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { CreateProjectDialog } from "@/components/projects/create-project-dialog";
import { ProjectsGrid } from "@/components/projects/projects-grid";
import { 
    FolderKanban, 
    Layers, 
    TrendingUp, 
    CheckCircle2, 
    Clock, 
    Plus, 
    Filter,
    Search
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ 
        where: { email: session?.user?.email || "" } 
    });

    if (!user) return <div>Access Denied</div>;

    const workspaceId = (user as any).activeWorkspaceId;
    const projects = await getProjects();
    const effectiveRole = await getEffectiveRole(user);
    const hasPMS = canAccessPMS(effectiveRole);
    if (!hasPMS) {
        redirect("/dashboard");
    }
    const showFinancials = canSeeFinancials(effectiveRole);
    
    const organizations = await prisma.organization.findMany({
        where: { workspaceId },
        select: { id: true, name: true },
        orderBy: { name: "asc" }
    });

    const workspaceMembers = await prisma.workspaceMember.findMany({
        where: { workspaceId },
        include: { user: { select: { id: true, name: true } } }
    });
    const users = workspaceMembers.map(m => m.user);

    // Calculate Stats
    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === 'ACTIVE').length;
    const totalBudget = showFinancials ? projects.reduce((acc, p) => acc + (p.budget || 0), 0) : 0;

    return (
        <div className="space-y-8 pb-12">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-card p-6 sm:p-8 rounded-[2.5rem] border border-border/40 shadow-xl shadow-primary/5 transition-all">
                <div className="space-y-2">
                    <div className="flex items-center gap-3 text-primary">
                        <div className="p-2 rounded-xl bg-primary/10">
                            <FolderKanban className="w-5 h-5" />
                        </div>
                        <span className="text-xs font-black uppercase tracking-[0.2em]">Project Management</span>
                    </div>
                    <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">Project Workspace</h1>
                    <p className="text-muted-foreground font-medium max-w-md">
                        Manage your enterprise project portfolios, track {showFinancials && "budgets,"} and collaborate with your team.
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    {effectiveRole !== "CLIENT" && (
                        <CreateProjectDialog organizations={organizations} users={users} />
                    )}
                </div>
            </div>

            {/* Main Content Area */}
            <ProjectsGrid 
                initialProjects={projects} 
                organizations={organizations} 
                users={users} 
                showFinancials={showFinancials} 
            />
        </div>
    );
}
