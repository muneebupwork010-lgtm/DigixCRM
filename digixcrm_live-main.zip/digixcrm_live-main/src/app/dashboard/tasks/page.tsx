import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getMyTasks } from "@/lib/actions/tasks";
import { TaskTable } from "@/components/tasks/task-table";
import { PersonalAnalytics } from "@/components/tasks/personal-analytics";
import { MyTasksContainer } from "@/components/tasks/my-tasks-container";
import { 
    CheckSquare, 
    Clock, 
    AlertCircle, 
    CheckCircle2, 
    Search, 
    Filter,
    Layers,
    Calendar,
    BarChart3,
    List
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { TaskCalendar } from "@/components/tasks/task-calendar";
import Link from "next/link";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function MyTasksPage({
    searchParams
}: {
    searchParams: Promise<{ tab?: string }>;
}) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ 
        where: { email: session?.user?.email || "" } 
    });

    if (!user) return <div className="p-10 text-center">Unauthorized Access</div>;

    const resolvedSearchParams = await searchParams;
    const tab = resolvedSearchParams.tab || "list";

    const workspaceId = (user as any).activeWorkspaceId;
    const tasks = await getMyTasks();
    
    // Fetch users for the TaskSheet (to allow reassignment within workspace)
    const workspaceMembers = await prisma.workspaceMember.findMany({
        where: { workspaceId },
        include: { user: { select: { id: true, name: true, image: true } } }
    });
    const users = workspaceMembers.map(m => m.user);

    // Calculate Personal Stats
    const totalTasks = tasks.length;
    const pendingTasks = tasks.filter(t => t.status !== 'DONE').length;
    const completedTasks = tasks.filter(t => t.status === 'DONE').length;
    const overdueTasks = tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'DONE').length;

    return (
        <div className="space-y-8 pb-12 animate-in fade-in duration-500">
            {/* Header Section */}
            <div className="flex flex-col gap-6 bg-card p-6 sm:p-8 rounded-[2.5rem] border border-border/40 shadow-xl shadow-primary/5 transition-all shrink-0">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-border/40">
                    <div className="space-y-2">
                        <div className="flex items-center gap-3 text-primary">
                            <div className="p-2 rounded-xl bg-primary/10">
                                <CheckSquare className="w-5 h-5" />
                            </div>
                            <span className="text-xs font-black uppercase tracking-[0.2em]">Personal Focus</span>
                        </div>
                        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">My Tasks</h1>
                        <p className="text-muted-foreground font-medium max-w-md">
                            Track and manage all tasks assigned to you across every project in this workspace.
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <Link href={tab === "calendar" ? "/dashboard/tasks?tab=list" : "/dashboard/tasks?tab=calendar"}>
                            <Button className="rounded-2xl h-12 px-6 font-black uppercase tracking-widest text-[10px] bg-primary hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
                                <Calendar className="w-4 h-4 mr-2" />
                                {tab === "calendar" ? "Back to List" : "Calendar View"}
                            </Button>
                        </Link>
                    </div>
                </div>

                {/* Sub-Navigation Tabs */}
                <div className="flex items-center gap-8 -mb-8">
                    {[
                        { id: "list", label: "Task List", icon: List },
                        { id: "calendar", label: "Calendar", icon: Calendar },
                        { id: "performance", label: "Performance", icon: BarChart3 },
                    ].map((t) => {
                        const isActive = tab === t.id;
                        const Icon = t.icon;
                        return (
                            <Link
                                key={t.id}
                                href={`/dashboard/tasks?tab=${t.id}`}
                                className={cn(
                                    "flex items-center gap-2 pb-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all relative",
                                    isActive 
                                        ? "text-primary after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-primary" 
                                        : "text-muted-foreground hover:text-foreground"
                                )}
                            >
                                <Icon className="w-3.5 h-3.5" />
                                <span>{t.label}</span>
                            </Link>
                        );
                    })}
                </div>
            </div>

            {/* Content Area */}
            <div className="space-y-8 pt-2">
                
                {tab === "list" && (
                    <>
                        {/* Stats Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            <StatCard title="Total Assigned" value={totalTasks} label="Global" icon={<Layers className="w-5 h-5" />} color="blue" />
                            <StatCard title="Pending Action" value={pendingTasks} label="Active" icon={<Clock className="w-5 h-5" />} color="amber" />
                            <StatCard title="Overdue Now" value={overdueTasks} label="Attention" icon={<AlertCircle className="w-5 h-5" />} color="red" pulse />
                            <StatCard title="Completed" value={completedTasks} label="Success" icon={<CheckCircle2 className="w-5 h-5" />} color="emerald" />
                        </div>

                        {/* Task Listing with Filters */}
                        <MyTasksContainer initialTasks={tasks} users={users as any} />
                    </>
                )}

                {tab === "performance" && (
                    <PersonalAnalytics tasks={tasks} />
                )}

                {tab === "calendar" && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                        <TaskCalendar tasks={tasks} users={users} />
                    </div>
                )}
            </div>
        </div>
    );
}

function StatCard({ title, value, label, icon, color, pulse }: any) {
    const colorClasses: any = {
        blue: "text-blue-500 bg-blue-500/10 shadow-blue-500/5",
        amber: "text-amber-500 bg-amber-500/10 shadow-amber-500/5",
        red: "text-red-500 bg-red-500/10 shadow-red-500/5",
        emerald: "text-emerald-500 bg-emerald-500/10 shadow-emerald-500/5"
    };

    return (
        <div className="bg-card p-6 rounded-3xl border border-border/40 shadow-lg space-y-4 hover:border-primary/20 transition-all group">
            <div className="flex items-center justify-between">
                <div className={cn("p-2.5 rounded-2xl transition-all group-hover:scale-110", colorClasses[color])}>
                    {icon}
                </div>
                <span className={cn("text-[10px] font-black uppercase tracking-widest", colorClasses[color].split(' ')[0], pulse && "animate-pulse")}>
                    {label}
                </span>
            </div>
            <div>
                <div className="text-4xl font-black tracking-tighter">{value}</div>
                <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mt-1">{title}</p>
            </div>
        </div>
    );
}

function EmptyState() {
    return (
        <div className="py-20 bg-muted/20 border-2 border-dashed border-border/40 rounded-[3rem] flex flex-col items-center justify-center text-center space-y-4">
            <div className="p-4 rounded-3xl bg-card shadow-xl border border-border/40">
                <CheckSquare className="w-12 h-12 text-muted-foreground opacity-20" />
            </div>
            <div className="space-y-1">
                <h3 className="text-xl font-black">All caught up!</h3>
                <p className="text-muted-foreground font-medium">You don't have any tasks assigned to you right now.</p>
            </div>
        </div>
    );
}

