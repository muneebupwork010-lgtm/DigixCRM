import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getEffectiveRole } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { SchedulerCalendarView } from "@/components/scheduler/calendar-view";
import { startOfWeek, endOfWeek, addWeeks, subWeeks, format } from "date-fns";

export const dynamic = "force-dynamic";

export default async function SchedulerPage({ searchParams }: { searchParams: Promise<{ week?: string }> }) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ where: { email: session?.user?.email || "" } });
    if (!user) redirect("/auth/signin");

    const role = await getEffectiveRole(user);
    if (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT") redirect("/dashboard");

    const workspaceId = (user as any).activeWorkspaceId;
    if (!workspaceId) redirect("/dashboard");

    const params = await searchParams;
    const weekParam = params?.week;
    const currentWeekStart = weekParam
        ? new Date(weekParam)
        : startOfWeek(new Date(), { weekStartsOn: 1 });

    const weekEnd = endOfWeek(currentWeekStart, { weekStartsOn: 1 });

    // Fetch bookings for this week
    const whereClause: any = {
        workspaceId,
        startTime: { gte: currentWeekStart, lte: weekEnd },
        status: { in: ["CONFIRMED", "PENDING"] },
    };

    // REP can only see their own
    if (role === "REP") {
        whereClause.profile = { userId: user.id };
    }

    const bookings = await (prisma as any).booking.findMany({
        where: whereClause,
        include: {
            meetingType: true,
            profile: {
                include: { user: { select: { name: true, email: true, image: true } } },
            },
        },
        orderBy: { startTime: "asc" },
    });

    // Get workspace consultants for "Book on Behalf" dialog
    const consultants = await (prisma as any).schedulerProfile.findMany({
        where: { workspaceId, isActive: true },
        include: {
            user: { select: { id: true, name: true, email: true, image: true, jobTitle: true } },
            meetingTypes: { where: { isActive: true }, orderBy: { order: "asc" } },
        },
    });

    // Get my profile for the "My Booking Link" display
    const myProfile = await (prisma as any).schedulerProfile.findUnique({
        where: { userId_workspaceId: { userId: user.id, workspaceId } },
    });

    return (
        <SchedulerCalendarView
            bookings={JSON.parse(JSON.stringify(bookings))}
            consultants={JSON.parse(JSON.stringify(consultants))}
            currentWeekStart={currentWeekStart.toISOString()}
            role={role}
            myProfile={myProfile ? JSON.parse(JSON.stringify(myProfile)) : null}
            workspaceId={workspaceId}
        />
    );
}
