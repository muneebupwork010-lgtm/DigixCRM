import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getEffectiveRole } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { AvailabilityEditor } from "@/components/scheduler/availability-editor";

export const dynamic = "force-dynamic";

export default async function AvailabilityPage() {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ where: { email: session?.user?.email || "" } });
    if (!user) redirect("/auth/signin");

    const role = await getEffectiveRole(user);
    if (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT") redirect("/dashboard");

    const workspaceId = (user as any).activeWorkspaceId;
    if (!workspaceId) redirect("/dashboard");

    // Fetch or create default profile
    let profile = await (prisma as any).schedulerProfile.findUnique({
        where: { userId_workspaceId: { userId: user.id, workspaceId } },
        include: {
            meetingTypes: { orderBy: { order: "asc" } },
            user: { select: { name: true, email: true, image: true, jobTitle: true } },
        },
    });

    return (
        <AvailabilityEditor
            profile={profile ? JSON.parse(JSON.stringify(profile)) : null}
            userName={user.name || "User"}
            userEmail={user.email || ""}
            userJobTitle={(user as any).jobTitle || ""}
        />
    );
}
