import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getEffectiveRole } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { BookingsList } from "@/components/scheduler/bookings-list";

export const dynamic = "force-dynamic";

export default async function BookingsPage({ searchParams }: { searchParams: Promise<{ filter?: string }> }) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ where: { email: session?.user?.email || "" } });
    if (!user) redirect("/auth/signin");

    const role = await getEffectiveRole(user);
    if (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT") redirect("/dashboard");

    const workspaceId = (user as any).activeWorkspaceId;
    if (!workspaceId) redirect("/dashboard");

    const params = await searchParams;
    const filter = (params?.filter as "upcoming" | "past" | "cancelled") || "upcoming";
    const now = new Date();

    const where: any = { workspaceId };

    // REP scope
    if (role === "REP") {
        where.profile = { userId: user.id };
    }

    if (filter === "upcoming") {
        where.startTime = { gte: now };
        where.status = { in: ["CONFIRMED", "PENDING"] };
    } else if (filter === "past") {
        where.startTime = { lt: now };
        where.status = { not: "CANCELLED" };
    } else if (filter === "cancelled") {
        where.status = "CANCELLED";
    }

    const bookings = await (prisma as any).booking.findMany({
        where,
        include: {
            meetingType: true,
            profile: {
                include: { user: { select: { name: true, email: true, image: true } } },
            },
        },
        orderBy: { startTime: filter === "past" ? "desc" : "asc" },
        take: 200,
    });

    return (
        <BookingsList
            bookings={JSON.parse(JSON.stringify(bookings))}
            currentFilter={filter}
            role={role}
        />
    );
}
