"use server";

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { LeadGenClient } from "./lead-gen-hub";

export default async function LeadGenPage() {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) redirect("/auth/login");

    const user = await prisma.user.findUnique({
        where: { email: session.user.email },
        include: {
            activeWorkspace: {
                include: {
                    integrations: true,
                    account: true
                }
            }
        }
    });

    if (!user || !user.activeWorkspaceId) redirect("/dashboard");

    const { getEffectiveRole, isSuperAdmin } = await import("@/lib/permissions");
    const effectiveRole = await getEffectiveRole(user);
    const isMaster = await isSuperAdmin(user);
    const planTier = (user.activeWorkspace as any)?.account?.planTier || "FREE";
    const isAllowedRole = effectiveRole === "MANAGER" || effectiveRole === "ADMIN" || effectiveRole === "ACCOUNT_OWNER" || isMaster;
    const isAllowedPlan = planTier === "PRO" || planTier === "ENTERPRISE";
    
    if (!isAllowedRole || !isAllowedPlan) {
        redirect("/dashboard");
    }

    // Fetch stats for insights
    const stats = {
        totalGenerated: await prisma.lead.count({
            where: { 
                workspaceId: user.activeWorkspaceId,
                source: { contains: "_ENGINE" }
            }
        }),
        recentLeads: await prisma.lead.findMany({
            where: { workspaceId: user.activeWorkspaceId },
            orderBy: { createdAt: "desc" },
            take: 10,
            include: { organization: true }
        })
    };

    return (
        <div className="flex-1 space-y-8 p-8 pt-6">
            <div className="flex items-center justify-between space-y-2">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Lead Generation Hub</h2>
                    <p className="text-muted-foreground">
                        Fuel your sales pipeline with high-intent data from premium sources.
                    </p>
                </div>
            </div>

            <LeadGenClient 
                activeWorkspaceId={user.activeWorkspaceId} 
                integrations={user.activeWorkspace?.integrations || []}
                stats={stats}
            />
        </div>
    );
}
