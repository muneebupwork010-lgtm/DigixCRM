"use client";

// Restored to hub
import { useState } from "react";
import { motion } from "framer-motion";
import { 
    Zap, 
    Search, 
    MapPin, 
    Loader2, 
    CheckCircle2, 
    AlertCircle, 
    Sparkles, 
    Globe, 
    Building2, 
    Users,
    TrendingUp,
    ShieldCheck,
    Lock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { generateLeadsAdvanced } from "@/lib/actions/lead-gen";
import { PROVIDERS, ProviderType } from "@/lib/lead-gen-config";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

interface LeadGenClientProps {
    activeWorkspaceId: string;
    integrations: any[];
    stats: {
        totalGenerated: number;
        recentLeads: any[];
    };
}

export function LeadGenClient({ activeWorkspaceId, integrations, stats }: LeadGenClientProps) {
    const [loading, setLoading] = useState(false);
    const [selectedProvider, setSelectedProvider] = useState<string>("MOCK");
    const [niche, setNiche] = useState("");
    const [location, setLocation] = useState("");
    const [limit, setLimit] = useState(20);
    const [maxReviews, setMaxReviews] = useState<number | undefined>(undefined);
    const [hotAndNew, setHotAndNew] = useState(false);
    const router = useRouter();

    const handleGenerate = async () => {
        const provider = PROVIDERS.find((p: any) => p.id === selectedProvider);
        if (provider?.requiresKey && !niche) {
            toast.error("Please provide a niche for premium generation.");
            return;
        }

        setLoading(true);
        try {
            const res = await generateLeadsAdvanced({
                providerId: selectedProvider,
                niche,
                location,
                limit,
                maxReviews,
                hotAndNew
            });

            if (res.success) {
                toast.success(`Successfully generated ${res.count} leads!`);
                router.refresh();
            } else {
                toast.error(res.error || "Generation failed.");
            }
        } catch (error) {
            toast.error("An unexpected error occurred.");
        } finally {
            setLoading(false);
        }
    };

    const getBadgeColor = (type: ProviderType) => {
        switch (type) {
            case "FREE": return "bg-emerald-500/10 text-emerald-600 border-emerald-500/20";
            case "PAID": return "bg-blue-500/10 text-blue-600 border-blue-500/20";
            case "PREMIUM": return "bg-purple-500/10 text-purple-600 border-purple-500/20 shadow-[0_0_15px_rgba(168,85,247,0.15)]";
        }
    };

    return (
        <div className="grid gap-8 lg:grid-cols-12">
            {/* Left Column: Configuration & Stats */}
            <div className="lg:col-span-8 space-y-8">
                {/* Stats Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="bg-gradient-to-br from-blue-50 to-white dark:from-blue-950/20 dark:to-card border-blue-100 dark:border-blue-900/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Auto-Generated Leads</CardTitle>
                            <Sparkles className="h-4 w-4 text-blue-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalGenerated}</div>
                            <p className="text-xs text-muted-foreground mt-1">Generated via engines</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-purple-50 to-white dark:from-purple-950/20 dark:to-card border-purple-100 dark:border-purple-900/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Premium Sources</CardTitle>
                            <TrendingUp className="h-4 w-4 text-purple-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">4 Active</div>
                            <p className="text-xs text-muted-foreground mt-1">Verified integrations</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-emerald-50 to-white dark:from-emerald-950/20 dark:to-card border-emerald-100 dark:border-emerald-900/30">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Cost Savings</CardTitle>
                            <Users className="h-4 w-4 text-emerald-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">High ROI</div>
                            <p className="text-xs text-muted-foreground mt-1">Compared to cold lists</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Provider Grid */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold flex items-center gap-2">
                            <Globe className="w-5 h-5 text-indigo-500" />
                            Choose Your Engine
                        </h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        {PROVIDERS.map((provider: any) => {
                            const isSelected = selectedProvider === provider.id;
                            const isIntegrationActive = integrations.some((i: any) => i.provider === provider.id && i.isActive);
                            
                            return (
                                <motion.div
                                    key={provider.id}
                                    whileHover={{ y: -4 }}
                                    whileTap={{ scale: 0.98 }}
                                    onClick={() => setSelectedProvider(provider.id)}
                                    className="cursor-pointer"
                                >
                                    <Card className={cn(
                                        "h-full transition-all border-2 relative overflow-hidden group",
                                        isSelected 
                                            ? "border-primary bg-primary/5 ring-4 ring-primary/10" 
                                            : "border-border/60 hover:border-border hover:shadow-md"
                                    )}>
                                        <CardHeader className="pb-3">
                                            <div className="flex justify-between items-start">
                                                <Badge className={cn("mb-2 font-bold", getBadgeColor(provider.type))}>
                                                    {provider.type}
                                                </Badge>
                                                {provider.requiresKey && (
                                                    isIntegrationActive ? (
                                                        <ShieldCheck className="w-4 h-4 text-emerald-500" />
                                                    ) : (
                                                        <Lock className="w-4 h-4 text-muted-foreground/50" />
                                                    )
                                                )}
                                            </div>
                                            <CardTitle className="text-base font-bold flex items-center gap-2">
                                                {provider.name}
                                                {isSelected && (
                                                    <motion.div layoutId="check" initial={{ scale: 0 }} animate={{ scale: 1 }}>
                                                        <CheckCircle2 className="w-4 h-4 text-primary" />
                                                    </motion.div>
                                                )}
                                            </CardTitle>
                                            <CardDescription className="text-xs leading-relaxed mt-2">
                                                {provider.description}
                                            </CardDescription>
                                        </CardHeader>
                                    </Card>
                                </motion.div>
                            );
                        })}
                    </div>
                </div>

                {/* Configuration Panel */}
                <Card className="border-border/60 shadow-xl bg-card/50 backdrop-blur-sm">
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-amber-500" />
                            Targeting Parameters
                        </CardTitle>
                        <CardDescription>Define your ideal prospect profile for the generation engine.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3">
                                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                                    <Search className="w-3 h-3" /> Niche / Industry
                                </label>
                                <Input 
                                    placeholder="e.g. Solar, SaaS, Law, Finance..." 
                                    value={niche}
                                    onChange={(e: any) => setNiche(e.target.value)}
                                    className="h-12 bg-background/50 border-border/60 focus:ring-primary/20"
                                />
                            </div>
                            <div className="space-y-3">
                                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                                    <MapPin className="w-3 h-3" /> Target Location
                                </label>
                                <Input 
                                    placeholder="e.g. London, Dubai, New York..." 
                                    value={location}
                                    onChange={(e: any) => setLocation(e.target.value)}
                                    className="h-12 bg-background/50 border-border/60 focus:ring-primary/20"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3">
                                <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Volume Control</label>
                                <div className="flex items-center gap-2">
                                    {[10, 20, 50, 100].map((v) => (
                                        <Button
                                            key={v}
                                            variant={limit === v ? "default" : "outline"}
                                            onClick={() => setLimit(v)}
                                            className="flex-1 h-10 font-bold text-xs px-1"
                                        >
                                            {v}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                            
                                {selectedProvider === "YELP" && (
                                    <>
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground text-blue-600">Max Reviews Filter</label>
                                            <div className="flex items-center gap-2">
                                                {[
                                                    { label: "Any", val: undefined },
                                                    { label: "< 10", val: 9 },
                                                    { label: "< 20", val: 19 },
                                                    { label: "< 50", val: 49 },
                                                ].map((opt) => (
                                                    <Button
                                                        key={opt.label}
                                                        variant={maxReviews === opt.val ? "default" : "outline"}
                                                        onClick={() => setMaxReviews(opt.val)}
                                                        className="flex-1 h-10 font-bold text-xs px-1"
                                                    >
                                                        {opt.label}
                                                    </Button>
                                                ))}
                                            </div>
                                        </div>
                                        <div className="col-span-1 md:col-span-2 flex items-center justify-between p-4 rounded-lg border border-blue-500/20 bg-blue-500/5">
                                            <div className="space-y-0.5">
                                                <label className="text-sm font-bold text-blue-700 dark:text-blue-400 flex items-center gap-2">
                                                    <Sparkles className="w-4 h-4" /> Hot & New Businesses Only
                                                </label>
                                                <p className="text-xs text-muted-foreground">Only fetch brand new businesses recently added to Yelp.</p>
                                            </div>
                                            <Switch checked={hotAndNew} onCheckedChange={setHotAndNew} />
                                        </div>
                                    </>
                                )}
                            </div>
                        </CardContent>
                        <CardFooter className="bg-muted/30 border-t p-6">
                        <Button 
                            className="w-full h-14 text-lg font-black tracking-tight gap-3 shadow-2xl shadow-primary/30 active:scale-95 transition-all"
                            onClick={handleGenerate}
                            disabled={loading}
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-6 h-6 animate-spin" />
                                    Powering Up Engines...
                                </>
                            ) : (
                                <>
                                    <Zap className="w-6 h-6 fill-current" />
                                    Initiate Intelligence Extraction
                                </>
                            )}
                        </Button>
                    </CardFooter>
                </Card>
            </div>

            {/* Right Column: History & Feed */}
            <div className="lg:col-span-4 space-y-6">
                <Card className="h-full border-border/60 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-emerald-500" />
                            Recent Generations
                        </CardTitle>
                        <CardDescription>Live feed of leads extracted into your workspace.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="divide-y divide-border/40">
                            {stats.recentLeads.map((lead: any) => (
                                <div key={lead.id} className="p-4 hover:bg-muted/30 transition-colors flex items-center gap-4 group">
                                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs shrink-0 group-hover:scale-110 transition-transform">
                                        {lead.firstName[0]}{lead.lastName[0]}
                                    </div>
                                    <div className="min-w-0 flex-1">
                                        <p className="text-sm font-bold truncate capitalize">{lead.firstName} {lead.lastName}</p>
                                        <p className="text-[10px] text-muted-foreground truncate uppercase tracking-widest font-medium">
                                            {lead.organization?.name || "Independent"} • {lead.source}
                                        </p>
                                    </div>
                                    <Badge variant="outline" className="text-[9px] font-bold uppercase px-1.5 h-5">
                                        {lead.status}
                                    </Badge>
                                </div>
                            ))}
                            {stats.recentLeads.length === 0 && (
                                <div className="p-12 text-center space-y-3">
                                    <Users className="w-12 h-12 text-muted-foreground/20 mx-auto" />
                                    <p className="text-sm text-muted-foreground">Your pipeline is waiting for fuel.</p>
                                </div>
                            )}
                        </div>
                    </CardContent>
                    {stats.recentLeads.length > 0 && (
                        <CardFooter className="p-4 border-t justify-center">
                            <Button variant="ghost" size="sm" className="text-xs font-bold text-primary hover:bg-primary/5" onClick={() => router.push('/dashboard/leads')}>
                                View All Leads
                            </Button>
                        </CardFooter>
                    )}
                </Card>

                {/* System Tips */}
                <div className="p-6 rounded-2xl bg-indigo-600 text-white space-y-3 shadow-xl shadow-indigo-500/20 relative overflow-hidden">
                    <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl" />
                    <Sparkles className="w-8 h-8 text-indigo-200" />
                    <h4 className="font-black tracking-tight text-lg">Pro Tip: Buying Signals</h4>
                    <p className="text-indigo-100 text-xs leading-relaxed font-medium">
                        Use the **Google News Signal** engine to find leads that just announced funding or expansions. These are 5x more likely to convert than cold lists.
                    </p>
                </div>
            </div>
        </div>
    );
}
