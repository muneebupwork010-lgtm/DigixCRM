import Link from "next/link";
import { OverviewCharts } from "@/components/dashboard/overview-charts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Activity, Target, CheckCircle2, TrendingUp, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getScopeWhere, getEffectiveRole, canSeeFinancials, canAccessCRM, canAccessPMS } from "@/lib/permissions";
import { DashboardControls } from "@/components/dashboard/dashboard-controls";
import { AiReportDialog } from "@/components/dashboard/ai-report-dialog";
import { subMonths, startOfMonth, endOfMonth, format, subDays } from "date-fns";
import { getCachedDashboardData } from "@/lib/actions/dashboard";

export const dynamic = "force-dynamic";

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ period?: string }> }) {
    const session = await getServerSession(authOptions);
    const user = await prisma.user.findUnique({ where: { email: session?.user?.email || "" } });
    const effectiveRole = await getEffectiveRole(user);
    const showFinancials = canSeeFinancials(effectiveRole);
    const hasCRM = canAccessCRM(effectiveRole);
    const hasPMS = canAccessPMS(effectiveRole);

    const scopeWhere = getScopeWhere(effectiveRole, user?.id as string, (user as any)?.activeWorkspaceId);

    // Resolve the selected period into a start date
    const resolvedParams = await searchParams;
    const periodParam = resolvedParams?.period || "6m";
    const now = new Date();
    const periodMonths = periodParam === "3m" ? 3 : periodParam === "12m" ? 12 : 6;
    const periodStart = startOfMonth(subMonths(now, periodMonths - 1));
    const periodFilter = { gte: periodStart };

    // Fetch Workspace for dynamic stages
    const workspace = await prisma.workspace.findUnique({
        where: { id: (user as any)?.activeWorkspaceId || "" }
    });
    
    // UNIFIED DEFAULTS: Prospect -> Contacted -> Negotiation -> Won -> Lost
    const stagesConfig: any[] = (workspace?.dealStages as any) || [
        { id: "s1", value: "QUALIFICATION", label: "Prospect" },
        { id: "s2", value: "PROPOSAL", label: "Contacted" },
        { id: "s3", value: "NEGOTIATION", label: "Negotiation" },
        { id: "s4", value: "WON", label: "Won" },
        { id: "s5", value: "LOST", label: "Lost" }
    ];

    // 1. Fetch Metrics using our High-Performance Cache
    const {
        totalLeads,
        convertedLeads,
        totalWon,
        activeDeals,
        totalActivities,
        dealsByStage,
        allDeals,
        myActiveTasksCount,
        myOverdueTasksCount,
        weeklyTaskActivity,
        overdueTasksList,
        topProjects,
        weeklyLeadActivity,
        recentLeads,
        hotDeals
    } = await getCachedDashboardData(
        user?.id as string,
        (user as any).activeWorkspaceId,
        effectiveRole,
        showFinancials,
        scopeWhere,
        periodMonths
    );

    // Process Weekly Activity for Graph (Only if they have PMS access)
    const weeklyTrend = hasPMS ? Array.from({ length: 7 }, (_, i) => {
        const day = subDays(new Date(), 6 - i);
        const dayLabel = format(day, "EEE");
        const created = weeklyTaskActivity.filter(t => format(new Date(t.createdAt), "yyyy-MM-dd") === format(day, "yyyy-MM-dd")).length;
        const completed = weeklyTaskActivity.filter(t => t.status === "DONE" && format(new Date(t.updatedAt), "yyyy-MM-dd") === format(day, "yyyy-MM-dd")).length;
        return { name: dayLabel, created, completed };
    }) : [];

    // Process Weekly Lead Activity for SalesPulse
    const salesTrend = hasCRM ? Array.from({ length: 7 }, (_, i) => {
        const day = subDays(new Date(), 6 - i);
        const dayLabel = format(day, "EEE");
        const leads = weeklyLeadActivity.filter(l => format(new Date(l.createdAt), "yyyy-MM-dd") === format(day, "yyyy-MM-dd")).length;
        const converted = weeklyLeadActivity.filter(l => l.status === "CONVERTED" && format(new Date(l.createdAt), "yyyy-MM-dd") === format(day, "yyyy-MM-dd")).length;
        return { name: dayLabel, leads, converted };
    }) : [];

    // Process Project Progress for Mini-cards
    const projectBriefs = hasPMS ? topProjects.map(p => {
        const total = p._count.tasks;
        const done = p.tasks.length;
        return {
            id: p.id,
            name: p.name,
            progress: total > 0 ? Math.round((done / total) * 100) : 0,
            tasksLeft: total - done
        };
    }) : [];

    // Aggregate deals by stage for the funnel
    const aggregatedStages = (showFinancials && hasCRM) ? stagesConfig.map(s => {
        const matchingDeals = dealsByStage.filter((d: any) => 
            d.customStage ? d.customStage === s.value : d.stage === s.value
        );
        return {
            name: s.label,
            value: matchingDeals.length,
            amount: matchingDeals.reduce((sum: number, d: any) => sum + (d.value || 0), 0)
        };
    }) : [];

    // Real Monthly Revenue Trend
    const monthlyRevenueTrend = (showFinancials && hasCRM) ? Array.from({ length: periodMonths }, (_, i) => {
        const monthDate = subMonths(now, (periodMonths - 1) - i);
        const start = startOfMonth(monthDate);
        const end = endOfMonth(monthDate);
        const label = format(monthDate, "MMM");

        const monthDeals = (allDeals as any[]).filter(d => {
            const date = new Date(d.updatedAt);
            return date >= start && date <= end;
        });

        const won = monthDeals
            .filter((d: any) => d.stage === "WON" || (d as any).customStage === "ONBOARDED")
            .reduce((sum: number, d: any) => sum + (d.value || 0), 0);

        const pipeline = monthDeals
            .filter((d: any) => !["WON", "LOST"].includes(d.stage))
            .reduce((sum: number, d: any) => sum + (d.value || 0), 0);

        return { name: label, won, pipeline };
    }) : [];

    // 3. Funnel Data (now limited to first 4 stages for UI balance, or all)
    const funnelData = aggregatedStages.filter(s => s.name !== "Lost");

    // 4. Computed Stats (Derived from Cached Metrics)
    const conversionRate = totalLeads > 0 ? ((convertedLeads / totalLeads) * 100).toFixed(1) : "0.0";
    const totalPipelineValue = (showFinancials && hasCRM) ? (allDeals as any[]).filter((d: any) => !["WON", "LOST"].includes(d.stage)).reduce((s: number, d: any) => s + (d.value || 0), 0) : 0;
    const negotiationDeals = aggregatedStages.find((s: any) => s.name === "Negotiation")?.value || 0;

    const formatCurrency = (amount: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount);
    
    return (
        <div className="flex-1 space-y-6 sm:space-y-12 animate-in fade-in duration-700 pb-10">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between pb-8 gap-6 border-b border-border/40">
                <div className="space-y-1">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="bg-primary/10 p-2 rounded-xl">
                            <Zap className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary/80">Command Center v2</span>
                    </div>
                    <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-foreground flex items-center gap-4 leading-none">
                        Good Morning
                        <span className="text-muted-foreground/40 font-black">/</span>
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/50">{user?.name?.split(' ')[0]}</span>
                    </h2>
                </div>
                <div className="flex items-center gap-3">
                    <DashboardControls />
                    <AiReportDialog
                        metrics={{
                            totalWon,
                            activeDeals,
                            showFinancials,
                            conversionRate: parseFloat(conversionRate),
                            totalActivities,
                            totalLeads,
                            convertedLeads,
                            totalPipelineValue,
                            negotiationDeals,
                            funnelData,
                            myActiveTasks: myActiveTasksCount,
                            myOverdueTasks: myOverdueTasksCount
                        }}
                    />
                </div>
            </div>

            {/* Layer 1: Executive KPI Tiles */}
            <div className={`grid gap-6 grid-cols-1 sm:grid-cols-2 ${showFinancials && hasCRM ? 'lg:grid-cols-4' : 'lg:grid-cols-2'}`}>
                {showFinancials && hasCRM && (
                    <KPITile 
                        title="Net Revenue" 
                        value={formatCurrency(totalWon)} 
                        subValue="Confirmed Won" 
                        icon={<Target className="w-5 h-5" />} 
                        trend="+12.5%"
                        href="/dashboard/deals?view=forecast"
                    />
                )}
                {showFinancials && hasCRM && (
                    <KPITile 
                        title="Active Pipeline" 
                        value={formatCurrency(totalPipelineValue)} 
                        subValue={`${activeDeals} live deals`} 
                        icon={<Briefcase className="w-5 h-5" />} 
                        color="indigo" 
                        href="/dashboard/deals"
                    />
                )}
                {(!showFinancials || !hasCRM) && (
                   <KPITile 
                        title="Total Activities" 
                        value={totalActivities} 
                        subValue="Historical Pulse" 
                        icon={<Activity className="w-5 h-5" />} 
                        color="emerald" 
                        href="/dashboard/activities"
                    />
                )}
                {hasCRM && (
                    <KPITile 
                        title="Conversion" 
                        value={`${conversionRate}%`} 
                        subValue={`${convertedLeads} leads converted`} 
                        icon={<TrendingUp className="w-5 h-5" />} 
                        color="emerald" 
                        href="/dashboard/leads"
                    />
                )}
                {hasPMS && (
                    <KPITile 
                        title="My Load" 
                        value={myActiveTasksCount} 
                        subValue={myOverdueTasksCount > 0 ? `${myOverdueTasksCount} overdue` : "All on track"} 
                        icon={<Activity className="w-5 h-5" />} 
                        color={myOverdueTasksCount > 0 ? "red" : "blue"}
                        href="/dashboard/projects"
                        isAlert={myOverdueTasksCount > 0}
                    />
                )}
            </div>

            {/* Layer 2: Intelligence Bento Grid (Hide if no PMS and no CRM access) */}
            {(hasPMS || hasCRM) && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        {hasPMS ? <WeeklyPulse data={weeklyTrend} /> : (
                            hasCRM ? <SalesPulse data={salesTrend} /> : (
                                <div className="h-full flex items-center justify-center border border-dashed rounded-[2.5rem] bg-muted/5 p-10 text-center">
                                    <p className="text-muted-foreground text-sm font-medium">Dashboard access restricted for your current role.</p>
                                </div>
                            )
                        )}
                    </div>
                    <div className="lg:col-span-1">
                        <IntelligenceFeed 
                            overdueTasks={hasPMS ? overdueTasksList : []} 
                            projectBriefs={hasPMS ? projectBriefs : []}
                            recentLeads={hasCRM ? recentLeads : []}
                            hotDeals={hasCRM ? hotDeals : []}
                        />
                    </div>
                </div>
            )}

            {/* Layer 3: Financial deep-dive */}
            {showFinancials && hasCRM && (
                <div className="pt-8 border-t border-border/40">
                    <div className="flex items-center justify-between mb-8">
                        <div>
                            <h3 className="text-xl font-black tracking-tight">Financial Performance</h3>
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mt-1">Deep-dive into conversion and revenue forecasting</p>
                        </div>
                    </div>
                    <div className="w-full overflow-hidden">
                        <OverviewCharts trendData={monthlyRevenueTrend} funnelData={funnelData} />
                    </div>
                </div>
            )}
        </div>
    );
}
import { WeeklyPulse, IntelligenceFeed, SalesPulse } from "@/components/dashboard/dashboard-bento";
import { Zap } from "lucide-react";

function KPITile({ title, value, subValue, icon, color = "primary", href, trend, isAlert }: any) {
    const colorMap: any = {
        primary: "bg-primary/10 text-primary border-primary/20 shadow-primary/5",
        indigo: "bg-indigo-500/10 text-indigo-500 border-indigo-500/20 shadow-indigo-500/5",
        emerald: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 shadow-emerald-500/5",
        blue: "bg-blue-500/10 text-blue-500 border-blue-500/20 shadow-blue-500/5",
        red: "bg-red-500/10 text-red-500 border-red-500/20 shadow-red-500/5"
    };

    return (
        <Link href={href}>
            <Card className={cn(
                "relative overflow-hidden group border-border/40 bg-card hover:bg-muted/5 transition-all duration-500 rounded-[2.5rem] shadow-sm hover:shadow-2xl hover:-translate-y-1.5 cursor-pointer h-full p-8",
                isAlert && "hover:border-red-500/40"
            )}>
                <div className="flex justify-between items-start mb-6">
                    <div className={cn("p-3 rounded-2xl border transition-transform group-hover:rotate-12 duration-500", colorMap[color])}>
                        {icon}
                    </div>
                    {trend && <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full">{trend}</span>}
                    {isAlert && <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />}
                </div>
                <div className="space-y-1">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">{title}</p>
                    <h3 className="text-3xl font-black tracking-tighter text-foreground truncate">{value}</h3>
                    <p className={cn("text-[10px] font-black uppercase tracking-widest mt-2", isAlert ? "text-red-500" : "text-muted-foreground/40")}>
                        {subValue}
                    </p>
                </div>
            </Card>
        </Link>
    );
}
