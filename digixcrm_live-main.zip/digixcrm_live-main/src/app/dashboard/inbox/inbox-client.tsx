"use client";

import { useState, useEffect, useRef } from "react";
import { ChatBox } from "@/components/chat/chat-box";
import { getOrCreateDirectConversation, markConversationAsRead } from "@/lib/actions/chat";
import { User, MessageSquare, Plus, Hash } from "lucide-react";
import { cn } from "@/lib/utils";
import { getPusherClient } from "@/lib/pusher-client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function InboxClient({ initialConversations, currentUserId, currentUser, allUsers }: any) {
    const [conversations, setConversations] = useState<any[]>(initialConversations);
    const [activeId, setActiveId] = useState<string | null>(initialConversations[0]?.id || null);
    const [showUsers, setShowUsers] = useState(false);

    const activeIdRef = useRef(activeId);
    useEffect(() => {
        activeIdRef.current = activeId;
    }, [activeId]);

    // Mark active conversation as read
    useEffect(() => {
        if (!activeId) return;

        const markAsRead = async () => {
            await markConversationAsRead(activeId);
            setConversations(prev =>
                prev.map(c =>
                    c.id === activeId
                        ? { ...c, unreadCount: 0, hasMention: false }
                        : c
                )
            );
        };

        markAsRead();
    }, [activeId]);

    // Pusher real-time updates for unread counts, mentions, and sorting
    useEffect(() => {
        const pusher = getPusherClient();
        if (!pusher) return;

        const channels = conversations.map(conv => {
            const channelName = `chat-${conv.id}`;
            const channel = pusher.subscribe(channelName);

            channel.bind("new-message", (newMessage: any) => {
                const isMe = newMessage.senderId === currentUserId;
                const isActive = activeIdRef.current === conv.id;

                if (isActive && !isMe) {
                    markConversationAsRead(conv.id);
                }

                let isMentioned = false;
                if (!isMe && currentUser?.name) {
                    const firstName = currentUser.name.split(" ")[0].toLowerCase();
                    const lowercaseContent = newMessage.content.toLowerCase();
                    isMentioned = lowercaseContent.includes(`@${firstName}`) || 
                                  lowercaseContent.includes(`@${currentUser.name.toLowerCase()}`);
                }

                setConversations(prev => {
                    const conversationIndex = prev.findIndex(c => c.id === conv.id);
                    if (conversationIndex === -1) return prev;

                    const updatedConv = {
                        ...prev[conversationIndex],
                        messages: [newMessage],
                        unreadCount: isActive ? 0 : (isMe ? prev[conversationIndex].unreadCount : prev[conversationIndex].unreadCount + 1),
                        hasMention: isActive ? false : (prev[conversationIndex].hasMention || isMentioned)
                    };

                    const newConversations = [...prev];
                    newConversations[conversationIndex] = updatedConv;

                    // Push updated conversation to the top
                    return [updatedConv, ...newConversations.filter(c => c.id !== conv.id)];
                });
            });

            return { channel, name: channelName };
        });

        return () => {
            channels.forEach(ch => {
                ch.channel.unbind("new-message");
                pusher.unsubscribe(ch.name);
            });
        };
    }, [currentUserId, currentUser, conversations.length]);

    const handleStartChat = async (userId: string) => {
        const res = await getOrCreateDirectConversation(userId);
        if (res.success && res.conversation) {
            const exists = conversations.find(c => c.id === res.conversation.id);
            if (!exists) {
                // Fetch dynamic name mapping on direct chat start
                const decoratedConv = {
                    ...res.conversation,
                    unreadCount: 0,
                    hasMention: false,
                    projectName: null
                };
                setConversations([decoratedConv, ...conversations]);
            }
            setActiveId(res.conversation.id);
            setShowUsers(false);
        }
    };

    // Calculate active chat header details
    const activeConv = conversations.find(c => c.id === activeId);
    let chatTitle = "Chat";
    let chatSubtitle = "";
    let projectLink = "";

    if (activeConv) {
        if (activeConv.type === "PROJECT") {
            chatTitle = activeConv.projectName || "Project Chat";
            chatSubtitle = "Project Chat Channel";
            const projId = activeConv.projectId || (activeConv.id.startsWith("project-") ? activeConv.id.replace("project-", "") : null);
            if (projId) {
                projectLink = `/dashboard/projects/${projId}`;
            }
        } else {
            const otherParticipant = activeConv.participants.find((p: any) => p.userId !== currentUserId);
            chatTitle = otherParticipant?.user?.name || otherParticipant?.user?.email || "Direct Message";
            chatSubtitle = "Direct Message";
        }
    }

    const getInitials = (name: string) => {
        if (!name) return "?";
        return name
            .split(" ")
            .map(n => n[0])
            .join("")
            .toUpperCase()
            .slice(0, 2);
    };

    const renderConversation = (conv: any) => {
        const otherParticipant = conv.participants.find((p: any) => p.userId !== currentUserId);
        const otherUser = otherParticipant?.user;
        const isActive = activeId === conv.id;
        const lastMsg = conv.messages?.[0]?.content || "No messages yet";
        const hasUnreads = conv.unreadCount > 0;

        return (
            <button
                key={conv.id}
                onClick={() => setActiveId(conv.id)}
                className={cn(
                    "w-full flex items-start gap-3 p-3 rounded-xl transition-all text-left border relative",
                    isActive 
                        ? "bg-primary/5 border-primary/20 shadow-sm" 
                        : "hover:bg-muted/60 border-transparent hover:border-muted-foreground/10"
                )}
            >
                {isActive && (
                    <div className="absolute left-0 top-3 bottom-3 w-1 rounded-r-full bg-primary" />
                )}
                
                <div className="shrink-0 mt-0.5">
                    {conv.type === "PROJECT" ? (
                        <div className="w-10 h-10 rounded-full bg-indigo-500/10 text-indigo-500 flex items-center justify-center font-semibold text-lg shrink-0">
                            <Hash className="w-5 h-5 text-indigo-500" />
                        </div>
                    ) : (
                        otherUser?.image ? (
                            <img src={otherUser.image} alt={otherUser.name || "User"} className="w-10 h-10 rounded-full object-cover" />
                        ) : (
                            <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold text-sm shrink-0">
                                {getInitials(otherUser?.name || otherUser?.email || "U")}
                            </div>
                        )
                    )}
                </div>
                
                <div className="flex-1 overflow-hidden">
                    <div className="flex items-center justify-between gap-2">
                        <div className={cn(
                            "text-sm truncate text-foreground",
                            hasUnreads ? "font-bold" : "font-semibold"
                        )}>
                            {conv.type === "PROJECT" ? (conv.projectName || "Project Chat") : (otherUser?.name || "Unknown User")}
                        </div>
                        
                        {/* Notification Badge Indicators */}
                        <div className="flex items-center gap-1.5 shrink-0">
                            {conv.hasMention && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-rose-500/10 text-rose-500 border border-rose-500/20 shadow-sm animate-pulse shrink-0">
                                    @ Mention
                                </span>
                            )}
                            {hasUnreads && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground shadow-sm min-w-[18px] text-center shrink-0">
                                    {conv.unreadCount}
                                </span>
                            )}
                        </div>
                    </div>
                    <div className={cn(
                        "text-xs truncate mt-0.5",
                        hasUnreads ? "font-semibold text-foreground" : "text-muted-foreground"
                    )}>
                        {lastMsg}
                    </div>
                </div>
            </button>
        );
    };

    const hasUnreadDirect = conversations.some(c => c.type !== "PROJECT" && (c.unreadCount > 0 || c.hasMention));
    const hasUnreadProject = conversations.some(c => c.type === "PROJECT" && (c.unreadCount > 0 || c.hasMention));

    return (
        <div className="flex w-full h-full border border-border rounded-xl bg-card overflow-hidden shadow-sm">
            {/* Sidebar List */}
            <div className="w-[300px] border-r border-border flex flex-col bg-muted/10 shrink-0">
                <div className="p-4 border-b border-border flex justify-between items-center bg-card">
                    <h2 className="font-semibold text-foreground">Messages</h2>
                    <button 
                        onClick={() => setShowUsers(!showUsers)}
                        className="p-1.5 rounded-md hover:bg-muted text-muted-foreground transition-colors"
                        title="New Chat"
                    >
                        <Plus className="w-4 h-4" />
                    </button>
                </div>

                {showUsers ? (
                    <div className="flex-1 overflow-y-auto p-2 space-y-1">
                        <div className="px-2 py-1 text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                            Start new chat
                        </div>
                        {allUsers.map((u: any) => (
                            <button
                                key={u.id}
                                onClick={() => handleStartChat(u.id)}
                                className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted text-left transition-colors"
                            >
                                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                    <User className="w-4 h-4 text-primary" />
                                </div>
                                <span className="font-medium text-sm truncate">{u.name || u.email}</span>
                            </button>
                        ))}
                    </div>
                ) : (
                    <Tabs defaultValue="direct" className="flex-1 flex flex-col overflow-hidden">
                        <div className="px-3 pt-3 pb-2 border-b border-border/50">
                            <TabsList className="w-full grid grid-cols-2">
                                <TabsTrigger value="direct" className="relative">
                                    Direct
                                    {hasUnreadDirect && (
                                        <span className="absolute top-2 right-3 w-2 h-2 rounded-full bg-primary" />
                                    )}
                                </TabsTrigger>
                                <TabsTrigger value="project" className="relative">
                                    Projects
                                    {hasUnreadProject && (
                                        <span className="absolute top-2 right-3 w-2 h-2 rounded-full bg-primary" />
                                    )}
                                </TabsTrigger>
                            </TabsList>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto">
                            <TabsContent value="direct" className="h-full m-0 p-2 space-y-1 outline-none">
                                {conversations.filter(c => c.type !== "PROJECT").length === 0 ? (
                                    <div className="p-4 text-center text-sm text-muted-foreground">
                                        No direct messages yet. Click + to start one.
                                    </div>
                                ) : (
                                    conversations.filter(c => c.type !== "PROJECT").map(renderConversation)
                                )}
                            </TabsContent>
                            
                            <TabsContent value="project" className="h-full m-0 p-2 space-y-1 outline-none">
                                {conversations.filter(c => c.type === "PROJECT").length === 0 ? (
                                    <div className="p-4 text-center text-sm text-muted-foreground">
                                        No project chats yet.
                                    </div>
                                ) : (
                                    conversations.filter(c => c.type === "PROJECT").map(renderConversation)
                                )}
                            </TabsContent>
                        </div>
                    </Tabs>
                )}
            </div>

            {/* Main Chat Area */}
            <div className="flex-1 bg-card relative">
                {activeId ? (
                    <ChatBox 
                        conversationId={activeId} 
                        title={chatTitle}
                        subtitle={chatSubtitle}
                        projectLink={projectLink}
                    />
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                        <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
                        <p>Select a conversation to start messaging</p>
                    </div>
                )}
            </div>
        </div>
    );
}
