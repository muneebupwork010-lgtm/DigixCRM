// Force TS cache refresh
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { InboxClient } from "@/app/dashboard/inbox/inbox-client";

export default async function InboxPage() {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) redirect("/auth/login"); // Fallback

    const currentUser = await prisma.user.findUnique({
        where: { id: userId },
        select: { id: true, name: true, email: true }
    });

    const participants = await prisma.conversationParticipant.findMany({
        where: { userId: userId },
        include: {
            conversation: {
                include: {
                    participants: {
                        include: { user: { select: { id: true, name: true, image: true } } }
                    },
                    messages: {
                        orderBy: { createdAt: 'desc' },
                        take: 1
                    }
                }
            }
        }
    });

    const rawConversations = participants.map(p => ({
        ...p.conversation,
        lastReadAt: p.lastReadAt,
    }));

    const projectIds = rawConversations
        .filter(c => c.type === "PROJECT")
        .map(c => c.projectId || (c.id.startsWith("project-") ? c.id.replace("project-", "") : null))
        .filter(Boolean) as string[];

    const projects = await prisma.project.findMany({
        where: { id: { in: projectIds } },
        select: { id: true, name: true }
    });

    const projectMap = new Map(projects.map(p => [p.id, p.name]));

    const conversations = await Promise.all(rawConversations.map(async (conv) => {
        const lastReadAt = conv.lastReadAt || new Date(0);

        const unreadCount = await prisma.message.count({
            where: {
                conversationId: conv.id,
                senderId: { not: userId },
                createdAt: { gt: lastReadAt }
            }
        });

        const hasMention = await prisma.mention.count({
            where: {
                userId: userId,
                message: {
                    conversationId: conv.id,
                    createdAt: { gt: lastReadAt }
                }
            }
        }) > 0;

        let projectName = null;
        if (conv.type === "PROJECT") {
            const projId = conv.projectId || (conv.id.startsWith("project-") ? conv.id.replace("project-", "") : null);
            projectName = projId ? projectMap.get(projId) : null;
        }

        return {
            ...conv,
            unreadCount,
            hasMention,
            projectName
        };
    }));

    const users = await prisma.user.findMany({
        select: { id: true, name: true, email: true, image: true },
        where: {
            id: { not: userId }
        }
    });

    conversations.sort((a, b) => {
        const aTime = a.messages?.[0]?.createdAt ? new Date(a.messages[0].createdAt).getTime() : new Date(a.createdAt).getTime();
        const bTime = b.messages?.[0]?.createdAt ? new Date(b.messages[0].createdAt).getTime() : new Date(b.createdAt).getTime();
        return bTime - aTime;
    });

    return (
        <div className="h-[calc(100vh-5rem)] flex flex-col p-4 md:p-8 max-w-7xl mx-auto w-full">
            <div className="flex items-center justify-between mb-6 shrink-0">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Inbox</h1>
                    <p className="text-muted-foreground mt-1">Direct messages and project activity</p>
                </div>
            </div>
            
            <InboxClient 
                initialConversations={conversations} 
                currentUserId={userId}
                currentUser={currentUser}
                allUsers={users}
            />
        </div>
    );
}
