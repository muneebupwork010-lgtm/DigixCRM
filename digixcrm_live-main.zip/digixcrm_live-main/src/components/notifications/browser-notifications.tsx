"use client";

import { useEffect, useState } from "react";
import { getUnreadNotifications, markAsRead } from "@/lib/actions/notifications";
import { toast } from "sonner";

export function BrowserNotifications() {
    const [permission, setPermission] = useState<NotificationPermission | "default">("default");

    useEffect(() => {
        if ("Notification" in window) {
            setPermission(Notification.permission);
            if (Notification.permission === "default") {
                Notification.requestPermission().then(setPermission);
            }
        }
    }, []);

    useEffect(() => {
        const checkNotifications = async () => {
            if (permission !== "granted") return;

            try {
                const notifications = await getUnreadNotifications();

                for (const notification of notifications) {
                    // Show browser notification
                    new Notification(notification.title, {
                        body: notification.message,
                        icon: "/favicon.ico", // Fallback to favicon
                    });

                    // Show in-app toast for better UX
                    toast(notification.title, {
                        description: notification.message,
                    });

                    // Mark as read
                    await markAsRead(notification.id);
                }
            } catch (err) {
                // Silently ignore network failures during background polling
                console.debug("Background notification sync paused due to network");
            }
        };

        // Initial check
        checkNotifications();

        // Check every 60 seconds
        const interval = setInterval(checkNotifications, 60000);
        return () => clearInterval(interval);
    }, [permission]);

    return null; // This component doesn't render anything visible
}
