"use client";

import { useState } from "react";
import { format, addDays, parseISO, startOfWeek, addWeeks, subWeeks, isToday, isSameDay } from "date-fns";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
    CalendarClock, ChevronLeft, ChevronRight, Plus, Video, MapPin, Clock,
    User, Mail, Phone, Copy, Check, ExternalLink
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";
import { BookOnBehalfDialog } from "./book-on-behalf-dialog";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

interface BookingItem {
    id: string;
    startTime: string;
    endTime: string;
    guestName: string;
    guestEmail: string;
    guestPhone?: string;
    guestNotes?: string;
    status: string;
    meetingLink?: string;
    location?: string;
    meetingType: {
        name: string;
        duration: number;
        color: string;
        mode: string;
    };
    profile: {
        displayName?: string;
        user: { name: string; email: string; image?: string };
    };
}

export function SchedulerCalendarView({
    bookings,
    consultants,
    currentWeekStart,
    role,
    myProfile,
    workspaceId,
}: {
    bookings: BookingItem[];
    consultants: any[];
    currentWeekStart: string;
    role: string;
    myProfile: any;
    workspaceId: string;
}) {
    const router = useRouter();
    const weekStart = parseISO(currentWeekStart);
    const [view, setView] = useState<"week" | "day">("week");
    const [selectedDay, setSelectedDay] = useState(new Date());
    const [bookOnBehalfOpen, setBookOnBehalfOpen] = useState(false);
    const [copiedLink, setCopiedLink] = useState(false);

    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 12 }, (_, i) => i + 7); // 7 AM to 6 PM

    const navigateWeek = (dir: "prev" | "next") => {
        const newWeek = dir === "next" ? addWeeks(weekStart, 1) : subWeeks(weekStart, 1);
        router.push(`/dashboard/scheduler?week=${format(newWeek, "yyyy-MM-dd")}`);
    };

    const goToToday = () => {
        const today = startOfWeek(new Date(), { weekStartsOn: 1 });
        router.push(`/dashboard/scheduler?week=${format(today, "yyyy-MM-dd")}`);
    };

    const getBookingsForDay = (day: Date) => {
        return bookings.filter((b) => isSameDay(parseISO(b.startTime), day));
    };

    const getBookingPosition = (booking: BookingItem) => {
        const start = parseISO(booking.startTime);
        const end = parseISO(booking.endTime);
        const startHour = start.getHours() + start.getMinutes() / 60;
        const endHour = end.getHours() + end.getMinutes() / 60;
        const top = ((startHour - 7) / 12) * 100;
        const height = ((endHour - startHour) / 12) * 100;
        return { top: `${top}%`, height: `${Math.max(height, 5)}%` };
    };

    const copyBookingLink = () => {
        if (myProfile?.slug) {
            const link = `${window.location.origin}/book/${workspaceId}/${myProfile.slug}`;
            navigator.clipboard.writeText(link);
            setCopiedLink(true);
            toast.success("Booking link copied!");
            setTimeout(() => setCopiedLink(false), 2000);
        }
    };

    return (
        <div className="flex-1 space-y-6 animate-in fade-in duration-700">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border/40">
                <div className="space-y-1">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="bg-primary/10 p-2 rounded-xl">
                            <CalendarClock className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary/80">Scheduler</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">
                        Calendar
                    </h2>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    {myProfile?.slug && (
                        <Button
                            variant="outline"
                            size="sm"
                            className="rounded-xl gap-2 text-xs font-bold"
                            onClick={copyBookingLink}
                        >
                            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                            {copiedLink ? "Copied!" : "My Booking Link"}
                        </Button>
                    )}
                    <Button
                        className="bg-primary hover:bg-primary/90 text-white shadow-sm shadow-primary/20 rounded-xl gap-2"
                        onClick={() => setBookOnBehalfOpen(true)}
                    >
                        <Plus className="w-4 h-4" />
                        <span className="hidden xs:inline">Book Appointment</span>
                        <span className="xs:hidden">Book</span>
                    </Button>
                </div>
            </div>

            {/* Week Navigation */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="rounded-xl font-bold text-xs" onClick={goToToday}>
                        Today
                    </Button>
                    <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="rounded-xl h-9 w-9" onClick={() => navigateWeek("prev")}>
                            <ChevronLeft className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="rounded-xl h-9 w-9" onClick={() => navigateWeek("next")}>
                            <ChevronRight className="w-4 h-4" />
                        </Button>
                    </div>
                    <h3 className="text-lg font-black tracking-tight">
                        {format(weekStart, "MMMM d")} – {format(addDays(weekStart, 6), "d, yyyy")}
                    </h3>
                </div>
                <div className="hidden sm:flex items-center gap-1 bg-muted/50 p-1 rounded-xl">
                    <button
                        onClick={() => setView("day")}
                        className={cn(
                            "px-3 py-1.5 rounded-lg text-xs font-bold transition-all",
                            view === "day" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                        )}
                    >
                        Day
                    </button>
                    <button
                        onClick={() => setView("week")}
                        className={cn(
                            "px-3 py-1.5 rounded-lg text-xs font-bold transition-all",
                            view === "week" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                        )}
                    >
                        Week
                    </button>
                </div>
            </div>

            {/* Calendar Grid */}
            {view === "week" ? (
                <Card className="rounded-[2rem] border-border/40 overflow-hidden shadow-sm">
                    {/* Day Headers */}
                    <div className="grid grid-cols-8 border-b border-border/40">
                        <div className="p-3 text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground/50 text-center border-r border-border/20">
                            Time
                        </div>
                        {weekDays.map((day) => (
                            <div
                                key={day.toISOString()}
                                className={cn(
                                    "p-3 text-center border-r border-border/20 last:border-r-0 cursor-pointer hover:bg-muted/30 transition-colors",
                                    isToday(day) && "bg-primary/5"
                                )}
                                onClick={() => { setSelectedDay(day); setView("day"); }}
                            >
                                <p className="text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground/60">
                                    {format(day, "EEE")}
                                </p>
                                <p className={cn(
                                    "text-xl font-black mt-1",
                                    isToday(day) ? "text-primary" : "text-foreground"
                                )}>
                                    {format(day, "d")}
                                </p>
                                {isToday(day) && <div className="w-1.5 h-1.5 rounded-full bg-primary mx-auto mt-1" />}
                            </div>
                        ))}
                    </div>

                    {/* Time Grid */}
                    <div className="grid grid-cols-8 max-h-[600px] overflow-y-auto">
                        {/* Time labels */}
                        <div className="border-r border-border/20">
                            {hours.map((hour) => (
                                <div key={hour} className="h-16 flex items-start justify-center pt-1 border-b border-border/10">
                                    <span className="text-[10px] font-bold text-muted-foreground/40">
                                        {format(new Date(2000, 0, 1, hour), "h a")}
                                    </span>
                                </div>
                            ))}
                        </div>

                        {/* Day columns */}
                        {weekDays.map((day) => {
                            const dayBookings = getBookingsForDay(day);
                            return (
                                <div key={day.toISOString()} className="relative border-r border-border/20 last:border-r-0">
                                    {hours.map((hour) => (
                                        <div key={hour} className={cn("h-16 border-b border-border/10", isToday(day) && "bg-primary/[0.02]")} />
                                    ))}
                                    {/* Bookings */}
                                    {dayBookings.map((booking) => {
                                        const pos = getBookingPosition(booking);
                                        return (
                                            <motion.div
                                                key={booking.id}
                                                initial={{ opacity: 0, scale: 0.95 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                className="absolute left-1 right-1 rounded-xl px-2 py-1 overflow-hidden cursor-pointer group border transition-all hover:shadow-lg hover:z-10"
                                                style={{
                                                    top: pos.top,
                                                    height: pos.height,
                                                    minHeight: "32px",
                                                    backgroundColor: `${booking.meetingType.color}15`,
                                                    borderColor: `${booking.meetingType.color}40`,
                                                }}
                                                title={`${booking.guestName} — ${booking.meetingType.name}`}
                                            >
                                                <div className="flex items-center gap-1">
                                                    {booking.meetingType.mode === "ONLINE" ? (
                                                        <Video className="w-3 h-3 shrink-0" style={{ color: booking.meetingType.color }} />
                                                    ) : (
                                                        <MapPin className="w-3 h-3 shrink-0" style={{ color: booking.meetingType.color }} />
                                                    )}
                                                    <span className="text-[10px] font-black truncate" style={{ color: booking.meetingType.color }}>
                                                        {format(parseISO(booking.startTime), "h:mm a")}
                                                    </span>
                                                </div>
                                                <p className="text-[10px] font-bold text-foreground/80 truncate mt-0.5">
                                                    {booking.guestName}
                                                </p>
                                            </motion.div>
                                        );
                                    })}
                                </div>
                            );
                        })}
                    </div>
                </Card>
            ) : (
                /* Day View */
                <DayView
                    day={selectedDay}
                    bookings={getBookingsForDay(selectedDay)}
                    hours={hours}
                    onBack={() => setView("week")}
                    onPrevDay={() => setSelectedDay(addDays(selectedDay, -1))}
                    onNextDay={() => setSelectedDay(addDays(selectedDay, 1))}
                />
            )}

            {/* Book on Behalf Dialog */}
            <BookOnBehalfDialog
                open={bookOnBehalfOpen}
                onOpenChange={setBookOnBehalfOpen}
                consultants={consultants}
            />
        </div>
    );
}

// ============================================
// DAY VIEW (expanded single-day view with booking cards)
// ============================================

function DayView({
    day,
    bookings,
    hours,
    onBack,
    onPrevDay,
    onNextDay,
}: {
    day: Date;
    bookings: BookingItem[];
    hours: number[];
    onBack: () => void;
    onPrevDay: () => void;
    onNextDay: () => void;
}) {
    return (
        <div className="space-y-4">
            <div className="flex items-center gap-3">
                <Button variant="outline" size="sm" className="rounded-xl font-bold text-xs" onClick={onBack}>
                    ← Week View
                </Button>
                <Button variant="ghost" size="icon" className="rounded-xl h-9 w-9" onClick={onPrevDay}>
                    <ChevronLeft className="w-4 h-4" />
                </Button>
                <h3 className="text-xl font-black tracking-tight">
                    {format(day, "EEEE, MMMM d, yyyy")}
                </h3>
                <Button variant="ghost" size="icon" className="rounded-xl h-9 w-9" onClick={onNextDay}>
                    <ChevronRight className="w-4 h-4" />
                </Button>
            </div>

            {bookings.length === 0 ? (
                <Card className="rounded-[2rem] p-12 text-center border-border/40">
                    <CalendarClock className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
                    <h3 className="text-lg font-black text-foreground/80">No Appointments</h3>
                    <p className="text-sm text-muted-foreground mt-1">This day is clear — no meetings scheduled.</p>
                </Card>
            ) : (
                <div className="space-y-3">
                    {bookings.map((booking) => (
                        <motion.div
                            key={booking.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Card
                                className="rounded-[1.5rem] p-5 border-border/40 hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5"
                                style={{ borderLeftWidth: 4, borderLeftColor: booking.meetingType.color }}
                            >
                                <div className="flex items-start justify-between gap-4">
                                    <div className="flex-1 min-w-0 space-y-3">
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <span
                                                className="text-[10px] font-black uppercase tracking-[0.15em] px-2 py-1 rounded-lg"
                                                style={{
                                                    backgroundColor: `${booking.meetingType.color}15`,
                                                    color: booking.meetingType.color,
                                                }}
                                            >
                                                {booking.meetingType.mode === "ONLINE" ? "🖥️ Online" : "🏢 In-Person"}
                                            </span>
                                            <span className="text-[10px] font-bold text-muted-foreground/50">
                                                {booking.meetingType.name} • {booking.meetingType.duration} min
                                            </span>
                                        </div>

                                        <div className="flex items-center gap-2">
                                            <Clock className="w-4 h-4 text-muted-foreground/50" />
                                            <span className="text-lg font-black text-foreground">
                                                {format(parseISO(booking.startTime), "h:mm a")} – {format(parseISO(booking.endTime), "h:mm a")}
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                            <div className="flex items-center gap-2">
                                                <User className="w-3.5 h-3.5 text-muted-foreground/50" />
                                                <span className="text-sm font-bold">{booking.guestName}</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Mail className="w-3.5 h-3.5 text-muted-foreground/50" />
                                                <span className="text-sm text-muted-foreground">{booking.guestEmail}</span>
                                            </div>
                                            {booking.guestPhone && (
                                                <div className="flex items-center gap-2">
                                                    <Phone className="w-3.5 h-3.5 text-muted-foreground/50" />
                                                    <span className="text-sm text-muted-foreground">{booking.guestPhone}</span>
                                                </div>
                                            )}
                                            {booking.location && (
                                                <div className="flex items-center gap-2">
                                                    <MapPin className="w-3.5 h-3.5 text-muted-foreground/50" />
                                                    <span className="text-sm text-muted-foreground">{booking.location}</span>
                                                </div>
                                            )}
                                        </div>

                                        {booking.guestNotes && (
                                            <p className="text-xs text-muted-foreground bg-muted/50 rounded-xl px-3 py-2 mt-2">
                                                "{booking.guestNotes}"
                                            </p>
                                        )}
                                    </div>

                                    <div className="flex flex-col items-end gap-2">
                                        <div className="text-right">
                                            <p className="text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground/40">Host</p>
                                            <p className="text-sm font-bold text-foreground">
                                                {booking.profile.displayName || booking.profile.user.name}
                                            </p>
                                        </div>
                                        {booking.meetingLink && (
                                            <a
                                                href={booking.meetingLink}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="flex items-center gap-1.5 text-xs font-bold text-primary hover:text-primary/80 transition-colors bg-primary/10 px-3 py-1.5 rounded-lg"
                                            >
                                                <ExternalLink className="w-3 h-3" />
                                                Join Meeting
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            )}
        </div>
    );
}
