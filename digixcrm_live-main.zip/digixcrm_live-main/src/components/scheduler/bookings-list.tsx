"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format, parseISO, isPast } from "date-fns";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
    CalendarCheck, Video, MapPin, Clock, User, Mail, Phone,
    ChevronRight, XCircle, CheckCircle2, AlertCircle, ExternalLink
} from "lucide-react";
import { cn } from "@/lib/utils";
import { cancelBooking, completeBooking } from "@/lib/actions/scheduler";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from "@/components/ui/alert-dialog";

const STATUS_STYLES: Record<string, { bg: string; text: string; label: string }> = {
    CONFIRMED: { bg: "bg-emerald-500/10", text: "text-emerald-600 dark:text-emerald-400", label: "Confirmed" },
    PENDING: { bg: "bg-amber-500/10", text: "text-amber-600 dark:text-amber-400", label: "Pending" },
    COMPLETED: { bg: "bg-blue-500/10", text: "text-blue-600 dark:text-blue-400", label: "Completed" },
    CANCELLED: { bg: "bg-red-500/10", text: "text-red-600 dark:text-red-400", label: "Cancelled" },
    NO_SHOW: { bg: "bg-zinc-500/10", text: "text-zinc-600 dark:text-zinc-400", label: "No Show" },
    RESCHEDULED: { bg: "bg-purple-500/10", text: "text-purple-600 dark:text-purple-400", label: "Rescheduled" },
};

export function BookingsList({
    bookings,
    currentFilter,
    role,
}: {
    bookings: any[];
    currentFilter: string;
    role: string;
}) {
    const router = useRouter();
    const [loading, setLoading] = useState<string | null>(null);

    const filters = [
        { key: "upcoming", label: "Upcoming" },
        { key: "past", label: "Past" },
        { key: "cancelled", label: "Cancelled" },
    ];

    const handleCancel = async (id: string) => {
        setLoading(id);
        const result = await cancelBooking(id, "Cancelled by staff");
        if (result.success) {
            toast.success("Booking cancelled");
            router.refresh();
        } else {
            toast.error(result.error || "Failed to cancel");
        }
        setLoading(null);
    };

    const handleComplete = async (id: string) => {
        setLoading(id);
        const result = await completeBooking(id);
        if (result.success) {
            toast.success("Marked as completed");
            router.refresh();
        } else {
            toast.error(result.error || "Failed to update");
        }
        setLoading(null);
    };

    return (
        <div className="flex-1 space-y-6 animate-in fade-in duration-700">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border/40">
                <div className="space-y-1">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="bg-primary/10 p-2 rounded-xl">
                            <CalendarCheck className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary/80">Scheduler</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">
                        All Bookings
                    </h2>
                </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-muted/50 p-1 rounded-xl w-fit">
                {filters.map((f) => (
                    <button
                        key={f.key}
                        onClick={() => router.push(`/dashboard/scheduler/bookings?filter=${f.key}`)}
                        className={cn(
                            "px-4 py-2 rounded-lg text-xs font-bold transition-all",
                            currentFilter === f.key
                                ? "bg-background shadow-sm text-foreground"
                                : "text-muted-foreground hover:text-foreground"
                        )}
                    >
                        {f.label}
                    </button>
                ))}
            </div>

            {/* Bookings */}
            {bookings.length === 0 ? (
                <Card className="rounded-[2rem] p-12 text-center border-border/40">
                    <CalendarCheck className="w-12 h-12 mx-auto text-muted-foreground/20 mb-4" />
                    <h3 className="text-lg font-black text-foreground/80">No Bookings</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                        {currentFilter === "upcoming" ? "No upcoming meetings scheduled." : 
                         currentFilter === "past" ? "No past meetings found." : "No cancelled bookings."}
                    </p>
                </Card>
            ) : (
                <div className="space-y-3">
                    {bookings.map((booking, i) => {
                        const status = STATUS_STYLES[booking.status] || STATUS_STYLES.CONFIRMED;
                        const isUpcoming = !isPast(parseISO(booking.startTime)) && booking.status === "CONFIRMED";

                        return (
                            <motion.div
                                key={booking.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.03 }}
                            >
                                <Card
                                    className="rounded-[1.5rem] p-5 border-border/40 hover:shadow-lg transition-all duration-300"
                                    style={{ borderLeftWidth: 4, borderLeftColor: booking.meetingType.color }}
                                >
                                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                        <div className="flex-1 min-w-0 space-y-2">
                                            <div className="flex items-center gap-2 flex-wrap">
                                                <span className={cn("text-[10px] font-black uppercase tracking-[0.15em] px-2 py-1 rounded-lg", status.bg, status.text)}>
                                                    {status.label}
                                                </span>
                                                <span
                                                    className="text-[10px] font-black uppercase tracking-[0.1em] px-2 py-1 rounded-lg"
                                                    style={{
                                                        backgroundColor: `${booking.meetingType.color}10`,
                                                        color: booking.meetingType.color,
                                                    }}
                                                >
                                                    {booking.meetingType.mode === "ONLINE" ? "🖥️ Online" : "🏢 In-Person"}
                                                </span>
                                                <span className="text-[10px] font-bold text-muted-foreground/50">
                                                    {booking.meetingType.name} • {booking.meetingType.duration} min
                                                </span>
                                            </div>

                                            <div className="flex items-center gap-3">
                                                <div className="flex items-center gap-1.5">
                                                    <Clock className="w-4 h-4 text-muted-foreground/40" />
                                                    <span className="text-sm font-black">
                                                        {format(parseISO(booking.startTime), "EEE, MMM d")} at {format(parseISO(booking.startTime), "h:mm a")}
                                                    </span>
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-4 flex-wrap">
                                                <div className="flex items-center gap-1.5">
                                                    <User className="w-3.5 h-3.5 text-muted-foreground/40" />
                                                    <span className="text-sm font-bold">{booking.guestName}</span>
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <Mail className="w-3.5 h-3.5 text-muted-foreground/40" />
                                                    <span className="text-xs text-muted-foreground">{booking.guestEmail}</span>
                                                </div>
                                                {booking.guestPhone && (
                                                    <div className="flex items-center gap-1.5">
                                                        <Phone className="w-3.5 h-3.5 text-muted-foreground/40" />
                                                        <span className="text-xs text-muted-foreground">{booking.guestPhone}</span>
                                                    </div>
                                                )}
                                            </div>

                                            <div className="text-[10px] text-muted-foreground/50 font-medium">
                                                Host: {booking.profile.displayName || booking.profile.user.name}
                                            </div>
                                        </div>

                                        {/* Actions */}
                                        <div className="flex items-center gap-2 shrink-0">
                                            {booking.meetingLink && isUpcoming && (
                                                <a
                                                    href={booking.meetingLink}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="flex items-center gap-1.5 text-xs font-bold text-primary hover:text-primary/80 bg-primary/10 px-3 py-2 rounded-xl transition-colors"
                                                >
                                                    <ExternalLink className="w-3 h-3" /> Join
                                                </a>
                                            )}

                                            {isUpcoming && (
                                                <>
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        className="rounded-xl text-xs font-bold gap-1"
                                                        onClick={() => handleComplete(booking.id)}
                                                        disabled={loading === booking.id}
                                                    >
                                                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                                                        Done
                                                    </Button>

                                                    <AlertDialog>
                                                        <AlertDialogTrigger asChild>
                                                            <Button
                                                                variant="outline"
                                                                size="sm"
                                                                className="rounded-xl text-xs font-bold gap-1 hover:border-red-500/50 hover:text-red-500"
                                                                disabled={loading === booking.id}
                                                            >
                                                                <XCircle className="w-3.5 h-3.5" />
                                                                Cancel
                                                            </Button>
                                                        </AlertDialogTrigger>
                                                        <AlertDialogContent className="rounded-2xl">
                                                            <AlertDialogHeader>
                                                                <AlertDialogTitle className="font-black">Cancel Booking?</AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                    This will cancel the appointment with {booking.guestName}. They will be notified.
                                                                </AlertDialogDescription>
                                                            </AlertDialogHeader>
                                                            <AlertDialogFooter>
                                                                <AlertDialogCancel className="rounded-xl">Keep It</AlertDialogCancel>
                                                                <AlertDialogAction
                                                                    className="rounded-xl bg-red-500 hover:bg-red-600"
                                                                    onClick={() => handleCancel(booking.id)}
                                                                >
                                                                    Yes, Cancel
                                                                </AlertDialogAction>
                                                            </AlertDialogFooter>
                                                        </AlertDialogContent>
                                                    </AlertDialog>
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </Card>
                            </motion.div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
