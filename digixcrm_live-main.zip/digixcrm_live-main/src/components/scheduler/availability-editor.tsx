"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
    Clock3, Save, Plus, Trash2, Video, MapPin, X, CalendarClock, Palette, Settings2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { upsertSchedulerProfile, createMeetingType, updateMeetingType, deleteMeetingType } from "@/lib/actions/scheduler";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
    Dialog, DialogContent, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const TIME_OPTIONS = Array.from({ length: 29 }, (_, i) => {
    const h = Math.floor(i / 2) + 7;
    const m = (i % 2) * 30;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
});

const COLOR_PRESETS = [
    "#6366f1", "#8b5cf6", "#ec4899", "#ef4444", "#f97316",
    "#eab308", "#22c55e", "#14b8a6", "#06b6d4", "#3b82f6",
];

const DEFAULT_SCHEDULE = [
    { day: 0, startTime: "09:00", endTime: "17:00", enabled: false },
    { day: 1, startTime: "09:00", endTime: "17:00", enabled: true },
    { day: 2, startTime: "09:00", endTime: "17:00", enabled: true },
    { day: 3, startTime: "09:00", endTime: "17:00", enabled: true },
    { day: 4, startTime: "09:00", endTime: "17:00", enabled: true },
    { day: 5, startTime: "09:00", endTime: "17:00", enabled: true },
    { day: 6, startTime: "09:00", endTime: "12:00", enabled: false },
];

interface ScheduleDay {
    day: number;
    startTime: string;
    endTime: string;
    enabled: boolean;
}

export function AvailabilityEditor({
    profile,
    userName,
    userEmail,
    userJobTitle,
}: {
    profile: any;
    userName: string;
    userEmail: string;
    userJobTitle: string;
}) {
    const router = useRouter();
    const [saving, setSaving] = useState(false);

    // Profile fields
    const [displayName, setDisplayName] = useState(profile?.displayName || userName);
    const [title, setTitle] = useState(profile?.title || userJobTitle);
    const [bio, setBio] = useState(profile?.bio || "");
    const [timezone, setTimezone] = useState(profile?.timezone || "America/New_York");
    const [bufferBefore, setBufferBefore] = useState(profile?.bufferBefore ?? 5);
    const [bufferAfter, setBufferAfter] = useState(profile?.bufferAfter ?? 5);
    const [minNotice, setMinNotice] = useState(profile?.minNotice ?? 60);
    const [maxAdvance, setMaxAdvance] = useState(profile?.maxAdvance ?? 30);

    // Schedule
    const [schedule, setSchedule] = useState<ScheduleDay[]>(
        (profile?.weeklySchedule as ScheduleDay[])?.length > 0
            ? (profile.weeklySchedule as ScheduleDay[])
            : DEFAULT_SCHEDULE
    );

    // Blocked dates
    const [blockedDates, setBlockedDates] = useState<string[]>(
        (profile?.blockedDates as string[]) || []
    );
    const [newBlockedDate, setNewBlockedDate] = useState("");

    // Meeting types
    const [meetingTypes, setMeetingTypes] = useState(profile?.meetingTypes || []);
    const [mtDialogOpen, setMtDialogOpen] = useState(false);
    const [mtName, setMtName] = useState("");
    const [mtDescription, setMtDescription] = useState("");
    const [mtDuration, setMtDuration] = useState(30);
    const [mtColor, setMtColor] = useState("#6366f1");
    const [mtMode, setMtMode] = useState<"ONLINE" | "IN_PERSON">("ONLINE");
    const [mtLocation, setMtLocation] = useState("");
    const [mtLocationNotes, setMtLocationNotes] = useState("");

    // Sync meetingTypes from server automatically when they change
    useEffect(() => {
        if (profile?.meetingTypes) {
            setMeetingTypes(profile.meetingTypes);
        }
    }, [profile?.meetingTypes]);

    const updateScheduleDay = (dayIndex: number, field: string, value: any) => {
        setSchedule((prev) =>
            prev.map((d) => (d.day === dayIndex ? { ...d, [field]: value } : d))
        );
    };

    const handleSaveProfile = async () => {
        setSaving(true);
        const result = await upsertSchedulerProfile({
            displayName,
            title,
            bio,
            timezone,
            bufferBefore,
            bufferAfter,
            minNotice,
            maxAdvance,
            weeklySchedule: schedule,
            blockedDates,
        });

        if (result.success) {
            toast.success("Availability saved!");
            router.refresh();
        } else {
            toast.error(result.error || "Failed to save");
        }
        setSaving(false);
    };

    const handleCreateMeetingType = async () => {
        if (!mtName) { toast.error("Please enter a name"); return; }
        const payload: any = {
            name: mtName,
            description: mtDescription,
            duration: mtDuration,
            color: mtColor,
            mode: mtMode,
        };
        if (mtMode === "ONLINE") payload.onlinePlatform = "ZOOM";
        if (mtMode === "IN_PERSON") {
            payload.location = mtLocation;
            payload.locationNotes = mtLocationNotes;
        }

        const result = await createMeetingType(payload);

        if (result.success) {
            toast.success("Meeting type created!");
            setMeetingTypes((prev: any) => [...prev, (result as any).meetingType]);
            setMtDialogOpen(false);
            setMtName("");
            setMtDescription("");
            setMtDuration(30);
            setMtColor("#6366f1");
            setMtMode("ONLINE");
            setMtLocation("");
            setMtLocationNotes("");
            router.refresh();
        } else {
            toast.error((result as any).error || "Failed to create");
        }
    };

    const handleDeleteMeetingType = async (id: string) => {
        setMeetingTypes((prev: any) => prev.filter((m: any) => m.id !== id));
        const result = await deleteMeetingType(id);
        if (result.success) {
            toast.success("Meeting type deleted");
            router.refresh();
        } else {
            toast.error(result.error || "Failed to delete");
        }
    };

    const handleToggleMeetingType = async (id: string, isActive: boolean) => {
        setMeetingTypes((prev: any) => prev.map((m: any) => m.id === id ? { ...m, isActive: !isActive } : m));
        const result = await updateMeetingType(id, { isActive: !isActive });
        if (result.success) {
            router.refresh();
        }
    };

    const addBlockedDate = () => {
        if (newBlockedDate && !blockedDates.includes(newBlockedDate)) {
            setBlockedDates((prev) => [...prev, newBlockedDate]);
            setNewBlockedDate("");
        }
    };

    const removeBlockedDate = (date: string) => {
        setBlockedDates((prev) => prev.filter((d) => d !== date));
    };

    const formatTime = (time: string) => {
        const [h, m] = time.split(":").map(Number);
        const ampm = h >= 12 ? "PM" : "AM";
        const hour = h % 12 || 12;
        return `${hour}:${m.toString().padStart(2, "0")} ${ampm}`;
    };

    return (
        <div className="flex-1 space-y-8 animate-in fade-in duration-700">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border/40">
                <div className="space-y-1">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="bg-primary/10 p-2 rounded-xl">
                            <Clock3 className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary/80">Scheduler</span>
                    </div>
                    <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">
                        My Availability
                    </h2>
                    <p className="text-sm text-muted-foreground mt-1">
                        Set your working hours and meeting types so clients can book time with you.
                    </p>
                </div>
                <Button
                    className="bg-primary hover:bg-primary/90 text-white shadow-sm shadow-primary/20 rounded-xl gap-2 min-w-[140px]"
                    onClick={handleSaveProfile}
                    disabled={saving}
                >
                    <Save className="w-4 h-4" />
                    {saving ? "Saving..." : "Save Changes"}
                </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Profile + Settings */}
                <div className="lg:col-span-1 space-y-6">
                    {/* Profile Card */}
                    <Card className="rounded-[2rem] p-6 border-border/40 space-y-5">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 border-b border-border/20 pb-2">
                            Public Profile
                        </h3>
                        <div className="space-y-4">
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold">Display Name</label>
                                <Input className="h-11 rounded-xl shadow-sm text-base" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold">Title / Role</label>
                                <Input className="h-11 rounded-xl shadow-sm" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Senior Consultant" />
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold">Short Bio</label>
                                <Textarea
                                    className="rounded-xl shadow-sm resize-none min-h-[60px]"
                                    value={bio}
                                    onChange={(e) => setBio(e.target.value)}
                                    placeholder="A brief intro shown on your booking page..."
                                />
                            </div>
                        </div>
                    </Card>

                    {/* Buffer Settings */}
                    <Card className="rounded-[2rem] p-6 border-border/40 space-y-5">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 border-b border-border/20 pb-2 flex items-center gap-2">
                            <Settings2 className="w-3.5 h-3.5" /> Scheduling Rules
                        </h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-muted-foreground">Buffer Before</label>
                                <Select value={bufferBefore.toString()} onValueChange={(v) => setBufferBefore(Number(v))}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {[0, 5, 10, 15, 30].map((v) => (
                                            <SelectItem key={v} value={v.toString()}>{v} min</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-muted-foreground">Buffer After</label>
                                <Select value={bufferAfter.toString()} onValueChange={(v) => setBufferAfter(Number(v))}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {[0, 5, 10, 15, 30].map((v) => (
                                            <SelectItem key={v} value={v.toString()}>{v} min</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-muted-foreground">Min Notice</label>
                                <Select value={minNotice.toString()} onValueChange={(v) => setMinNotice(Number(v))}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {[30, 60, 120, 240, 1440].map((v) => (
                                            <SelectItem key={v} value={v.toString()}>
                                                {v < 60 ? `${v} min` : v < 1440 ? `${v / 60} hrs` : "1 day"}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-muted-foreground">Max Advance</label>
                                <Select value={maxAdvance.toString()} onValueChange={(v) => setMaxAdvance(Number(v))}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {[7, 14, 30, 60, 90].map((v) => (
                                            <SelectItem key={v} value={v.toString()}>{v} days</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </Card>

                    {/* Blocked Dates */}
                    <Card className="rounded-[2rem] p-6 border-border/40 space-y-4">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 border-b border-border/20 pb-2">
                            🚫 Blocked Dates
                        </h3>
                        <div className="flex gap-2">
                            <Input type="date" className="h-10 rounded-xl shadow-sm flex-1" value={newBlockedDate} onChange={(e) => setNewBlockedDate(e.target.value)} />
                            <Button variant="outline" size="sm" className="rounded-xl" onClick={addBlockedDate}>
                                <Plus className="w-4 h-4" />
                            </Button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {blockedDates.map((d) => (
                                <span key={d} className="flex items-center gap-1.5 bg-red-500/10 text-red-600 dark:text-red-400 text-xs font-bold px-3 py-1.5 rounded-lg">
                                    {d}
                                    <button onClick={() => removeBlockedDate(d)} className="hover:text-red-700"><X className="w-3 h-3" /></button>
                                </span>
                            ))}
                            {blockedDates.length === 0 && <p className="text-xs text-muted-foreground">No dates blocked</p>}
                        </div>
                    </Card>
                </div>

                {/* Right Column: Schedule + Meeting Types */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Weekly Schedule */}
                    <Card className="rounded-[2rem] p-6 border-border/40 space-y-5">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 border-b border-border/20 pb-2">
                            📅 Weekly Working Hours
                        </h3>
                        <div className="space-y-3">
                            {schedule.map((day) => (
                                <div
                                    key={day.day}
                                    className={cn(
                                        "flex items-center gap-4 p-4 rounded-2xl border transition-all",
                                        day.enabled ? "border-border/40 bg-background" : "border-border/20 bg-muted/20 opacity-60"
                                    )}
                                >
                                    <Switch
                                        checked={day.enabled}
                                        onCheckedChange={(v) => updateScheduleDay(day.day, "enabled", v)}
                                    />
                                    <span className="w-28 text-sm font-bold">{DAYS[day.day]}</span>
                                    {day.enabled ? (
                                        <div className="flex items-center gap-2 flex-1">
                                            <Select value={day.startTime} onValueChange={(v) => updateScheduleDay(day.day, "startTime", v)}>
                                                <SelectTrigger className="rounded-xl h-10 w-32"><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    {TIME_OPTIONS.map((t) => (
                                                        <SelectItem key={t} value={t}>{formatTime(t)}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                            <span className="text-muted-foreground font-bold">to</span>
                                            <Select value={day.endTime} onValueChange={(v) => updateScheduleDay(day.day, "endTime", v)}>
                                                <SelectTrigger className="rounded-xl h-10 w-32"><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    {TIME_OPTIONS.map((t) => (
                                                        <SelectItem key={t} value={t}>{formatTime(t)}</SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    ) : (
                                        <span className="text-sm text-muted-foreground/50 font-medium flex-1">Unavailable</span>
                                    )}
                                </div>
                            ))}
                        </div>
                    </Card>

                    {/* Meeting Types */}
                    <Card className="rounded-[2rem] p-6 border-border/40 space-y-5">
                        <div className="flex items-center justify-between border-b border-border/20 pb-3">
                            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                🗓️ Meeting Types
                            </h3>
                            <Button size="sm" className="rounded-xl gap-2 text-xs font-bold" onClick={() => setMtDialogOpen(true)}>
                                <Plus className="w-3.5 h-3.5" /> Add Type
                            </Button>
                        </div>

                        {meetingTypes.length === 0 ? (
                            <div className="text-center py-10">
                                <CalendarClock className="w-12 h-12 mx-auto text-muted-foreground/20 mb-3" />
                                <p className="text-sm font-bold text-muted-foreground">No meeting types yet</p>
                                <p className="text-xs text-muted-foreground/60 mt-1">Create your first meeting type so clients can book with you.</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {meetingTypes.map((mt: any) => (
                                    <motion.div
                                        key={mt.id}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="flex items-center justify-between p-4 rounded-2xl border border-border/40 hover:shadow-md transition-all"
                                        style={{ borderLeftWidth: 4, borderLeftColor: mt.color }}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div
                                                className="w-10 h-10 rounded-xl flex items-center justify-center"
                                                style={{ backgroundColor: `${mt.color}15` }}
                                            >
                                                {mt.mode === "ONLINE" ? (
                                                    <Video className="w-5 h-5" style={{ color: mt.color }} />
                                                ) : (
                                                    <MapPin className="w-5 h-5" style={{ color: mt.color }} />
                                                )}
                                            </div>
                                            <div>
                                                <p className="font-bold text-sm">{mt.name}</p>
                                                <p className="text-[10px] text-muted-foreground">
                                                    {mt.duration} min • {mt.mode === "ONLINE" ? "Zoom" : `In-Person${mt.location ? ` • ${mt.location}` : ""}`}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Switch
                                                checked={mt.isActive}
                                                onCheckedChange={() => handleToggleMeetingType(mt.id, mt.isActive)}
                                            />
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="rounded-xl h-8 w-8 text-muted-foreground hover:text-red-500"
                                                onClick={() => handleDeleteMeetingType(mt.id)}
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </Card>
                </div>
            </div>

            {/* Create Meeting Type Dialog */}
            <Dialog open={mtDialogOpen} onOpenChange={setMtDialogOpen}>
                <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden bg-white/95 dark:bg-card/95 backdrop-blur-xl border border-border/60">
                    <div className="bg-muted/30 px-6 py-4 border-b border-border/40">
                        <DialogTitle className="text-xl font-black tracking-tight flex items-center gap-2">
                            <CalendarClock className="w-5 h-5 text-primary" />
                            New Meeting Type
                        </DialogTitle>
                        <DialogDescription className="mt-1 text-sm text-muted-foreground">
                            Define a type of meeting that clients can book with you.
                        </DialogDescription>
                    </div>

                    <div className="px-6 py-5 space-y-4 max-h-[60vh] overflow-y-auto">
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold">Meeting Name *</label>
                            <Input className="h-11 rounded-xl shadow-sm text-base" placeholder="30-Min Consultation" value={mtName} onChange={(e) => setMtName(e.target.value)} />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold">Description</label>
                            <Input className="h-11 rounded-xl shadow-sm" placeholder="A quick intro call to discuss your needs" value={mtDescription} onChange={(e) => setMtDescription(e.target.value)} />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold">Duration</label>
                                <Select value={mtDuration.toString()} onValueChange={(v) => setMtDuration(Number(v))}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {[15, 30, 45, 60, 90, 120].map((d) => (
                                            <SelectItem key={d} value={d.toString()}>{d} min</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-xs font-bold">Mode</label>
                                <Select value={mtMode} onValueChange={(v) => setMtMode(v as any)}>
                                    <SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="ONLINE">🖥️ Online (Zoom)</SelectItem>
                                        <SelectItem value="IN_PERSON">🏢 In-Person</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        {mtMode === "IN_PERSON" && (
                            <div className="space-y-3 bg-muted/30 rounded-2xl p-4 border border-border/20">
                                <div className="space-y-1.5">
                                    <label className="text-xs font-bold flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> Address</label>
                                    <Input className="h-10 rounded-xl shadow-sm" placeholder="123 Main St, Suite 200" value={mtLocation} onChange={(e) => setMtLocation(e.target.value)} />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-xs font-bold">Location Notes</label>
                                    <Input className="h-10 rounded-xl shadow-sm" placeholder="2nd floor, ask for reception" value={mtLocationNotes} onChange={(e) => setMtLocationNotes(e.target.value)} />
                                </div>
                            </div>
                        )}

                        <div className="space-y-1.5">
                            <label className="text-xs font-bold flex items-center gap-1.5"><Palette className="w-3.5 h-3.5" /> Color</label>
                            <div className="flex gap-2 flex-wrap">
                                {COLOR_PRESETS.map((c) => (
                                    <button
                                        key={c}
                                        onClick={() => setMtColor(c)}
                                        className={cn(
                                            "w-8 h-8 rounded-lg border-2 transition-all",
                                            mtColor === c ? "border-foreground scale-110 shadow-lg" : "border-transparent hover:scale-105"
                                        )}
                                        style={{ backgroundColor: c }}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>

                    <DialogFooter className="px-6 py-4 border-t border-border/40">
                        <Button variant="outline" className="rounded-xl" onClick={() => setMtDialogOpen(false)}>Cancel</Button>
                        <Button className="rounded-xl min-w-[120px]" onClick={handleCreateMeetingType}>
                            Create Type
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
