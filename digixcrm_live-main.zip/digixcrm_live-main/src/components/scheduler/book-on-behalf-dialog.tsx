"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { format, parseISO } from "date-fns";
import {
    Dialog, DialogContent, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, User, Mail, Phone, Clock, Video, MapPin, ChevronRight, ChevronLeft, StickyNote, Search, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { getAvailableSlots, getAvailableDates, createBookingOnBehalf, searchWorkspaceClients } from "@/lib/actions/scheduler";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

interface Consultant {
    id: string;
    displayName?: string;
    userId: string;
    user: { id: string; name: string; email: string; image?: string; jobTitle?: string };
    meetingTypes: {
        id: string;
        name: string;
        duration: number;
        color: string;
        mode: string;
        location?: string;
    }[];
}

export function BookOnBehalfDialog({
    open,
    onOpenChange,
    consultants,
    initialGuestName = "",
    initialGuestEmail = "",
    initialGuestPhone = "",
}: {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    consultants: Consultant[];
    initialGuestName?: string;
    initialGuestEmail?: string;
    initialGuestPhone?: string;
}) {
    const router = useRouter();
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);

    // Selections
    const [selectedConsultant, setSelectedConsultant] = useState<string>("");
    const [selectedMeetingType, setSelectedMeetingType] = useState<string>("");
    const [selectedDate, setSelectedDate] = useState<string>("");
    const [selectedTime, setSelectedTime] = useState<string>("");

    // Available data
    const [availableDates, setAvailableDates] = useState<string[]>([]);
    const [availableSlots, setAvailableSlots] = useState<string[]>([]);
    const [slotsLoading, setSlotsLoading] = useState(false);

    // Guest details
    const [guestName, setGuestName] = useState(initialGuestName);
    const [guestEmail, setGuestEmail] = useState(initialGuestEmail);
    const [guestPhone, setGuestPhone] = useState(initialGuestPhone);
    const [guestNotes, setGuestNotes] = useState("");

    // Sync initial props if they change
    useEffect(() => {
        if (initialGuestName) setGuestName(initialGuestName);
        if (initialGuestEmail) setGuestEmail(initialGuestEmail);
        if (initialGuestPhone) setGuestPhone(initialGuestPhone);
    }, [initialGuestName, initialGuestEmail, initialGuestPhone]);

    // Search state
    const [searchQuery, setSearchQuery] = useState("");
    const [searchResults, setSearchResults] = useState<any[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [showResults, setShowResults] = useState(false);

    const consultant = consultants.find((c) => c.id === selectedConsultant);
    const meetingType = consultant?.meetingTypes.find((mt) => mt.id === selectedMeetingType);

    // Debounced search
    useEffect(() => {
        if (step !== 3 || searchQuery.length < 2) {
            setSearchResults([]);
            setShowResults(false);
            return;
        }

        const timer = setTimeout(async () => {
            setIsSearching(true);
            const res = await searchWorkspaceClients(searchQuery);
            if (res.success) {
                setSearchResults(res.clients || []);
                setShowResults(true);
            }
            setIsSearching(false);
        }, 300);

        return () => clearTimeout(timer);
    }, [searchQuery, step]);

    const selectClient = (client: any) => {
        setGuestName(client.name || "");
        setGuestEmail(client.email || "");
        setGuestPhone(client.phone || "");
        setSearchQuery("");
        setShowResults(false);
    };

    // Load available dates when consultant + meeting type selected
    useEffect(() => {
        if (selectedConsultant && selectedMeetingType) {
            getAvailableDates(selectedConsultant, selectedMeetingType).then((res) => {
                if (res.success && res.dates) {
                    setAvailableDates(res.dates);
                }
            });
        }
    }, [selectedConsultant, selectedMeetingType]);

    // Load slots when date selected
    useEffect(() => {
        if (selectedConsultant && selectedMeetingType && selectedDate) {
            setSlotsLoading(true);
            getAvailableSlots(selectedConsultant, selectedMeetingType, selectedDate).then((res) => {
                if (res.success && res.slots) {
                    setAvailableSlots(res.slots);
                }
                setSlotsLoading(false);
            });
        }
    }, [selectedConsultant, selectedMeetingType, selectedDate]);

    const resetForm = () => {
        setStep(1);
        setSelectedConsultant("");
        setSelectedMeetingType("");
        setSelectedDate("");
        setSelectedTime("");
        setGuestName(initialGuestName);
        setGuestEmail(initialGuestEmail);
        setGuestPhone(initialGuestPhone);
        setGuestNotes("");
        setAvailableDates([]);
        setAvailableSlots([]);
    };

    const handleSubmit = async () => {
        if (!guestName || !guestEmail) {
            toast.error("Please fill in the client's name and email");
            return;
        }

        setLoading(true);
        const [h, m] = selectedTime.split(":").map(Number);
        const dateObj = parseISO(selectedDate);
        dateObj.setHours(h, m, 0, 0);

        const result = await createBookingOnBehalf({
            consultantProfileId: selectedConsultant,
            meetingTypeId: selectedMeetingType,
            startTime: dateObj.toISOString(),
            guestName,
            guestEmail,
            guestPhone: guestPhone || undefined,
            guestNotes: guestNotes || undefined,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        });

        if (result.success) {
            toast.success("Appointment booked successfully!");
            resetForm();
            onOpenChange(false);
            router.refresh();
        } else {
            toast.error(result.error || "Failed to book appointment");
        }
        setLoading(false);
    };

    return (
        <Dialog open={open} onOpenChange={(v) => { if (!v) resetForm(); onOpenChange(v); }}>
            <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-white/95 dark:bg-card/95 backdrop-blur-xl border border-border/60">
                {/* Header */}
                <div className="bg-muted/30 px-6 py-4 border-b border-border/40">
                    <DialogTitle className="text-xl font-black tracking-tight text-foreground flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-primary" />
                        Book Appointment for Client
                    </DialogTitle>
                    <DialogDescription className="mt-1 text-sm text-muted-foreground">
                        Schedule a meeting on behalf of a walk-in or phone client.
                    </DialogDescription>
                    {/* Step Indicator */}
                    <div className="flex items-center gap-2 mt-4">
                        {[1, 2, 3].map((s) => (
                            <div key={s} className="flex items-center gap-2">
                                <div className={cn(
                                    "w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all",
                                    step >= s
                                        ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                                        : "bg-muted text-muted-foreground"
                                )}>
                                    {s}
                                </div>
                                {s < 3 && <div className={cn("w-8 h-0.5 rounded-full transition-all", step > s ? "bg-primary" : "bg-muted")} />}
                            </div>
                        ))}
                        <span className="text-[10px] font-bold text-muted-foreground/60 ml-2">
                            {step === 1 ? "Select Consultant" : step === 2 ? "Pick Time" : "Client Details"}
                        </span>
                    </div>
                </div>

                <div className="px-6 py-5 max-h-[60vh] overflow-y-auto">
                    <AnimatePresence mode="wait">
                        {/* Step 1: Select Consultant & Meeting Type */}
                        {step === 1 && (
                            <motion.div
                                key="step1"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-5"
                            >
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                        Select Consultant
                                    </label>
                                    <div className="grid grid-cols-1 gap-2">
                                        {consultants.map((c) => (
                                            <button
                                                key={c.id}
                                                onClick={() => { setSelectedConsultant(c.id); setSelectedMeetingType(""); }}
                                                className={cn(
                                                    "flex items-center gap-3 p-4 rounded-2xl border transition-all text-left",
                                                    selectedConsultant === c.id
                                                        ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
                                                        : "border-border/40 hover:border-border hover:bg-muted/30"
                                                )}
                                            >
                                                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-black text-sm">
                                                    {c.user.name?.charAt(0) || "?"}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-sm">{c.displayName || c.user.name}</p>
                                                    <p className="text-[10px] text-muted-foreground font-medium">{c.user.jobTitle || c.user.email}</p>
                                                </div>
                                            </button>
                                        ))}
                                        {consultants.length === 0 && (
                                            <div className="text-center py-8 text-muted-foreground text-sm">
                                                No consultants have set up their scheduler yet.
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {consultant && (
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                            Meeting Type
                                        </label>
                                        <div className="grid grid-cols-1 gap-2">
                                            {consultant.meetingTypes.map((mt) => (
                                                <button
                                                    key={mt.id}
                                                    onClick={() => setSelectedMeetingType(mt.id)}
                                                    className={cn(
                                                        "flex items-center gap-3 p-4 rounded-2xl border transition-all text-left",
                                                        selectedMeetingType === mt.id
                                                            ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
                                                            : "border-border/40 hover:border-border hover:bg-muted/30"
                                                    )}
                                                >
                                                    <div
                                                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                                                        style={{ backgroundColor: `${mt.color}15` }}
                                                    >
                                                        {mt.mode === "ONLINE" ? (
                                                            <Video className="w-5 h-5" style={{ color: mt.color }} />
                                                        ) : (
                                                            <MapPin className="w-5 h-5" style={{ color: mt.color }} />
                                                        )}
                                                    </div>
                                                    <div>
                                                        <p className="font-bold text-sm">{mt.name}</p>
                                                        <p className="text-[10px] text-muted-foreground font-medium">
                                                            {mt.duration} min • {mt.mode === "ONLINE" ? "Online (Zoom)" : `In-Person${mt.location ? ` • ${mt.location}` : ""}`}
                                                        </p>
                                                    </div>
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </motion.div>
                        )}

                        {/* Step 2: Pick Date & Time */}
                        {step === 2 && (
                            <motion.div
                                key="step2"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-5"
                            >
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                        Select Date
                                    </label>
                                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[200px] overflow-y-auto">
                                        {availableDates.slice(0, 16).map((dateStr) => (
                                            <button
                                                key={dateStr}
                                                onClick={() => { setSelectedDate(dateStr); setSelectedTime(""); }}
                                                className={cn(
                                                    "p-3 rounded-xl border text-center transition-all",
                                                    selectedDate === dateStr
                                                        ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
                                                        : "border-border/40 hover:border-border hover:bg-muted/30"
                                                )}
                                            >
                                                <p className="text-[10px] font-black uppercase text-muted-foreground/60">
                                                    {format(parseISO(dateStr), "EEE")}
                                                </p>
                                                <p className="text-lg font-black">{format(parseISO(dateStr), "d")}</p>
                                                <p className="text-[10px] font-bold text-muted-foreground/40">
                                                    {format(parseISO(dateStr), "MMM")}
                                                </p>
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {selectedDate && (
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                            Available Times — {format(parseISO(selectedDate), "EEEE, MMM d")}
                                        </label>
                                        {slotsLoading ? (
                                            <div className="text-center py-8 text-muted-foreground text-sm">Loading available times...</div>
                                        ) : availableSlots.length === 0 ? (
                                            <div className="text-center py-8 text-muted-foreground text-sm">No available slots for this date.</div>
                                        ) : (
                                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                                {availableSlots.map((slot) => {
                                                    const [h, m] = slot.split(":").map(Number);
                                                    const displayTime = format(new Date(2000, 0, 1, h, m), "h:mm a");
                                                    return (
                                                        <button
                                                            key={slot}
                                                            onClick={() => setSelectedTime(slot)}
                                                            className={cn(
                                                                "p-3 rounded-xl border text-center transition-all font-bold text-sm",
                                                                selectedTime === slot
                                                                    ? "border-primary bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                                                                    : "border-border/40 hover:border-primary/50 hover:bg-primary/5"
                                                            )}
                                                        >
                                                            {displayTime}
                                                        </button>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </motion.div>
                        )}

                        {/* Step 3: Client Details */}
                        {step === 3 && (
                            <motion.div
                                key="step3"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-5"
                            >
                                {/* Summary */}
                                <div className="bg-muted/30 rounded-2xl p-4 border border-border/40 space-y-2">
                                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Booking Summary</p>
                                    <div className="grid grid-cols-2 gap-2 text-sm">
                                        <div className="flex items-center gap-2">
                                            <User className="w-3.5 h-3.5 text-muted-foreground/50" />
                                            <span className="font-bold">{consultant?.displayName || consultant?.user.name}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {meetingType?.mode === "ONLINE" ? <Video className="w-3.5 h-3.5 text-muted-foreground/50" /> : <MapPin className="w-3.5 h-3.5 text-muted-foreground/50" />}
                                            <span className="font-medium text-muted-foreground">{meetingType?.name}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Calendar className="w-3.5 h-3.5 text-muted-foreground/50" />
                                            <span className="font-medium text-muted-foreground">{selectedDate && format(parseISO(selectedDate), "EEE, MMM d")}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Clock className="w-3.5 h-3.5 text-muted-foreground/50" />
                                            <span className="font-bold text-primary">
                                                {selectedTime && format(new Date(2000, 0, 1, ...selectedTime.split(":").map(Number)), "h:mm a")}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <div className="col-span-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 border-b border-border/20 pb-2">
                                        Client Information
                                    </div>
                                    
                                    {/* CRM Search Field */}
                                    <div className="relative">
                                        <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-xl px-3 py-2 text-primary focus-within:ring-2 ring-primary/20 transition-all">
                                            {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                                            <input 
                                                className="bg-transparent border-none outline-none text-sm w-full font-bold placeholder:text-primary/40 placeholder:font-medium"
                                                placeholder="Search existing client by name or email to auto-fill..."
                                                value={searchQuery}
                                                onChange={(e) => setSearchQuery(e.target.value)}
                                            />
                                        </div>
                                        {showResults && searchResults.length > 0 && (
                                            <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-zinc-900 border border-border/50 shadow-xl rounded-xl overflow-hidden z-50">
                                                {searchResults.map((client, idx) => (
                                                    <button
                                                        key={idx}
                                                        onClick={() => selectClient(client)}
                                                        className="w-full text-left px-4 py-3 hover:bg-muted/50 border-b border-border/10 last:border-0 transition-colors"
                                                    >
                                                        <div className="flex items-center justify-between">
                                                            <span className="font-bold text-sm">{client.name}</span>
                                                            <span className="text-[10px] font-black uppercase bg-primary/10 text-primary px-2 py-0.5 rounded-md">
                                                                {client.type}
                                                            </span>
                                                        </div>
                                                        <span className="text-xs text-muted-foreground">{client.email} {client.phone ? `• ${client.phone}` : ""}</span>
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                        {showResults && searchResults.length === 0 && searchQuery.length >= 2 && !isSearching && (
                                            <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-zinc-900 border border-border/50 shadow-xl rounded-xl p-4 text-center z-50">
                                                <p className="text-sm text-muted-foreground">No matching clients found in CRM.</p>
                                            </div>
                                        )}
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground/80 flex items-center gap-1.5">
                                                <User className="w-3.5 h-3.5" /> Full Name *
                                            </label>
                                            <Input
                                                className="h-11 rounded-xl shadow-sm text-base"
                                                placeholder="John Smith"
                                                value={guestName}
                                                onChange={(e) => setGuestName(e.target.value)}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground/80 flex items-center gap-1.5">
                                                <Mail className="w-3.5 h-3.5" /> Email Address *
                                            </label>
                                            <Input
                                                className="h-11 rounded-xl shadow-sm text-base"
                                                type="email"
                                                placeholder="john@example.com"
                                                value={guestEmail}
                                                onChange={(e) => setGuestEmail(e.target.value)}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground/80 flex items-center gap-1.5">
                                                <Phone className="w-3.5 h-3.5" /> Phone Number
                                            </label>
                                            <Input
                                                className="h-11 rounded-xl shadow-sm text-base"
                                                placeholder="+1 (555) 000-0000"
                                                value={guestPhone}
                                                onChange={(e) => setGuestPhone(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-xs font-bold text-foreground/80 flex items-center gap-1.5">
                                            <StickyNote className="w-3.5 h-3.5" /> Notes
                                        </label>
                                        <Textarea
                                            className="rounded-xl shadow-sm resize-none min-h-[60px] text-base"
                                            placeholder="Client mentioned they'd like to discuss..."
                                            value={guestNotes}
                                            onChange={(e) => setGuestNotes(e.target.value)}
                                        />
                                    </div>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* Footer */}
                <DialogFooter className="px-6 py-4 border-t border-border/40 flex items-center justify-between">
                    <Button
                        variant="outline"
                        className="rounded-xl"
                        onClick={() => step > 1 ? setStep(step - 1) : onOpenChange(false)}
                    >
                        <ChevronLeft className="w-4 h-4 mr-1" />
                        {step > 1 ? "Back" : "Cancel"}
                    </Button>

                    {step < 3 ? (
                        <Button
                            className="rounded-xl min-w-[120px]"
                            disabled={
                                (step === 1 && (!selectedConsultant || !selectedMeetingType)) ||
                                (step === 2 && (!selectedDate || !selectedTime))
                            }
                            onClick={() => setStep(step + 1)}
                        >
                            Next
                            <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                    ) : (
                        <Button
                            className="rounded-xl min-w-[160px]"
                            disabled={loading || !guestName || !guestEmail}
                            onClick={handleSubmit}
                        >
                            {loading ? "Booking..." : "✅ Confirm Booking"}
                        </Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
