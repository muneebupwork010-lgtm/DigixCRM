"use client";

import { useState, useEffect } from "react";
import { format, parseISO } from "date-fns";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
    Calendar, Video, MapPin, Clock, User, Mail, Phone, ChevronLeft,
    CheckCircle2, ArrowRight, CalendarClock, StickyNote
} from "lucide-react";
import { cn } from "@/lib/utils";
import { getAvailableDates, getAvailableSlots, createBooking } from "@/lib/actions/scheduler";
import { motion, AnimatePresence } from "framer-motion";

interface MeetingTypeData {
    id: string;
    name: string;
    description?: string;
    duration: number;
    color: string;
    mode: string;
    location?: string;
    locationNotes?: string;
}

interface ProfileData {
    id: string;
    displayName?: string;
    title?: string;
    bio?: string;
    user: { name: string; image?: string };
    workspace: { name: string; logo?: string };
    meetingTypes: MeetingTypeData[];
}

export function PublicBookingWizard({ profile }: { profile: ProfileData }) {
    const [step, setStep] = useState(1);

    // Selections
    const [selectedType, setSelectedType] = useState<string>("");
    const [selectedDate, setSelectedDate] = useState<string>("");
    const [selectedTime, setSelectedTime] = useState<string>("");

    // Available data
    const [availableDates, setAvailableDates] = useState<string[]>([]);
    const [availableSlots, setAvailableSlots] = useState<string[]>([]);
    const [slotsLoading, setSlotsLoading] = useState(false);

    // Guest details
    const [guestName, setGuestName] = useState("");
    const [guestEmail, setGuestEmail] = useState("");
    const [guestPhone, setGuestPhone] = useState("");
    const [guestNotes, setGuestNotes] = useState("");

    // Submission
    const [submitting, setSubmitting] = useState(false);
    const [confirmed, setConfirmed] = useState(false);
    const [bookingResult, setBookingResult] = useState<any>(null);
    const [error, setError] = useState("");

    const meetingType = profile.meetingTypes.find((mt) => mt.id === selectedType);

    // Load dates on type select
    useEffect(() => {
        if (selectedType) {
            getAvailableDates(profile.id, selectedType).then((res) => {
                if (res.success && res.dates) setAvailableDates(res.dates);
            });
        }
    }, [selectedType, profile.id]);

    // Load slots on date select
    useEffect(() => {
        if (selectedType && selectedDate) {
            setSlotsLoading(true);
            getAvailableSlots(profile.id, selectedType, selectedDate).then((res) => {
                if (res.success && res.slots) setAvailableSlots(res.slots);
                setSlotsLoading(false);
            });
        }
    }, [selectedType, selectedDate, profile.id]);

    const handleSubmit = async () => {
        if (!guestName || !guestEmail) {
            setError("Please fill in your name and email.");
            return;
        }
        setError("");
        setSubmitting(true);

        const [h, m] = selectedTime.split(":").map(Number);
        const dateObj = parseISO(selectedDate);
        dateObj.setHours(h, m, 0, 0);

        const result = await createBooking({
            meetingTypeId: selectedType,
            profileId: profile.id,
            startTime: dateObj.toISOString(),
            guestName,
            guestEmail,
            guestPhone: guestPhone || undefined,
            guestNotes: guestNotes || undefined,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        });

        if (result.success) {
            setBookingResult(result.booking);
            setConfirmed(true);
        } else {
            setError(result.error || "Something went wrong. Please try again.");
        }
        setSubmitting(false);
    };

    // ==========================================
    // CONFIRMATION SCREEN
    // ==========================================
    if (confirmed) {
        return (
            <Card className="max-w-lg w-full rounded-[2.5rem] p-8 sm:p-10 border-border/40 shadow-2xl text-center space-y-6">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200 }}>
                    <div className="w-20 h-20 mx-auto rounded-full bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center">
                        <CheckCircle2 className="w-10 h-10 text-emerald-500" />
                    </div>
                </motion.div>
                <div>
                    <h2 className="text-2xl font-black tracking-tight">You're All Set!</h2>
                    <p className="text-muted-foreground text-sm mt-2">Your meeting has been booked successfully.</p>
                </div>
                <div className="bg-muted/30 rounded-2xl p-5 space-y-3 text-left border border-border/20">
                    <div className="flex items-center gap-2">
                        {meetingType?.mode === "ONLINE" ? <Video className="w-4 h-4 text-primary" /> : <MapPin className="w-4 h-4 text-primary" />}
                        <span className="font-bold text-sm">{meetingType?.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-muted-foreground/50" />
                        <span className="text-sm">{selectedDate && format(parseISO(selectedDate), "EEEE, MMMM d, yyyy")}</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground/50" />
                        <span className="text-sm font-bold text-primary">
                            {selectedTime && format(new Date(2000, 0, 1, ...selectedTime.split(":").map(Number)), "h:mm a")}
                        </span>
                        <span className="text-xs text-muted-foreground">({meetingType?.duration} min)</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-muted-foreground/50" />
                        <span className="text-sm">with {profile.displayName || profile.user.name}</span>
                    </div>
                    {meetingType?.mode === "IN_PERSON" && meetingType?.location && (
                        <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-muted-foreground/50" />
                            <span className="text-sm text-muted-foreground">{meetingType.location}</span>
                        </div>
                    )}
                </div>
                <p className="text-xs text-muted-foreground/60">
                    A confirmation will be sent to <strong>{guestEmail}</strong>
                </p>
                <div className="pt-2 border-t border-border/20">
                    <p className="text-[10px] font-bold text-muted-foreground/40 uppercase tracking-[0.2em]">
                        Powered by {profile.workspace.name}
                    </p>
                </div>
            </Card>
        );
    }

    // ==========================================
    // BOOKING WIZARD
    // ==========================================
    return (
        <Card className="max-w-2xl w-full rounded-[2.5rem] overflow-hidden border-border/40 shadow-2xl">
            {/* Profile Header */}
            <div className="bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 px-6 sm:px-8 py-6 border-b border-border/20">
                <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center text-primary font-black text-xl">
                        {(profile.displayName || profile.user.name)?.charAt(0) || "?"}
                    </div>
                    <div>
                        <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                            Book with {profile.displayName || profile.user.name}
                        </h1>
                        {profile.title && (
                            <p className="text-sm text-muted-foreground font-medium">{profile.title} at {profile.workspace.name}</p>
                        )}
                    </div>
                </div>
                {profile.bio && (
                    <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{profile.bio}</p>
                )}
            </div>

            <div className="p-6 sm:p-8">
                <AnimatePresence mode="wait">
                    {/* STEP 1: Choose Meeting Type */}
                    {step === 1 && (
                        <motion.div
                            key="s1"
                            initial={{ opacity: 0, x: 30 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -30 }}
                            className="space-y-4"
                        >
                            <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                What would you like to schedule?
                            </h2>
                            <div className="space-y-3">
                                {profile.meetingTypes.map((mt) => (
                                    <button
                                        key={mt.id}
                                        onClick={() => { setSelectedType(mt.id); setStep(2); }}
                                        className="w-full flex items-center gap-4 p-5 rounded-2xl border border-border/40 hover:border-primary/50 hover:shadow-lg hover:-translate-y-0.5 transition-all text-left group"
                                    >
                                        <div
                                            className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                                            style={{ backgroundColor: `${mt.color}15` }}
                                        >
                                            {mt.mode === "ONLINE" ? (
                                                <Video className="w-6 h-6" style={{ color: mt.color }} />
                                            ) : (
                                                <MapPin className="w-6 h-6" style={{ color: mt.color }} />
                                            )}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="font-bold text-base">{mt.name}</p>
                                            <p className="text-sm text-muted-foreground mt-0.5">
                                                {mt.duration} min • {mt.mode === "ONLINE" ? "Online via Zoom" : `In-Person${mt.location ? ` • ${mt.location}` : ""}`}
                                            </p>
                                            {mt.description && (
                                                <p className="text-xs text-muted-foreground/60 mt-1">{mt.description}</p>
                                            )}
                                        </div>
                                        <ArrowRight className="w-5 h-5 text-muted-foreground/30 group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
                                    </button>
                                ))}
                            </div>
                        </motion.div>
                    )}

                    {/* STEP 2: Pick Date & Time */}
                    {step === 2 && (
                        <motion.div
                            key="s2"
                            initial={{ opacity: 0, x: 30 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -30 }}
                            className="space-y-5"
                        >
                            <button onClick={() => { setStep(1); setSelectedDate(""); setSelectedTime(""); }} className="flex items-center gap-1 text-sm font-bold text-muted-foreground hover:text-foreground transition-colors">
                                <ChevronLeft className="w-4 h-4" /> Back
                            </button>

                            {meetingType && (
                                <div className="flex items-center gap-3 bg-muted/30 rounded-xl px-4 py-3 border border-border/20">
                                    {meetingType.mode === "ONLINE" ? <Video className="w-4 h-4" style={{ color: meetingType.color }} /> : <MapPin className="w-4 h-4" style={{ color: meetingType.color }} />}
                                    <span className="text-sm font-bold">{meetingType.name}</span>
                                    <span className="text-xs text-muted-foreground">• {meetingType.duration} min</span>
                                </div>
                            )}

                            <div>
                                <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 mb-3">
                                    Pick a Date
                                </h2>
                                <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-[220px] overflow-y-auto">
                                    {availableDates.slice(0, 20).map((dateStr) => (
                                        <button
                                            key={dateStr}
                                            onClick={() => { setSelectedDate(dateStr); setSelectedTime(""); }}
                                            className={cn(
                                                "p-3 rounded-xl border text-center transition-all hover:-translate-y-0.5",
                                                selectedDate === dateStr
                                                    ? "border-primary bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                                                    : "border-border/40 hover:border-primary/50 hover:shadow-md"
                                            )}
                                        >
                                            <p className={cn("text-[10px] font-black uppercase", selectedDate === dateStr ? "text-primary-foreground/70" : "text-muted-foreground/50")}>
                                                {format(parseISO(dateStr), "EEE")}
                                            </p>
                                            <p className="text-xl font-black mt-0.5">{format(parseISO(dateStr), "d")}</p>
                                            <p className={cn("text-[10px] font-bold", selectedDate === dateStr ? "text-primary-foreground/60" : "text-muted-foreground/40")}>
                                                {format(parseISO(dateStr), "MMM")}
                                            </p>
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {selectedDate && (
                                <div>
                                    <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 mb-3">
                                        Available Times — {format(parseISO(selectedDate), "EEEE, MMM d")}
                                    </h2>
                                    {slotsLoading ? (
                                        <div className="text-center py-8">
                                            <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto" />
                                            <p className="text-sm text-muted-foreground mt-3">Loading times...</p>
                                        </div>
                                    ) : availableSlots.length === 0 ? (
                                        <div className="text-center py-8 bg-muted/20 rounded-2xl border border-dashed border-border/30">
                                            <CalendarClock className="w-8 h-8 mx-auto text-muted-foreground/30 mb-2" />
                                            <p className="text-sm text-muted-foreground">No available times on this day.</p>
                                            <p className="text-xs text-muted-foreground/60 mt-1">Please choose another date.</p>
                                        </div>
                                    ) : (
                                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                            {availableSlots.map((slot) => {
                                                const [h, m] = slot.split(":").map(Number);
                                                const displayTime = format(new Date(2000, 0, 1, h, m), "h:mm a");
                                                return (
                                                    <button
                                                        key={slot}
                                                        onClick={() => setSelectedTime(slot)}
                                                        className={cn(
                                                            "py-3 px-2 rounded-xl border text-center transition-all font-bold text-sm hover:-translate-y-0.5",
                                                            selectedTime === slot
                                                                ? "border-primary bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                                                                : "border-border/40 hover:border-primary/50 hover:shadow-md"
                                                        )}
                                                    >
                                                        {displayTime}
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    )}
                                </div>
                            )}

                            {selectedTime && (
                                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                                    <Button
                                        className="w-full h-12 rounded-xl text-base font-bold shadow-lg shadow-primary/20"
                                        onClick={() => setStep(3)}
                                    >
                                        Continue <ArrowRight className="w-4 h-4 ml-2" />
                                    </Button>
                                </motion.div>
                            )}
                        </motion.div>
                    )}

                    {/* STEP 3: Your Details */}
                    {step === 3 && (
                        <motion.div
                            key="s3"
                            initial={{ opacity: 0, x: 30 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -30 }}
                            className="space-y-5"
                        >
                            <button onClick={() => setStep(2)} className="flex items-center gap-1 text-sm font-bold text-muted-foreground hover:text-foreground transition-colors">
                                <ChevronLeft className="w-4 h-4" /> Back
                            </button>

                            {/* Summary */}
                            <div className="bg-muted/30 rounded-2xl p-4 border border-border/20 space-y-2">
                                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Your Appointment</p>
                                <div className="flex items-center gap-6 flex-wrap text-sm">
                                    <div className="flex items-center gap-1.5">
                                        {meetingType?.mode === "ONLINE" ? <Video className="w-4 h-4 text-primary" /> : <MapPin className="w-4 h-4 text-primary" />}
                                        <span className="font-bold">{meetingType?.name}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <Calendar className="w-4 h-4 text-muted-foreground/50" />
                                        <span>{selectedDate && format(parseISO(selectedDate), "EEE, MMM d")}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <Clock className="w-4 h-4 text-primary" />
                                        <span className="font-bold text-primary">
                                            {selectedTime && format(new Date(2000, 0, 1, ...selectedTime.split(":").map(Number)), "h:mm a")}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                                Tell us about yourself
                            </h2>

                            <div className="space-y-4">
                                <div className="space-y-1.5">
                                    <label className="text-sm font-bold flex items-center gap-1.5">
                                        <User className="w-4 h-4 text-muted-foreground/50" /> Your Name *
                                    </label>
                                    <Input
                                        className="h-12 rounded-xl shadow-sm text-base"
                                        placeholder="John Smith"
                                        value={guestName}
                                        onChange={(e) => setGuestName(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-sm font-bold flex items-center gap-1.5">
                                        <Mail className="w-4 h-4 text-muted-foreground/50" /> Email Address *
                                    </label>
                                    <Input
                                        className="h-12 rounded-xl shadow-sm text-base"
                                        type="email"
                                        placeholder="john@example.com"
                                        value={guestEmail}
                                        onChange={(e) => setGuestEmail(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-sm font-bold flex items-center gap-1.5">
                                        <Phone className="w-4 h-4 text-muted-foreground/50" /> Phone Number
                                    </label>
                                    <Input
                                        className="h-12 rounded-xl shadow-sm text-base"
                                        placeholder="+1 (555) 000-0000"
                                        value={guestPhone}
                                        onChange={(e) => setGuestPhone(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-1.5">
                                    <label className="text-sm font-bold flex items-center gap-1.5">
                                        <StickyNote className="w-4 h-4 text-muted-foreground/50" /> Anything we should know?
                                    </label>
                                    <Textarea
                                        className="rounded-xl shadow-sm resize-none min-h-[70px] text-base"
                                        placeholder="I'd like to discuss..."
                                        value={guestNotes}
                                        onChange={(e) => setGuestNotes(e.target.value)}
                                    />
                                </div>
                            </div>

                            {error && (
                                <div className="bg-red-500/10 text-red-600 dark:text-red-400 text-sm font-bold px-4 py-3 rounded-xl">
                                    {error}
                                </div>
                            )}

                            <Button
                                className="w-full h-13 rounded-xl text-base font-bold shadow-lg shadow-primary/20"
                                onClick={handleSubmit}
                                disabled={submitting || !guestName || !guestEmail}
                            >
                                {submitting ? (
                                    <div className="flex items-center gap-2">
                                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                                        Booking...
                                    </div>
                                ) : (
                                    <>✅ Confirm Booking</>
                                )}
                            </Button>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            {/* Footer */}
            <div className="px-6 sm:px-8 py-4 border-t border-border/20 text-center">
                <p className="text-[10px] font-bold text-muted-foreground/40 uppercase tracking-[0.15em]">
                    Powered by {profile.workspace.name}
                </p>
            </div>
        </Card>
    );
}
