"use client";

import { useState, useEffect } from "react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
    AlertCircle, 
    CheckCircle2, 
    Clock, 
    ArrowRight, 
    TrendingUp, 
    Zap,
    Briefcase,
    Target
} from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, Bar, BarChart } from "recharts";
import { cn } from "@/lib/utils";
import Link from "next/link";

interface IntelligenceFeedProps {
    overdueTasks?: any[];
    projectBriefs?: any[];
    recentLeads?: any[];
    hotDeals?: any[];
    userRole?: string;
}

export function IntelligenceFeed({ overdueTasks = [], projectBriefs = [], recentLeads = [], hotDeals = [], userRole }: IntelligenceFeedProps) {
    const isSalesOnly = !projectBriefs.length && !overdueTasks.length;

    return (
        <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden h-full"> 
            <CardHeader className="p-8 pb-4">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-xl font-black tracking-tight">Intelligence Feed</CardTitle>
                        <CardDescription className="text-xs font-bold opacity-60">
                            {isSalesOnly ? "Strategic focus and sales pulse" : "Critical focus and project pulse"}
                        </CardDescription>
                    </div>
                    <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 text-[10px] font-black uppercase tracking-widest px-3 py-1">
                        {isSalesOnly ? "Pipeline Control" : "Mission Control"}
                    </Badge>
                </div>
            </CardHeader>
            <CardContent className="p-8 pt-0 space-y-8">
                {/* Urgent Section */}
                <div className="space-y-4">
                    <div className={cn(
                        "flex items-center gap-2 text-[10px] font-black uppercase tracking-widest",
                        isSalesOnly ? "text-amber-500/80" : "text-red-500/80"
                    )}>
                        {isSalesOnly ? <Zap className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                        {isSalesOnly ? "Priority Leads" : "Critical Attention"}
                    </div>
                    <div className="space-y-3">
                        {isSalesOnly ? (
                            recentLeads.length > 0 ? recentLeads.slice(0, 3).map(lead => (
                                <div key={lead.id} className="group flex items-center justify-between p-4 rounded-2xl bg-amber-500/5 border border-amber-500/10 hover:border-amber-500/30 transition-all cursor-pointer">
                                    <div className="space-y-1">
                                        <p className="text-xs font-black truncate max-w-[180px]">{lead.firstName} {lead.lastName}</p>
                                        <p className="text-[9px] font-bold text-muted-foreground opacity-60 uppercase">{lead.service || "New Lead"}</p>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <Badge className="bg-amber-500/10 text-amber-500 border-none text-[9px] font-black uppercase">Recent</Badge>
                                        <ArrowRight className="w-4 h-4 text-amber-500 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                                    </div>
                                </div>
                            )) : (
                                <div className="p-6 text-center rounded-2xl border border-dashed border-border/40 bg-muted/5">
                                    <p className="text-[10px] font-black uppercase tracking-widest opacity-40">No new leads today</p>
                                </div>
                            )
                        ) : (
                            overdueTasks.length > 0 ? overdueTasks.map(task => (
                                <div key={task.id} className="group flex items-center justify-between p-4 rounded-2xl bg-red-500/5 border border-red-500/10 hover:border-red-500/30 transition-all cursor-pointer">
                                    <div className="space-y-1">
                                        <p className="text-xs font-black truncate max-w-[180px]">{task.title}</p>
                                        <p className="text-[9px] font-bold text-muted-foreground opacity-60 uppercase">{task.project?.name}</p>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <Badge className="bg-red-500/10 text-red-500 border-none text-[9px] font-black uppercase">Overdue</Badge>
                                        <ArrowRight className="w-4 h-4 text-red-500 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                                    </div>
                                </div>
                            )) : (
                                <div className="p-6 text-center rounded-2xl border border-dashed border-border/40 bg-muted/5">
                                    <CheckCircle2 className="w-8 h-8 text-emerald-500/40 mx-auto mb-2" />
                                    <p className="text-[10px] font-black uppercase tracking-widest opacity-40">All clear today</p>
                                </div>
                            )
                        )}
                    </div>
                </div>

                {/* Secondary Section */}
                <div className="space-y-4">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary/80">
                        {isSalesOnly ? <Target className="w-3 h-3" /> : <Briefcase className="w-3 h-3" />}
                        {isSalesOnly ? "Hot Opportunities" : "Active Projects"}
                    </div>
                    <div className="grid gap-3">
                        {isSalesOnly ? (
                            hotDeals.length > 0 ? hotDeals.slice(0, 3).map(deal => (
                                <div key={deal.id} className="p-4 rounded-2xl bg-muted/20 border border-border/20 hover:border-primary/30 transition-all">
                                    <div className="flex items-center justify-between mb-2">
                                        <p className="text-xs font-black truncate">{deal.title}</p>
                                        <span className="text-[10px] font-black text-primary">${(deal.value / 1000).toFixed(1)}k</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Badge variant="outline" className="text-[8px] font-black uppercase py-0">{deal.stage}</Badge>
                                        <span className="text-[9px] font-bold text-muted-foreground opacity-60 uppercase tracking-tighter">Updated {new Date(deal.updatedAt).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            )) : (
                                <div className="p-6 text-center rounded-2xl border border-dashed border-border/40 bg-muted/5">
                                    <p className="text-[10px] font-black uppercase tracking-widest opacity-40">No active deals</p>
                                </div>
                            )
                        ) : (
                            projectBriefs.map(project => (
                                <Link key={project.id} href={`/dashboard/projects/${project.id}`} className="block group">
                                    <div className="p-4 rounded-2xl bg-muted/20 border border-border/20 hover:border-primary/30 transition-all">
                                        <div className="flex items-center justify-between mb-3">
                                            <p className="text-xs font-black truncate">{project.name}</p>
                                            <span className="text-[10px] font-black text-primary">{project.progress}%</span>
                                        </div>
                                        <Progress value={project.progress} className="h-1.5 rounded-full bg-muted shadow-inner" />
                                        <p className="text-[9px] font-bold text-muted-foreground mt-2 opacity-60 uppercase tracking-tighter">{project.tasksLeft} tasks remaining</p>
                                    </div>
                                </Link>
                            ))
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

interface WeeklyPulseProps {
    data: any[];
}

export function WeeklyPulse({ data }: WeeklyPulseProps) {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);
    return (
        <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden h-full">
            <CardHeader className="p-8 pb-4">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-xl font-black tracking-tight">Weekly Pulse</CardTitle>
                        <CardDescription className="text-xs font-bold opacity-60">Workload momentum vs output</CardDescription>
                    </div>
                    <div className="flex items-center gap-4 text-[9px] font-black uppercase tracking-widest">
                        <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-primary" />
                            Created
                        </div>
                        <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            Completed
                        </div>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-8 pt-4">
                <div className="h-[300px] w-full mt-4">
                    {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                    <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                        <BarChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.2} />
                            <XAxis 
                                dataKey="name" 
                                fontSize={10} 
                                fontWeight={800} 
                                tickLine={false} 
                                axisLine={false} 
                                dy={10}
                            />
                            <YAxis 
                                hide 
                            />
                            <Tooltip 
                                contentStyle={{ borderRadius: '20px', border: '1px solid var(--border)', backgroundColor: 'var(--card)', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)' }}
                                cursor={{ fill: 'var(--primary)', opacity: 0.05 }}
                            />
                            <Bar 
                                dataKey="completed" 
                                fill="var(--primary)" 
                                radius={[6, 6, 0, 0]} 
                                barSize={12}
                            />
                            <Bar 
                                dataKey="created" 
                                fill="rgba(16, 185, 129, 0.5)" 
                                radius={[6, 6, 0, 0]} 
                                barSize={12}
                            />
                        </BarChart>
                    </ResponsiveContainer>
                    )}
                </div>
                
                <div className="mt-8 p-6 rounded-3xl bg-muted/10 border border-border/20 flex items-center justify-between">
                    <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground opacity-60">Team Momentum</p>
                        <h4 className="text-sm font-black">Velocity is stable</h4>
                    </div>
                    <div className="flex items-center gap-2 text-primary bg-primary/10 px-4 py-2 rounded-2xl border border-primary/10">
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-xs font-black">Normal</span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

export function SalesPulse({ data }: { data: any[] }) {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);
    return (
        <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden h-full">
            <CardHeader className="p-8 pb-4">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-xl font-black tracking-tight">Sales Pulse</CardTitle>
                        <CardDescription className="text-xs font-bold opacity-60">Lead acquisition vs conversion velocity</CardDescription>
                    </div>
                    <div className="flex items-center gap-4 text-[9px] font-black uppercase tracking-widest">
                        <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-primary" />
                            New Leads
                        </div>
                        <div className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-amber-500" />
                            Converted
                        </div>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-8 pt-4">
                <div className="h-[300px] w-full mt-4">
                    {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                    <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                        <AreaChart data={data}>
                            <defs>
                                <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.1}/>
                                    <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.2} />
                            <XAxis 
                                dataKey="name" 
                                fontSize={10} 
                                fontWeight={800} 
                                tickLine={false} 
                                axisLine={false} 
                                dy={10}
                            />
                            <Tooltip 
                                contentStyle={{ borderRadius: '20px', border: '1px solid var(--border)', backgroundColor: 'var(--card)', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)' }}
                            />
                            <Area 
                                type="monotone" 
                                dataKey="leads" 
                                stroke="var(--primary)" 
                                strokeWidth={4}
                                fillOpacity={1} 
                                fill="url(#colorLeads)" 
                            />
                            <Area 
                                type="monotone" 
                                dataKey="converted" 
                                stroke="#f59e0b" 
                                strokeWidth={4}
                                fillOpacity={0}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                    )}
                </div>
                
                <div className="mt-8 p-6 rounded-3xl bg-muted/10 border border-border/20 flex items-center justify-between">
                    <div className="space-y-1">
                        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground opacity-60">Pipeline Health</p>
                        <h4 className="text-sm font-black">Growth is consistent</h4>
                    </div>
                    <div className="flex items-center gap-2 text-amber-500 bg-amber-500/10 px-4 py-2 rounded-2xl border border-amber-500/10">
                        <Zap className="w-4 h-4" />
                        <span className="text-xs font-black">Optimal</span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
