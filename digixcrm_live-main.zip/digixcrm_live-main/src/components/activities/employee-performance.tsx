"use client";

import { useMemo, useState, useEffect } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Cell,
    PieChart,
    Pie,
    AreaChart,
    Area,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
    Zap, 
    Clock, 
    CheckCircle2,
    Calendar,
    Target,
    ArrowUpRight,
    Layout,
    TrendingUp,
    Timer,
    CheckSquare
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format, subDays, isSameDay, differenceInDays } from "date-fns";

interface EmployeePerformanceProps {
    tasks: any[];
    user: any;
    dateRange: { from: Date | undefined; to?: Date | undefined } | undefined;
}

export function EmployeePerformance({ tasks, user, dateRange }: EmployeePerformanceProps) {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);
    // 1. Weekly Velocity (Specific User)
    const velocityData = useMemo(() => {
        const from = dateRange?.from || subDays(new Date(), 30);
        const to = dateRange?.to || new Date();
        const days = differenceInDays(to, from) + 1;
        
        // Group by day for the chart
        const dailyData: { [key: string]: number } = {};
        tasks.forEach(t => {
            if (t.status === "DONE" && t.updatedAt) {
                const dayKey = format(new Date(t.updatedAt), "MMM dd");
                dailyData[dayKey] = (dailyData[dayKey] || 0) + 1;
            }
        });

        // Ensure we have a smooth line even if days are missing
        const result = [];
        for (let i = 0; i < Math.min(days, 14); i++) {
            const date = subDays(to, i);
            const key = format(date, "MMM dd");
            result.unshift({
                date: key,
                completed: dailyData[key] || 0
            });
        }
        return result;
    }, [tasks, dateRange]);

    // 2. Performance Metrics
    const stats = useMemo(() => {
        const completedTasks = tasks.filter(t => t.status === "DONE");
        const completedCount = completedTasks.length;
        const total = tasks.length;
        
        const onTime = completedTasks.filter(t => 
            t.dueDate && t.updatedAt && new Date(t.updatedAt) <= new Date(t.dueDate)
        ).length;

        // Efficiency: Only look at completed tasks that actually have time data
        const tasksWithTime = completedTasks.filter(t => (t.estimatedHours || 0) > 0);
        const totalEst = tasksWithTime.reduce((sum, t) => sum + (t.estimatedHours || 0), 0);
        const totalAct = tasksWithTime.reduce((sum, t) => sum + (t.actualHours || 0), 0);

        let efficiency = 100;
        if (totalEst > 0 && totalAct > 0) {
            efficiency = (totalEst / totalAct) * 100;
        } else if (totalEst > 0 && totalAct === 0 && completedCount > 0) {
            // Completed but no actual hours logged? Assume 100% or don't skew
            efficiency = 100;
        }

        return {
            completed: completedCount,
            total,
            successRate: total > 0 ? (completedCount / total) * 100 : 0,
            onTimeRate: completedCount > 0 ? (onTime / completedCount) * 100 : 0,
            efficiency: Math.min(efficiency, 200) // Cap at 200% to keep it realistic
        };
    }, [tasks]);

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {/* KPI Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <KPICard 
                    title="Throughput" 
                    value={stats.completed} 
                    subtitle={`of ${stats.total} assigned tasks done`}
                    icon={<CheckSquare className="w-5 h-5 text-emerald-500" />}
                    color="emerald"
                />
                <KPICard 
                    title="Efficiency" 
                    value={`${Math.round(stats.efficiency)}%`} 
                    subtitle="Estimated vs Actual hours"
                    icon={<Timer className="w-5 h-5 text-blue-500" />}
                    color="blue"
                />
                <KPICard 
                    title="Reliability" 
                    value={`${Math.round(stats.onTimeRate)}%`} 
                    subtitle="Completed before due date"
                    icon={<TrendingUp className="w-5 h-5 text-indigo-500" />}
                    color="indigo"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Velocity Pulse */}
                <Card className="border-border/40 shadow-sm bg-card rounded-3xl overflow-hidden">
                    <CardHeader className="p-6 pb-0">
                        <CardTitle className="text-sm font-black uppercase tracking-widest text-muted-foreground">Output Consistency</CardTitle>
                        <CardDescription className="text-xs font-bold">Tasks completed over selected timeline</CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                        <div className="h-[200px] w-full">
                            {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <AreaChart data={velocityData}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.2} />
                                    <XAxis 
                                        dataKey="date" 
                                        fontSize={10} 
                                        fontWeight={700}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <Tooltip />
                                    <Area 
                                        type="monotone" 
                                        dataKey="completed" 
                                        stroke="var(--primary)" 
                                        fill="var(--primary)" 
                                        fillOpacity={0.1} 
                                        strokeWidth={3}
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Profile Snapshot */}
                <Card className="border-border/40 shadow-sm bg-card rounded-3xl p-6 flex flex-col justify-between">
                    <div className="flex items-center gap-4">
                        <div className="bg-primary/10 p-4 rounded-2xl">
                            <Target className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="text-lg font-black tracking-tight">{user?.name}'s Summary</h3>
                            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground italic">Current Productivity Context</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-6">
                        <div className="p-4 rounded-2xl bg-muted/30 border border-border/20">
                            <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest mb-1">Success Rate</p>
                            <p className="text-xl font-black">{Math.round(stats.successRate)}%</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-muted/30 border border-border/20">
                            <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest mb-1">Open Load</p>
                            <p className="text-xl font-black">{stats.total - stats.completed}</p>
                        </div>
                    </div>

                    <p className="text-[10px] font-bold text-muted-foreground mt-6 leading-relaxed bg-muted/10 p-3 rounded-xl border border-dashed border-border/40">
                        {stats.onTimeRate > 80 
                            ? "Exhibits high dependability with consistent on-time delivery." 
                            : stats.completed > 5 
                                ? "Maintains a steady output but watch for timeline deviations."
                                : "Awaiting more data to establish a performance baseline."}
                    </p>
                </Card>
            </div>
        </div>
    );
}

function KPICard({ title, value, subtitle, icon, color }: any) {
    const bgColors: any = {
        emerald: "bg-emerald-500/10 text-emerald-500",
        blue: "bg-blue-500/10 text-blue-500",
        indigo: "bg-indigo-500/10 text-indigo-500"
    };

    return (
        <Card className="border-border/40 shadow-sm bg-card rounded-3xl p-5 hover:border-primary/20 transition-all">
            <div className="flex items-center justify-between mb-3">
                <div className={cn("p-2 rounded-xl", bgColors[color])}>
                    {icon}
                </div>
                <Badge variant="outline" className="text-[9px] font-black uppercase tracking-tighter border-none bg-muted/50">Performance</Badge>
            </div>
            <div className="space-y-0.5">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">{title}</p>
                <h3 className="text-3xl font-black tracking-tighter">{value}</h3>
                <p className="text-[10px] font-bold text-muted-foreground/50">{subtitle}</p>
            </div>
        </Card>
    );
}
