"use client";

import { useMemo, useState, useEffect } from "react";
import { User } from "@/generated/prisma/client/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
    DollarSign, 
    Target, 
    TrendingUp, 
    Users, 
    Activity, 
    Pencil, 
    Check, 
    X,
    LayoutDashboard,
    PieChart,
    Briefcase,
    ChevronDown,
    Search
} from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { startOfDay, endOfDay, isWithinInterval, subDays, format } from "date-fns";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { updateUserTarget } from "@/lib/actions/targets";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from "@/components/ui/select";
import { EmployeePerformance } from "./employee-performance";
import { cn } from "@/lib/utils";

interface PerformanceHubProps {
    currentUser: User;
    effectiveRole: string;
    leads: any[];
    deals: any[];
    tasks: any[];
    targets?: Record<string, number>;
    workspaceUsers?: any[];
}

export function PerformanceHub({ 
    currentUser, 
    effectiveRole, 
    leads, 
    deals, 
    tasks,
    targets = {}, 
    workspaceUsers = [] 
}: PerformanceHubProps) {
    const defaultFrom = subDays(new Date(), 30);
    const [dateRange, setDateRange] = useState<{ from: Date | undefined; to?: Date | undefined } | undefined>({
        from: defaultFrom,
        to: new Date()
    });

    const [selectedUserId, setSelectedUserId] = useState<string>("all");
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);

    const showSales = effectiveRole !== "STAFF";
    const isManagerOrAdmin = effectiveRole === "ADMIN" || effectiveRole === "MANAGER";
    const [activeTab, setActiveTab] = useState(showSales ? "sales" : "pms");

    const relevantUsers = useMemo(() => {
        return workspaceUsers.filter(user => {
            if (activeTab === "sales") {
                return user.role === "ADMIN" || user.role === "MANAGER" || user.role === "REP";
            } else {
                return user.role === "ADMIN" || user.role === "MANAGER" || user.role === "PROJECT_MANAGER" || user.role === "STAFF";
            }
        });
    }, [workspaceUsers, activeTab]);

    // Reset user selection if the currently selected user is not relevant to the new tab
    useEffect(() => {
        if (selectedUserId !== "all" && !relevantUsers.some(u => u.id === selectedUserId)) {
            setSelectedUserId("all");
        }
    }, [activeTab, relevantUsers, selectedUserId]);

    // Filter Logic
    const { filteredLeads, filteredDeals, filteredTasks } = useMemo(() => {
        const from = dateRange?.from ? startOfDay(dateRange.from) : undefined;
        const to = dateRange?.to ? endOfDay(dateRange.to) : from ? endOfDay(from) : undefined;
        
        let l = leads;
        let d = deals;
        let t = tasks;

        // 1. Date Range Filter
        if (from && to) {
            const interval = { start: from, end: to };
            l = leads.filter(item => isWithinInterval(new Date(item.createdAt), interval));
            d = deals.filter(item => isWithinInterval(new Date(item.createdAt), interval));
            // Tasks use updatedAt for completion tracking or createdAt for assignment
            t = tasks.filter(item => isWithinInterval(new Date(item.updatedAt || item.createdAt), interval));
        }

        // 2. User Selection Filter (Only if Admin/Manager)
        if (selectedUserId !== "all" && isManagerOrAdmin) {
            l = l.filter(item => item.ownerId === selectedUserId);
            d = d.filter(item => item.ownerId === selectedUserId);
            t = t.filter(item => item.assigneeId === selectedUserId);
        } else if (!isManagerOrAdmin) {
            // Strict self-view for REPs
            l = l.filter(item => item.ownerId === currentUser.id);
            d = d.filter(item => item.ownerId === currentUser.id);
            t = t.filter(item => item.assigneeId === currentUser.id);
        }

        return { filteredLeads: l, filteredDeals: d, filteredTasks: t };
    }, [leads, deals, tasks, dateRange, selectedUserId, isManagerOrAdmin, currentUser.id]);

    const myWonDeals = filteredDeals.filter(d => d.stage === "WON" || d.customStage === "ONBOARDED");
    const myRevenue = myWonDeals.reduce((sum, d) => sum + (Number(d.value) || 0), 0);
    const myConvertedLeads = filteredLeads.filter(l => l.status === "CONVERTED");

    // Dynamic Targets
    const [localTargets, setLocalTargets] = useState(targets);
    const [editingUserId, setEditingUserId] = useState<string | null>(null);
    const [editTargetValue, setEditTargetValue] = useState("");
    const [isSavingTarget, setIsSavingTarget] = useState(false);

    const baseMonthlyTarget = (selectedUserId === "all" && isManagerOrAdmin)
        ? workspaceUsers.reduce((sum, u) => sum + (localTargets[u.id] || 0), 0)
        : (localTargets[selectedUserId === "all" ? currentUser.id : selectedUserId] || 0); 
        
    const monthlyTarget = baseMonthlyTarget > 0 ? baseMonthlyTarget : 0;
    const targetProgress = monthlyTarget > 0 ? Math.min((myRevenue / monthlyTarget) * 100, 100) : 0;

    const handleSaveUserTarget = async (userId: string) => {
        const numVal = parseFloat(editTargetValue);
        if (isNaN(numVal) || numVal <= 0) {
            toast.error("Please enter a valid positive number");
            return;
        }

        setIsSavingTarget(true);
        const res = await updateUserTarget(userId, numVal);
        if (res.success) {
            toast.success("Rep Target updated!");
            setLocalTargets(prev => ({ ...prev, [userId]: numVal }));
            setEditingUserId(null);
        } else {
            toast.error(res.error || "Failed to update target");
        }
        setIsSavingTarget(false);
    };

    const conversionRate = filteredLeads.length > 0
        ? Math.round((myConvertedLeads.length / filteredLeads.length) * 100)
        : 0;

    const revenueChartData = useMemo(() => {
        const sortedDeals = [...myWonDeals].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        const sortedMap: Record<string, number> = {};
        
        sortedDeals.forEach(deal => {
            const dayKey = format(new Date(deal.createdAt), "MMM dd");
            if (!sortedMap[dayKey]) sortedMap[dayKey] = 0;
            sortedMap[dayKey] += Number(deal.value) || 0;
        });

        if (Object.keys(sortedMap).length === 0) {
            return [{ date: format(subDays(new Date(), 7), "MMM dd"), revenue: 0 }, { date: format(new Date(), "MMM dd"), revenue: 0 }];
        }

        return Object.entries(sortedMap).map(([date, revenue]) => ({ date, revenue }));
    }, [myWonDeals]);

    // Leaderboard Data Restoration
    const leaderboard = useMemo(() => {
        const repMap: Record<string, { id: string; name: string; totalRevenue: number; wonDeals: number; totalLeads: number; convertedLeads: number }> = {};

        filteredLeads.forEach(lead => {
            if (!lead.ownerId) return;
            const repId = lead.ownerId;
            const repName = lead.owner?.name || "Unknown Rep";
            if (!repMap[repId]) repMap[repId] = { id: repId, name: repName, totalRevenue: 0, wonDeals: 0, totalLeads: 0, convertedLeads: 0 };
            repMap[repId].totalLeads += 1;
            if (lead.status === "CONVERTED") repMap[repId].convertedLeads += 1;
        });

        filteredDeals.forEach(deal => {
            if (!deal.ownerId) return;
            const repId = deal.ownerId;
            const repName = deal.owner?.name || "Unknown Rep";
            if (!repMap[repId]) repMap[repId] = { id: repId, name: repName, totalRevenue: 0, wonDeals: 0, totalLeads: 0, convertedLeads: 0 };
            if (deal.stage === "WON" || deal.customStage === "ONBOARDED") {
                repMap[repId].wonDeals += 1;
                repMap[repId].totalRevenue += Number(deal.value) || 0;
            }
        });

        return Object.values(repMap).sort((a, b) => b.totalRevenue - a.totalRevenue);
    }, [filteredLeads, filteredDeals]);

    return (
        <div className="space-y-8 pb-10">
            {/* Global Controls */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-card/60 backdrop-blur-xl p-6 rounded-[2rem] border border-border/40 shadow-xl shadow-primary/5 sticky top-0 z-40">
                <div className="flex items-center gap-6">
                    <div className="bg-primary/10 p-2.5 rounded-2xl">
                        <Activity className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                        <h2 className="text-sm font-black uppercase tracking-widest text-foreground/70">Context Control</h2>
                        <p className="text-[10px] font-bold text-muted-foreground/60">Filtering {selectedUserId === "all" ? "Team-Wide" : "Individual"} Data</p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-4">
                    {isManagerOrAdmin && (
                        <div className="flex items-center gap-3 bg-muted/20 px-4 py-1.5 rounded-2xl border border-border/20">
                            <span className="text-[10px] font-black uppercase text-muted-foreground/60 whitespace-nowrap">Focus on:</span>
                            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                                <SelectTrigger className="w-[180px] bg-transparent border-0 ring-0 focus:ring-0 text-[11px] font-black h-8 p-0 px-2 uppercase tracking-wide">
                                    <SelectValue placeholder="Team Member" />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl border-border/40 bg-card/95 backdrop-blur-xl">
                                    <SelectItem value="all" className="text-[11px] font-bold uppercase tracking-wide">Global Dashboard</SelectItem>
                                    {relevantUsers.map(user => (
                                        <SelectItem key={user.id} value={user.id} className="text-[11px] font-bold uppercase tracking-wide">
                                            {user.name} ({user.role})
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    <div className="bg-muted/20 p-1.5 rounded-2xl border border-border/20">
                        <DatePickerWithRange date={dateRange} setDate={setDateRange} />
                    </div>
                </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
                <TabsList className="bg-muted/20 p-1.5 rounded-2xl h-14 border border-border/20 gap-2">
                    {showSales && (
                        <TabsTrigger value="sales" className="rounded-xl px-8 data-[state=active]:bg-card data-[state=active]:shadow-lg text-[10px] font-black uppercase tracking-widest gap-2">
                            <TrendingUp className="w-3.5 h-3.5" />
                            Sales Pipeline
                        </TabsTrigger>
                    )}
                    <TabsTrigger value="pms" className="rounded-xl px-8 data-[state=active]:bg-card data-[state=active]:shadow-lg text-[10px] font-black uppercase tracking-widest gap-2">
                        <Briefcase className="w-3.5 h-3.5" />
                        Personnel (PMS)
                    </TabsTrigger>
                </TabsList>

                {showSales && (
                    <TabsContent value="sales" className="space-y-8 mt-0 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <KPICard title="Revenue Generated" value={`$${myRevenue.toLocaleString()}`} subtitle="Verified closures" icon={<DollarSign className="w-5 h-5" />} color="emerald" />
                        <ProgressCard title="Quota Target" value={`$${monthlyTarget.toLocaleString()}`} progress={targetProgress} subtitle={`${targetProgress.toFixed(0)}% reached`} icon={<Target className="w-5 h-5 text-indigo-500" />} />
                        <KPICard title="Conversion" value={`${conversionRate}%`} subtitle={`${myConvertedLeads.length} leads won`} icon={<TrendingUp className="w-5 h-5" />} color="purple" />
                        <KPICard title="Total Leads" value={filteredLeads.length} subtitle="Captured/Assigned" icon={<Users className="w-5 h-5" />} color="orange" />
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                        <Card className="xl:col-span-2 border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden">
                            <CardHeader className="p-8 pb-0">
                                <CardTitle className="text-xl font-black">Velocity Growth</CardTitle>
                                <CardDescription className="text-xs font-bold opacity-60">Visualizing {selectedUserId === "all" ? "cumulative team" : "individual"} revenue closed</CardDescription>
                            </CardHeader>
                            <CardContent className="p-8 pt-4">
                                <div className="h-[300px] w-full mt-6">
                                    {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-[2rem]" /> : (
                                        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                            <AreaChart data={revenueChartData}>
                                                <defs>
                                                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                                        <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                                                        <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                                                    </linearGradient>
                                                </defs>
                                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.3} />
                                                <XAxis dataKey="date" stroke="var(--muted-foreground)" fontSize={10} fontWeight={800} tickLine={false} axisLine={false} />
                                                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: 'var(--muted-foreground)' }} />
                                                <Tooltip contentStyle={{ borderRadius: '16px', border: '1px solid var(--border)', backgroundColor: 'var(--card)' }} />
                                                <Area type="monotone" dataKey="revenue" stroke="var(--primary)" strokeWidth={4} fillOpacity={1} fill="url(#colorRevenue)" />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Restore Leaderboard UI */}
                        <div className="space-y-6">
                            <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card p-2">
                                <CardHeader className="p-6 pb-2">
                                    <CardTitle className="text-sm font-black uppercase tracking-widest opacity-70">Top Performers</CardTitle>
                                    <CardDescription className="text-[10px] font-bold">Revenue Leaderboard</CardDescription>
                                </CardHeader>
                                <CardContent className="p-2 space-y-1">
                                    {leaderboard.length > 0 ? (
                                        leaderboard.slice(0, 5).map((rep, idx) => (
                                            <div key={rep.id} className="flex items-center justify-between p-4 rounded-2xl hover:bg-muted/30 transition-colors group">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-black text-primary border border-primary/20">
                                                        {idx + 1}
                                                    </div>
                                                    <div>
                                                        <p className="text-xs font-black tracking-tight">{rep.name}</p>
                                                        <p className="text-[9px] font-bold text-muted-foreground opacity-60">{rep.wonDeals} deals won</p>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-xs font-black text-primary">${rep.totalRevenue.toLocaleString()}</p>
                                                    <div className="flex items-center justify-end gap-1 mt-1">
                                                        {editingUserId === rep.id ? (
                                                            <div className="flex items-center gap-1">
                                                                <Input 
                                                                    className="h-5 w-16 text-[9px] font-black px-1" 
                                                                    value={editTargetValue} 
                                                                    onChange={(e) => setEditTargetValue(e.target.value)}
                                                                    onBlur={() => setEditingUserId(null)}
                                                                    autoFocus
                                                                />
                                                            </div>
                                                        ) : (
                                                            <p className="text-[8px] font-black uppercase tracking-tighter opacity-40 cursor-pointer hover:opacity-100 transition-opacity" onClick={() => {
                                                                setEditingUserId(rep.id);
                                                                setEditTargetValue((localTargets[rep.id] || 0).toString());
                                                            }}>
                                                                Target: ${(localTargets[rep.id] || 0).toLocaleString()}
                                                            </p>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="p-10 text-center opacity-40 text-[10px] font-black uppercase tracking-widest">No data available</div>
                                    )}
                                </CardContent>
                            </Card>

                            <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card p-2">
                                <CardHeader className="p-6 pb-2">
                                    <p className="text-sm font-black uppercase tracking-widest opacity-70">Efficiency</p>
                                    <CardDescription className="text-[10px] font-bold">Conversion Rate</CardDescription>
                                </CardHeader>
                                <CardContent className="p-4 space-y-4">
                                    {leaderboard.slice(0, 3).map((rep) => {
                                        const rate = rep.totalLeads > 0 ? Math.round((rep.convertedLeads / rep.totalLeads) * 100) : 0;
                                        return (
                                            <div key={rep.id} className="space-y-1.5">
                                                <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-tighter opacity-70 px-1">
                                                    <span>{rep.name}</span>
                                                    <span>{rate}%</span>
                                                </div>
                                                <div className="h-1.5 w-full bg-muted/30 rounded-full overflow-hidden">
                                                    <div className="h-full bg-primary rounded-full transition-all duration-1000" style={{ width: `${rate}%` }} />
                                                </div>
                                            </div>
                                        );
                                    })}
                                </CardContent>
                            </Card>
                        </div>
                        </div>
                    </TabsContent>
                )}

                <TabsContent value="pms" className="space-y-8 mt-0">
                    <EmployeePerformance 
                        tasks={filteredTasks} 
                        user={selectedUserId === "all" ? currentUser : workspaceUsers.find(u => u.id === selectedUserId)} 
                        dateRange={dateRange}
                    />
                </TabsContent>
            </Tabs>
        </div>
    );
}

function KPICard({ title, value, subtitle, icon, color }: any) {
    const colorMap: any = {
        emerald: "bg-emerald-500/10 text-emerald-500",
        purple: "bg-purple-500/10 text-purple-500",
        orange: "bg-orange-500/10 text-orange-500"
    };

    return (
        <Card className="border-border/40 shadow-xl rounded-[2rem] bg-card p-6 hover:border-primary/20 transition-all">
            <div className="flex items-center justify-between mb-4">
                <div className={cn("p-2.5 rounded-2xl", colorMap[color])}>{icon}</div>
                <Badge variant="outline" className="text-[9px] font-black uppercase border-none bg-muted/50">Sales KPI</Badge>
            </div>
            <div className="space-y-0.5">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">{title}</p>
                <h3 className="text-3xl font-black tracking-tighter">{value}</h3>
                <p className="text-[10px] font-bold text-muted-foreground/50">{subtitle}</p>
            </div>
        </Card>
    );
}

function ProgressCard({ title, value, progress, subtitle, icon }: any) {
    return (
        <Card className="border-border/40 shadow-xl rounded-[2rem] bg-card p-6">
            <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 rounded-2xl bg-indigo-500/10">{icon}</div>
                <Badge variant="outline" className="text-[9px] font-black uppercase border-none bg-indigo-500/10 text-indigo-500">Target</Badge>
            </div>
            <div className="space-y-0.5 mb-3">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">{title}</p>
                <h3 className="text-3xl font-black tracking-tighter">{value}</h3>
            </div>
            <div className="space-y-2">
                <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-[9px] font-black text-indigo-500/80 uppercase tracking-widest">{subtitle}</p>
            </div>
        </Card>
    );
}

function Badge({ children, className, variant }: any) {
    return (
        <span className={cn(
            "px-2 py-0.5 rounded-full inline-flex items-center",
            variant === "outline" ? "border" : "bg-primary text-primary-foreground",
            className
        )}>
            {children}
        </span>
    );
}

