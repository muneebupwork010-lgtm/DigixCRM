"use client";

import { cn } from "@/lib/utils";
import Image from "next/image";

interface LogoProps {
    className?: string;
    variant?: "emblem" | "horizontal" | "vertical";
    size?: "sm" | "md" | "lg" | "xl";
    showText?: boolean;
}

export function Logo({ className, variant = "horizontal", size = "md", showText }: LogoProps) {
    // Backward compatibility: If showText is explicitly false, force emblem.
    // If showText is true, force horizontal.
    let resolvedVariant = variant;
    if (showText === false) resolvedVariant = "emblem";
    if (showText === true) resolvedVariant = "horizontal";

    const sizeMap = {
        emblem: { sm: "h-6", md: "h-8", lg: "h-10", xl: "h-14" },
        horizontal: { sm: "h-8", md: "h-11", lg: "h-14", xl: "h-20" },
        vertical: { sm: "h-20", md: "h-32", lg: "h-40", xl: "h-48" },
    };
    
    const heightClass = sizeMap[resolvedVariant][size];

    const logoDefinitions = {
        emblem: { light: "/logo-emblem-dark.png", dark: "/logo-emblem-light.png" },
        horizontal: { light: "/logo-horizontal-dark.png", dark: "/logo-horizontal-light.png" },
        vertical: { light: "/logo-vertical-dark.png", dark: "/logo-vertical-light.png" },
    };

    const srcs = logoDefinitions[resolvedVariant];

    return (
        <div className={cn("relative inline-flex items-center justify-center shrink-0 transition-opacity", heightClass, className)}>
            {/* Light Theme Logo (Hidden in dark mode) */}
            <img
                src={srcs.light}
                alt="DigixCRM Logo"
                className="w-auto h-full block dark:hidden object-contain"
            />
            {/* Dark Theme Logo (Hidden in light mode) */}
            <img
                src={srcs.dark}
                alt="DigixCRM Logo"
                className="w-auto h-full hidden dark:block object-contain"
            />
        </div>
    );
}
