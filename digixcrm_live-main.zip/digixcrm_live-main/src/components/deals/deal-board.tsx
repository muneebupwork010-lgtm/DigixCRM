"use client";

import { useState, useRef, useEffect } from "react";
import { DealStage } from "@/generated/prisma/client/client";
import { updateDealStage } from "@/lib/actions/deals";
import { DealSheet } from "./deal-sheet";
import { toast } from "sonner";

import { AlertCircle, CheckCircle2, UserCircle, Search, FilterX, ChevronLeft, ChevronRight, GripHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useRouter } from "next/navigation";
import { MultiSelect } from "@/components/ui/multi-select";

import {
    DndContext,
    useSensor,
    useSensors,
    MouseSensor,
    TouchSensor,
    DragOverlay,
    defaultDropAnimationSideEffects,
    DragStartEvent,
    DragEndEvent,
    closestCenter
} from "@dnd-kit/core";
import { useDraggable, useDroppable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";

// Make sure to extend Deal type to include Organization name if fetched
type EnhancedDeal = {
    id: string;
    title: string;
    value: number;
    stage: DealStage;
    customStage?: string | null;
    organization?: { name: string } | null;
    updatedAt: Date;
    createdAt: Date;
    source?: string | null;
    project?: { id: string } | null;
    owner?: { name: string | null; email: string | null; image?: string | null } | null;
    contacts?: { firstName: string; lastName: string; email?: string | null }[];
};

interface DealBoardProps {
    data: EnhancedDeal[];
    effectiveRole: string;
    organizations: { id: string; name: string }[];
    dealStages: any;
    users: { id: string; name: string | null; image?: string | null }[];
}

function DroppableColumn({ id, children, className }: any) {
    const { setNodeRef, isOver } = useDroppable({ id });
    return (
        <div ref={setNodeRef} className={`${className} transition-all duration-300 ${isOver ? 'ring-2 ring-primary/50 bg-primary/5' : ''}`}>
           {children}
        </div>
    );
}

function DraggableCard({ deal, isRotten, daysInStage, stage, handleOnboard, handleArchive, onClick }: any) {
    const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
        id: deal.id,
        data: { deal }
    });

    const style = {
        transform: CSS.Translate.toString(transform),
        opacity: isDragging ? 0.3 : 1,
        touchAction: 'manipulation' // Prevents browser scrolling when dragging the card on mobile
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...attributes}
            {...listeners}
            onClick={onClick}
            className={`bg-card p-4 rounded-xl shadow-[0_2px_10px_rgb(0,0,0,0.02)] border ${isRotten ? 'border-red-500/50' : 'border-border/60'} cursor-grab active:cursor-grabbing hover:border-border/80 hover:shadow-[0_4px_16px_rgb(0,0,0,0.06)] transition-all relative group`}
        >
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <GripHorizontal className="w-4 h-4 text-muted-foreground/30" />
            </div>

            <div className="font-semibold text-[15px] text-foreground leading-tight mb-1 pr-6">
                {deal.title}
            </div>
            <div className="text-sm font-medium tracking-tight text-muted-foreground mb-4">
                ${deal.value.toLocaleString()}
            </div>

            <div className="flex items-center justify-between mb-4">
                <div className="flex -space-x-2">
                    <Avatar className="w-6 h-6 border-2 border-background ring-1 ring-border shadow-sm">
                        <AvatarImage src={deal.owner?.image || ""} />
                        <AvatarFallback className="text-[6px] font-bold">
                            {deal.owner?.name?.substring(0, 2).toUpperCase() || "?"}
                        </AvatarFallback>
                    </Avatar>
                </div>
                <div>
                    {isRotten ? (
                        <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center">
                            <AlertCircle className="w-3 h-3 text-red-600" />
                        </div>
                    ) : (
                        <div className="w-5 h-5 rounded-full bg-indigo-100 flex items-center justify-center">
                            <CheckCircle2 className="w-3 h-3 text-indigo-600" />
                        </div>
                    )}
                </div>
            </div>

            <div className="pt-3 border-t border-border/50 flex items-center justify-between text-muted-foreground">
                <span className="text-[11px] font-medium">{daysInStage} days in stage</span>
            </div>

            {stage.value === "WON" && (
                <div className="mt-3 animate-in fade-in zoom-in duration-300 relative z-10" onPointerDown={(e) => e.stopPropagation()}>
                    <button 
                        onClick={(e) => { e.stopPropagation(); handleOnboard(e, deal.id); }}
                        className="w-full py-1.5 text-xs font-bold rounded-md bg-indigo-600 hover:bg-indigo-700 text-white transition-colors shadow-sm border border-indigo-800"
                    >
                        Process Order →
                    </button>
                </div>
            )}
            {stage.value === "LOST" && (
                <div className="mt-3 animate-in fade-in zoom-in duration-300 relative z-10" onPointerDown={(e) => e.stopPropagation()}>
                    <button 
                        onClick={(e) => { e.stopPropagation(); handleArchive(e, deal.id); }}
                        className="w-full py-1.5 text-xs font-bold rounded-md bg-stone-700 hover:bg-stone-800 text-white transition-colors shadow-sm border border-stone-900"
                    >
                        Archive Deal →
                    </button>
                </div>
            )}
        </div>
    );
}

export function DealBoard({ data, effectiveRole, organizations, dealStages, users }: DealBoardProps) {
    const [deals, setDeals] = useState<EnhancedDeal[]>(data);
    const [selectedDeal, setSelectedDeal] = useState<EnhancedDeal | null>(null);

    useEffect(() => {
        setDeals(data);
        if (selectedDeal) {
            const updated = data.find((d: any) => d.id === selectedDeal.id);
            if (updated) setSelectedDeal(updated);
        }
    }, [data]);
    const [activeDragDeal, setActiveDragDeal] = useState<EnhancedDeal | null>(null);
    const router = useRouter();
    const [searchQuery, setSearchQuery] = useState("");
    const [sourceFilter, setSourceFilter] = useState<string[]>([]);
    const [assigneeFilter, setAssigneeFilter] = useState<string[]>([]);

    const allSources = Array.from(new Set(data.map(d => d.source || "MANUAL").filter(Boolean))) as string[];

    const formatSource = (source: string) => {
        const defaultLabels: Record<string, string> = {
            MANUAL: "Manual",
            IMPORT: "Import",
            META_ADS: "Meta Ads",
            PPC: "PPC",
            SEO: "SEO",
            WP_SYNC: "WP Sync",
            TEST: "Test"
        };
        return defaultLabels[source] || source;
    };

    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const [showLeftArrow, setShowLeftArrow] = useState(false);
    const [showRightArrow, setShowRightArrow] = useState(true);

    const handleScroll = () => {
        if (!scrollContainerRef.current) return;
        const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
        setShowLeftArrow(scrollLeft > 20);
        setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 20);
    };

    useEffect(() => {
        handleScroll();
        window.addEventListener('resize', handleScroll);
        // Small delay to allow deals render to trigger scroll width change
        setTimeout(handleScroll, 100); 
        return () => window.removeEventListener('resize', handleScroll);
    }, [deals]);

    const scrollBy = (amount: number) => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollBy({ left: amount, behavior: "smooth" });
        }
    };

    const sensors = useSensors(
        useSensor(MouseSensor, { activationConstraint: { distance: 5 } }), // Desktop mouse drag
        useSensor(TouchSensor, { activationConstraint: { delay: 250, tolerance: 5 } }) // Mobile long-press to drag
    );

    const onDragStart = (e: DragStartEvent) => {
        const deal = deals.find(d => d.id === e.active.id);
        if (deal) setActiveDragDeal(deal);
    };

    const onDragEnd = async (e: DragEndEvent) => {
        setActiveDragDeal(null);
        const { active, over } = e;
        if (!over) return; // Dropped outside a valid sortable context

        const dealId = active.id as string;
        const targetStage = over.id as string;

        const deal = deals.find(d => d.id === dealId);
        if (!deal) return;

        // Skip if dropping in the same stage
        const currentStageValue = deal.customStage ? deal.customStage : deal.stage;
        if (currentStageValue === targetStage) return;

        const isEnum = ["QUALIFICATION", "PROPOSAL", "NEGOTIATION", "WON", "LOST"].includes(targetStage);
        const prevDeals = [...deals];

        setDeals(current =>
            current.map(d =>
                d.id === dealId ? { 
                    ...d, 
                    stage: isEnum ? (targetStage as DealStage) : "QUALIFICATION",
                    customStage: isEnum ? null : targetStage,
                    updatedAt: new Date() // Optimistic update of timer
                } as any : d
            )
        );

        const res = await updateDealStage(dealId, targetStage);
        if (!res.success) {
            toast.error(res.error || "Failed to move opportunity");
            setDeals(prevDeals); // Revert optimistic update
        } else {
            // Success toast removed to prevent duplication with system-wide SSE NotificationCenter toast
            router.refresh();
        }
    };

    const handleOnboard = async (e: React.MouseEvent, dealId: string) => {
        e.stopPropagation();
        const prevDeals = [...deals];
        setDeals(current =>
            current.map(deal =>
                deal.id === dealId ? { 
                    ...deal, 
                    stage: "QUALIFICATION",
                    customStage: "ONBOARDED" 
                } as any : deal
            )
        );

        const res = await updateDealStage(dealId, "ONBOARDED");
        if (!res.success) {
            toast.error(res.error || "Failed to create order");
            setDeals(prevDeals);
        } else {
            toast.success("Order Successfully Confirmed! Check the Orders control center.");
            router.refresh();
        }
    };

    const handleArchive = async (e: React.MouseEvent, dealId: string) => {
        e.stopPropagation();
        const prevDeals = [...deals];
        setDeals(current =>
            current.map(deal =>
                deal.id === dealId ? { 
                    ...deal, 
                    stage: "LOST",
                    customStage: "ARCHIVED" 
                } as any : deal
            )
        );

        const res = await updateDealStage(dealId, "ARCHIVED");
        if (!res.success) {
            toast.error(res.error || "Failed to archive opportunity");
            setDeals(prevDeals);
        } else {
            toast.success("Opportunity successfully archived to Closed-Lost!");
            router.refresh();
        }
    };

    const stagesConfig = dealStages || [
        { id: "s1", value: "QUALIFICATION", label: "Contacted",       color: "slate"  },
        { id: "s2", value: "PROPOSAL",      label: "Proposal Sent",   color: "blue"   },
        { id: "s3", value: "NEGOTIATION",   label: "Negotiation",     color: "amber"  },
        { id: "s4", value: "WON",           label: "Sales Confirmed", color: "indigo" },
        { id: "s5", value: "LOST",          label: "Closed Lost",     color: "red"    }
    ];

    const getColorVars = (color: string) => {
        switch (color) {
            case "blue": return { header: "bg-blue-500/10 text-blue-700", border: "border-blue-500/20", columnColor: "bg-blue-500/[0.02]" };
            case "amber": return { header: "bg-amber-500/10 text-amber-700", border: "border-amber-500/20", columnColor: "bg-amber-500/[0.02]" };
            case "indigo": return { header: "bg-indigo-500/10 text-indigo-700", border: "border-indigo-500/20", columnColor: "bg-indigo-500/[0.02]" };
            case "red": return { header: "bg-red-500/10 text-red-700", border: "border-red-500/20", columnColor: "bg-red-500/[0.02]" };
            case "purple": return { header: "bg-purple-500/10 text-purple-700", border: "border-purple-500/20", columnColor: "bg-purple-500/[0.02]" };
            case "pink": return { header: "bg-pink-500/10 text-pink-700", border: "border-pink-500/20", columnColor: "bg-pink-500/[0.02]" };
            default: return { header: "bg-slate-500/10 text-slate-700", border: "border-slate-500/20", columnColor: "bg-slate-500/[0.02]" };
        }
    }

    const dropAnimation = {
        sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: "0.4" } } })
    };

    return (
        <div className="flex flex-col gap-6 h-full relative">
            {/* Filter Bar */}
            <div className="flex flex-col md:flex-row gap-3 items-center bg-card p-4 rounded-xl border border-border shadow-sm transition-all duration-300">
                <div className="relative flex-1 w-full">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                        placeholder="Search opportunities by title or company..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 bg-muted border-border focus:bg-background transition-all h-10 rounded-lg text-sm"
                    />
                </div>

                <div className="flex items-center gap-4 px-2">
                    <MultiSelect
                        options={allSources.map(s => ({ label: formatSource(s), value: s }))}
                        selected={sourceFilter}
                        onChange={setSourceFilter}
                        placeholder="Sources"
                        className="w-[160px] bg-muted border border-border"
                    />

                    <MultiSelect
                        options={users.map(u => ({ label: u.name || "Unknown", value: u.id }))}
                        selected={assigneeFilter}
                        onChange={setAssigneeFilter}
                        placeholder="Assignees"
                        className="w-[160px] bg-muted border border-border"
                    />
                    
                    <div className="flex flex-col items-end">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Total Pipeline</span>
                        <span className="text-lg font-black text-primary leading-none">
                            ${deals.filter(d => {
                                const q = searchQuery.toLowerCase();
                                const contactMatch = d.contacts?.some(c => 
                                    `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) ||
                                    c.firstName.toLowerCase().includes(q) ||
                                    c.lastName.toLowerCase().includes(q)
                                );
                                return (d.title.toLowerCase().includes(q) || 
                                    d.organization?.name?.toLowerCase().includes(q) ||
                                    contactMatch) &&
                                    (sourceFilter.length === 0 || sourceFilter.includes(d.source || "MANUAL")) &&
                                    (assigneeFilter.length === 0 || (d as any).ownerId && assigneeFilter.includes((d as any).ownerId)) &&
                                    d.customStage !== "ONBOARDED" && 
                                    d.customStage !== "ARCHIVED"
                            }).reduce((sum, d) => sum + d.value, 0).toLocaleString()}
                        </span>
                    </div>
                    {searchQuery && (
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setSearchQuery("")}
                            className="bg-muted hover:bg-muted/80 h-10 w-10 border border-border shrink-0"
                        >
                            <FilterX className="w-4 h-4 text-muted-foreground" />
                        </Button>
                    )}
                </div>
            </div>

            <DndContext id="deal-board" sensors={sensors} collisionDetection={closestCenter} onDragStart={onDragStart} onDragEnd={onDragEnd}>
                <div className="relative group/board">
                    {/* Floating Left Arrow */}
                    {showLeftArrow && (
                        <button 
                            onClick={() => scrollBy(-340)}
                            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-40 w-10 h-10 md:w-12 md:h-12 bg-background/90 backdrop-blur-md border border-border rounded-full shadow-xl flex items-center justify-center hover:bg-background hover:scale-110 hover:shadow-2xl transition-all text-primary hover:text-primary opacity-0 group-hover/board:opacity-100"
                        >
                            <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
                        </button>
                    )}
                    
                    {/* Floating Right Arrow */}
                    {showRightArrow && (
                        <button 
                            onClick={() => scrollBy(340)}
                            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-40 w-10 h-10 md:w-12 md:h-12 bg-background/90 backdrop-blur-md border border-border rounded-full shadow-xl flex items-center justify-center hover:bg-background hover:scale-110 hover:shadow-2xl transition-all text-primary hover:text-primary opacity-0 group-hover/board:opacity-100"
                        >
                            <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
                        </button>
                    )}

                    <div 
                        ref={scrollContainerRef}
                        onScroll={handleScroll}
                        className="flex gap-6 overflow-x-auto pb-8 h-[calc(100vh-280px)] scrollbar-hide snap-proximity snap-x"
                        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                    >
                    {stagesConfig.map((stage: any, i: number) => {
                        const columnDeals = deals.filter(d => {
                            const matchesStage = (d as any).customStage ? (d as any).customStage === stage.value : d.stage === stage.value;
                            const q = searchQuery.toLowerCase();
                            const contactMatch = d.contacts?.some(c => 
                                `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) ||
                                c.firstName.toLowerCase().includes(q) ||
                                c.lastName.toLowerCase().includes(q)
                            );
                            const matchesSearch = d.title.toLowerCase().includes(q) || 
                                                d.organization?.name?.toLowerCase().includes(q) ||
                                                contactMatch;
                            const matchesSource = sourceFilter.length === 0 || sourceFilter.includes(d.source || "MANUAL");
                            const matchesAssignee = assigneeFilter.length === 0 || ((d as any).ownerId && assigneeFilter.includes((d as any).ownerId));
                            return matchesStage && matchesSearch && matchesSource && matchesAssignee;
                        });
                        const design = getColorVars(stage.color);

                        return (
                            <DroppableColumn
                                key={stage.id || stage.value || `stage-${i}`}
                                id={stage.value}
                                className={`min-w-[320px] w-[320px] rounded-2xl flex flex-col border ${design.border} ${design.columnColor} overflow-hidden shadow-sm snap-center`}
                            >
                                <div className={`px-4 py-3 mx-2 mt-2 rounded-xl ${design.header} flex items-center justify-between`}>
                                    <h3 className="font-semibold text-sm tracking-tight">{stage.label}</h3>
                                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-background/60 shadow-sm border border-black/5">
                                        {columnDeals.length}
                                    </span>
                                </div>

                                <div className="flex-1 p-2 flex flex-col gap-3 overflow-y-auto px-2 min-h-[150px] pt-4">
                                    {columnDeals.map((deal) => {
                                        const isRotten =
                                            (deal.stage !== "WON" && deal.stage !== "LOST") &&
                                            (new Date().getTime() - new Date(deal.updatedAt).getTime() > 30 * 24 * 60 * 60 * 1000);
                                        const daysInStage = Math.max(1, Math.floor((new Date().getTime() - new Date(deal.updatedAt).getTime()) / (1000 * 3600 * 24)));

                                        return (
                                            <DraggableCard
                                                key={deal.id}
                                                deal={deal}
                                                isRotten={isRotten}
                                                daysInStage={daysInStage}
                                                stage={stage}
                                                handleOnboard={handleOnboard}
                                                handleArchive={handleArchive}
                                                onClick={() => setSelectedDeal(deal)}
                                            />
                                        );
                                    })}
                                </div>
                            </DroppableColumn>
                        );
                    })}
                    {/* Add spacer so last column isn't obscured by the right arrow at maximum scroll */}
                    <div className="min-w-[48px] shrink-0" aria-hidden="true" />
                    </div>
                </div>

                <DragOverlay dropAnimation={dropAnimation}>
                    {activeDragDeal ? (
                        <div className="bg-card p-4 rounded-xl shadow-2xl border border-primary/40 rotate-3 cursor-grabbing transform scale-105">
                            <div className="font-semibold text-[15px] text-foreground leading-tight mb-1 pr-6">
                                {activeDragDeal.title}
                            </div>
                            <div className="text-sm font-medium tracking-tight text-muted-foreground mb-4">
                                ${activeDragDeal.value.toLocaleString()}
                            </div>
                            <div className="flex items-center justify-between mb-4 opacity-70">
                                <div className="flex -space-x-2">
                                    <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center border-2 border-background ring-1 ring-border">
                                        <UserCircle className="w-5 h-5 text-muted-foreground" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : null}
                </DragOverlay>
            </DndContext>

            <DealSheet
                deal={selectedDeal}
                isOpen={!!selectedDeal}
                onClose={() => setSelectedDeal(null)}
                effectiveRole={effectiveRole}
                dealStages={dealStages}
                organizations={organizations}
                users={users}
            />
        </div>
    );
}

