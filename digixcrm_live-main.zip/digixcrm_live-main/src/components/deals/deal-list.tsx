"use client";

import { useState, useMemo, useEffect } from "react";
import { useConfirm } from "@/components/providers/confirm-dialog-provider";
import {
    ColumnDef,
    flexRender,
    getCoreRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
    SortingState,
} from "@tanstack/react-table";
import { DealStage } from "@/generated/prisma/client/client";
import { formatDistanceToNow, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
    Building2, 
    Eye, 
    MoreHorizontal, 
    Pencil, 
    Trash2, 
    Search, 
    FilterX, 
    ArrowUpDown, 
    ChevronUp, 
    ChevronDown,
    DollarSign,
    Calendar,
    LayoutGrid
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { DealSheet } from "./deal-sheet";
import { EditDealDialog } from "./edit-deal-dialog";
import { deleteDeal } from "@/lib/actions/deals";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

type EnhancedDeal = {
    id: string;
    title: string;
    value: number;
    stage: DealStage;
    customStage?: string | null;
    organization?: { name: string } | null;
    updatedAt: Date;
    createdAt: Date;
};

interface DealListProps {
    data: EnhancedDeal[];
    effectiveRole: string;
    organizations: { id: string; name: string }[];
    dealStages: any;
    users: any[];
}

export function DealList({ data, effectiveRole, organizations, dealStages, users }: DealListProps) {
    const { confirm } = useConfirm();
    const router = useRouter();
    const [selectedDeal, setSelectedDeal] = useState<EnhancedDeal | null>(null);

    useEffect(() => {
        if (selectedDeal) {
            const updated = data.find((d: any) => d.id === selectedDeal.id);
            if (updated) setSelectedDeal(updated);
        }
    }, [data, selectedDeal]);
    const [editingDeal, setEditingDeal] = useState<EnhancedDeal | null>(null);
    const [isDeleting, setIsDeleting] = useState<string | null>(null);
    const [sorting, setSorting] = useState<SortingState>([]);

    // --- Filter States ---
    const [searchQuery, setSearchQuery] = useState("");
    const [stageFilter, setStageFilter] = useState("ALL");
    const [dateRange, setDateRange] = useState<{ from: Date | undefined; to?: Date | undefined } | undefined>();

    const isAdmin = effectiveRole === "ADMIN";

    const stagesConfig = dealStages || [
        { id: "s1", value: "QUALIFICATION", label: "Qualification", color: "slate" },
        { id: "s2", value: "PROPOSAL", label: "Proposal", color: "blue" },
        { id: "s3", value: "NEGOTIATION", label: "Negotiation", color: "amber" },
        { id: "s4", value: "WON", label: "Closed Won", color: "indigo" },
        { id: "s5", value: "LOST", label: "Closed Lost", color: "red" }
    ];

    const getColorClass = (c: string) => {
        switch (c) {
            case "blue": return "bg-blue-500/10 text-blue-600 border-blue-200 dark:border-blue-900/50";
            case "amber": return "bg-amber-500/10 text-amber-600 border-amber-200 dark:border-amber-900/50";
            case "indigo": return "bg-indigo-500/10 text-indigo-600 border-indigo-200 dark:border-indigo-900/50";
            case "red": return "bg-red-500/10 text-red-600 border-red-200 dark:border-red-900/50";
            case "purple": return "bg-purple-500/10 text-purple-600 border-purple-200 dark:border-purple-900/50";
            case "pink": return "bg-pink-500/10 text-pink-600 border-pink-200 dark:border-pink-900/50";
            case "emerald": return "bg-emerald-500/10 text-emerald-600 border-emerald-200 dark:border-emerald-900/50";
            default: return "bg-slate-500/10 text-slate-600 border-slate-200 dark:border-slate-800";
        }
    };

    // --- Filter Logic ---
    const filteredData = useMemo(() => {
        const query = searchQuery.toLowerCase();
        return data.filter((deal) => {
            const matchesSearch =
                (deal.title || "").toLowerCase().includes(query) ||
                (deal.organization?.name || "").toLowerCase().includes(query);

            const stageValue = deal.customStage || deal.stage;
            const matchesStage = stageFilter === "ALL" || stageValue === stageFilter;

            let matchesDate = true;
            if (dateRange?.from) {
                const dealDate = new Date(deal.createdAt);
                if (dateRange.to) {
                    matchesDate = isWithinInterval(dealDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.to)
                    });
                } else {
                    matchesDate = isWithinInterval(dealDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.from)
                    });
                }
            }

            return matchesSearch && matchesStage && matchesDate;
        });
    }, [data, searchQuery, stageFilter, dateRange]);

    const handleDelete = async (id: string, title: string) => {
        const isConfirmed = await confirm({
            title: "Delete Deal",
            description: `Are you sure you want to permanently delete "${title}"?`,
            variant: "destructive",
            confirmText: "Delete"
        });
        if (!isConfirmed) return;
        setIsDeleting(id);
        const res = await deleteDeal(id);
        if (res.success) {
            toast.success("Deal deleted.");
            router.refresh();
        } else {
            toast.error("Failed to delete deal.");
        }
        setIsDeleting(null);
    };

    const columns: ColumnDef<EnhancedDeal>[] = [
        {
            accessorKey: "title",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Deal Name
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => (
                <div className="font-bold text-foreground tracking-tight">{row.getValue("title")}</div>
            ),
        },
        {
            accessorKey: "organization",
            header: "Organization",
            cell: ({ row }) => {
                const org = row.original.organization;
                if (!org) return <span className="text-muted-foreground text-xs italic">Independent</span>;
                return (
                    <div className="flex items-center gap-2 text-foreground font-medium text-xs">
                        <Building2 className="w-3.5 h-3.5 text-indigo-500/60" />
                        {org.name}
                    </div>
                );
            },
        },
        {
            accessorKey: "value",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Value
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => {
                const value = row.getValue("value") as number;
                return (
                    <div className="flex items-center gap-1 font-black text-foreground">
                        <DollarSign className="w-3 h-3 text-emerald-500" />
                        {value.toLocaleString()}
                    </div>
                );
            },
        },
        {
            accessorKey: "stage",
            header: "Status",
            cell: ({ row }) => {
                const deal = row.original;
                const stageValue = deal.customStage || deal.stage;
                const currentStage = stagesConfig.find((s: any) => s.value === stageValue);
                const label = currentStage?.label || stageValue;
                const color = currentStage?.color || "slate";

                return (
                    <Badge variant="outline" className={`${getColorClass(color)} px-2 py-0.5 rounded-full font-black text-[9px] uppercase tracking-widest border-0 shadow-sm`}>
                        {label}
                    </Badge>
                );
            },
        },
        {
            accessorKey: "createdAt",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Created
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => {
                const date = new Date(row.original.createdAt);
                return <div className="text-[11px] text-muted-foreground font-medium uppercase">{date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>;
            },
        },
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const deal = row.original;
                return (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedDeal(deal)}
                            className="h-8 px-2.5 text-primary hover:text-primary hover:bg-primary/5 font-bold text-[11px]"
                        >
                            <Eye className="w-3.5 h-3.5 mr-1.5" />
                            Details
                        </Button>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                    <MoreHorizontal className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48 p-2 rounded-2xl shadow-2xl">
                                <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-2 py-1.5">Record Options</DropdownMenuLabel>
                                <DropdownMenuItem className="gap-2 py-2.5 font-bold rounded-xl" onClick={() => setEditingDeal(deal)}>
                                    <Pencil className="w-4 h-4" /> Edit Deal
                                </DropdownMenuItem>
                                {isAdmin && (
                                    <>
                                        <DropdownMenuSeparator className="opacity-50" />
                                        <DropdownMenuItem 
                                            className="gap-2 py-2.5 font-bold text-red-500 focus:text-red-500 focus:bg-red-50 dark:focus:bg-red-900/20 rounded-xl"
                                            onClick={() => handleDelete(deal.id, deal.title)}
                                            disabled={isDeleting === deal.id}
                                        >
                                            <Trash2 className="w-4 h-4" /> {isDeleting === deal.id ? "Deleting..." : "Delete Permanently"}
                                        </DropdownMenuItem>
                                    </>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                );
            },
        },
    ];

    const table = useReactTable({
        data: filteredData,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        onSortingChange: setSorting,
        state: { sorting },
        initialState: {
            pagination: { pageSize: 15 },
            sorting: [{ id: "createdAt", desc: true }]
        },
    });

    return (
        <div className="flex flex-col gap-4">
            {/* Filter Toolbar */}
            <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center bg-card p-4 rounded-2xl border border-border/50 shadow-sm transition-all duration-300">
                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 w-full xl:w-auto flex-1">
                    <div className="relative w-full md:w-[300px] lg:w-[400px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                            placeholder="Search deals or organizations..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 bg-muted/50 border-border focus:bg-background transition-all h-10 rounded-xl text-sm"
                        />
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                        <Select value={stageFilter} onValueChange={setStageFilter}>
                            <SelectTrigger className="w-full sm:w-[160px] bg-muted/50 border-border h-10 rounded-xl font-bold text-xs ring-0">
                                <SelectValue placeholder="Pipeline Stage" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl border-border shadow-2xl">
                                <SelectItem value="ALL" className="font-bold">All Stages</SelectItem>
                                {stagesConfig.map((s: any) => (
                                    <SelectItem key={s.value} value={s.value} className="font-medium text-xs">
                                        {s.label}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3 w-full xl:w-auto">
                    <div className="relative w-full sm:w-auto">
                        <DatePickerWithRange date={dateRange} setDate={setDateRange} />
                    </div>

                    {(searchQuery || stageFilter !== "ALL" || dateRange) && (
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                                setSearchQuery("");
                                setStageFilter("ALL");
                                setDateRange(undefined);
                            }}
                            className="text-muted-foreground hover:text-foreground h-10 w-10 shrink-0 hidden sm:flex"
                            title="Clear all filters"
                        >
                            <FilterX className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>

            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden pb-4">
                {filteredData.length > 0 ? (
                    filteredData.map((deal) => {
                        const stageValue = deal.customStage || deal.stage;
                        const currentStage = stagesConfig.find((s: any) => s.value === stageValue);
                        const label = currentStage?.label || stageValue;
                        const color = currentStage?.color || "slate";

                        return (
                            <div
                                key={deal.id}
                                className="p-4 rounded-2xl border border-border/60 bg-card shadow-sm active:scale-[0.98] transition-all duration-200"
                                onClick={() => setSelectedDeal(deal)}
                            >
                                <div className="flex items-start justify-between mb-4">
                                    <div>
                                        <h3 className="text-base font-black text-foreground tracking-tight leading-none mb-2">
                                            {deal.title}
                                        </h3>
                                        <div className="flex items-center gap-2 text-xs text-muted-foreground font-bold italic uppercase tracking-tighter">
                                            <Building2 className="w-3 h-3" />
                                            {deal.organization?.name || "Independent"}
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 bg-emerald-500/5 px-2 py-1 rounded-lg border border-emerald-500/10">
                                        <DollarSign className="w-3 h-3 text-emerald-500" />
                                        <span className="text-xs font-black text-emerald-600">{deal.value.toLocaleString()}</span>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between pt-4 border-t border-border/40">
                                    <div className="flex flex-wrap gap-2">
                                        <Badge variant="outline" className={`${getColorClass(color)} px-2 py-0.5 rounded-full font-black text-[8px] uppercase tracking-widest border-0`}>
                                            {label}
                                        </Badge>
                                        <div className="flex items-center gap-1.5 px-2 py-0.5 bg-muted rounded-full text-[9px] font-bold text-muted-foreground tracking-tighter">
                                            <Calendar className="w-2.5 h-2.5 opacity-50" />
                                            {new Date(deal.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                        </div>
                                    </div>
                                    <div onClick={(e) => e.stopPropagation()}>
                                        <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-8 w-8 p-0 rounded-full bg-muted/40 hover:bg-primary/10 hover:text-primary transition-colors"
                                            onClick={() => setEditingDeal(deal)}
                                        >
                                            <Pencil className="w-3.5 h-3.5" />
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                ) : (
                    <div className="py-12 flex flex-col items-center justify-center text-center text-muted-foreground font-medium bg-muted/20 rounded-3xl border-2 border-dashed border-border/40">
                        <LayoutGrid className="w-8 h-8 opacity-20 mb-3" />
                        <p className="text-sm">No deals matching query</p>
                    </div>
                )}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
                <Table>
                    <TableHeader className="bg-muted/40">
                        {table.getHeaderGroups().map((headerGroup) => (
                            <TableRow key={headerGroup.id} className="hover:bg-transparent border-border/50">
                                {headerGroup.headers.map((header) => (
                                    <TableHead key={header.id} className="h-12 px-5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                                        {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map((row) => (
                                <TableRow
                                    key={row.id}
                                    className="cursor-pointer transition-colors border-border/40 hover:bg-muted/30"
                                    onClick={() => setSelectedDeal(row.original)}
                                >
                                    {row.getVisibleCells().map((cell) => (
                                        <TableCell key={cell.id} className="px-5 py-3.5 text-[13px] whitespace-nowrap align-middle">
                                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={columns.length} className="h-24 text-center text-muted-foreground font-bold italic opacity-40">
                                    No Pipeline Architecture Detected.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Pagination Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-4 border-t border-border/50">
                <div className="text-sm text-muted-foreground font-medium text-center sm:text-left">
                    Displaying <span className="text-foreground font-black">{table.getRowModel().rows.length}</span> of <span className="text-foreground font-black">{filteredData.length}</span> deals.
                </div>
                
                <div className="flex items-center gap-3 sm:gap-6 flex-wrap justify-center sm:justify-end w-full sm:w-auto">
                    <div className="flex items-center gap-2">
                        <p className="text-xs font-black text-muted-foreground uppercase tracking-widest hidden xs:block">Density</p>
                        <Select
                            value={`${table.getState().pagination.pageSize}`}
                            onValueChange={(value) => table.setPageSize(Number(value))}
                        >
                            <SelectTrigger className="h-8 w-[70px] bg-muted/50 border-border/50 font-black text-[10px] ring-0 focus:ring-1 ring-primary/20">
                                <SelectValue placeholder={table.getState().pagination.pageSize} />
                            </SelectTrigger>
                            <SelectContent side="top" className="border-border shadow-2xl rounded-xl">
                                {[15, 30, 50, 100].map((pageSize) => (
                                    <SelectItem key={pageSize} value={`${pageSize}`} className="text-[10px] font-bold">
                                        {pageSize}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex items-center justify-center text-[10px] font-black min-w-[90px] whitespace-nowrap bg-muted/40 px-3 py-1 rounded-full border border-border/50 uppercase tracking-tight">
                        Page {table.getState().pagination.pageIndex + 1} <span className="text-muted-foreground font-light mx-1.5">/</span> {table.getPageCount() || 1}
                    </div>

                    <div className="flex items-center gap-1.5">
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all shadow-none border-border"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            <span className="sr-only">Previous page</span>
                            <span className="text-lg leading-none mb-0.5">‹</span>
                        </Button>
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all shadow-none border-border"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            <span className="sr-only">Next page</span>
                            <span className="text-lg leading-none mb-0.5">›</span>
                        </Button>
                    </div>
                </div>
            </div>

            <DealSheet
                deal={selectedDeal}
                isOpen={!!selectedDeal}
                onClose={() => setSelectedDeal(null)}
                effectiveRole={effectiveRole}
                dealStages={dealStages}
                organizations={organizations}
                users={users}
            />

            {editingDeal && (
                <EditDealDialog
                    deal={editingDeal}
                    organizations={organizations}
                    dealStages={dealStages}
                    open={!!editingDeal}
                    onOpenChange={(open) => !open && setEditingDeal(null)}
                />
            )}
        </div>
    );
}
