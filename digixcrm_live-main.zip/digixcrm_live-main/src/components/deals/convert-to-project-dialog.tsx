"use client";

import { useState } from "react";
import { Hammer, Loader2, Sparkles, FolderPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { convertDealToProject } from "@/lib/actions/pms-bridge";
import { useRouter } from "next/navigation";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function ConvertToProjectDialog({ 
    deal,
    users = [] 
}: { 
    deal: { id: string, title: string };
    users?: { id: string; name: string | null; image?: string | null; role?: string }[] 
}) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [ownerId, setOwnerId] = useState("");
    const router = useRouter();
    
    // Filter to only show Project Managers, Managers, or Admins
    const pmUsers = users.filter(u => u.role === "PROJECT_MANAGER" || u.role === "MANAGER" || u.role === "ADMIN");

    const handleConvert = async () => {
        setLoading(true);
        try {
            const res = await convertDealToProject(deal.id, { ownerId });
            if (res.success && res.data) {
                toast.success(`Deal converted to project: ${deal.title}`);
                setOpen(false);
                router.push(`/dashboard/projects/${res.data.id}`);
            } else {
                toast.error(res.error || "Failed to convert deal");
            }
        } catch (error) {
            toast.error("An unexpected error occurred");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="w-full sm:w-auto rounded-xl font-bold bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 gap-2 border border-indigo-500/30 group">
                    <Hammer className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                    Convert to Project
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] rounded-3xl border-border/40 shadow-2xl p-0 overflow-hidden">
                <div className="bg-gradient-to-br from-indigo-600 to-primary p-8 text-white relative overflow-hidden">
                    <Sparkles className="absolute -right-4 -top-4 w-24 h-24 opacity-20 rotate-12" />
                    <div className="p-3 rounded-2xl bg-white/10 w-fit backdrop-blur-md border border-white/20 mb-4">
                        <FolderPlus className="w-6 h-6" />
                    </div>
                    <DialogTitle className="text-2xl font-black tracking-tight">Onboard Success</DialogTitle>
                    <DialogDescription className="text-white/80 font-medium text-sm mt-1">
                        Transform this won deal into an active project workspace.
                    </DialogDescription>
                </div>

                <div className="p-8 space-y-6">
                    <div className="space-y-2">
                        <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1 font-sans">Project Manager (PM)</Label>
                        <Select value={ownerId} onValueChange={setOwnerId}>
                            <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold">
                                <SelectValue placeholder="Assign PM" />
                            </SelectTrigger>
                            <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                {pmUsers.map((user) => (
                                    <SelectItem key={user.id} value={user.id}>
                                        <div className="flex items-center gap-2">
                                            <Avatar className="h-5 w-5">
                                                <AvatarImage src={user.image || ""} />
                                                <AvatarFallback className="text-[8px] font-black">{user.name?.substring(0, 2).toUpperCase()}</AvatarFallback>
                                            </Avatar>
                                            <span className="font-bold text-xs">{user.name}</span>
                                            {user.role === "ADMIN" && <span className="text-[8px] bg-primary/10 text-primary px-1 rounded uppercase">Admin</span>}
                                            {user.role === "MANAGER" && <span className="text-[8px] bg-indigo-500/10 text-indigo-500 px-1 rounded uppercase">Mgr</span>}
                                        </div>
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <p className="text-[10px] text-muted-foreground italic ml-1 font-medium">
                            * Budget and description will be synced automatically.
                        </p>
                    </div>

                    <div className="flex flex-col gap-3">
                        <Button 
                            onClick={handleConvert} 
                            disabled={loading || !ownerId}
                            className="w-full rounded-xl h-12 font-black uppercase tracking-widest text-[11px] bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-500/20"
                        >
                            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Hammer className="w-4 h-4 mr-2" />}
                            Initialize Project Roadmap
                        </Button>
                        <Button 
                            variant="ghost" 
                            onClick={() => setOpen(false)}
                            className="w-full rounded-xl font-bold text-muted-foreground"
                        >
                            Cancel
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
