"use client";

import { useState, useEffect } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Building2, UserCircle2, Clock, CheckCircle2, Phone, Mail, FileText, Pencil, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getDealActivities, createActivity } from "@/lib/actions/activities";
import { updateDealValue } from "@/lib/actions/deals";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { DealStage } from "@/generated/prisma/client/client";
import { EditDealDialog } from "./edit-deal-dialog";
import { deleteDeal } from "@/lib/actions/deals";
import { useConfirm } from "@/components/providers/confirm-dialog-provider";
import { useRouter } from "next/navigation";
import { ConvertToProjectDialog } from "./convert-to-project-dialog";
import { RenewDealDialog } from "./renew-deal-dialog";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Trash2 } from "lucide-react";
import { dial } from "@/lib/dialer";

type EnhancedDeal = {
    id: string;
    title: string;
    value: number;
    stage: DealStage;
    customStage?: string | null;
    organization?: { name: string } | null;
    updatedAt: Date;
    source?: string | null;
    project?: { id: string } | null;
    owner?: { name: string | null; email: string | null; image?: string | null } | null;
};

export function DealDetailsView({
    deal,
    dealStages,
    effectiveRole,
    organizations,
    onValueUpdate,
    onClose,
    users
}: {
    deal: EnhancedDeal;
    dealStages?: any;
    effectiveRole: string;
    onValueUpdate?: (newValue: number) => void;
    onClose?: () => void;
    organizations?: { id: string; name: string }[];
    users?: { id: string; name: string | null; image?: string | null; role?: string }[];
}) {
    const { confirm } = useConfirm();
    const router = useRouter();
    const isManagerOrAdmin = ["ADMIN", "MANAGER"].includes(effectiveRole);
    const isAdmin = effectiveRole === "ADMIN";
    
    const [activities, setActivities] = useState<any[]>([]);
    const [note, setNote] = useState("");
    const [loading, setLoading] = useState(false);
    const [activitiesLoading, setActivitiesLoading] = useState(false);
    const [isEditingValue, setIsEditingValue] = useState(false);
    const [editValue, setEditValue] = useState("");
    const [isSavingValue, setIsSavingValue] = useState(false);
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    useEffect(() => {
        if (deal) {
            fetchActivities();
        }
    }, [deal]);



    const handleCall = () => {
        dial({ dealId: deal.id, contactName: deal.title });
    };

    const fetchActivities = async () => {
        setActivitiesLoading(true);
        const res = await getDealActivities(deal.id);
        if (res.success && res.data) {
            setActivities(res.data);
        }
        setActivitiesLoading(false);
    };

    const handleSaveNote = async () => {
        if (!note.trim()) return;
        setLoading(true);
        const res = await createActivity({
            type: "NOTE",
            notes: note,
            dealId: deal.id
        });
        if (res.success) {
            setNote("");
            fetchActivities();
        }
        setLoading(false);
    };

    const handleSaveValue = async () => {
        const numVal = parseFloat(editValue);
        if (isNaN(numVal) || numVal < 0) {
            toast.error("Please enter a valid positive number");
            return;
        }

        setIsSavingValue(true);
        const res = await updateDealValue(deal.id, numVal);
        if (res.success) {
            toast.success("Pipeline value updated!");
            setIsEditingValue(false);
            if (onValueUpdate) onValueUpdate(numVal);
        } else {
            toast.error(res.error || "Failed to update value");
        }
        setIsSavingValue(false);
    };

    const handleDelete = async () => {
        const isConfirmed = await confirm({
            title: "Delete Deal",
            description: `Are you sure you want to permanently delete "${deal.title}"?`,
            variant: "destructive",
            confirmText: "Delete"
        });
        if (!isConfirmed) return;
        setIsDeleting(true);
        const res = await deleteDeal(deal.id);
        if (res.success) {
            toast.success("Deal deleted.");
            router.refresh();
            if (onClose) onClose();
        } else {
            toast.error("Failed to delete deal.");
            setIsDeleting(false);
        }
    };

    return (
        <div className="flex flex-col md:flex-row bg-background h-full w-full">
            <div className="flex-1 bg-card px-6 pb-6 pt-0 shadow-sm z-10 overflow-y-auto scrollbar-none">
                <div className="py-6 border-b border-border/50">
                    <div className="flex justify-between items-start gap-4">
                        <h2 className="text-2xl font-bold tracking-tight text-foreground">{deal.title}</h2>
                        {isManagerOrAdmin && (
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:bg-muted shrink-0">
                                        <MoreHorizontal className="w-5 h-5" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-48 shadow-xl border-border rounded-xl">
                                    <DropdownMenuItem className="gap-2 font-bold py-2.5 cursor-pointer rounded-lg" onClick={() => setIsEditDialogOpen(true)}>
                                        <Pencil className="w-4 h-4" /> Edit Deal Details
                                    </DropdownMenuItem>
                                    {isAdmin && (
                                        <>
                                            <DropdownMenuSeparator />
                                            <DropdownMenuItem 
                                                className="gap-2 font-bold py-2.5 text-red-500 hover:text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-500/10 cursor-pointer rounded-lg"
                                                onClick={handleDelete}
                                                disabled={isDeleting}
                                            >
                                                <Trash2 className="w-4 h-4" /> {isDeleting ? "Deleting..." : "Delete Permanently"}
                                            </DropdownMenuItem>
                                        </>
                                    )}
                                </DropdownMenuContent>
                            </DropdownMenu>
                        )}
                        {(deal.stage === "WON" || deal.customStage === "WON" || deal.customStage === "ONBOARDED") && (
                            <div className="flex gap-2">
                                {deal.project ? (
                                    <Button 
                                        disabled 
                                        className="w-full sm:w-auto rounded-xl font-black uppercase tracking-widest text-[11px] bg-secondary text-secondary-foreground border border-border/50 gap-2 opacity-80"
                                    >
                                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                        Project Created
                                    </Button>
                                ) : (
                                    <ConvertToProjectDialog deal={deal} users={users || []} />
                                )}
                                <RenewDealDialog deal={deal} />
                            </div>
                        )}
                    </div>
                    <div className="flex items-center gap-3 mt-3">
                        <span className="inline-flex items-center rounded-md bg-blue-500/10 px-2.5 py-1 text-xs font-semibold text-blue-600 dark:text-blue-400 ring-1 ring-inset ring-blue-500/20 uppercase tracking-wider">
                            {(() => {
                                const stageValue = deal.customStage || deal.stage;
                                const stagesConfig = dealStages || [
                                    { value: "QUALIFICATION", label: "New Lead" },
                                    { value: "PROPOSAL", label: "Contacted" },
                                    { value: "NEGOTIATION", label: "Negotiation" },
                                    { value: "WON", label: "Closed Won" },
                                    { value: "LOST", label: "Closed Lost" }
                                ];
                                const currentStage = stagesConfig.find((s: any) => s.value === stageValue);
                                return currentStage?.label || stageValue.replace("_", " ");
                            })()}
                        </span>
                        
                        {isEditingValue ? (
                            <div className="flex items-center gap-1">
                                <div className="relative">
                                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">$</span>
                                    <Input 
                                        type="number" 
                                        className="h-7 w-24 pl-5 text-xs focus-visible:ring-1 focus-visible:ring-primary/50 bg-background" 
                                        value={editValue} 
                                        onChange={(e) => setEditValue(e.target.value)} 
                                        autoFocus 
                                        onKeyDown={(e) => e.key === "Enter" && handleSaveValue()}
                                    />
                                </div>
                                <Button size="icon" variant="ghost" className="h-7 w-7 text-green-600 hover:text-green-700 hover:bg-green-500/10" onClick={handleSaveValue} disabled={isSavingValue}>
                                    <Check className="h-4 w-4" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground hover:bg-muted" onClick={() => setIsEditingValue(false)} disabled={isSavingValue}>
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>
                        ) : (
                            <span 
                                className="text-muted-foreground font-semibold flex items-center gap-1.5 transition-colors group px-1 py-0.5 rounded-sm text-sm cursor-pointer hover:text-foreground hover:bg-muted/50"
                                onClick={() => {
                                    setEditValue(deal.value.toString());
                                    setIsEditingValue(true);
                                }}
                            >
                                ${deal.value.toLocaleString()}
                                <Pencil className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground" />
                            </span>
                        )}
                    </div>
                </div>
                <div className="py-6 space-y-6">
                    {deal.organization && (
                        <div className="space-y-2">
                            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Organization</h4>
                            <div className="flex items-center gap-3">
                                <div className="bg-primary/10 p-2 rounded-md">
                                    <Building2 className="w-4 h-4 text-primary" />
                                </div>
                                <span className="text-sm font-medium text-foreground">{deal.organization.name}</span>
                            </div>
                        </div>
                    )}
                    <div className="space-y-2">
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Primary Contact</h4>
                        <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8 border border-border/40 shadow-sm">
                                <AvatarImage src={deal.owner?.image || ""} />
                                <AvatarFallback className="bg-muted text-muted-foreground">
                                    <UserCircle2 className="w-4 h-4" />
                                </AvatarFallback>
                            </Avatar>
                            <div className="flex flex-col">
                                <span className="text-sm font-bold text-foreground">{deal.owner?.name || "Pending Assignment"}</span>
                                {deal.owner?.email && <span className="text-[10px] text-muted-foreground">{deal.owner.email}</span>}
                            </div>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Lead Source</h4>
                        <div className="flex items-center gap-3">
                            <div className="bg-primary/10 p-2 rounded-md border border-primary/20 shadow-sm">
                                <Building2 className="w-4 h-4 text-primary opacity-70" />
                            </div>
                            <span className="text-sm font-bold text-foreground">
                                {(deal.source || "MANUAL").replace("_", " ")}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            {/* Right Side - Activities Feed */}
            <div className="w-full md:w-[360px] flex flex-col bg-muted/20 border-l border-border h-full">
                {/* Quick Input Box */}
                <div className="p-4 pt-3 border-b border-border bg-card shadow-sm z-10 sticky top-0">
                    <div className="flex items-center gap-2 mb-3">
                        <Button onClick={handleCall} variant="outline" size="sm" className="h-8 px-2 text-xs flex-1 bg-background text-foreground text-[10px] uppercase font-bold"><Phone className="w-3 h-3 mr-1" /> Call</Button>
                        <Button onClick={() => window.location.href = "mailto:"} variant="outline" size="sm" className="h-8 px-2 text-xs flex-1 bg-background text-foreground text-[10px] uppercase font-bold"><Mail className="w-3 h-3 mr-1" /> Email</Button>
                        <Button variant="outline" size="sm" className="h-8 px-2 text-xs flex-1 bg-background text-foreground text-[10px] uppercase font-bold"><CheckCircle2 className="w-3 h-3 mr-1" /> Task</Button>
                    </div>
                    <Textarea
                        placeholder="Take a note..."
                        className="min-h-[80px] text-sm resize-none focus-visible:ring-1 focus-visible:ring-primary/50 shadow-sm border-border bg-background"
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                    />
                    <div className="flex justify-between items-center mt-3">
                        <span className="text-xs flex items-center gap-1 text-muted-foreground">
                            <FileText className="w-3 h-3" /> Note taking
                        </span>
                        <Button size="sm" onClick={handleSaveNote} disabled={loading || !note.trim()}>
                            {loading ? "Saving..." : "Save Note"}
                        </Button>
                    </div>
                </div>

                {/* Infinite Scroll Feed */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {activitiesLoading ? (
                        <div className="text-center text-sm text-muted-foreground mt-10">Loading activities...</div>
                    ) : activities.length > 0 ? (
                        activities.map((activity) => (
                            <div key={activity.id} className="relative pl-8 pb-2">
                                <div className="absolute left-[11px] top-8 bottom-[-16px] w-[1px] bg-border last-of-type:hidden" />
                                <div className="absolute left-0 top-1">
                                    <Avatar className="h-6 w-6 border border-background shadow-sm ring-1 ring-border/50">
                                        <AvatarImage src={activity.user?.image || ""} />
                                        <AvatarFallback className="text-[8px] font-bold bg-primary/10 text-primary">
                                            {activity.user?.name?.substring(0, 2).toUpperCase() || "U"}
                                        </AvatarFallback>
                                    </Avatar>
                                </div>
                                <div className="bg-card p-3 rounded-lg border border-border shadow-sm ml-1 relative">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                                            {activity.user?.name || "User"}
                                        </span>
                                        <span className="text-[10px] text-muted-foreground font-medium flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                                        </span>
                                    </div>
                                    <div className="text-xs text-muted-foreground font-medium mb-1">
                                        {activity.type === "NOTE" ? "left a note" : `logged a ${activity.type.toLowerCase()}`}
                                    </div>
                                    {activity.notes && (
                                        <div className="mt-2 text-sm text-foreground bg-muted border border-border p-2.5 rounded-md leading-relaxed whitespace-pre-wrap">
                                            {activity.notes}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-center text-sm text-muted-foreground mt-10 flex flex-col items-center">
                            <div className="bg-card p-3 rounded-full shadow-sm border border-border mb-3">
                                <FileText className="w-5 h-5 text-muted-foreground/50" />
                            </div>
                            No activities yet. <br /> Log a note to get started!
                        </div>
                    )}
                </div>
            </div>
            
            {isEditDialogOpen && (
                <EditDealDialog
                    deal={deal as any}
                    organizations={organizations || []}
                    dealStages={dealStages || []}
                    open={isEditDialogOpen}
                    onOpenChange={setIsEditDialogOpen}
                />
            )}
        </div>
    );
}
