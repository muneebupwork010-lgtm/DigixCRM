"use client";

import { useState, useEffect } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Building2, Clock, CheckCircle2, Phone, Mail, FileText, MapPin, CalendarPlus, ExternalLink, Star, DollarSign, Tag, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { getLeadActivities, createActivity } from "@/lib/actions/activities";
import { getWorkspaceConsultants } from "@/lib/actions/scheduler";
import { formatDistanceToNow } from "date-fns";
import { Lead } from "@/generated/prisma/client/client";
import { BookOnBehalfDialog } from "@/components/scheduler/book-on-behalf-dialog";
import { dial } from "@/lib/dialer";

export function LeadDetailsView({
    lead
}: {
    lead: (Lead & { 
        organization?: any;
        owner?: { name: string | null; email: string | null; image?: string | null; } | null;
        createdBy?: { name: string | null; email: string | null; image?: string | null; } | null;
    });
}) {
    const [activities, setActivities] = useState<any[]>([]);
    const [note, setNote] = useState("");
    const [loading, setLoading] = useState(false);
    const [activitiesLoading, setActivitiesLoading] = useState(false);
    
    // Scheduler state
    const [bookMeetingOpen, setBookMeetingOpen] = useState(false);
    const [consultants, setConsultants] = useState<any[]>([]);

    useEffect(() => {
        if (lead) {
            fetchActivities();
        }
    }, [lead]);



    const handleCall = () => {
        dial({
            number: lead.phone || undefined,
            leadId: lead.id,
            contactName: `${lead.firstName} ${lead.lastName}`.trim(),
        });
    };

    useEffect(() => {
        const fetchConsultants = async () => {
            const res = await getWorkspaceConsultants();
            if (res.success && res.profiles) {
                setConsultants(res.profiles);
            }
        };
        fetchConsultants();
    }, []);

    const fetchActivities = async () => {
        setActivitiesLoading(true);
        const res = await getLeadActivities(lead.id);
        if (res.success && res.data) {
            setActivities(res.data);
        }
        setActivitiesLoading(false);
    };

    const handleSaveNote = async () => {
        if (!note.trim()) return;
        setLoading(true);
        const res = await createActivity({
            type: "NOTE",
            notes: note,
            leadId: lead.id
        });
        if (res.success) {
            setNote("");
            fetchActivities();
        }
        setLoading(false);
    };

    return (
        <div className="flex flex-col md:flex-row bg-background h-full w-full">
            <div className="flex-1 bg-card px-6 pb-6 pt-0 shadow-sm z-10 overflow-y-auto scrollbar-none">
                <div className="py-6 border-b border-border/50">
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">{lead.firstName} {lead.lastName}</h2>
                    <div className="flex items-center gap-2 mt-2">
                        <span className="inline-flex items-center rounded-md bg-blue-500/10 px-2 py-1 text-xs font-medium text-blue-600 dark:text-blue-400 ring-1 ring-inset ring-blue-500/20">
                            {(lead.status as any) === "CONVERTED" ? "IN SALES PIPELINE" : (lead.status as any) === "PENDING_APPROVAL" ? "PENDING APPROVAL" : lead.status.replace("_", " ")}
                        </span>
                        {(lead as any).organization && (
                            <span className="text-muted-foreground font-medium flex items-center gap-1">
                                <Building2 className="w-3.5 h-3.5" /> {(lead as any).organization.name}
                            </span>
                        )}
                    </div>
                </div>
                <div className="py-6 space-y-6">
                    <div className="space-y-2">
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Contact Details</h4>
                        <div className="flex flex-col gap-3">
                            {lead.email && (
                                <a 
                                    href={`mailto:${lead.email}`}
                                    className="group flex items-center gap-3 text-sm font-medium text-foreground text-left hover:text-primary transition-colors"
                                    title="Send an email"
                                >
                                    <div className="bg-primary/10 p-2 rounded-md group-hover:bg-primary/20 transition-colors">
                                        <Mail className="w-4 h-4 text-primary" />
                                    </div>
                                    <span className="group-hover:underline">{lead.email}</span>
                                </a>
                            )}
                            {lead.phone && (
                                <button
                                    type="button"
                                    onClick={handleCall}
                                    className="group flex items-center gap-3 text-sm font-medium text-foreground text-left hover:text-primary transition-colors"
                                    title="Call this number"
                                >
                                    <div className="bg-primary/10 p-2 rounded-md group-hover:bg-primary/20 transition-colors">
                                        <Phone className="w-4 h-4 text-primary" />
                                    </div>
                                    <span className="group-hover:underline">{lead.phone}</span>
                                </button>
                            )}
                            {lead.location && (
                                <div className="flex items-center gap-3 text-sm font-medium text-foreground">
                                    <div className="bg-primary/10 p-2 rounded-md">
                                        <MapPin className="w-4 h-4 text-primary" />
                                    </div>
                                    {lead.location}
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-border/50">
                        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Service Details</h4>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Service</p>
                                <p className="text-sm font-semibold text-foreground">{(lead as any).service || "-"}</p>
                            </div>
                            <div className="space-y-1">
                                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Quotation</p>
                                <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                                    ${Number((lead as any).quotation || 0).toLocaleString()}
                                </p>
                            </div>
                            <div className="col-span-2 space-y-1">
                                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Remarks</p>
                                {(() => {
                                    let parsedRemarks: any = null;
                                    try {
                                        const rawRemarks = (lead as any).remarks || "";
                                        if (rawRemarks.startsWith('{') && rawRemarks.includes('"isJson":true')) {
                                            parsedRemarks = JSON.parse(rawRemarks);
                                        }
                                    } catch(e) {}

                                    if (parsedRemarks) {
                                        return (
                                            <div className="flex flex-col gap-3 bg-muted/10 border border-border/50 p-3 rounded-lg">
                                                <div className="flex flex-wrap gap-2">
                                                    <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 shadow-none"><Star className="w-3.5 h-3.5 mr-1 fill-amber-500/20" /> {parsedRemarks.rating} ({parsedRemarks.reviews} reviews)</Badge>
                                                    {parsedRemarks.price && <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 shadow-none"><DollarSign className="w-3.5 h-3.5 mr-0.5" /> {parsedRemarks.price}</Badge>}
                                                </div>
                                                
                                                {parsedRemarks.categories?.length > 0 && (
                                                    <div className="flex flex-wrap gap-1.5 mt-1">
                                                        {parsedRemarks.categories.map((c: string, i: number) => (
                                                            <Badge key={i} variant="secondary" className="text-[10px] font-semibold bg-primary/5 text-primary/80 hover:bg-primary/10 shadow-none"><Tag className="w-2.5 h-2.5 mr-1 opacity-70" /> {c}</Badge>
                                                        ))}
                                                    </div>
                                                )}

                                                {parsedRemarks.transactions?.length > 0 && (
                                                    <div className="flex flex-wrap gap-1.5 mt-0.5">
                                                        {parsedRemarks.transactions.map((t: string, i: number) => (
                                                            <Badge key={i} variant="outline" className="text-[10px] capitalize bg-blue-500/5 text-blue-600 border-blue-500/20 shadow-none"><Truck className="w-2.5 h-2.5 mr-1" /> {t.replace('_', ' ')}</Badge>
                                                        ))}
                                                    </div>
                                                )}

                                                {parsedRemarks.link && (
                                                    <a 
                                                        href={parsedRemarks.link} 
                                                        target="_blank" 
                                                        rel="noreferrer"
                                                        className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 mt-1 not-italic w-fit bg-blue-500/10 px-3 py-1.5 rounded-full ring-1 ring-blue-500/30 transition-all hover:bg-blue-500/20 hover:scale-[1.02]"
                                                    >
                                                        <ExternalLink className="w-3.5 h-3.5" /> View Business Profile
                                                    </a>
                                                )}
                                            </div>
                                        );
                                    }

                                    return (
                                        <div className="text-sm text-foreground italic border-l-2 border-primary/20 pl-3 py-2 bg-muted/20 rounded-r-md flex flex-col gap-2">
                                            <span>
                                                {((lead as any).remarks || "No specific remarks.").split(' | Link: ')[0]}
                                            </span>
                                            {((lead as any).remarks || "").includes(' | Link: ') && (
                                                <a 
                                                    href={((lead as any).remarks || "").split(' | Link: ')[1]} 
                                                    target="_blank" 
                                                    rel="noreferrer"
                                                    className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 mt-1 not-italic w-fit bg-blue-500/10 px-3 py-1.5 rounded-full ring-1 ring-blue-500/30 transition-all hover:bg-blue-500/20 hover:scale-[1.02]"
                                                >
                                                    <ExternalLink className="w-3.5 h-3.5" /> View Business Profile
                                                </a>
                                            )}
                                        </div>
                                    );
                                })()}
                            </div>
                        </div>
                    </div>

                    <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Assignment Details</h4>
                    <div className="flex flex-col gap-4 bg-muted/20 p-4 rounded-lg border border-border mt-3">
                        <div className="flex flex-col gap-1">
                            <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Assigned To (Owner)</span>
                            <div className="flex items-center gap-3 mt-1">
                                <Avatar className="h-8 w-8">
                                    <AvatarImage src={lead.owner?.image || ""} />
                                    <AvatarFallback className="bg-primary/10 text-primary font-bold text-xs ring-1 ring-primary/20">
                                        {lead.owner?.name?.substring(0, 2).toUpperCase() || "UN"}
                                    </AvatarFallback>
                                </Avatar>
                                <div className="flex flex-col">
                                    <span className="text-sm font-bold text-foreground">{lead.owner?.name || "Unassigned"}</span>
                                    <span className="text-[10px] text-muted-foreground">{lead.owner?.email || "-"}</span>
                                </div>
                            </div>
                        </div>
                        
                        {lead.createdBy ? (
                            <div className="flex flex-col gap-1 pt-3 border-t border-border/50">
                                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Created By</span>
                                <div className="flex items-center gap-3 mt-1">
                                    <Avatar className="h-6 w-6">
                                        <AvatarImage src={lead.createdBy.image || ""} />
                                        <AvatarFallback className="bg-muted text-muted-foreground font-bold text-[9px] ring-1 ring-border">
                                            {lead.createdBy.name?.substring(0, 2).toUpperCase() || "UN"}
                                        </AvatarFallback>
                                    </Avatar>
                                    <span className="text-xs font-semibold text-foreground">{lead.createdBy.name || lead.createdBy.email}</span>
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-col gap-1 pt-3 border-t border-border/50">
                                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">Created By</span>
                                <div className="flex items-center gap-3 mt-1">
                                    <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center ring-1 ring-blue-200">
                                        <span className="text-[10px] font-bold text-blue-600">SYS</span>
                                    </div>
                                    <span className="text-xs font-bold text-blue-600">System Integration</span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {/* Right Side - Activities Feed */}
            <div className="w-full md:w-[360px] flex flex-col bg-muted/20 border-l border-border h-full">
                {/* Quick Input Box */}
                <div className="p-4 pt-3 border-b border-border bg-card shadow-sm z-10 sticky top-0">
                    <div className="grid grid-cols-2 gap-2 mb-3">
                        <Button onClick={() => setBookMeetingOpen(true)} className="col-span-2 h-9 text-xs shadow-sm bg-primary hover:bg-primary/90 text-primary-foreground font-black tracking-wide">
                            <CalendarPlus className="w-4 h-4 mr-2" /> Book Meeting
                        </Button>
                        <Button onClick={handleCall} disabled={!lead.phone} variant="outline" size="sm" className="h-8 px-2 text-xs flex-1 bg-background text-foreground text-[10px] uppercase font-bold"><Phone className="w-3 h-3 mr-1" /> Call</Button>
                        <Button onClick={() => window.location.href = `mailto:${lead.email || ''}`} disabled={!lead.email} variant="outline" size="sm" className="h-8 px-2 text-xs flex-1 bg-background text-foreground text-[10px] uppercase font-bold"><Mail className="w-3 h-3 mr-1" /> Email</Button>
                    </div>
                    <Textarea
                        placeholder="Take a note..."
                        className="min-h-[80px] text-sm resize-none focus-visible:ring-1 focus-visible:ring-primary/50 shadow-sm border-border bg-background"
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                    />
                    <div className="flex justify-between items-center mt-3">
                        <span className="text-xs flex items-center gap-1 text-muted-foreground">
                            <FileText className="w-3 h-3" /> Note taking
                        </span>
                        <Button size="sm" onClick={handleSaveNote} disabled={loading || !note.trim()}>
                            {loading ? "Saving..." : "Save Note"}
                        </Button>
                    </div>
                </div>

                {/* Infinite Scroll Feed */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {activitiesLoading ? (
                        <div className="text-center text-sm text-muted-foreground mt-10">Loading activities...</div>
                    ) : activities.length > 0 ? (
                        activities.map((activity) => (
                            <div key={activity.id} className="relative pl-6 pb-2">
                                <div className="absolute left-[9px] top-6 bottom-[-16px] w-[2px] bg-border last-of-type:hidden" />
                                <div className="absolute left-0 top-1">
                                    <Avatar className="h-6 w-6 border border-background shadow-sm ring-1 ring-border/50">
                                        <AvatarImage src={activity.user?.image || ""} />
                                        <AvatarFallback className="text-[8px] font-bold bg-primary/10 text-primary">
                                            {activity.user?.name?.substring(0, 2).toUpperCase() || "U"}
                                        </AvatarFallback>
                                    </Avatar>
                                </div>
                                <div className="bg-card p-3 rounded-lg border border-border shadow-sm ml-2 relative">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                                            {activity.user?.name || "User"}
                                        </span>
                                        <span className="text-[10px] text-muted-foreground font-medium flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                                        </span>
                                    </div>
                                    <div className="text-xs text-muted-foreground font-medium mb-1">
                                        {activity.type === "NOTE" ? "left a note" : `logged a ${activity.type.toLowerCase()}`}
                                    </div>
                                    {activity.notes && (
                                        <div className="mt-2 text-sm text-foreground bg-muted border border-border p-2.5 rounded-md leading-relaxed whitespace-pre-wrap">
                                            {activity.notes}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-center text-sm text-muted-foreground mt-10 flex flex-col items-center">
                            <div className="bg-card p-3 rounded-full shadow-sm border border-border mb-3">
                                <FileText className="w-5 h-5 text-muted-foreground/50" />
                            </div>
                            No activities yet. <br /> Log a note to get started!
                        </div>
                    )}
                </div>
            </div>
            
            <BookOnBehalfDialog 
                open={bookMeetingOpen}
                onOpenChange={setBookMeetingOpen}
                consultants={consultants}
                initialGuestName={`${lead.firstName} ${lead.lastName}`.trim()}
                initialGuestEmail={lead.email || ""}
                initialGuestPhone={lead.phone || ""}
            />
        </div>
    );
}
