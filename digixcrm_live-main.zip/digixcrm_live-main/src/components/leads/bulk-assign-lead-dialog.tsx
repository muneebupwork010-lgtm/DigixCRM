"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { bulkAssignLeads } from "@/lib/actions/leads";
import { getUsers } from "@/lib/actions/users";
import { toast } from "sonner";
import { UserPlus, Users2, ArrowRight, Check, ChevronsUpDown } from "lucide-react";
import { useRouter } from "next/navigation";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface BulkAssignLeadDialogProps {
    selectedIds: Set<string>;
    onSuccess: () => void;
}

export function BulkAssignLeadDialog({ selectedIds, onSuccess }: BulkAssignLeadDialogProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [users, setUsers] = useState<any[]>([]);
    const [assignedUserId, setAssignedUserId] = useState<string>("");
    const [isLoading, setIsLoading] = useState(false);
    const [openCombobox, setOpenCombobox] = useState(false);
    const router = useRouter();

    const selectedUser = users.find(u => u.id === assignedUserId);

    useEffect(() => {
        if (isOpen && users.length === 0) {
            getUsers().then((res) => setUsers(res));
        }
    }, [isOpen, users.length]);

    const handleAssign = async () => {
        if (!assignedUserId) return toast.error("Select a representative first.");
        if (selectedIds.size === 0) return toast.error("No leads selected.");
        
        setIsLoading(true);
        const res = await bulkAssignLeads(Array.from(selectedIds), assignedUserId);
        if (res.success) {
            toast.success(`Successfully assigned ${res.count} leads.`);
            setIsOpen(false);
            onSuccess();
            router.refresh();
        } else {
            toast.error(res.error || "Failed to bulk assign leads");
        }
        setIsLoading(false);
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
                <Button
                    variant="secondary"
                    size="sm"
                    className="bg-indigo-500 hover:bg-indigo-600 text-white shadow-sm border-0"
                >
                    <UserPlus className="w-3.5 h-3.5 mr-2" />
                    Bulk Assign
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[480px] p-0 overflow-hidden rounded-[2rem] border-border/50 shadow-2xl">
                <div className="bg-gradient-to-br from-indigo-50 to-white dark:from-indigo-950/20 dark:to-background p-6 sm:p-8 border-b border-border/40">
                    <DialogHeader>
                        <div className="flex items-center gap-4 mb-1">
                            <div className="p-3 bg-indigo-500/10 rounded-2xl shrink-0">
                                <Users2 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            <div className="text-left">
                                <DialogTitle className="text-xl font-black tracking-tight">Bulk Assign Leads</DialogTitle>
                                <DialogDescription className="text-sm font-medium mt-1.5">
                                    You have selected <span className="text-indigo-600 dark:text-indigo-400 font-bold">{selectedIds.size}</span> leads to reassign.
                                </DialogDescription>
                            </div>
                        </div>
                    </DialogHeader>
                </div>
                
                <div className="p-6 sm:p-8 pt-6 space-y-8">
                    <div className="space-y-3">
                        <label className="text-[11px] font-black uppercase tracking-widest text-muted-foreground/70">Select New Owner</label>
                        <Popover open={openCombobox} onOpenChange={setOpenCombobox}>
                            <PopoverTrigger asChild>
                                <Button
                                    variant="outline"
                                    role="combobox"
                                    aria-expanded={openCombobox}
                                    className="w-full h-16 rounded-2xl bg-muted/30 border-border/50 hover:bg-muted/50 transition-colors px-4 flex justify-between items-center font-normal"
                                >
                                    {selectedUser ? (
                                        <div className="flex items-center gap-3">
                                            <Avatar className="h-9 w-9 border border-border/50 shadow-sm">
                                                <AvatarImage src={selectedUser.image || ""} />
                                                <AvatarFallback className="text-[10px] bg-primary/5 text-primary font-bold">
                                                    {selectedUser.name?.substring(0, 2).toUpperCase() || "UN"}
                                                </AvatarFallback>
                                            </Avatar>
                                            <div className="flex flex-col text-left">
                                                <span className="font-bold text-sm leading-none text-foreground">{selectedUser.name || selectedUser.email}</span>
                                                <span className="text-[10px] text-muted-foreground mt-1.5 font-bold tracking-wider uppercase">{selectedUser.role}</span>
                                            </div>
                                        </div>
                                    ) : (
                                        <span className="text-muted-foreground">Choose a representative...</span>
                                    )}
                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-[430px] p-1 rounded-2xl shadow-xl border-border/50" align="start">
                                <Command>
                                    <CommandInput placeholder="Search team members..." className="h-11 border-none focus:ring-0" />
                                    <CommandList className="max-h-[220px]">
                                        <CommandEmpty>No members found.</CommandEmpty>
                                        <CommandGroup>
                                            {users.map((user) => (
                                                <CommandItem
                                                    key={user.id}
                                                    value={user.name || user.email || user.id}
                                                    onSelect={() => {
                                                        setAssignedUserId(user.id);
                                                        setOpenCombobox(false);
                                                    }}
                                                    className="py-3 px-4 rounded-xl cursor-pointer transition-colors"
                                                >
                                                    <div className="flex items-center gap-3 flex-1">
                                                        <Avatar className="h-9 w-9 border border-border/50 shadow-sm">
                                                            <AvatarImage src={user.image || ""} />
                                                            <AvatarFallback className="text-[10px] bg-primary/5 text-primary font-bold">
                                                                {user.name?.substring(0, 2).toUpperCase() || "UN"}
                                                            </AvatarFallback>
                                                        </Avatar>
                                                        <div className="flex flex-col text-left">
                                                            <span className="font-bold text-sm leading-none">{user.name || user.email}</span>
                                                            <span className="text-[10px] text-muted-foreground mt-1 font-bold tracking-wider uppercase">{user.role}</span>
                                                        </div>
                                                    </div>
                                                    <Check
                                                        className={cn(
                                                            "ml-2 h-4 w-4 text-indigo-600",
                                                            assignedUserId === user.id ? "opacity-100" : "opacity-0"
                                                        )}
                                                    />
                                                </CommandItem>
                                            ))}
                                        </CommandGroup>
                                    </CommandList>
                                </Command>
                            </PopoverContent>
                        </Popover>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                        <Button 
                            variant="ghost" 
                            onClick={() => setIsOpen(false)}
                            className="rounded-xl h-12 px-6 font-bold text-muted-foreground hover:text-foreground hover:bg-muted/50"
                        >
                            Cancel
                        </Button>
                        <Button 
                            onClick={handleAssign} 
                            disabled={isLoading || !assignedUserId}
                            className="rounded-xl h-12 px-6 font-bold shadow-lg shadow-indigo-500/20 bg-indigo-600 hover:bg-indigo-700 text-white transition-all active:scale-[0.98]"
                        >
                            {isLoading ? "Assigning..." : (
                                <>
                                    Confirm Assignment
                                    <ArrowRight className="w-4 h-4 ml-2 opacity-70" />
                                </>
                            )}
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
