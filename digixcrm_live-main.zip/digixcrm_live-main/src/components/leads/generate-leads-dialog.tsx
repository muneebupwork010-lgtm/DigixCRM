"use client";

import { useState } from "react";
import { 
    Dialog, 
    DialogContent, 
    DialogDescription, 
    DialogHeader, 
    DialogTitle, 
    DialogTrigger,
    DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from "@/components/ui/select";
import { Zap, Loader2, Search, MapPin, CheckCircle2, AlertTriangle, Building2 } from "lucide-react";
import { generateLeadsAction } from "@/lib/actions/leads";
import { PROVIDERS } from "@/lib/lead-gen-config";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

export function GenerateLeadsDialog() {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [provider, setProvider] = useState<string>("MOCK");
    const [niche, setNiche] = useState("");
    const [location, setLocation] = useState("");
    const [limit, setLimit] = useState("10");
    const router = useRouter();

    const handleGenerate = async () => {
        if (provider !== "MOCK" && (!niche || !location)) {
            toast.error("Please provide both a niche and a location.");
            return;
        }

        setLoading(true);
        try {
            const res = await generateLeadsAction({
                provider,
                niche,
                location,
                limit: parseInt(limit)
            });

            if (res.success) {
                toast.success(`Successfully generated ${res.count} leads from ${provider}!`);
                setOpen(false);
                router.refresh();
            } else {
                toast.error(res.error || "Generation failed. Make sure your API key is set in Settings > Integrations.");
            }
        } catch (error) {
            toast.error("An unexpected error occurred.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button variant="outline" className="gap-2 font-bold border-primary/20 hover:bg-primary/5 transition-all">
                    <Zap className="w-4 h-4 text-primary fill-primary/20" />
                    Lead Engine
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px] border-border/40 bg-background/80 backdrop-blur-2xl shadow-[0_0_50px_-12px_rgba(0,0,0,0.3)] overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
                <DialogHeader className="space-y-4 pt-4">
                    <div className="flex justify-center mb-2">
                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-primary shadow-inner relative">
                            <div className="absolute inset-0 rounded-2xl bg-primary/20 blur-xl" />
                            <Zap className="w-8 h-8 fill-primary/30 relative z-10" />
                        </div>
                    </div>
                    <div className="text-center">
                        <DialogTitle className="text-3xl font-black tracking-tight bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
                            Intelligence Extraction
                        </DialogTitle>
                        <DialogDescription className="font-medium mt-1.5 text-sm max-w-sm mx-auto">
                            Deploy connected APIs to extract high-intent prospect data directly into your pipeline.
                        </DialogDescription>
                    </div>
                </DialogHeader>

                <div className="space-y-6 py-6">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Data Source Engine</Label>
                            <Select value={provider} onValueChange={setProvider}>
                                <SelectTrigger className="h-12 bg-background/50 border-border/60 focus:ring-primary/20 font-semibold shadow-sm transition-all hover:bg-background/80">
                                    <SelectValue placeholder="Select provider" />
                                </SelectTrigger>
                                <SelectContent>
                                    {PROVIDERS.map((p) => (
                                        <SelectItem key={p.id} value={p.id} className="font-medium">
                                            {p.name} <span className="text-muted-foreground ml-1 font-normal text-xs">({p.type})</span>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Extraction Volume</Label>
                            <Select value={limit} onValueChange={setLimit}>
                                <SelectTrigger className="h-12 bg-background/50 border-border/60 focus:ring-primary/20 font-semibold shadow-sm transition-all hover:bg-background/80">
                                    <SelectValue placeholder="Limit" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="5">5 Profiles</SelectItem>
                                    <SelectItem value="10">10 Profiles</SelectItem>
                                    <SelectItem value="20">20 Profiles</SelectItem>
                                    <SelectItem value="50">50 Profiles</SelectItem>
                                    <SelectItem value="100">100 Profiles</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="space-y-5">
                        <div className="space-y-2">
                            <Label htmlFor="niche" className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground flex items-center gap-2">
                                <Search className="w-3.5 h-3.5 text-primary" /> Target Niche / Industry
                            </Label>
                            <Input 
                                id="niche" 
                                placeholder="e.g. SaaS, Commercial Real Estate, Dentists..." 
                                value={niche}
                                onChange={(e) => setNiche(e.target.value)}
                                className="h-12 bg-background/50 border-border/60 focus:ring-primary/20 font-medium transition-all hover:bg-background/80"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="location" className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground flex items-center gap-2">
                                <MapPin className="w-3.5 h-3.5 text-primary" /> Geographical Focus
                            </Label>
                            <Input 
                                id="location" 
                                placeholder="e.g. Austin TX, London, Global..." 
                                value={location}
                                onChange={(e) => setLocation(e.target.value)}
                                className="h-12 bg-background/50 border-border/60 focus:ring-primary/20 font-medium transition-all hover:bg-background/80"
                            />
                        </div>
                    </div>

                    <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 flex items-start gap-3 relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-indigo-500 to-purple-500" />
                        <Zap className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                        <p className="text-[11px] leading-relaxed text-indigo-900/80 dark:text-indigo-200/80 font-medium">
                            <strong className="text-indigo-600 dark:text-indigo-400">Notice:</strong> Paid/Premium engines require API keys configured in Workspace Settings. Generated leads bypass the manual review queue and enter pipeline as <strong className="text-foreground italic">NEW</strong>.
                        </p>
                    </div>
                </div>

                <DialogFooter className="pt-2">
                    <Button 
                        onClick={handleGenerate} 
                        disabled={loading} 
                        className="w-full h-14 text-lg font-black tracking-tight gap-3 shadow-xl shadow-primary/25 active:scale-[0.98] transition-all bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                    >
                        {loading ? (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
                                <Loader2 className="w-5 h-5 animate-spin" />
                                Extracting Data...
                            </motion.div>
                        ) : (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
                                <Zap className="w-5 h-5 fill-current" />
                                Initiate Extraction
                            </motion.div>
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
