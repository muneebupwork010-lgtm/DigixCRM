"use client";

/**
 * Secure Fields Input Section
 * 
 * Renders the "🔒 Secure Information" form section inside
 * Create/Edit Contact dialogs. Allows authorized users to
 * input PII data that gets encrypted on save.
 * 
 * Features:
 * - SSN auto-formatting (XXX-XX-XXXX)
 * - Visual security indicators
 * - Separate save confirmation for secure data
 */

import { useState, useEffect, useCallback } from "react";
import { Shield, Lock, Eye, EyeOff, AlertTriangle, Check, Loader2, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
    saveSecureField,
    revealSecureField,
    deleteSecureField,
    getSecureFieldMasks,
} from "@/lib/actions/secure-fields";
import { formatSSN } from "@/lib/field-encryption";

interface SecureFieldsSectionProps {
    contactId: string | null; // null for new contacts (fields saved after contact creation)
    userRole: string;
    canView: boolean; // canViewSecureFields result
    canEdit: boolean; // canEditSecureFields result
    /** For new contacts: collect values to save after contact is created */
    onPendingFieldsChange?: (fields: { fieldName: string; value: string }[]) => void;
}

interface FieldState {
    fieldName: string;
    label: string;
    hasValue: boolean;
    maskedValue: string | null;
    inputValue: string;
    isRevealed: boolean;
    revealedValue: string | null;
    revealTimer: number | null; // countdown seconds
    isSaving: boolean;
    isRevealing: boolean;
    isDeleting: boolean;
    inputType: string;
    placeholder: string;
}

const FIELD_CONFIG: Record<string, { label: string; inputType: string; placeholder: string }> = {
    SSN: { label: "Social Security Number", inputType: "text", placeholder: "XXX-XX-XXXX" },
    DOB_CLIENT: { label: "Client Date of Birth", inputType: "date", placeholder: "MM/DD/YYYY" },
    DOB_SPOUSE: { label: "Spouse Date of Birth", inputType: "date", placeholder: "MM/DD/YYYY" },
    DRIVERS_LICENSE: { label: "Driver's License", inputType: "text", placeholder: "License Number" },
    PASSPORT: { label: "Passport Number", inputType: "text", placeholder: "Passport Number" },
    TAX_ID: { label: "Tax ID / EIN", inputType: "text", placeholder: "XX-XXXXXXX" },
};

export function SecureFieldsSection({
    contactId,
    userRole,
    canView,
    canEdit,
    onPendingFieldsChange,
}: SecureFieldsSectionProps) {
    const [fields, setFields] = useState<FieldState[]>([]);
    const [loading, setLoading] = useState(false);

    // Load existing masked fields for edit mode
    useEffect(() => {
        if (contactId) {
            loadMasks();
        } else {
            // New contact — initialize empty fields
            setFields(
                Object.entries(FIELD_CONFIG).map(([fieldName, config]) => ({
                    fieldName,
                    label: config.label,
                    hasValue: false,
                    maskedValue: null,
                    inputValue: "",
                    isRevealed: false,
                    revealedValue: null,
                    revealTimer: null,
                    isSaving: false,
                    isRevealing: false,
                    isDeleting: false,
                    inputType: config.inputType,
                    placeholder: config.placeholder,
                }))
            );
        }
    }, [contactId]);

    // Notify parent of pending fields for new contacts
    useEffect(() => {
        if (!contactId && onPendingFieldsChange) {
            const pending = fields
                .filter((f) => f.inputValue.trim() !== "")
                .map((f) => ({ fieldName: f.fieldName, value: f.inputValue }));
            onPendingFieldsChange(pending);
        }
    }, [fields, contactId, onPendingFieldsChange]);

    async function loadMasks() {
        if (!contactId) return;
        setLoading(true);
        const result = await getSecureFieldMasks(contactId);
        if (result.success && result.fields) {
            setFields(
                result.fields.map((f: any) => ({
                    fieldName: f.fieldName,
                    label: f.label,
                    hasValue: f.hasValue,
                    maskedValue: f.maskedValue,
                    inputValue: "",
                    isRevealed: false,
                    revealedValue: null,
                    revealTimer: null,
                    isSaving: false,
                    isRevealing: false,
                    isDeleting: false,
                    inputType: FIELD_CONFIG[f.fieldName]?.inputType || "text",
                    placeholder: FIELD_CONFIG[f.fieldName]?.placeholder || "",
                }))
            );
        }
        setLoading(false);
    }

    const updateField = useCallback((fieldName: string, updates: Partial<FieldState>) => {
        setFields((prev) =>
            prev.map((f) => (f.fieldName === fieldName ? { ...f, ...updates } : f))
        );
    }, []);

    // Handle SSN formatting
    function handleInputChange(fieldName: string, value: string) {
        if (fieldName === "SSN") {
            value = formatSSN(value);
        }
        updateField(fieldName, { inputValue: value });
    }

    // Save a single field (edit mode only)
    async function handleSaveField(fieldName: string) {
        if (!contactId) return;
        const field = fields.find((f) => f.fieldName === fieldName);
        if (!field || !field.inputValue.trim()) return;

        updateField(fieldName, { isSaving: true });

        const result = await saveSecureField(contactId, fieldName as any, field.inputValue);

        if (result.success) {
            toast.success(`${field.label} encrypted and saved securely`);
            updateField(fieldName, {
                isSaving: false,
                hasValue: true,
                inputValue: "",
                maskedValue: getMaskForField(fieldName),
            });
        } else {
            toast.error(result.error || "Failed to save");
            updateField(fieldName, { isSaving: false });
        }
    }

    // Reveal a field (ADMIN only)
    async function handleReveal(fieldName: string) {
        if (!contactId || !canView) return;

        const confirmed = window.confirm(
            "⚠️ SECURITY NOTICE\n\nRevealing this field will be permanently recorded in the audit log with your identity and timestamp.\n\nContinue?"
        );
        if (!confirmed) return;

        updateField(fieldName, { isRevealing: true });

        const result = await revealSecureField(contactId, fieldName as any);

        if (result.success && result.value) {
            updateField(fieldName, {
                isRevealing: false,
                isRevealed: true,
                revealedValue: result.value,
                revealTimer: 30,
            });

            // Auto-hide countdown
            let countdown = 30;
            const interval = setInterval(() => {
                countdown--;
                if (countdown <= 0) {
                    clearInterval(interval);
                    updateField(fieldName, {
                        isRevealed: false,
                        revealedValue: null,
                        revealTimer: null,
                    });
                } else {
                    updateField(fieldName, { revealTimer: countdown });
                }
            }, 1000);
        } else {
            toast.error(result.error || "Failed to reveal");
            updateField(fieldName, { isRevealing: false });
        }
    }

    // Hide a revealed field immediately
    function handleHide(fieldName: string) {
        updateField(fieldName, {
            isRevealed: false,
            revealedValue: null,
            revealTimer: null,
        });
    }

    // Delete a field (ADMIN only)
    async function handleDelete(fieldName: string) {
        if (!contactId) return;

        const confirmed = window.confirm(
            "⚠️ PERMANENT DELETION\n\nThis will permanently delete this encrypted field. This action cannot be undone.\n\nContinue?"
        );
        if (!confirmed) return;

        updateField(fieldName, { isDeleting: true });

        const result = await deleteSecureField(contactId, fieldName as any);

        if (result.success) {
            toast.success("Secure field deleted");
            updateField(fieldName, {
                isDeleting: false,
                hasValue: false,
                maskedValue: null,
                inputValue: "",
            });
        } else {
            toast.error(result.error || "Failed to delete");
            updateField(fieldName, { isDeleting: false });
        }
    }

    function getMaskForField(fieldName: string): string {
        switch (fieldName) {
            case "SSN": return "•••-••-••••";
            case "DOB_CLIENT":
            case "DOB_SPOUSE": return "••/••/••••";
            default: return "••••••••••";
        }
    }

    if (!canEdit && !canView) return null;
    if (loading) {
        return (
            <div className="mt-4 pt-4 border-t border-amber-500/20">
                <div className="flex items-center gap-2 text-amber-600 text-xs">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Loading secure fields...
                </div>
            </div>
        );
    }

    return (
        <div className="mt-4 pt-4 border-t-2 border-amber-500/30">
            {/* Header */}
            <div className="flex items-center gap-2.5 mb-4">
                <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <Shield className="w-4 h-4 text-amber-600" />
                </div>
                <div className="flex-1">
                    <Label className="text-sm font-black text-amber-700 dark:text-amber-400 tracking-tight">
                        Secure Information
                    </Label>
                    <p className="text-[10px] text-amber-600/70 dark:text-amber-500/60 font-medium leading-tight">
                        AES-256 encrypted · Audit logged · Admin-only visibility
                    </p>
                </div>
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
                    <Lock className="w-2.5 h-2.5 text-amber-600" />
                    <span className="text-[9px] font-black text-amber-600 uppercase tracking-widest">
                        Vault
                    </span>
                </div>
            </div>

            {/* Fields */}
            <div className="space-y-3">
                {fields.map((field) => (
                    <div
                        key={field.fieldName}
                        className="group relative p-3 rounded-xl bg-amber-500/[0.03] border border-amber-500/15 hover:border-amber-500/25 transition-all duration-200"
                    >
                        <div className="flex items-center justify-between mb-1.5">
                            <Label className="text-xs font-bold text-foreground/80 flex items-center gap-1.5">
                                <Lock className="w-3 h-3 text-amber-500/60" />
                                {field.label}
                            </Label>
                            {field.hasValue && (
                                <div className="flex items-center gap-1">
                                    <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                                        <Check className="w-2.5 h-2.5 text-emerald-500" />
                                        <span className="text-[9px] font-bold text-emerald-600 uppercase">
                                            Stored
                                        </span>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Existing value display */}
                        {field.hasValue && !field.inputValue && (
                            <div className="flex items-center gap-2">
                                <div 
                                    className="flex-1 h-9 px-3 flex items-center rounded-lg bg-zinc-100/80 dark:bg-zinc-800/50 border border-border/50 font-mono text-sm tracking-wider text-muted-foreground select-none"
                                    onCopy={(e) => {
                                        e.preventDefault();
                                        toast.error("Copying secure fields is disabled for security reasons.");
                                    }}
                                    onContextMenu={(e) => e.preventDefault()}
                                >
                                    {field.isRevealed && field.revealedValue ? (
                                        <span className="text-foreground font-bold animate-in fade-in duration-300 select-none blur-[0.3px]">
                                            {field.revealedValue}
                                        </span>
                                    ) : (
                                        <span className="opacity-60">{field.maskedValue}</span>
                                    )}
                                </div>

                                {/* Reveal/Hide buttons — ADMIN ONLY */}
                                {canView && !field.isRevealed && (
                                    <Button
                                        type="button"
                                        variant="outline"
                                        size="sm"
                                        className="h-9 px-3 text-[10px] font-bold uppercase tracking-wider border-amber-500/30 text-amber-600 hover:bg-amber-500/10 hover:text-amber-700 hover:border-amber-500/50 transition-all"
                                        onClick={() => handleReveal(field.fieldName)}
                                        disabled={field.isRevealing}
                                    >
                                        {field.isRevealing ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                        ) : (
                                            <>
                                                <Eye className="w-3 h-3 mr-1.5" />
                                                Reveal
                                            </>
                                        )}
                                    </Button>
                                )}

                                {field.isRevealed && (
                                    <div className="flex items-center gap-1.5">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            className="h-9 px-3 text-[10px] font-bold uppercase tracking-wider border-red-500/30 text-red-500 hover:bg-red-500/10 transition-all"
                                            onClick={() => handleHide(field.fieldName)}
                                        >
                                            <EyeOff className="w-3 h-3 mr-1.5" />
                                            Hide
                                        </Button>
                                        {field.revealTimer && (
                                            <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 border border-red-500/20 animate-pulse">
                                                <span className="text-[10px] font-black text-red-500 tabular-nums">
                                                    {field.revealTimer}s
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {/* Delete button — ADMIN ONLY */}
                                {canView && !field.isRevealed && (
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="icon"
                                        className="h-9 w-9 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                                        onClick={() => handleDelete(field.fieldName)}
                                        disabled={field.isDeleting}
                                    >
                                        {field.isDeleting ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                        ) : (
                                            <Trash2 className="w-3.5 h-3.5" />
                                        )}
                                    </Button>
                                )}
                            </div>
                        )}

                        {/* Input field (new value or updating) */}
                        {(!field.hasValue || field.inputValue) && canEdit && (
                            <div className="flex items-center gap-2">
                                <Input
                                    type={field.inputType}
                                    placeholder={field.placeholder}
                                    value={field.inputValue.trim()}
                                    onChange={(e) =>
                                        handleInputChange(field.fieldName, e.target.value)
                                    }
                                    className="h-9 text-sm bg-background/80 border-amber-500/20 focus:border-amber-500/50 focus:ring-amber-500/20 font-mono"
                                    autoComplete="off"
                                    data-lpignore="true"
                                    data-form-type="other"
                                />

                                {/* Save button — only in edit mode (contactId exists) */}
                                {contactId && field.inputValue.trim() && (
                                    <Button
                                        type="button"
                                        size="sm"
                                        className="h-9 px-3 text-[10px] font-bold uppercase tracking-wider bg-amber-600 hover:bg-amber-700 text-white shadow-lg shadow-amber-600/20"
                                        onClick={() => handleSaveField(field.fieldName)}
                                        disabled={field.isSaving}
                                    >
                                        {field.isSaving ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                        ) : (
                                            <>
                                                <Lock className="w-3 h-3 mr-1" />
                                                Encrypt
                                            </>
                                        )}
                                    </Button>
                                )}

                                {/* Cancel updating */}
                                {field.hasValue && (
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        size="sm"
                                        className="h-9 px-2 text-xs text-muted-foreground"
                                        onClick={() =>
                                            updateField(field.fieldName, { inputValue: "" })
                                        }
                                    >
                                        Cancel
                                    </Button>
                                )}
                            </div>
                        )}

                        {/* Not viewable indicator for non-admins */}
                        {field.hasValue && !canView && (
                            <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-amber-600/50 font-medium">
                                <Lock className="w-2.5 h-2.5" />
                                Encrypted — Admin access required to view
                            </div>
                        )}
                    </div>
                ))}
            </div>

            {/* Security footer */}
            <div className="mt-3 flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-500/[0.04] border border-amber-500/10">
                <AlertTriangle className="w-3 h-3 text-amber-500/50 shrink-0" />
                <p className="text-[9px] text-amber-600/50 font-medium leading-tight">
                    All secure fields are encrypted with AES-256-GCM + HKDF key derivation. 
                    Every access is permanently recorded in the audit trail.
                </p>
            </div>
        </div>
    );
}
