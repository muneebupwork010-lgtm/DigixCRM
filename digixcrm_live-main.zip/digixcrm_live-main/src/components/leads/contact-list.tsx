"use client";

import { useState, useMemo } from "react";
import {
    ColumnDef,
    flexRender,
    getCoreRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
    SortingState,
} from "@tanstack/react-table";
import { 
    Table, 
    TableBody, 
    TableCell, 
    TableHead, 
    TableHeader, 
    TableRow 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { 
    Search, 
    Mail, 
    Phone, 
    Building2, 
    MoreHorizontal, 
    Trash2, 
    Edit, 
    FilterX, 
    ArrowUpDown, 
    ChevronUp, 
    ChevronDown,
    User,
    Calendar,
    MailPlus,
    Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuLabel,
    DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { deleteContact } from "@/lib/actions/contacts";
import { toast } from "sonner";
import { EditContactDialog } from "./edit-contact-dialog";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { isWithinInterval, startOfDay, endOfDay } from "date-fns";

interface ContactListProps {
    data: any[];
    organizations?: { id: string; name: string }[];
    userRole?: string;
}

export function ContactList({ data, organizations = [], userRole = "REP" }: ContactListProps) {
    const [sorting, setSorting] = useState<SortingState>([]);
    
    // --- Filter States ---
    const [searchTerm, setSearchTerm] = useState("");
    const [organizationFilter, setOrganizationFilter] = useState("ALL");
    const [dateRange, setDateRange] = useState<{ from: Date | undefined; to?: Date | undefined } | undefined>();
    
    // Edit Contact State
    const [activeContact, setActiveContact] = useState<any>(null);
    const [editDialogOpen, setEditDialogOpen] = useState(false);

    // --- Filter Logic ---
    const filteredData = useMemo(() => {
        const query = searchTerm.toLowerCase();
        return data.filter(contact => {
            const matchesSearch = 
                (contact.firstName || "").toLowerCase().includes(query) ||
                (contact.lastName || "").toLowerCase().includes(query) ||
                (contact.email || "").toLowerCase().includes(query) ||
                (contact.phone || "").toLowerCase().includes(query);
                
            const matchesOrg = organizationFilter === "ALL" || contact.organizationId === organizationFilter;
            
            let matchesDate = true;
            if (dateRange?.from) {
                const contactDate = new Date(contact.createdAt);
                if (dateRange.to) {
                    matchesDate = isWithinInterval(contactDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.to)
                    });
                } else {
                    matchesDate = isWithinInterval(contactDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.from)
                    });
                }
            }
            
            return matchesSearch && matchesOrg && matchesDate;
        });
    }, [data, searchTerm, organizationFilter, dateRange]);

    const handleDelete = async (id: string) => {
        if (!confirm("Are you sure you want to delete this contact?")) return;
        const result = await deleteContact(id);
        if (result.success) {
            toast.success("Contact successfully removed.");
        } else {
            toast.error(result.error || "Failed to remove contact.");
        }
    };

    const columns: ColumnDef<any>[] = [
        {
            accessorKey: "name",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Identity
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => (
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20 shrink-0">
                        <User className="w-4 h-4 text-primary" />
                    </div>
                    <div className="font-bold text-foreground tracking-tight">
                        {row.original.firstName} {row.original.lastName}
                    </div>
                    {row.original._hasSecureFields && (
                        <div className="p-1 rounded bg-amber-500/10 border border-amber-500/20" title="Has encrypted PII data">
                            <Shield className="w-3 h-3 text-amber-600" />
                        </div>
                    )}
                </div>
            ),
        },
        {
            accessorKey: "email",
            header: "Communication",
            cell: ({ row }) => (
                <div className="space-y-0.5">
                    <div className="flex items-center gap-2 text-foreground font-bold text-xs ring-0">
                        <Mail className="w-3.5 h-3.5 text-muted-foreground/60" />
                        {row.original.email || <span className="opacity-30 italic font-medium uppercase text-[10px]">No Email</span>}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground font-medium text-[11px]">
                        <Phone className="w-3.5 h-3.5 text-muted-foreground/60" />
                        {row.original.phone || "--"}
                    </div>
                </div>
            ),
        },
        {
            accessorKey: "organization",
            header: "Affiliation",
            cell: ({ row }) => {
                const org = row.original.organization;
                return (
                    <div className="flex items-center gap-2.5 text-foreground font-bold text-xs">
                        <Building2 className="w-4 h-4 text-indigo-500/60" />
                        {org?.name || <span className="opacity-30 italic font-medium uppercase text-[10px]">Independent</span>}
                    </div>
                );
            },
        },
        {
            accessorKey: "createdAt",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Integration
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => {
                const date = new Date(row.original.createdAt);
                return (
                    <div className="text-[11px] text-muted-foreground font-bold uppercase tracking-tight">
                        {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </div>
                );
            },
        },
        {
            id: "actions",
            header: "Controls",
            cell: ({ row }) => {
                const contact = row.original;
                return (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2.5 text-primary hover:text-primary hover:bg-primary/5 font-black text-[10px] uppercase tracking-widest"
                            onClick={() => {
                                setActiveContact(contact);
                                setEditDialogOpen(true);
                            }}
                        >
                            <Edit className="w-3.5 h-3.5 mr-2" />
                            Calibrate
                        </Button>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0 rounded-full hover:bg-muted font-bold text-muted-foreground">
                                    <MoreHorizontal className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-52 p-2 rounded-2xl shadow-2xl">
                                <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-2 py-1.5">Action Protocols</DropdownMenuLabel>
                                <DropdownMenuItem className="gap-2 py-2.5 font-bold rounded-xl" onClick={() => { setActiveContact(contact); setEditDialogOpen(true); }}>
                                    <Edit className="w-4 h-4" /> Edit Parameters
                                </DropdownMenuItem>
                                <DropdownMenuSeparator className="opacity-50" />
                                <DropdownMenuItem 
                                    className="gap-2 py-2.5 font-bold text-red-500 focus:text-red-500 focus:bg-red-50 dark:focus:bg-red-900/20 rounded-xl"
                                    onClick={() => handleDelete(contact.id)}
                                >
                                    <Trash2 className="w-4 h-4" /> Purge Identity
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                );
            },
        },
    ];

    const table = useReactTable({
        data: filteredData,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        onSortingChange: setSorting,
        state: { sorting },
        initialState: {
            pagination: { pageSize: 15 },
            sorting: [{ id: "createdAt", desc: true }]
        },
    });

    return (
        <div className="flex flex-col gap-4">
            {/* Filter Toolbar */}
            <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center bg-card p-4 rounded-2xl border border-border/50 shadow-sm transition-all duration-300">
                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 w-full xl:w-auto flex-1">
                    <div className="relative w-full md:w-[300px] lg:w-[400px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input 
                            placeholder="Identify contacts by name, email, phone..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10 h-10 bg-muted/50 border-border focus:bg-background transition-all rounded-xl text-sm ring-0"
                        />
                    </div>

                    <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                        <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
                            <SelectTrigger className="w-full sm:w-[200px] bg-muted/50 border-border h-10 rounded-xl font-bold text-[11px] ring-0 tracking-tight">
                                <SelectValue placeholder="System Filter: Org" />
                            </SelectTrigger>
                            <SelectContent className="rounded-2xl border-border shadow-2xl">
                                <SelectItem value="ALL" className="font-bold">Global Entities</SelectItem>
                                {organizations.map((org) => (
                                    <SelectItem key={org.id} value={org.id} className="font-medium text-xs truncate max-w-[180px]">{org.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3 w-full xl:w-auto">
                    <div className="relative w-full sm:w-auto">
                        <DatePickerWithRange date={dateRange} setDate={setDateRange} />
                    </div>

                    {(searchTerm || organizationFilter !== "ALL" || dateRange) && (
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                                setSearchTerm("");
                                setOrganizationFilter("ALL");
                                setDateRange(undefined);
                            }}
                            className="text-muted-foreground hover:text-foreground h-10 w-10 shrink-0 hidden sm:flex border border-border/60"
                            title="Reset Protocols"
                        >
                            <FilterX className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>

            {/* Mobile Contact Cards */}
            <div className="grid grid-cols-1 gap-4 md:hidden pb-4">
                {table.getRowModel().rows.length > 0 ? (
                    table.getRowModel().rows.map((row) => {
                        const contact = row.original;
                        return (
                            <div 
                                key={contact.id} 
                                className="p-5 rounded-3xl border border-border/60 bg-card shadow-sm active:scale-[0.98] transition-all duration-200"
                            >
                                <div className="flex items-start justify-between mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 flex items-center justify-center shrink-0">
                                            <User className="w-5 h-5 text-indigo-600" />
                                        </div>
                                        <div>
                                            <h3 className="text-base font-black tracking-tight text-foreground leading-none mb-1.5">
                                                {contact.firstName} {contact.lastName}
                                            </h3>
                                            <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-black uppercase tracking-widest">
                                                <Building2 className="w-2.5 h-2.5 opacity-50" />
                                                {contact.organization?.name || "Independent"}
                                            </div>
                                        </div>
                                    </div>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" className="h-9 w-9 p-0 rounded-2xl bg-muted/40 transition-colors">
                                                <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end" className="w-52 p-2 rounded-2xl shadow-2xl">
                                            <DropdownMenuItem 
                                                className="gap-2 py-3 font-bold rounded-xl"
                                                onClick={() => {
                                                    setActiveContact(contact);
                                                    setEditDialogOpen(true);
                                                }}
                                            >
                                                <Edit className="w-4 h-4" />
                                                Adjust Parameters
                                            </DropdownMenuItem>
                                            <DropdownMenuItem 
                                                className="gap-2 py-3 font-bold text-red-500 focus:text-red-500 focus:bg-red-50 dark:focus:bg-red-900/20 rounded-xl"
                                                onClick={() => handleDelete(contact.id)}
                                            >
                                                <Trash2 className="w-4 h-4" />
                                                Erase Protocol
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>

                                <div className="space-y-3 bg-muted/30 p-4 rounded-2xl border border-border/40">
                                    <div className="flex items-center gap-3 text-xs font-bold text-foreground/70">
                                        <div className="bg-background/80 p-2 rounded-xl border border-border/40 shadow-sm">
                                            <Mail className="w-3.5 h-3.5 text-primary" />
                                        </div>
                                        <span className="truncate">{contact.email || "Null Contact Point"}</span>
                                    </div>
                                    <div className="flex items-center gap-3 text-xs font-bold text-foreground/70">
                                        <div className="bg-background/80 p-2 rounded-xl border border-border/40 shadow-sm">
                                            <Phone className="w-3.5 h-3.5 text-primary" />
                                        </div>
                                        <span>{contact.phone || "No Active Line"}</span>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                ) : (
                    <div className="py-20 flex flex-col items-center justify-center text-center text-muted-foreground font-medium bg-muted/20 rounded-3xl border-2 border-dashed border-border/40">
                         <MailPlus className="w-10 h-10 opacity-20 mb-4" />
                         <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40">Zero Identities Detected</p>
                    </div>
                )}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
                <Table>
                    <TableHeader className="bg-muted/40">
                        {table.getHeaderGroups().map((headerGroup) => (
                            <TableRow key={headerGroup.id} className="hover:bg-transparent border-border/50">
                                {headerGroup.headers.map((header) => (
                                    <TableHead key={header.id} className="h-12 px-5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                                        {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map((row) => (
                                <TableRow key={row.id} className="hover:bg-muted/30 transition-colors border-border/40">
                                    {row.getVisibleCells().map((cell) => (
                                        <TableCell key={cell.id} className="px-5 py-4 text-[13px] whitespace-nowrap align-middle">
                                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={columns.length} className="h-32 text-center text-muted-foreground font-black italic opacity-30 uppercase tracking-[0.3em]">
                                    Identity Matrix Empty
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <EditContactDialog 
                open={editDialogOpen}
                onOpenChange={setEditDialogOpen}
                contact={activeContact}
                organizations={organizations}
                userRole={userRole}
            />

            {/* Pagination Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-4 border-t border-border/50">
                <div className="text-sm text-muted-foreground font-medium text-center sm:text-left">
                    Processing <span className="text-foreground font-black">{table.getRowModel().rows.length}</span> of <span className="text-foreground font-black">{filteredData.length}</span> identities.
                </div>
                
                <div className="flex items-center gap-3 sm:gap-6 flex-wrap justify-center sm:justify-end w-full sm:w-auto">
                    <div className="flex items-center gap-2">
                        <p className="text-xs font-black text-muted-foreground uppercase tracking-widest hidden xs:block">Buffer</p>
                        <Select
                            value={`${table.getState().pagination.pageSize}`}
                            onValueChange={(value) => table.setPageSize(Number(value))}
                        >
                            <SelectTrigger className="h-8 w-[76px] bg-muted/50 border-border/50 font-black text-[10px] ring-0 rounded-lg">
                                <SelectValue placeholder={table.getState().pagination.pageSize} />
                            </SelectTrigger>
                            <SelectContent side="top" className="border-border shadow-2xl rounded-xl">
                                {[15, 30, 50, 100].map((size) => (
                                    <SelectItem key={size} value={`${size}`} className="text-[10px] font-bold">
                                        {size}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex items-center justify-center text-[10px] font-black min-w-[90px] whitespace-nowrap bg-muted/40 px-3 py-1 rounded-full border border-border/50 uppercase tracking-tighter">
                        Page {table.getState().pagination.pageIndex + 1} <span className="text-muted-foreground font-light mx-1.5">/</span> {table.getPageCount() || 1}
                    </div>

                    <div className="flex items-center gap-1.5">
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all rounded-lg border-border"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            <span className="sr-only">Previous</span>
                            <span className="text-lg leading-none mb-0.5">‹</span>
                        </Button>
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all rounded-lg border-border"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            <span className="sr-only">Next</span>
                            <span className="text-lg leading-none mb-0.5">›</span>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
