"use client";

import { useState, useEffect } from "react";
import { Edit2, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { updateContact } from "@/lib/actions/contacts";
import { toast } from "sonner";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SecureFieldsSection } from "./secure-fields-section";
import { canViewSecureFields, canEditSecureFields } from "@/lib/permissions-base";

interface EditContactDialogProps {
    contact: any;
    organizations: { id: string; name: string }[];
    open: boolean;
    onOpenChange: (open: boolean) => void;
    userRole?: string;
}

export function EditContactDialog({ contact, organizations, open, onOpenChange, userRole = "REP" }: EditContactDialogProps) {
    const [loading, setLoading] = useState(false);

    // Family members state
    const [children, setChildren] = useState<{ name: string; dob: string }[]>([]);
    const [spouse, setSpouse] = useState<{ name: string; dob: string } | null>(null);

    useEffect(() => {
        if (contact && open) {
            const family = contact.familyMembers as any;
            if (family) {
                if (Array.isArray(family.children)) {
                    setChildren(family.children);
                } else {
                    setChildren([]);
                }
                if (family.spouse) {
                    setSpouse(family.spouse);
                } else {
                    setSpouse(null);
                }
            } else {
                setChildren([]);
                setSpouse(null);
            }
        }
    }, [contact, open]);

    const addChild = () => setChildren([...children, { name: "", dob: "" }]);
    const removeChild = (index: number) => setChildren(children.filter((_, i) => i !== index));
    const updateChild = (index: number, field: "name" | "dob", value: string) => {
        const newChildren = [...children];
        newChildren[index][field] = value;
        setChildren(newChildren);
    };

    async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        setLoading(true);
        const formData = new FormData(e.currentTarget);
        
        // Clean family data
        const validChildren = children.filter(c => c.name.trim() !== "");
        const familyMembers: any = {};
        if (validChildren.length > 0) familyMembers.children = validChildren;
        if (spouse && spouse.name.trim() !== "") familyMembers.spouse = spouse;

        const finalFamilyMembers = Object.keys(familyMembers).length > 0 ? familyMembers : null;

        const data = {
            firstName: formData.get("firstName") as string,
            lastName: formData.get("lastName") as string,
            email: formData.get("email") as string,
            phone: formData.get("phone") as string,
            dob: formData.get("dob") as string,
            organizationId: formData.get("organizationId") === "none" ? null : formData.get("organizationId") as string,
            familyMembers: finalFamilyMembers,
        };

        const result = await updateContact(contact.id, data);
        setLoading(false);

        if (result.success) {
            toast.success("Contact updated successfully");
            onOpenChange(false);
        } else {
            toast.error(result.error || "Failed to update contact");
        }
    }

    if (!contact) return null;

    // Convert Date object or ISO string to YYYY-MM-DD for the date input
    const dobValue = contact.dob ? new Date(contact.dob).toISOString().split('T')[0] : "";

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px]">
                <form onSubmit={handleSubmit}>
                    <DialogHeader>
                        <DialogTitle>Edit Contact</DialogTitle>
                    </DialogHeader>
                    <div className="max-h-[60vh] overflow-y-auto pr-2">
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="edit-firstName">First Name</Label>
                                    <Input id="edit-firstName" name="firstName" defaultValue={contact.firstName || ""} required />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit-lastName">Last Name</Label>
                                    <Input id="edit-lastName" name="lastName" defaultValue={contact.lastName || ""} required />
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="edit-email">Email</Label>
                                    <Input id="edit-email" name="email" type="email" defaultValue={contact.email || ""} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit-phone">Phone</Label>
                                    <Input id="edit-phone" name="phone" defaultValue={contact.phone || ""} />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="edit-organizationId" className="flex justify-between items-center">
                                        <span>Organization</span>
                                        <span className="text-[10px] text-muted-foreground">Optional</span>
                                    </Label>
                                    <Select name="organizationId" defaultValue={contact.organizationId || "none"}>
                                        <SelectTrigger autoFocus={false}>
                                            <SelectValue placeholder="Select Organization" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">None</SelectItem>
                                            {organizations.map((org) => (
                                                <SelectItem key={org.id} value={org.id}>
                                                    {org.name}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="edit-dob" className="flex justify-between items-center">
                                        <span>Date of Birth</span>
                                        <span className="text-[10px] text-muted-foreground">Optional</span>
                                    </Label>
                                    <Input id="edit-dob" name="dob" type="date" defaultValue={dobValue} />
                                </div>
                            </div>

                            {/* Family Members Section */}
                            <div className="mt-4 pt-4 border-t border-border/50">
                                <div className="flex items-center justify-between mb-3">
                                    <div>
                                        <Label className="text-sm font-bold">Family Members</Label>
                                        <p className="text-[10px] text-muted-foreground">Add spouse & children for automated birthday wishes.</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        {!spouse && (
                                            <Button type="button" variant="outline" size="sm" onClick={() => setSpouse({ name: "", dob: "" })} className="h-8">
                                                <Plus className="w-3 h-3 mr-1" /> Add Spouse
                                            </Button>
                                        )}
                                        <Button type="button" variant="outline" size="sm" onClick={addChild} className="h-8">
                                            <Plus className="w-3 h-3 mr-1" /> Add Child
                                        </Button>
                                    </div>
                                </div>
                                
                                <div className="space-y-3">
                                    {spouse && (
                                        <div className="flex gap-2 items-start bg-indigo-500/5 p-2.5 rounded-xl border border-indigo-500/20">
                                            <div className="space-y-1.5 flex-1">
                                                <Input 
                                                    placeholder="Spouse's Name" 
                                                    value={spouse.name}
                                                    onChange={(e) => setSpouse({ ...spouse, name: e.target.value })}
                                                    className="h-8 text-xs bg-background/50"
                                                />
                                            </div>
                                            <div className="space-y-1.5 flex-1">
                                                <Input 
                                                    type="date"
                                                    value={spouse.dob}
                                                    onChange={(e) => setSpouse({ ...spouse, dob: e.target.value })}
                                                    className="h-8 text-xs bg-background/50"
                                                />
                                            </div>
                                            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-50" onClick={() => setSpouse(null)}>
                                                <X className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    )}
                                    {children.map((child, index) => (
                                        <div key={index} className="flex gap-2 items-start bg-muted/30 p-2.5 rounded-xl border border-border/50">
                                            <div className="space-y-1.5 flex-1">
                                                <Input 
                                                    placeholder="Child's Name" 
                                                    value={child.name}
                                                    onChange={(e) => updateChild(index, "name", e.target.value)}
                                                    className="h-8 text-xs"
                                                />
                                            </div>
                                            <div className="space-y-1.5 flex-1">
                                                <Input 
                                                    type="date"
                                                    value={child.dob}
                                                    onChange={(e) => updateChild(index, "dob", e.target.value)}
                                                    className="h-8 text-xs"
                                                />
                                            </div>
                                            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-50" onClick={() => removeChild(index)}>
                                                <X className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Secure PII Vault Section */}
                            {canEditSecureFields(userRole) && contact && (
                                <SecureFieldsSection
                                    contactId={contact.id}
                                    userRole={userRole}
                                    canView={canViewSecureFields(userRole)}
                                    canEdit={canEditSecureFields(userRole)}
                                />
                            )}

                        </div>
                    </div>
                    <DialogFooter className="mt-4">
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={loading}>
                            {loading ? "Saving..." : "Save Changes"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
