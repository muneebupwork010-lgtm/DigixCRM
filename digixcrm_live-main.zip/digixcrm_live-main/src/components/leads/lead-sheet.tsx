"use client";

import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { X, User2 } from "lucide-react";
import { Lead } from "@/generated/prisma/client/client";
import { LeadDetailsView } from "./lead-details-view";

export function LeadSheet({
    lead,
    isOpen,
    onClose
}: {
    lead: (Lead & { 
        organization?: any;
        owner?: { name: string | null; email: string | null; } | null;
        createdBy?: { name: string | null; email: string | null; } | null;
    }) | null;
    isOpen: boolean;
    onClose: () => void;
}) {
    if (!lead) return null;

    return (
        <Sheet open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <SheetContent 
                side="right" 
                className="w-full sm:max-w-4xl p-0 flex flex-col border-l border-border bg-background"
                showCloseButton={false} 
            >
                {/* Unified Header Strip */}
                <div className="h-14 border-b border-border/40 bg-muted/5 flex items-center justify-between px-6 shrink-0 z-50">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20">
                            <User2 className="w-4 h-4 text-primary" />
                        </div>
                        <h3 className="text-xs font-black uppercase tracking-widest text-foreground/70">Lead Database Profile</h3>
                    </div>
                    <button 
                        onClick={onClose}
                        className="w-9 h-9 rounded-xl bg-background border border-border/50 shadow-[0_4px_12px_-2px_rgba(15,23,42,0.12)] flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-primary/5 hover:border-primary/30 hover:shadow-[0_8px_20px_-4px_rgba(15,23,42,0.2)] transition-all active:scale-95 group"
                        title="Close (Esc)"
                    >
                        <X className="w-4 h-4 group-hover:rotate-90 transition-transform duration-300" />
                    </button>
                </div>

                <SheetHeader className="sr-only">
                    <SheetTitle>Lead Database Profile</SheetTitle>
                    <SheetDescription>Overview of the lead activity feed, notes, and metrics.</SheetDescription>
                </SheetHeader>

                {/* Mobile Header - Sticky (Restored for mobile specific design) */}
                <div className="sticky top-0 z-[100] w-full bg-background/95 backdrop-blur-md border-b border-border sm:hidden flex items-center justify-between px-6 py-4 h-16 shrink-0">
                    <h3 className="font-black text-lg tracking-tight text-foreground">Lead Profile</h3>
                    <button 
                        onClick={onClose}
                        className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <div className="flex-1 w-full relative overflow-y-auto scrollbar-none">
                    <LeadDetailsView lead={lead} />
                </div>
            </SheetContent>
        </Sheet>
    );
}
