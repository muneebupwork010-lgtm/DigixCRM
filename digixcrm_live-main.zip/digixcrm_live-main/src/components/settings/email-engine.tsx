"use client";

import React, { useEffect, useState } from "react";
import { Mail, Plus, Trash2, Bell, ShieldCheck, Save, Loader2, X, AlertCircle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

export function EmailEngine() {
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [newEmail, setNewEmail] = useState("");
    const [settings, setSettings] = useState({
        adminNotificationEmails: [] as string[],
        notifyOnLeadForm: true,
        notifyOnOnboarding: true,
    });

    const fetchSettings = async () => {
        try {
            const res = await fetch("/api/settings/notifications");
            const data = await res.json();
            if (data.success) {
                setSettings(data.settings);
            }
        } catch (error) {
            toast.error("Failed to load email engine settings.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchSettings();
    }, []);

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const res = await fetch("/api/settings/notifications", {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(settings),
            });
            if (res.ok) {
                toast.success("Notification settings synced successfully.");
            } else {
                toast.error("Failed to update engine settings.");
            }
        } catch (error) {
            toast.error("Network error during sync.");
        } finally {
            setIsSaving(false);
        }
    };

    const addEmail = () => {
        const trimmed = newEmail.trim().toLowerCase();
        if (!trimmed) return;
        if (!/^\S+@\S+\.\S+$/.test(trimmed)) {
            toast.error("Invalid email format.");
            return;
        }
        if (settings.adminNotificationEmails.includes(trimmed)) {
            toast.error("Email already in notification list.");
            return;
        }

        setSettings({
            ...settings,
            adminNotificationEmails: [...settings.adminNotificationEmails, trimmed]
        });
        setNewEmail("");
    };

    const removeEmail = (emailToRemove: string) => {
        setSettings({
            ...settings,
            adminNotificationEmails: settings.adminNotificationEmails.filter(e => e !== emailToRemove)
        });
    };

    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center p-12 text-muted-foreground animate-pulse">
                <Loader2 className="w-8 h-8 animate-spin mb-4" />
                <p className="text-sm font-medium">Initializing Email Engine...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Card className="border-border/60 shadow-xl shadow-primary/5 bg-card/50 backdrop-blur-md overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
                    <Mail className="w-32 h-32" />
                </div>
                
                <CardHeader className="pb-4">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20">
                            <Mail className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                            <CardTitle className="text-2xl font-black tracking-tight flex items-center gap-2">
                                Administrative Notification Engine
                                <span className="text-[10px] uppercase bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold border border-primary/20">Super Admin Only</span>
                            </CardTitle>
                            <CardDescription className="text-sm font-medium italic">
                                Orchestrate global platform alerts for lead generation and new client onboarding events.
                            </CardDescription>
                        </div>
                    </div>
                </CardHeader>

                <CardContent className="space-y-8">
                    {/* EMAIL LIST MANAGEMENT */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between">
                            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground block">
                                Recipient Distribution List
                            </Label>
                            <span className="text-[10px] font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded border border-border/50">
                                {settings?.adminNotificationEmails?.length || 0} Configured
                            </span>
                        </div>
                        
                        <div className="grid gap-3">
                            <div className="flex gap-2">
                                <div className="relative flex-1">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
                                    <Input 
                                        placeholder="admin@example.com"
                                        value={newEmail}
                                        onChange={(e) => setNewEmail(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && addEmail()}
                                        className="pl-10 h-11 bg-background/50 border-border/50 focus:ring-primary/20 transition-all rounded-xl font-medium"
                                    />
                                </div>
                                <Button onClick={addEmail} className="h-11 px-5 rounded-xl font-bold gap-2 shadow-lg shadow-primary/20">
                                    <Plus className="w-4 h-4" /> Add
                                </Button>
                            </div>

                            <div className="flex flex-wrap gap-2 pt-2">
                                {(settings?.adminNotificationEmails?.length || 0) === 0 ? (
                                    <div className="w-full py-8 border-2 border-dashed border-border/50 rounded-2xl flex flex-col items-center justify-center text-muted-foreground gap-2">
                                        <AlertCircle className="w-5 h-5 opacity-20" />
                                        <p className="text-xs font-semibold uppercase tracking-wider opacity-40">No Recipients Configured</p>
                                    </div>
                                ) : settings?.adminNotificationEmails?.map((email) => (
                                    <div key={email} className="group flex items-center gap-2 px-3 py-1.5 bg-background border border-border/50 rounded-lg shadow-sm animate-in zoom-in-95 duration-200 hover:border-primary/30 transition-all">
                                        <span className="text-sm font-bold text-foreground/80">{email}</span>
                                        <button 
                                            onClick={() => removeEmail(email)}
                                            className="ml-1 p-1 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded transition-all"
                                        >
                                            <X className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    <Separator className="bg-border/50" />

                    {/* EVENT TRIGGERS */}
                    <div className="space-y-6">
                        <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground block mb-2">
                            Notification Event Triggers
                        </Label>
                        
                        <div className="grid gap-4">
                            <div className="flex items-center justify-between p-4 rounded-2xl bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors group">
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                        <Bell className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
                                        <Label className="font-bold text-base cursor-pointer">Landing Page Leads</Label>
                                    </div>
                                    <p className="text-xs text-muted-foreground font-medium leading-relaxed max-w-sm">
                                        Send email alerts when a visitor submits the "Contact Sales" or "Get Started" forms on the landing page.
                                    </p>
                                </div>
                                <Switch 
                                    checked={settings.notifyOnLeadForm}
                                    onCheckedChange={(v) => setSettings({ ...settings, notifyOnLeadForm: v })}
                                />
                            </div>

                            <div className="flex items-center justify-between p-4 rounded-2xl bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors group">
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                        <ShieldCheck className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
                                        <Label className="font-bold text-base cursor-pointer">New Account Onboarding</Label>
                                    </div>
                                    <p className="text-xs text-muted-foreground font-medium leading-relaxed max-w-sm">
                                        Alert the team when a new client successfully completes their tenant registration and workspace setup.
                                    </p>
                                </div>
                                <Switch 
                                    checked={settings.notifyOnOnboarding}
                                    onCheckedChange={(v) => setSettings({ ...settings, notifyOnOnboarding: v })}
                                />
                            </div>
                        </div>
                    </div>
                </CardContent>

                <CardFooter className="bg-muted/30 border-t border-border/50 px-8 py-6 flex justify-between items-center">
                    <p className="text-[10px] text-muted-foreground font-medium max-w-[280px]">
                        Changes take effect immediately upon sync. Note that individual SMTP limits may apply.
                    </p>
                    <Button 
                        disabled={isSaving}
                        onClick={handleSave}
                        className="rounded-xl font-black px-10 py-6 gap-2 shadow-xl shadow-primary/20 active:scale-95 transition-all text-base"
                    >
                        {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                        Sync Engine Configuration
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
