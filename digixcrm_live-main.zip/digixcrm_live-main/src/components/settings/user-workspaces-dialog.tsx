"use client";

import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import { assignUserToWorkspace } from "@/lib/actions/workspaces";
import { Loader2, Building2, ShieldEllipsis, Info } from "lucide-react";
import { useRouter } from "next/navigation";
import { Label } from "@/components/ui/label";
import { useSession } from "next-auth/react";
import { useConfirm } from "@/components/providers/confirm-dialog-provider";
import { toast } from "sonner";

const ROLE_DESCRIPTIONS: Record<string, string> = {
    STAFF: "Task execution only. No CRM/Sales or Financial access.",
    REP: "Sales focus. Sees own Revenue & Leads. No Project access.",
    PROJECT_MANAGER: "Production oversight. Full Projects/Tasks. No Sales access.",
    CLIENT: "External client. PMS only. Can create/manage own tasks & comment.",
    MANAGER: "Business operations. Full access to all data & reports.",
    ADMIN: "System Administrator. Complete control over all settings."
};

export function UserWorkspacesDialog({
    user,
    workspaces,
    customRoles,
    open,
    onOpenChange
}: {
    user: any;
    workspaces: any[];
    customRoles?: any[];
    open: boolean;
    onOpenChange: (open: boolean) => void;
}) {
    const router = useRouter();
    const [loadingId, setLoadingId] = useState<string | null>(null);
    const { data: session } = useSession();
    const { confirm } = useConfirm();

    if (!user) return null;

    const allMemberships = user.workspaceMemberships || [];
    const memberships = allMemberships.filter((m: any) => 
        workspaces.some(ws => ws.id === m.workspaceId)
    );

    const handleRoleChange = async (workspaceId: string, selectedValue: string) => {
        let role: "ADMIN" | "MANAGER" | "PROJECT_MANAGER" | "STAFF" | "REP" | "CLIENT" = selectedValue as any;
        let customRoleId = "none";

        if (selectedValue.startsWith("custom_")) {
            role = "REP"; // Base permission layer for all PBAC roles
            customRoleId = selectedValue.replace("custom_", "");
        }

        const currentMembership = memberships.find((m: any) => m.workspaceId === workspaceId);
        
        if (currentMembership?.role === "ADMIN" && role !== "ADMIN") {
            if (user.isAccountOwner) {
                toast.error("Account Owners cannot be demoted from the Administrator role.");
                return;
            }

            const isSelf = session?.user?.email === user.email;
            if (isSelf) {
                const confirmed = await confirm({
                    title: "Remove Admin Rights?",
                    description: "You are about to remove your own Administrator privileges. You will lose access to team management and billing. This action cannot be undone by you.",
                    variant: "destructive",
                    confirmText: "Yes, Demote Me"
                });
                if (!confirmed) return;
            }
        }

        setLoadingId(workspaceId);
        const result = await assignUserToWorkspace(workspaceId, user.email, role, customRoleId);
        if (result.success) {
            router.refresh();
        } else {
            toast.error(result.error || "Failed to update role");
        }
        setLoadingId(null);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px]">
                <TooltipProvider delayDuration={0}>
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <ShieldEllipsis className="w-5 h-5" />
                            Manage Roles for {user.name || "User"}
                        </DialogTitle>
                        <DialogDescription>
                            {user.email}
                        </DialogDescription>
                    </DialogHeader>

                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2 mb-3">
                            <Building2 className="w-3.5 h-3.5" /> Workspace Roles
                        </Label>
                        
                        {memberships.length === 0 && (
                            <div className="text-sm text-muted-foreground italic py-2">No workspace memberships.</div>
                        )}

                        {memberships.map((m: any) => {
                            const ws = workspaces.find(w => w.id === m.workspaceId);
                            return (
                                <div key={m.workspaceId} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border">
                                    <div className="flex flex-col gap-1">
                                        <span className="text-sm font-semibold">{ws?.name || "Unknown Workspace"}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Select
                                            value={m.customRoleId ? `custom_${m.customRoleId}` : m.role}
                                            disabled={loadingId === m.workspaceId}
                                            onValueChange={(val: any) => handleRoleChange(m.workspaceId, val)}
                                        >
                                            <SelectTrigger className="w-[180px] h-9 text-[11px] font-bold uppercase tracking-wider bg-background shadow-none">
                                                {loadingId === m.workspaceId ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : null}
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="w-[240px]">
                                                <SelectItem value="STAFF" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase">Staff</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.STAFF}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>
                                                    
                                                    <SelectItem value="REP" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase text-blue-600">Representative</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.REP}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>

                                                    <SelectItem value="PROJECT_MANAGER" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase text-emerald-600">Project Manager</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.PROJECT_MANAGER}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>

                                                    <SelectItem value="CLIENT" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase text-orange-600">Client</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.CLIENT}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>

                                                    <SelectItem value="MANAGER" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase text-indigo-600">Manager</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.MANAGER}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>

                                                    <SelectItem value="ADMIN" className="py-2">
                                                        <div className="flex items-center justify-between w-full pr-4">
                                                            <span className="text-[11px] font-bold uppercase text-red-600">Administrator</span>
                                                            <Tooltip>
                                                                <TooltipTrigger asChild>
                                                                    <div className="hover:bg-muted p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                        <Info className="w-3.5 h-3.5 text-muted-foreground/60" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[200px] text-[10px] p-2">
                                                                    {ROLE_DESCRIPTIONS.ADMIN}
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>
                                                
                                                {customRoles && customRoles.length > 0 && (
                                                    <>
                                                        <div className="px-2 py-1.5">
                                                            <div className="text-[10px] font-black uppercase tracking-widest text-muted-foreground/50 flex items-center gap-2">
                                                                <div className="h-px flex-1 bg-border/50" />
                                                                Workspace Custom Roles
                                                                <div className="h-px flex-1 bg-border/50" />
                                                            </div>
                                                        </div>
                                                        {customRoles.map(cr => (
                                                            <SelectItem key={cr.id} value={`custom_${cr.id}`} className="py-2 focus:bg-amber-50">
                                                                <div className="flex items-center justify-between w-full pr-4">
                                                                    <span className="text-[11px] font-bold uppercase text-amber-600 flex items-center gap-1.5">
                                                                        <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                                                                        {cr.name}
                                                                    </span>
                                                                    <Tooltip>
                                                                        <TooltipTrigger asChild>
                                                                            <div className="hover:bg-amber-100 p-1 rounded-full transition-colors" onClick={(e) => e.stopPropagation()}>
                                                                                <Info className="w-3.5 h-3.5 text-amber-600/60" />
                                                                            </div>
                                                                        </TooltipTrigger>
                                                                <TooltipContent side="right" className="max-w-[240px] p-3">
                                                                    <div className="space-y-1.5">
                                                                        <p className="text-[10px] font-bold uppercase tracking-wider text-amber-600 mb-1">Custom Permissions</p>
                                                                        <div className="flex flex-wrap gap-1">
                                                                            {cr.permissions && cr.permissions.length > 0 ? cr.permissions.map((p: string) => (
                                                                                <span key={p} className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-700 border border-amber-500/20 text-[9px] font-medium uppercase tracking-tight">
                                                                                    {p.replace(/_/g, ' ')}
                                                                                </span>
                                                                            )) : <span className="text-[10px] text-muted-foreground italic">No specific permissions defined</span>}
                                                                        </div>
                                                                    </div>
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </>
                                        )}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
                </TooltipProvider>
            </DialogContent>
        </Dialog>
    );
}
