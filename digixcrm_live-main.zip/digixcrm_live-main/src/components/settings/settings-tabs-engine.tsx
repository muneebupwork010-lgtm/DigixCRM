"use client";

import { useTransition, useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Tabs } from "@/components/ui/tabs";

/**
 * A reactive wrapper for the Settings Tabs.
 * Drives the Radix Tabs state exclusively via the URL to prevent rendering all tabs locally.
 */
export function SettingsTabsEngine({ children }: { children: React.ReactNode }) {
    const searchParams = useSearchParams();
    const router = useRouter();
    const [isPending, startTransition] = useTransition();
    
    const serverTab = searchParams.get("tab") || "profile";
    const [optimisticTab, setOptimisticTab] = useState<string | null>(null);
    
    // The visual active tab is either the one they just clicked, or the one the server confirmed.
    const activeTab = optimisticTab || serverTab;

    const handleTabChange = (value: string) => {
        setOptimisticTab(value);
        startTransition(() => {
            router.push(`/dashboard/settings?tab=${value}`, { scroll: false });
        });
    };
    
    // Reset optimistic state when the server catches up
    useEffect(() => {
        setOptimisticTab(null);
    }, [serverTab]);

    return (
        <div className={`transition-all duration-300 ${isPending ? "opacity-60 saturate-50" : "opacity-100 saturate-100"}`}>
            <Tabs 
                value={activeTab} 
                onValueChange={handleTabChange} 
                className="w-full"
            >
                {children}
            </Tabs>
        </div>
    );
}
