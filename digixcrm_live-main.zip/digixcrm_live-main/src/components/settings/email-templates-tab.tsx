"use client";

import { useState, useEffect } from "react";
import { 
    Mail, Plus, Trash2, Edit2, Copy, Eye, Loader2, Sparkles, AlertCircle, Save 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
    getEmailTemplates,
    createEmailTemplate,
    updateEmailTemplate,
    deleteEmailTemplate,
    duplicateEmailTemplate,
    seedDefaultTemplates
} from "@/lib/actions/email-templates";
import { TEMPLATE_VARIABLES, renderTemplate, SAMPLE_CONTEXT } from "@/lib/template-engine";

export function EmailTemplatesTab() {
    const [templates, setTemplates] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [isSeeding, setIsSeeding] = useState(false);
    
    // Editor State
    const [isEditorOpen, setIsEditorOpen] = useState(false);
    const [currentTemplate, setCurrentTemplate] = useState<any>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [previewMode, setPreviewMode] = useState(false);
    
    // Delete State
    const [templateToDelete, setTemplateToDelete] = useState<string | null>(null);

    // Form State
    const [formData, setFormData] = useState({
        name: "",
        subject: "",
        body: "",
        category: "GENERAL",
        isActive: true
    });

    const fetchTemplates = async () => {
        setLoading(true);
        const res = await getEmailTemplates();
        if (res.success) {
            setTemplates(res.data);
        } else {
            toast.error(res.error);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchTemplates();
    }, []);

    const handleSeedDefaults = async () => {
        setIsSeeding(true);
        const res = await seedDefaultTemplates();
        if (res.success) {
            toast.success(`Seeded ${res.count} default templates.`);
            fetchTemplates();
        } else {
            toast.error(res.error);
        }
        setIsSeeding(false);
    };

    const handleOpenEditor = (template: any = null) => {
        if (template) {
            setCurrentTemplate(template);
            setFormData({
                name: template.name,
                subject: template.subject,
                body: template.body,
                category: template.category,
                isActive: template.isActive
            });
        } else {
            setCurrentTemplate(null);
            setFormData({
                name: "",
                subject: "",
                body: "",
                category: "GENERAL",
                isActive: true
            });
        }
        setPreviewMode(false);
        setIsEditorOpen(true);
    };

    const handleSave = async () => {
        if (!formData.name.trim() || !formData.subject.trim() || !formData.body.trim()) {
            toast.error("Name, Subject, and Body are required.");
            return;
        }

        setIsSaving(true);
        let res;
        
        if (currentTemplate) {
            res = await updateEmailTemplate(currentTemplate.id, formData);
        } else {
            res = await createEmailTemplate(formData);
        }

        if (res.success) {
            toast.success(currentTemplate ? "Template updated" : "Template created");
            setIsEditorOpen(false);
            fetchTemplates();
        } else {
            toast.error(res.error);
        }
        setIsSaving(false);
    };

    const handleDelete = async () => {
        if (!templateToDelete) return;
        
        const res = await deleteEmailTemplate(templateToDelete);
        if (res.success) {
            toast.success("Template deleted");
            setTemplateToDelete(null);
            fetchTemplates();
        } else {
            toast.error(res.error);
        }
    };

    const handleDuplicate = async (id: string) => {
        const res = await duplicateEmailTemplate(id);
        if (res.success) {
            toast.success("Template duplicated");
            fetchTemplates();
        } else {
            toast.error(res.error);
        }
    };

    const insertVariable = (variable: string) => {
        // Simple insertion at end for now (in real app, insert at cursor position)
        setFormData(prev => ({
            ...prev,
            body: prev.body + ` {{${variable}}}`
        }));
        toast.info(`Inserted {{${variable}}}`);
    };

    // Group variables for UI
    const groupedVariables = TEMPLATE_VARIABLES.reduce((acc, v) => {
        if (!acc[v.group]) acc[v.group] = [];
        acc[v.group].push(v);
        return acc;
    }, {} as Record<string, typeof TEMPLATE_VARIABLES[number][]>);

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                <div>
                    <h3 className="text-xl font-bold text-foreground">Email Templates Engine</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                        Design dynamic message templates for automated workflows and quick sending.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    {templates.length === 0 && !loading && (
                        <Button variant="outline" onClick={handleSeedDefaults} disabled={isSeeding} className="bg-primary/5 text-primary border-primary/20">
                            {isSeeding ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                            Load Library
                        </Button>
                    )}
                    <Button onClick={() => handleOpenEditor()} className="shadow-sm">
                        <Plus className="w-4 h-4 mr-2" /> New Template
                    </Button>
                </div>
            </div>

            {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[1, 2, 3].map(i => (
                        <div key={i} className="h-48 rounded-xl bg-muted/40 animate-pulse border border-border/50" />
                    ))}
                </div>
            ) : templates.length === 0 ? (
                <div className="py-20 text-center bg-muted/20 border border-dashed rounded-xl border-border/60">
                    <Mail className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                    <h3 className="text-lg font-bold text-foreground">No Templates Found</h3>
                    <p className="text-sm text-muted-foreground max-w-md mx-auto mt-2 mb-6">
                        Create your first email template to standardize communication across your team, or load our pre-built library.
                    </p>
                    <Button onClick={handleSeedDefaults} disabled={isSeeding}>
                        {isSeeding ? "Loading..." : "Load Pre-built Library"}
                    </Button>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {templates.map(template => (
                        <Card key={template.id} className={`relative overflow-hidden group transition-all hover:shadow-md ${!template.isActive ? 'opacity-70' : ''}`}>
                            {template.isDefault && (
                                <div className="absolute top-0 right-0">
                                    <div className="bg-primary text-primary-foreground text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-bl-lg shadow-sm">
                                        Default
                                    </div>
                                </div>
                            )}
                            <CardHeader className="pb-3">
                                <div className="flex justify-between items-start mb-1">
                                    <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-tight bg-muted">
                                        {template.category.replace("_", " ")}
                                    </Badge>
                                    <Switch 
                                        checked={template.isActive} 
                                        onCheckedChange={async (checked) => {
                                            await updateEmailTemplate(template.id, { isActive: checked });
                                            fetchTemplates();
                                        }}
                                        aria-label="Toggle active status"
                                    />
                                </div>
                                <CardTitle className="text-base line-clamp-1" title={template.name}>
                                    {template.name}
                                </CardTitle>
                                <CardDescription className="text-xs line-clamp-1 font-medium italic">
                                    Subj: {template.subject}
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="pb-4">
                                <div className="text-xs text-muted-foreground bg-muted/40 p-3 rounded-lg border border-border/50 line-clamp-3 h-16 leading-relaxed relative">
                                    <div className="absolute inset-0 bg-gradient-to-t from-muted/40 to-transparent bottom-0 h-8 mt-auto" />
                                    {template.body}
                                </div>
                            </CardContent>
                            <CardFooter className="pt-0 flex justify-between gap-2 border-t border-border/50 px-6 py-3 bg-muted/10">
                                <Button variant="ghost" size="sm" className="h-8 px-2 text-xs font-semibold hover:bg-primary/10 hover:text-primary" onClick={() => handleOpenEditor(template)}>
                                    <Edit2 className="w-3.5 h-3.5 mr-1.5" /> Edit
                                </Button>
                                <div className="flex gap-1">
                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => handleDuplicate(template.id)} title="Duplicate">
                                        <Copy className="w-4 h-4" />
                                    </Button>
                                    {!template.isDefault && (
                                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-50" onClick={() => setTemplateToDelete(template.id)} title="Delete">
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    )}
                                </div>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}

            {/* Template Editor Modal */}
            <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
                <DialogContent className="sm:max-w-[900px] p-0 overflow-hidden flex flex-col h-[85vh] sm:h-[80vh] bg-background">
                    <div className="flex justify-between items-center p-4 border-b border-border bg-card">
                        <div className="flex items-center gap-3">
                            <div className="bg-primary/10 p-2 rounded-lg">
                                <Mail className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                                <DialogTitle className="text-lg">{currentTemplate ? "Edit Template" : "Create Template"}</DialogTitle>
                                <DialogDescription className="text-xs">Design your email using smart variables.</DialogDescription>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="flex items-center space-x-2 mr-4 bg-muted/50 p-1 rounded-lg">
                                <Button 
                                    type="button"
                                    variant={!previewMode ? "secondary" : "ghost"} 
                                    size="sm" 
                                    className="h-7 text-xs px-3"
                                    onClick={() => setPreviewMode(false)}
                                >
                                    <Edit2 className="w-3 h-3 mr-1" /> Editor
                                </Button>
                                <Button 
                                    type="button"
                                    variant={previewMode ? "secondary" : "ghost"} 
                                    size="sm" 
                                    className="h-7 text-xs px-3"
                                    onClick={() => setPreviewMode(true)}
                                >
                                    <Eye className="w-3 h-3 mr-1" /> Preview
                                </Button>
                            </div>
                            <Button variant="outline" size="sm" onClick={() => setIsEditorOpen(false)}>Cancel</Button>
                            <Button size="sm" onClick={handleSave} disabled={isSaving}>
                                {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                                Save
                            </Button>
                        </div>
                    </div>

                    <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
                        {/* Left Side - Editor / Preview */}
                        <div className="flex-1 flex flex-col overflow-y-auto p-6 scrollbar-thin">
                            {!previewMode ? (
                                <div className="space-y-5">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <Label className="text-xs font-bold text-muted-foreground uppercase">Template Name</Label>
                                            <Input 
                                                placeholder="e.g. Welcome Email" 
                                                value={formData.name}
                                                onChange={(e) => setFormData({...formData, name: e.target.value})}
                                                disabled={currentTemplate?.isDefault}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <Label className="text-xs font-bold text-muted-foreground uppercase">Category</Label>
                                            <Select 
                                                value={formData.category} 
                                                onValueChange={(v) => setFormData({...formData, category: v})}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Select category" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="GENERAL">General</SelectItem>
                                                    <SelectItem value="FOLLOW_UP">Follow Up</SelectItem>
                                                    <SelectItem value="ONBOARDING">Onboarding</SelectItem>
                                                    <SelectItem value="PROMOTION">Promotion</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    
                                    <div className="space-y-1.5">
                                        <Label className="text-xs font-bold text-muted-foreground uppercase">Subject Line</Label>
                                        <Input 
                                            placeholder="Subject..." 
                                            value={formData.subject}
                                            onChange={(e) => setFormData({...formData, subject: e.target.value})}
                                            className="font-medium"
                                        />
                                    </div>

                                    <div className="space-y-1.5 flex-1 flex flex-col min-h-[300px]">
                                        <Label className="text-xs font-bold text-muted-foreground uppercase">Email Body</Label>
                                        <Textarea 
                                            placeholder="Write your email here..." 
                                            value={formData.body}
                                            onChange={(e) => setFormData({...formData, body: e.target.value})}
                                            className="flex-1 min-h-[300px] resize-none font-mono text-sm leading-relaxed"
                                        />
                                    </div>
                                </div>
                            ) : (
                                <div className="space-y-6 h-full flex flex-col">
                                    <div className="bg-amber-50 border border-amber-200 text-amber-800 text-xs px-4 py-2.5 rounded-lg flex items-center gap-2 font-medium">
                                        <AlertCircle className="w-4 h-4" />
                                        Previewing with sample data. Actual values will depend on the lead.
                                    </div>
                                    
                                    <div className="bg-white border shadow-sm rounded-xl overflow-hidden flex-1 flex flex-col">
                                        <div className="bg-zinc-50 border-b p-4 space-y-2">
                                            <div className="flex gap-4 text-sm">
                                                <span className="text-zinc-500 w-16 text-right">To:</span>
                                                <span className="font-medium text-zinc-900">{SAMPLE_CONTEXT.email}</span>
                                            </div>
                                            <div className="flex gap-4 text-sm">
                                                <span className="text-zinc-500 w-16 text-right">Subject:</span>
                                                <span className="font-bold text-zinc-900">{renderTemplate(formData.subject, SAMPLE_CONTEXT)}</span>
                                            </div>
                                        </div>
                                        <div className="p-6 text-sm text-zinc-800 leading-relaxed whitespace-pre-wrap flex-1 overflow-y-auto">
                                            {renderTemplate(formData.body, SAMPLE_CONTEXT)}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Right Side - Variable Injector */}
                        {!previewMode && (
                            <div className="w-full md:w-64 bg-muted/20 border-l border-border p-4 flex flex-col overflow-y-auto scrollbar-thin">
                                <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">Available Variables</h4>
                                <div className="space-y-6">
                                    {Object.entries(groupedVariables).map(([group, vars]) => (
                                        <div key={group}>
                                            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-2 px-1">{group}</div>
                                            <div className="space-y-1.5">
                                                {vars.map(v => (
                                                    <Button 
                                                        key={v.key}
                                                        variant="outline" 
                                                        size="sm" 
                                                        className="w-full justify-start h-8 text-xs font-mono bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/30"
                                                        onClick={() => insertVariable(v.key)}
                                                        title={`Example: ${v.example}`}
                                                    >
                                                        <Plus className="w-3 h-3 mr-2 opacity-50" />
                                                        {'{'}{'{'}{v.key}{'}'}{'}'}
                                                    </Button>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </DialogContent>
            </Dialog>

            {/* Delete Confirmation */}
            <AlertDialog open={!!templateToDelete} onOpenChange={(open) => !open && setTemplateToDelete(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Delete Template?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will permanently remove the template. Automated workflows using this template may fail to send messages.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700 text-white">
                            Delete Permanently
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
