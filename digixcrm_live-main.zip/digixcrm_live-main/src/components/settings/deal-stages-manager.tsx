"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { updateWorkspaceDealStages, renameDealStage, deleteDealStage } from "@/lib/actions/deals";
import { Plus, Trash2, Edit2, Check, X, ShieldCheck, Lock } from "lucide-react";
import { toast } from "sonner";
import { useConfirm } from "@/components/providers/confirm-dialog-provider";
import { useRouter } from "next/navigation";

export interface DealStageConfig {
    id: string;
    value: string;
    label: string;
    color: string;
}

// These three system stages are protected — administrators may rename them
// but CANNOT delete them because they anchor core revenue calculations.
const PROTECTED_STAGE_VALUES = ["QUALIFICATION", "WON", "LOST"] as const;
type ProtectedStageValue = typeof PROTECTED_STAGE_VALUES[number];

const PROTECTED_STAGE_MESSAGES: Record<ProtectedStageValue, string> = {
    QUALIFICATION: "System Stage — This is the entry stage for all converted leads and cannot be removed.",
    WON:  "Revenue Stage — Deals marked as 'Won' feed into revenue reporting and forecasting. This stage is protected and cannot be deleted.",
    LOST: "Outcome Stage — Deals marked as 'Lost' are tracked for analytics and pipeline health. This stage is protected and cannot be deleted.",
};

// UNIFIED DEFAULTS: Prospect -> Contacted -> Negotiation -> Won -> Lost
const DEFAULT_STAGES: DealStageConfig[] = [
    { id: "s1", value: "QUALIFICATION", label: "Prospect",          color: "slate"  },
    { id: "s2", value: "PROPOSAL",      label: "Contacted",         color: "blue"   },
    { id: "s3", value: "NEGOTIATION",   label: "Negotiation",       color: "amber"  },
    { id: "s4", value: "WON",           label: "Won",               color: "indigo" },
    { id: "s5", value: "LOST",          label: "Lost",              color: "red"    },
];

interface DealStagesManagerProps {
    workspaceId: string;
    initialStages: DealStageConfig[] | null;
}

function isProtected(stage: DealStageConfig): boolean {
    return (PROTECTED_STAGE_VALUES as readonly string[]).includes(stage.value);
}

function getProtectedMessage(stage: DealStageConfig): string | null {
    if (!isProtected(stage)) return null;
    return PROTECTED_STAGE_MESSAGES[stage.value as ProtectedStageValue] ?? null;
}

export function DealStagesManager({ workspaceId, initialStages }: DealStagesManagerProps) {
    const [stages, setStages] = useState<DealStageConfig[]>(
        initialStages || DEFAULT_STAGES
    );

    // Sync state when initialStages prop changes (fixes fallback issues on reloads)
    useEffect(() => {
        if (initialStages) {
            setStages(initialStages);
        }
    }, [initialStages]);

    const [editingId, setEditingId] = useState<string | null>(null);
    const [editValue, setEditValue] = useState("");
    const [loading, setLoading] = useState(false);
    const { confirm } = useConfirm();
    const router = useRouter();

    const handleSaveList = async (newList: DealStageConfig[]) => {
        setLoading(true);
        const result = await updateWorkspaceDealStages(workspaceId, newList);
        if (result.success) {
            setStages(newList);
            toast.success("Pipeline stages updated successfully.");
            router.refresh();
        } else {
            toast.error(result.error || "Failed to save stages");
        }
        setLoading(false);
    };

    const handleRename = async (id: string, newLabel: string) => {
        if (!newLabel.trim()) return;

        const stage = stages.find(s => s.id === id);
        if (!stage) return;

        const oldLabel = stage.label;
        if (oldLabel === newLabel) {
            setEditingId(null);
            return;
        }

        setLoading(true);

        // For default/system stages (s1..s5), only the UI label changes.
        // The DB enum value (WON, LOST, etc.) stays intact so features remain unaffected.
        const isDefault = id.startsWith("s");

        if (!isDefault) {
            const renameResult = await renameDealStage(workspaceId, stage.value, newLabel);
            if (!renameResult.success) {
                toast.error(renameResult.error);
                setLoading(false);
                setEditingId(null);
                return;
            }
        }

        const newList = stages.map(s =>
            s.id === id ? { ...s, label: newLabel, value: isDefault ? s.value : newLabel } : s
        );
        await handleSaveList(newList);

        setEditingId(null);
        setLoading(false);
    };

    const handleDelete = async (stage: DealStageConfig) => {
        // Hard-block protected stages — show informative toast instead
        if (isProtected(stage)) {
            toast.warning(getProtectedMessage(stage) ?? "This stage is protected and cannot be deleted.", {
                duration: 5000,
            });
            return;
        }

        if (stages.length <= 1) {
            toast.error("You must have at least one stage in the pipeline.");
            return;
        }

        const isConfirmed = await confirm({
            title: "Delete Pipeline Stage",
            description: `Are you sure you want to delete "${stage.label}"? All deals currently in this stage will be moved to the first available stage.`,
            confirmText: "Delete Stage",
            variant: "destructive",
        });

        if (!isConfirmed) return;

        setLoading(true);
        const fallback = stages.find(s => s.id !== stage.id);
        if (!fallback) return;

        const delResult = await deleteDealStage(workspaceId, stage.value, fallback.value);
        if (delResult.success) {
            const newList = stages.filter(s => s.id !== stage.id);
            await handleSaveList(newList);
        } else {
            toast.error(delResult.error);
        }
        setLoading(false);
    };

    const handleAdd = () => {
        const newStage: DealStageConfig = {
            id: `custom_${Date.now()}`,
            value: "New Stage",
            label: "New Stage",
            color: "slate",
        };
        handleSaveList([...stages, newStage]);
    };

    const moveStage = (index: number, direction: "up" | "down") => {
        if (direction === "up" && index === 0) return;
        if (direction === "down" && index === stages.length - 1) return;

        const newList = [...stages];
        const targetIndex = direction === "up" ? index - 1 : index + 1;
        const temp = newList[index];
        newList[index] = newList[targetIndex];
        newList[targetIndex] = temp;

        handleSaveList(newList);
    };

    const cycleColor = (id: string) => {
        const colors = ["slate", "blue", "amber", "indigo", "red", "purple", "pink"];
        const stageIndex = stages.findIndex(s => s.id === id);
        if (stageIndex === -1) return;

        const currentIdx = colors.indexOf(stages[stageIndex].color);
        const nextColor = colors[(currentIdx + 1) % colors.length];

        const newList = [...stages];
        newList[stageIndex].color = nextColor;
        handleSaveList(newList);
    };

    const getColorClass = (color: string) => {
        switch (color) {
            case "blue":   return "bg-blue-500/10 text-blue-600 border-blue-500/20";
            case "amber":  return "bg-amber-500/10 text-amber-600 border-amber-500/20";
            case "indigo": return "bg-indigo-500/10 text-indigo-600 border-indigo-500/20";
            case "red":    return "bg-red-500/10 text-red-600 border-red-500/20";
            case "purple": return "bg-purple-500/10 text-purple-600 border-purple-500/20";
            case "pink":   return "bg-pink-500/10 text-pink-600 border-pink-500/20";
            default:       return "bg-slate-500/10 text-slate-600 border-slate-500/20";
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="text-lg font-medium">Pipeline Stages</h3>
                    <p className="text-sm text-muted-foreground">
                        Manage the Kanban columns and deal lifecycle for this workspace.
                    </p>
                </div>
                <Button onClick={handleAdd} disabled={loading} size="sm" variant="outline" className="gap-2">
                    <Plus className="w-4 h-4" /> Add Stage
                </Button>
            </div>

            {/* Protected-stage legend */}
            <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-800/40 dark:bg-amber-900/10 px-4 py-3">
                <ShieldCheck className="w-4 h-4 mt-0.5 text-amber-600 dark:text-amber-400 shrink-0" />
                <p className="text-xs text-amber-700 dark:text-amber-400 leading-relaxed">
                    Stages marked with <Lock className="inline w-3 h-3 mx-0.5 align-text-bottom" /> are <strong>system-protected</strong> — they are required for revenue calculations, forecasting, and reporting. You can <strong>rename</strong> them freely, but they <strong>cannot be deleted</strong>.
                </p>
            </div>

            <div className="space-y-2 border rounded-xl bg-muted/10 p-4">
                {stages.map((stage, index) => {
                    const protected_ = isProtected(stage);
                    const protectedMsg = getProtectedMessage(stage);

                    return (
                        <div
                            key={stage.id}
                            className={`flex items-center gap-3 bg-background border p-3 rounded-lg shadow-sm ${protected_ ? "border-dashed" : ""}`}
                        >
                            {/* Ordering controls */}
                            <div className="flex flex-col gap-0.5">
                                <button
                                    onClick={() => moveStage(index, "up")}
                                    disabled={index === 0 || loading}
                                    className="p-0.5 text-muted-foreground hover:bg-muted rounded disabled:opacity-30 disabled:hover:bg-transparent"
                                >
                                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.18179 8.81819C4.00605 8.99392 3.72113 8.99392 3.54539 8.81819C3.36965 8.64245 3.36965 8.35753 3.54539 8.18179L7.18179 4.54539C7.26618 4.461 7.38064 4.41355 7.50009 4.41355C7.61954 4.41355 7.734 4.461 7.81839 4.54539L11.4548 8.18179C11.6305 8.35753 11.6305 8.64245 11.4548 8.81819C11.279 8.99392 10.9941 8.99392 10.8184 8.81819L7.50009 5.49988L4.18179 8.81819Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path></svg>
                                </button>
                                <button
                                    onClick={() => moveStage(index, "down")}
                                    disabled={index === stages.length - 1 || loading}
                                    className="p-0.5 text-muted-foreground hover:bg-muted rounded disabled:opacity-30 disabled:hover:bg-transparent"
                                >
                                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.18179 6.18181C4.00605 6.00608 3.72113 6.00608 3.54539 6.18181C3.36965 6.35755 3.36965 6.64247 3.54539 6.81821L7.18179 10.4546C7.26618 10.539 7.38064 10.5865 7.50009 10.5865C7.61954 10.5865 7.734 10.539 7.81839 10.4546L11.4548 6.81821C11.6305 6.64247 11.6305 6.35755 11.4548 6.18181C11.279 6.00608 10.9941 6.00608 10.8184 6.18181L7.50009 9.50012L4.18179 6.18181Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path></svg>
                                </button>
                            </div>

                            {/* Stage label / editing */}
                            <div className="flex-1">
                                {editingId === stage.id ? (
                                    <div className="flex items-center gap-2">
                                        <Input
                                            value={editValue}
                                            onChange={(e) => setEditValue(e.target.value)}
                                            className="h-8 text-sm max-w-[200px]"
                                            autoFocus
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter") handleRename(stage.id, editValue);
                                                if (e.key === "Escape") setEditingId(null);
                                            }}
                                        />
                                        <Button size="icon" variant="ghost" className="h-8 w-8 text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50" onClick={() => handleRename(stage.id, editValue)} disabled={loading}>
                                            <Check className="w-4 h-4" />
                                        </Button>
                                        <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground" onClick={() => setEditingId(null)} disabled={loading}>
                                            <X className="w-4 h-4" />
                                        </Button>
                                    </div>
                                ) : (
                                    <div className="flex items-center gap-2">
                                        <button
                                            title="Click to cycle color"
                                            onClick={() => cycleColor(stage.id)}
                                            className={`px-3 py-1 rounded border text-xs font-bold transition-all hover:brightness-95 ${getColorClass(stage.color)}`}
                                        >
                                            {stage.label}
                                        </button>
                                        {/* Protected badge */}
                                        {protected_ && (
                                            <span
                                                title={protectedMsg ?? ""}
                                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-100 text-amber-700 border border-amber-300 dark:bg-amber-900/30 dark:text-amber-400 dark:border-amber-700 cursor-help"
                                            >
                                                <Lock className="w-2.5 h-2.5" />
                                                Protected
                                            </span>
                                        )}
                                    </div>
                                )}
                            </div>

                            {/* Action buttons */}
                            {editingId !== stage.id && (
                                <div className="flex items-center gap-1" style={{ opacity: 1 }}>
                                    {/* Edit — always enabled */}
                                    <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-8 w-8 text-muted-foreground hover:text-primary"
                                        title="Rename stage"
                                        onClick={() => {
                                            setEditValue(stage.label);
                                            setEditingId(stage.id);
                                        }}
                                        disabled={loading}
                                    >
                                        <Edit2 className="w-4 h-4" />
                                    </Button>

                                    {/* Delete — disabled + tooltip for protected stages */}
                                    <div
                                        title={
                                            protected_
                                                ? (protectedMsg ?? "This stage is protected and cannot be deleted.")
                                                : stages.length <= 1
                                                ? "You must have at least one stage."
                                                : "Delete stage"
                                        }
                                        className="inline-flex"
                                    >
                                        <Button
                                            size="icon"
                                            variant="ghost"
                                            className={`h-8 w-8 ${protected_ ? "text-muted-foreground/30 cursor-not-allowed" : "text-muted-foreground hover:text-red-500"}`}
                                            onClick={() => handleDelete(stage)}
                                            disabled={loading || protected_ || stages.length <= 1}
                                        >
                                            {protected_ ? (
                                                <Lock className="w-4 h-4" />
                                            ) : (
                                                <Trash2 className="w-4 h-4" />
                                            )}
                                        </Button>
                                    </div>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            <p className="text-xs text-muted-foreground">
                Click on a stage badge to cycle its color. Renaming a stage automatically updates all deals inside it.
                Protected stages are required for revenue reporting and cannot be removed.
            </p>
        </div>
    );
}
