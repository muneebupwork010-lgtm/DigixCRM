"use client";

import { useState } from "react";
import { Plus, Loader2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { createProject } from "@/lib/actions/projects";
import { ProjectStatus, Priority, ProjectType } from "@/generated/prisma/client";

export function CreateProjectDialog({ 
    organizations,
    users 
}: { 
    organizations: { id: string; name: string }[],
    users?: { id: string; name: string | null }[] 
}) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        name: "",
        description: "",
        status: "PLANNING" as ProjectStatus,
        priority: "MEDIUM" as Priority,
        organizationId: "",
        ownerId: "",
        budget: 0,
        startDate: "",
        endDate: "",
        memberIds: [] as string[],
        type: "EXTERNAL" as ProjectType,
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const res = await createProject({
                ...formData,
                budget: Number(formData.budget),
                startDate: formData.startDate ? new Date(formData.startDate) : null,
                endDate: formData.endDate ? new Date(formData.endDate) : null,
                organizationId: formData.organizationId || null,
                ownerId: formData.ownerId || null,
                memberIds: formData.memberIds,
                type: formData.type,
            });

            if (res.success) {
                toast.success("Project created successfully");
                setOpen(false);
                setFormData({
                    name: "",
                    description: "",
                    status: "PLANNING",
                    priority: "MEDIUM",
                    organizationId: "",
                    ownerId: "",
                    budget: 0,
                    startDate: "",
                    endDate: "",
                    memberIds: [],
                    type: "EXTERNAL"
                });
            } else {
                toast.error(res.error || "Failed to create project");
            }
        } catch (error) {
            toast.error("An unexpected error occurred");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="rounded-xl font-bold shadow-lg shadow-primary/20 gap-2">
                    <Plus className="w-4 h-4" />
                    New Project
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px] rounded-3xl border-border/40 shadow-2xl">
                <form onSubmit={handleSubmit}>
                    <DialogHeader>
                        <DialogTitle className="text-2xl font-black">Create New Project</DialogTitle>
                        <DialogDescription className="font-medium">
                            Set up a new project workspace for your team and clients.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="grid gap-5 py-6">
                        <div className="space-y-2">
                            <Label htmlFor="name" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Project Name</Label>
                            <Input
                                id="name"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                placeholder="e.g. Website Overhaul 2024"
                                className="rounded-xl bg-muted/30 border-border/50 h-12"
                                required
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Priority</Label>
                                <Select 
                                    value={formData.priority} 
                                    onValueChange={(val) => setFormData({ ...formData, priority: val as Priority })}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="LOW">Low</SelectItem>
                                        <SelectItem value="MEDIUM">Medium</SelectItem>
                                        <SelectItem value="HIGH">High</SelectItem>
                                        <SelectItem value="URGENT">Urgent</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Status</Label>
                                <Select 
                                    value={formData.status} 
                                    onValueChange={(val) => setFormData({ ...formData, status: val as ProjectStatus })}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="PLANNING">Planning</SelectItem>
                                        <SelectItem value="ACTIVE">Active</SelectItem>
                                        <SelectItem value="ON_HOLD">On Hold</SelectItem>
                                        <SelectItem value="COMPLETED">Completed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Project Type</Label>
                                <Select 
                                    value={formData.type} 
                                    onValueChange={(val) => {
                                        setFormData({ 
                                            ...formData, 
                                            type: val as ProjectType,
                                            // Reset organizationId if switching to Internal
                                            organizationId: val === "INTERNAL" ? "" : formData.organizationId
                                        });
                                    }}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="INTERNAL">Internal</SelectItem>
                                        <SelectItem value="EXTERNAL">External (Client)</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Client / Organization</Label>
                                <Select 
                                    value={formData.organizationId} 
                                    onValueChange={(val) => setFormData({ ...formData, organizationId: val })}
                                    disabled={formData.type === "INTERNAL"}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12">
                                        <SelectValue placeholder={formData.type === "INTERNAL" ? "N/A (Internal)" : "Select an organization"} />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        {organizations.map((org) => (
                                            <SelectItem key={org.id} value={org.id}>{org.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Additional Team Members</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" className="w-full justify-between rounded-xl bg-muted/30 border-border/50 h-12 font-normal">
                                        {formData.memberIds.length === 0 
                                            ? <span className="text-muted-foreground">Select team members...</span>
                                            : <span>{formData.memberIds.length} selected</span>}
                                        <ChevronDown className="w-4 h-4 opacity-50" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-full sm:w-[240px] p-2 rounded-xl border-border/40 shadow-xl" align="start">
                                    <div className="max-h-48 overflow-y-auto space-y-1">
                                        {users?.map(u => (
                                            <div key={u.id} className="flex items-center space-x-2 p-2 hover:bg-muted/50 rounded-lg cursor-pointer transition-colors" onClick={() => {
                                                const isSelected = formData.memberIds.includes(u.id);
                                                setFormData(prev => ({
                                                    ...prev,
                                                    memberIds: isSelected 
                                                        ? prev.memberIds.filter(id => id !== u.id)
                                                        : [...prev.memberIds, u.id]
                                                }))
                                            }}>
                                                <Checkbox checked={formData.memberIds.includes(u.id)} className="pointer-events-none" />
                                                <span className="text-sm font-medium leading-none">{u.name || u.id}</span>
                                            </div>
                                        ))}
                                        {(!users || users.length === 0) && (
                                            <div className="text-xs text-muted-foreground p-2 text-center">No users available</div>
                                        )}
                                    </div>
                                </PopoverContent>
                            </Popover>
                            <p className="text-[10px] text-muted-foreground ml-1 leading-tight">You, PMs, and Admins are added automatically.</p>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="startDate" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Start Date</Label>
                                <Input
                                    id="startDate"
                                    type="date"
                                    value={formData.startDate}
                                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                                    className="rounded-xl bg-muted/30 border-border/50 h-12"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="endDate" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">End Date (Estimate)</Label>
                                <Input
                                    id="endDate"
                                    type="date"
                                    value={formData.endDate}
                                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                                    className="rounded-xl bg-muted/30 border-border/50 h-12"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="description" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Project Description</Label>
                            <Textarea
                                id="description"
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                placeholder="Describe the project goals and scope..."
                                className="rounded-xl bg-muted/30 border-border/50 min-h-[100px] resize-none"
                            />
                        </div>
                    </div>

                    <DialogFooter className="gap-2 sm:gap-0">
                        <Button
                            type="button"
                            variant="ghost"
                            onClick={() => setOpen(false)}
                            className="rounded-xl font-bold"
                        >
                            Cancel
                        </Button>
                        <Button
                            type="submit"
                            disabled={loading}
                            className="rounded-xl font-bold bg-primary px-8 shadow-lg shadow-primary/20"
                        >
                            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                            Initialize Project
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
