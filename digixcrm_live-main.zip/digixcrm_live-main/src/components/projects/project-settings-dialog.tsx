"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { 
    Dialog, 
    DialogContent, 
    DialogDescription, 
    DialogHeader, 
    DialogTitle, 
    DialogTrigger,
    DialogFooter
} from "@/components/ui/dialog";
import { 
    Tabs, 
    TabsContent, 
    TabsList, 
    TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    Settings, 
    Users, 
    Trash2, 
    AlertTriangle, 
    Plus, 
    X,
    Check
} from "lucide-react";
import { updateProject, deleteProject, addProjectMember, removeProjectMember } from "@/lib/actions/projects";
import { ProjectType } from "@/generated/prisma/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface ProjectSettingsDialogProps {
    project: any;
    workspaceUsers: any[];
    trigger?: React.ReactNode;
}

export function ProjectSettingsDialog({ project, workspaceUsers, trigger }: ProjectSettingsDialogProps) {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [confirmDelete, setConfirmDelete] = useState(false);

    // Form States
    const [name, setName] = useState(project.name);
    const [description, setDescription] = useState(project.description || "");
    const [status, setStatus] = useState(project.status);
    const [priority, setPriority] = useState(project.priority);
    const [endDate, setEndDate] = useState(project.endDate ? format(new Date(project.endDate), "yyyy-MM-dd") : "");
    const [type, setType] = useState<ProjectType>(project.type || "EXTERNAL");

    const handleUpdate = async () => {
        setLoading(true);
        const result = await updateProject(project.id, {
            name,
            description,
            status,
            priority,
            type,
            endDate: endDate ? new Date(endDate) : null
        });
        setLoading(false);
        if (result.success) {
            toast.success("Project updated successfully");
            setOpen(false);
        } else {
            toast.error(result.error);
        }
    };

    const handleDelete = async () => {
        if (!confirmDelete) {
            setConfirmDelete(true);
            return;
        }
        setLoading(true);
        const result = await deleteProject(project.id);
        setLoading(false);
        if (result.success) {
            toast.success("Project deleted");
            router.push("/dashboard/projects");
        } else {
            toast.error(result.error);
        }
    };

    const handleAddMember = async (userId: string) => {
        const result = await addProjectMember(project.id, userId);
        if (result.success) {
            toast.success("Member added");
        } else {
            toast.error(result.error);
        }
    };

    const handleRemoveMember = async (userId: string) => {
        const result = await removeProjectMember(project.id, userId);
        if (result.success) {
            toast.success("Member removed");
        } else {
            toast.error(result.error);
        }
    };

    const projectMemberIds = new Set(project.members?.map((m: any) => m.userId) || []);
    const availableUsers = workspaceUsers.filter(u => !projectMemberIds.has(u.id));

    return (
        <Dialog open={open} onOpenChange={(val) => { setOpen(val); if(!val) setConfirmDelete(false); }}>
            <DialogTrigger asChild>
                {trigger ? trigger : (
                    <Button variant="outline" className="rounded-xl font-bold order-first md:order-last border-border/40 hover:bg-muted/50 transition-all">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                    </Button>
                )}
            </DialogTrigger>
            <DialogContent className="max-w-2xl rounded-[2.5rem] border-border/40 p-0 overflow-hidden shadow-2xl">
                <DialogHeader className="p-8 pb-0">
                    <DialogTitle className="text-2xl font-black tracking-tight">Project Settings</DialogTitle>
                    <DialogDescription className="text-sm font-bold text-muted-foreground opacity-60">
                        Manage project details, team access, and lifecycle.
                    </DialogDescription>
                </DialogHeader>

                <Tabs defaultValue="general" className="w-full">
                    <div className="px-8 mt-6">
                        <TabsList className="bg-muted/50 p-1 rounded-2xl w-full grid grid-cols-3">
                            <TabsTrigger value="general" className="rounded-xl font-black text-[10px] uppercase tracking-widest">General</TabsTrigger>
                            <TabsTrigger value="team" className="rounded-xl font-black text-[10px] uppercase tracking-widest">Team Access</TabsTrigger>
                            <TabsTrigger value="danger" className="rounded-xl font-black text-[10px] uppercase tracking-widest text-red-500 data-[state=active]:bg-red-500/10">Danger Zone</TabsTrigger>
                        </TabsList>
                    </div>

                    <div className="p-8 pt-6 min-h-[400px]">
                        <TabsContent value="general" className="space-y-6 mt-0 animate-in fade-in duration-300">
                            <div className="grid gap-6">
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Project Name</Label>
                                    <Input 
                                        value={name} 
                                        onChange={(e) => setName(e.target.value)} 
                                        className="rounded-xl border-border/50 font-bold"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Description</Label>
                                    <Textarea 
                                        value={description} 
                                        onChange={(e) => setDescription(e.target.value)} 
                                        className="rounded-xl border-border/50 font-bold min-h-[100px]"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Status</Label>
                                        <Select value={status} onValueChange={setStatus}>
                                            <SelectTrigger className="rounded-xl border-border/50 font-bold">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-xl border-border/40">
                                                <SelectItem value="PLANNING">Planning</SelectItem>
                                                <SelectItem value="ACTIVE">Active</SelectItem>
                                                <SelectItem value="ON_HOLD">On Hold</SelectItem>
                                                <SelectItem value="COMPLETED">Completed</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Priority</Label>
                                        <Select value={priority} onValueChange={setPriority}>
                                            <SelectTrigger className="rounded-xl border-border/50 font-bold">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-xl border-border/40">
                                                <SelectItem value="LOW">Low</SelectItem>
                                                <SelectItem value="MEDIUM">Medium</SelectItem>
                                                <SelectItem value="HIGH">High</SelectItem>
                                                <SelectItem value="URGENT">Urgent</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Project Type</Label>
                                        <Select value={type} onValueChange={(val) => setType(val as ProjectType)}>
                                            <SelectTrigger className="rounded-xl border-border/50 font-bold">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-xl border-border/40">
                                                <SelectItem value="INTERNAL">Internal</SelectItem>
                                                <SelectItem value="EXTERNAL">External (Client)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Deadline</Label>
                                        <Input 
                                            type="date" 
                                            value={endDate} 
                                            onChange={(e) => setEndDate(e.target.value)}
                                            className="rounded-xl border-border/50 font-bold"
                                        />
                                    </div>
                                </div>
                            </div>
                        </TabsContent>

                        <TabsContent value="team" className="space-y-6 mt-0 animate-in fade-in duration-300">
                            <div className="space-y-6">
                                <div className="space-y-3">
                                    <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Add Team Member</Label>
                                    
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button
                                                variant="outline"
                                                role="combobox"
                                                className="w-full justify-between rounded-xl border-border/50 font-bold py-6 px-4"
                                            >
                                                <span className="text-muted-foreground">Search users by name...</span>
                                                <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-[300px] p-0 rounded-2xl shadow-xl border-border/40" align="start">
                                            <div className="p-2 border-b border-border/30">
                                                <div className="flex items-center gap-2 px-2 py-1 rounded-xl bg-muted/30">
                                                    <Search className="w-4 h-4 text-muted-foreground/50" />
                                                    <input
                                                        type="text"
                                                        placeholder="Search by name..."
                                                        className="flex-1 bg-transparent border-none outline-none text-xs font-bold placeholder:text-muted-foreground/40"
                                                        onChange={(e) => {
                                                            const val = e.target.value.toLowerCase();
                                                            const items = document.querySelectorAll('.member-search-item');
                                                            items.forEach((item: any) => {
                                                                const text = item.getAttribute('data-name')?.toLowerCase() || "";
                                                                if (text.includes(val)) {
                                                                    item.style.display = 'flex';
                                                                } else {
                                                                    item.style.display = 'none';
                                                                }
                                                            });
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="max-h-[220px] overflow-y-auto p-1">
                                                {availableUsers.length > 0 ? availableUsers.map(user => (
                                                    <button
                                                        key={user.id}
                                                        data-name={user.name}
                                                        className="member-search-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-primary/5 cursor-pointer transition-colors"
                                                        onClick={() => handleAddMember(user.id)}
                                                    >
                                                        <Avatar className="h-7 w-7">
                                                            <AvatarImage src={user.image || ""} />
                                                            <AvatarFallback className="text-[9px] font-black">{user.name?.substring(0, 2).toUpperCase() || "UN"}</AvatarFallback>
                                                        </Avatar>
                                                        <span className="text-sm font-bold text-left">{user.name}</span>
                                                    </button>
                                                )) : (
                                                    <div className="p-4 text-center text-xs font-bold text-muted-foreground opacity-60">No users available</div>
                                                )}
                                            </div>
                                        </PopoverContent>
                                    </Popover>
                                </div>

                                <div className="space-y-3">
                                    <Label className="text-[10px] font-black uppercase tracking-widest opacity-60">Current Members ({project.members?.length || 0})</Label>
                                    <div className="grid gap-2">
                                        {project.members?.map((member: any) => (
                                            <div key={member.id} className="flex items-center justify-between p-3 rounded-2xl bg-muted/20 border border-border/30 group hover:border-primary/20 transition-all">
                                                <div className="flex items-center gap-3">
                                                    <Avatar className="h-8 w-8 border border-border/50">
                                                        <AvatarImage src={member.user.image || ""} />
                                                        <AvatarFallback className="text-[10px] font-black">{member.user.name?.substring(0, 2).toUpperCase() || "UN"}</AvatarFallback>
                                                    </Avatar>
                                                    <div>
                                                        <p className="text-xs font-black">{member.user.name}</p>
                                                        <p className="text-[9px] font-bold text-muted-foreground uppercase opacity-60 tracking-tighter">{member.role}</p>
                                                    </div>
                                                </div>
                                                <Button 
                                                    variant="ghost" 
                                                    size="icon" 
                                                    className="h-8 w-8 rounded-full text-muted-foreground hover:text-red-500 hover:bg-red-500/5 opacity-0 group-hover:opacity-100 transition-all"
                                                    onClick={() => handleRemoveMember(member.userId)}
                                                >
                                                    <X className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </TabsContent>

                        <TabsContent value="danger" className="space-y-6 mt-0 animate-in fade-in duration-300">
                            <div className="p-8 rounded-[2rem] bg-red-500/5 border border-red-500/10 space-y-6">
                                <div className="flex items-start gap-4 text-red-500">
                                    <div className="bg-red-500/10 p-3 rounded-2xl">
                                        <AlertTriangle className="w-6 h-6" />
                                    </div>
                                    <div className="space-y-1">
                                        <h4 className="text-lg font-black tracking-tight">Delete Project</h4>
                                        <p className="text-xs font-bold opacity-70 leading-relaxed">This action is permanent and cannot be undone. All tasks, milestones, and data associated with this project will be deleted.</p>
                                    </div>
                                </div>

                                <Button 
                                    variant={confirmDelete ? "destructive" : "outline"} 
                                    className={cn(
                                        "w-full rounded-2xl h-14 font-black uppercase tracking-widest text-xs gap-3 transition-all duration-300",
                                        !confirmDelete && "border-red-500/20 text-red-500 hover:bg-red-500/10 hover:border-red-500/40"
                                    )}
                                    onClick={handleDelete}
                                    disabled={loading}
                                >
                                    {confirmDelete ? (
                                        <>
                                            <Check className="w-4 h-4" />
                                            Confirm Permanent Deletion
                                        </>
                                    ) : (
                                        <>
                                            <Trash2 className="w-4 h-4" />
                                            Delete this Project
                                        </>
                                    )}
                                </Button>
                                {confirmDelete && (
                                    <p className="text-[10px] font-black text-center text-red-500 uppercase tracking-widest animate-pulse">Click once more to confirm</p>
                                )}
                            </div>
                        </TabsContent>
                    </div>
                </Tabs>

                <DialogFooter className="p-8 pt-0 flex sm:justify-between items-center gap-4">
                    <Button variant="ghost" className="rounded-xl font-bold opacity-60" onClick={() => setOpen(false)}>Cancel</Button>
                    <Button className="rounded-xl px-10 font-bold bg-primary text-primary-foreground shadow-xl shadow-primary/20" onClick={handleUpdate} disabled={loading}>
                        {loading ? "Saving..." : "Save Changes"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
