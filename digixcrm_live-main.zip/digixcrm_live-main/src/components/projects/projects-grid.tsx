"use client";

import { useState } from "react";
import { ProjectCard } from "@/components/projects/project-card";
import { CreateProjectDialog } from "@/components/projects/create-project-dialog";
import { Search, Filter, FolderKanban, Layers, TrendingUp, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function ProjectsGrid({ initialProjects, organizations, users, showFinancials }: any) {
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState("ALL");
    const [projectTypeFilter, setProjectTypeFilter] = useState<"ALL" | "INTERNAL" | "EXTERNAL">("ALL");

    // Filter projects based on search query and status filter
    const filteredProjects = initialProjects.filter((project: any) => {
        const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                              project.description?.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesStatus = statusFilter === "ALL" || project.status === statusFilter;
        const matchesType = projectTypeFilter === "ALL" || project.type === projectTypeFilter;

        return matchesSearch && matchesStatus && matchesType;
    });

    const toggleFilter = () => {
        // Toggle between ALL and ACTIVE for quick filtering
        setStatusFilter(prev => prev === "ALL" ? "ACTIVE" : "ALL");
    };

    // Calculate Stats
    const totalProjects = initialProjects.length;
    const activeProjects = initialProjects.filter((p: any) => p.status === 'ACTIVE').length;
    const totalBudget = showFinancials ? initialProjects.reduce((acc: number, p: any) => acc + (p.budget || 0), 0) : 0;

    return (
        <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div 
                    className={`bg-card p-6 rounded-[2rem] border border-border/40 shadow-lg space-y-4 cursor-pointer transition-all ${statusFilter === "ALL" ? "ring-2 ring-blue-500 shadow-blue-500/10" : "hover:shadow-blue-500/5 hover:border-blue-500/20"}`}
                    onClick={() => setStatusFilter("ALL")}
                >
                    <div className="flex items-center justify-between">
                        <div className="p-2.5 rounded-2xl bg-blue-500/10 text-blue-500">
                            <Layers className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest bg-blue-500/5 px-2 py-1 rounded-full">Overview</span>
                    </div>
                    <div>
                        <div className="text-4xl font-black tracking-tighter">{totalProjects}</div>
                        <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mt-1">Total Projects</p>
                    </div>
                </div>

                <div 
                    className={`bg-card p-6 rounded-[2rem] border border-border/40 shadow-lg space-y-4 cursor-pointer transition-all ${statusFilter === "ACTIVE" ? "ring-2 ring-emerald-500 shadow-emerald-500/10" : "hover:shadow-emerald-500/5 hover:border-emerald-500/20"}`}
                    onClick={() => setStatusFilter("ACTIVE")}
                >
                    <div className="flex items-center justify-between">
                        <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-500">
                            <TrendingUp className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-500/5 px-2 py-1 rounded-full">Tracking</span>
                    </div>
                    <div>
                        <div className="text-4xl font-black tracking-tighter">{activeProjects}</div>
                        <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mt-1">Active Now</p>
                    </div>
                </div>

                {showFinancials && (
                    <div className="bg-card p-6 rounded-[2rem] border border-border/40 shadow-lg shadow-indigo-500/5 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                        <div className="flex items-center justify-between">
                            <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-500">
                                <CheckCircle2 className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest bg-indigo-500/5 px-2 py-1 rounded-full">Financials</span>
                        </div>
                        <div>
                            <div className="text-4xl font-black tracking-tighter">${totalBudget.toLocaleString()}</div>
                            <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mt-1">Portfolio Value</p>
                        </div>
                    </div>
                )}
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-96 group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                    <Input 
                        placeholder="Search projects..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-11 rounded-2xl bg-card border-border/40 h-12 shadow-sm focus-visible:ring-primary/20 transition-all font-medium"
                    />
                </div>
                
                <div className="flex items-center bg-muted/20 border border-border/40 p-1 rounded-2xl w-full sm:w-auto overflow-hidden shadow-inner">
                    <button 
                        onClick={() => setProjectTypeFilter("ALL")}
                        className={`flex-1 sm:flex-none px-6 py-2 text-[11px] font-black uppercase tracking-widest rounded-xl transition-all ${projectTypeFilter === "ALL" ? "bg-background shadow-md text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-background/50"}`}
                    >
                        All
                    </button>
                    <button 
                        onClick={() => setProjectTypeFilter("INTERNAL")}
                        className={`flex-1 sm:flex-none px-6 py-2 text-[11px] font-black uppercase tracking-widest rounded-xl transition-all ${projectTypeFilter === "INTERNAL" ? "bg-background shadow-md text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-background/50"}`}
                    >
                        Internal
                    </button>
                    <button 
                        onClick={() => setProjectTypeFilter("EXTERNAL")}
                        className={`flex-1 sm:flex-none px-6 py-2 text-[11px] font-black uppercase tracking-widest rounded-xl transition-all ${projectTypeFilter === "EXTERNAL" ? "bg-background shadow-md text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-background/50"}`}
                    >
                        External
                    </button>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                    <Button 
                        variant={statusFilter === "ACTIVE" ? "default" : "outline"} 
                        onClick={toggleFilter}
                        className="rounded-2xl h-12 px-6 font-black uppercase tracking-widest text-[10px] border-border/40 transition-all gap-2"
                    >
                        <Filter className="w-4 h-4" />
                        {statusFilter === "ACTIVE" ? "Active Only" : "All Projects"}
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProjects.map((project: any) => (
                    <ProjectCard key={project.id} project={project} workspaceUsers={users} />
                ))}
                
                {filteredProjects.length === 0 && (
                    <div className="col-span-full py-20 bg-muted/20 border-2 border-dashed border-border/40 rounded-[3rem] flex flex-col items-center justify-center text-center space-y-4">
                        <div className="p-4 rounded-3xl bg-card shadow-xl border border-border/40">
                            <FolderKanban className="w-12 h-12 text-muted-foreground opacity-20" />
                        </div>
                        <div className="space-y-1">
                            <h3 className="text-xl font-black">{initialProjects.length > 0 ? "No matching projects" : "No projects discovered"}</h3>
                            <p className="text-muted-foreground font-medium">
                                {initialProjects.length > 0 ? "Try adjusting your search or filters." : "Create your first project to start managing tasks and teams."}
                            </p>
                        </div>
                        {initialProjects.length === 0 && (
                            <CreateProjectDialog organizations={organizations} users={users} />
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
