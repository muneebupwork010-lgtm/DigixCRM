"use client";

import Link from "next/link";
import { 
    Calendar, 
    ChevronRight, 
    Clock, 
    MoreVertical, 
    Users as UsersIcon,
    Target
} from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

import { useRouter } from "next/navigation";

import { ProjectSettingsDialog } from "@/components/projects/project-settings-dialog";

interface ProjectCardProps {
    project: any; // Using any for brevity, should ideally be typed with Prisma output
    workspaceUsers?: any[];
}

const statusColors: Record<string, string> = {
    PLANNING: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    ACTIVE: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    ON_HOLD: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    COMPLETED: "bg-indigo-500/10 text-indigo-500 border-indigo-500/20",
};

const priorityColors: Record<string, string> = {
    LOW: "text-muted-foreground",
    MEDIUM: "text-blue-500",
    HIGH: "text-amber-500",
    URGENT: "text-red-500",
};

export function ProjectCard({ project, workspaceUsers = [] }: ProjectCardProps) {
    const router = useRouter();
    const totalTasks = project._count?.tasks || 0;
    const completedTasks = project.tasks?.length || 0;
    const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    const handleCardClick = () => {
        router.push(`/dashboard/projects/${project.id}`);
    };

    return (
        <Card 
            onClick={handleCardClick}
            className="group relative overflow-hidden rounded-3xl border-border/50 bg-card hover:shadow-2xl hover:shadow-primary/5 transition-all duration-300 hover:-translate-y-1 cursor-pointer"
        >
            <CardHeader className="p-6 pb-2 space-y-4">
                <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1.5">
                        <Badge variant="outline" className={cn("rounded-full px-3 py-0.5 text-[10px] uppercase font-black tracking-widest", statusColors[project.status] || "bg-muted text-muted-foreground")}>
                            {project.status.replace('_', ' ')}
                        </Badge>
                        <h3 className="text-xl font-black tracking-tight group-hover:text-primary transition-colors line-clamp-1">
                            {project.name}
                        </h3>
                        {project.organization && (
                             <p className="text-sm font-bold text-muted-foreground flex items-center gap-1.5">
                                <Target className="w-3.5 h-3.5" />
                                {project.organization.name}
                            </p>
                        )}
                    </div>
                    <div onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                                    <MoreVertical className="w-4 h-4 text-muted-foreground" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="rounded-xl border-border/40 shadow-xl">
                                {workspaceUsers && workspaceUsers.length > 0 ? (
                                    <ProjectSettingsDialog 
                                        project={project} 
                                        workspaceUsers={workspaceUsers} 
                                        trigger={
                                            <DropdownMenuItem className="font-bold" onSelect={(e) => e.preventDefault()}>Edit Project</DropdownMenuItem>
                                        } 
                                    />
                                ) : (
                                    <DropdownMenuItem className="font-bold" onClick={(e) => {
                                        e.stopPropagation();
                                        router.push(`/dashboard/projects/${project.id}`);
                                    }}>
                                        Edit Project
                                    </DropdownMenuItem>
                                )}
                                <DropdownMenuItem className="font-bold text-red-500">Archive</DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>
            </CardHeader>

            <CardContent className="p-6 pt-2 space-y-6">
                <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-black uppercase tracking-widest text-muted-foreground">
                        <span>Progress</span>
                        <span className="text-primary">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2 rounded-full bg-muted/50" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block">Priority</span>
                        <span className={cn("text-sm font-bold flex items-center gap-1.5", priorityColors[project.priority])}>
                            <div className={cn("w-1.5 h-1.5 rounded-full", project.priority === 'URGENT' ? 'bg-red-500 animate-pulse' : 'bg-current')} />
                            {project.priority}
                        </span>
                    </div>
                    <div className="space-y-1 text-right">
                        <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block">Deadline</span>
                        <span className="text-sm font-bold flex items-center justify-end gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                            {project.endDate ? format(new Date(project.endDate), "MMM d") : "N/A"}
                        </span>
                    </div>
                </div>
            </CardContent>

            <CardFooter className="p-6 pt-0 flex items-center justify-between">
                <div className="flex -space-x-2">
                    {/* PM Avatar */}
                    <Avatar className="h-8 w-8 ring-4 ring-card rounded-full border border-border/50">
                        <AvatarImage src={project.owner?.image || ""} />
                        <AvatarFallback className="bg-primary/10 text-primary text-[10px] font-black">
                            {project.owner?.name?.substring(0, 2).toUpperCase() || "PM"}
                        </AvatarFallback>
                    </Avatar>
                    <div className="h-8 w-8 rounded-full ring-4 ring-card bg-muted flex items-center justify-center text-[10px] font-black text-muted-foreground border border-border/50">
                        +{totalTasks}
                    </div>
                </div>

                <div className="flex items-center gap-1 text-sm font-black text-primary group-hover:gap-2 transition-all">
                    Enter Project
                    <ChevronRight className="w-4 h-4" />
                </div>
            </CardFooter>
        </Card>
    );
}
