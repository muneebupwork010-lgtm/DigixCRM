"use client";

import { useState, useEffect } from "react";
import { getProjectMilestones, createMilestone, updateMilestone, deleteMilestone } from "@/lib/actions/milestones";
import { 
    Flag, 
    Plus, 
    MoreHorizontal, 
    Calendar,
    CheckCircle2,
    Clock,
    Trash2,
    Pencil
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { TaskSheet } from "../tasks/task-sheet";

export function MilestonesView({ projectId, users = [], currentUser }: { projectId: string, users?: any[], currentUser?: { id: string; role: string } }) {
    const [milestones, setMilestones] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [expandedMilestones, setExpandedMilestones] = useState<string[]>([]);
    const [selectedTask, setSelectedTask] = useState<any | null>(null);
    
    const toggleExpand = (id: string) => {
        setExpandedMilestones(prev => 
            prev.includes(id) ? prev.filter(mid => mid !== id) : [...prev, id]
        );
    };
    
    // Create form state
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [dueDate, setDueDate] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        fetchMilestones();
    }, [projectId]);

    const fetchMilestones = async () => {
        setLoading(true);
        const data = await getProjectMilestones(projectId);
        setMilestones(data);
        setLoading(false);
    };

    const handleCreate = async () => {
        if (!title.trim()) return;
        setIsSubmitting(true);

        const res = await createMilestone({
            projectId,
            title,
            description,
            dueDate: dueDate ? new Date(dueDate) : null
        });

        if (res.success) {
            toast.success("Milestone created");
            setIsCreateOpen(false);
            setTitle("");
            setDescription("");
            setDueDate("");
            fetchMilestones();
        } else {
            toast.error(res.error || "Failed to create milestone");
        }
        setIsSubmitting(false);
    };

    const handleStatusChange = async (id: string, status: string) => {
        const res = await updateMilestone(id, { status });
        if (res.success) {
            toast.success("Status updated");
            fetchMilestones();
        } else {
            toast.error(res.error || "Failed to update status");
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm("Are you sure you want to delete this milestone?")) return;
        const res = await deleteMilestone(id);
        if (res.success) {
            toast.success("Milestone deleted");
            fetchMilestones();
        } else {
            toast.error(res.error || "Failed to delete milestone");
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case "COMPLETED": return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
            case "IN_PROGRESS": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
            default: return "bg-muted text-muted-foreground border-border";
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-64 gap-3">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Loading Milestones...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 p-2">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-card p-4 rounded-[2rem] border border-border/40 shadow-sm">
                <div className="flex items-center gap-3 pl-2">
                    <div className="p-2 bg-primary/10 rounded-xl">
                        <Flag className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                        <h3 className="text-sm font-black uppercase tracking-widest">Project Milestones</h3>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">{milestones.length} defined stages</p>
                    </div>
                </div>
                {currentUser?.role !== "CLIENT" && (
                <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                    <DialogTrigger asChild>
                        <Button className="rounded-xl h-10 px-6 font-black uppercase tracking-widest text-[10px] bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
                            <Plus className="w-4 h-4 mr-2" />
                            New Milestone
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] rounded-[2.5rem] p-8">
                        <DialogHeader>
                            <DialogTitle className="text-2xl font-black tracking-tight">Create Milestone</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-6 py-4">
                            <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Title</label>
                                <Input 
                                    value={title}
                                    onChange={e => setTitle(e.target.value)}
                                    placeholder="e.g. Design Phase Complete"
                                    className="h-12 rounded-xl border-border/40 font-medium"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Description</label>
                                <Textarea 
                                    value={description}
                                    onChange={e => setDescription(e.target.value)}
                                    placeholder="Goals and deliverables for this milestone..."
                                    className="min-h-[100px] rounded-xl border-border/40 resize-none font-medium"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Due Date</label>
                                <Input 
                                    type="date"
                                    value={dueDate}
                                    onChange={e => setDueDate(e.target.value)}
                                    className="h-12 rounded-xl border-border/40 font-medium text-muted-foreground"
                                />
                            </div>
                        </div>
                        <Button 
                            onClick={handleCreate} 
                            disabled={isSubmitting || !title.trim()}
                            className="w-full h-12 rounded-xl font-black uppercase tracking-widest text-xs"
                        >
                            {isSubmitting ? "Creating..." : "Create Milestone"}
                        </Button>
                    </DialogContent>
                </Dialog>
                )}
            </div>

            <div className="grid gap-4">
                {milestones.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20 bg-muted/20 border-2 border-dashed border-border/40 rounded-[2.5rem] text-center">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                            <Flag className="w-8 h-8 text-primary" />
                        </div>
                        <h3 className="text-lg font-black uppercase tracking-tight">No Milestones Yet</h3>
                        <p className="text-xs font-bold text-muted-foreground mt-1 uppercase tracking-widest max-w-sm">
                            Break your project down into key phases and deliverables to track overall progress.
                        </p>
                    </div>
                ) : (
                    milestones.map((milestone) => {
                        const totalTasks = milestone.tasks?.length || 0;
                        const completedTasks = milestone.tasks?.filter((t: any) => t.status === "DONE").length || 0;
                        const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
                        const isExpanded = expandedMilestones.includes(milestone.id);
                        
                        return (
                            <div key={milestone.id} 
                                style={{ touchAction: 'pan-y' }}
                                className={cn(
                                    "bg-card rounded-[2rem] border border-border/40 shadow-sm group hover:border-primary/20 transition-all duration-300 relative overflow-hidden flex flex-col",
                                    isExpanded && "ring-2 ring-primary/20 border-primary/20"
                                )}
                            >
                                <div 
                                    onClick={() => toggleExpand(milestone.id)}
                                    className="p-6 cursor-pointer"
                                >
                                    {progress === 100 && (
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                                    )}
                                    
                                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 relative z-10">
                                        <div className="space-y-3 flex-1">
                                            <div className="flex items-center gap-3">
                                                <Badge variant="outline" className={cn("rounded-full px-3 py-0.5 text-[10px] font-black tracking-widest uppercase border", getStatusColor(milestone.status))}>
                                                    {milestone.status.replace("_", " ")}
                                                </Badge>
                                                {milestone.dueDate && (
                                                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground">
                                                        <Calendar className="w-3.5 h-3.5" />
                                                        {format(new Date(milestone.dueDate), "MMM d, yyyy")}
                                                    </div>
                                                )}
                                            </div>
                                            
                                            <div className="flex items-center justify-between gap-4">
                                                <div>
                                                    <h4 className="text-xl font-black tracking-tight group-hover:text-primary transition-colors">{milestone.title}</h4>
                                                    {milestone.description && (
                                                        <p className="text-sm font-medium text-muted-foreground mt-1 line-clamp-2">
                                                            {milestone.description}
                                                        </p>
                                                    )}
                                                </div>
                                                <div className={cn("p-2 rounded-full bg-muted/50 transition-transform duration-300 shrink-0", isExpanded && "rotate-180")}>
                                                    <Plus className={cn("w-4 h-4 text-muted-foreground transition-all", isExpanded ? "rotate-45" : "")} />
                                                </div>
                                            </div>
                                        </div>

                                    <div className="flex items-center gap-8 md:w-[300px] shrink-0">
                                        <div className="flex-1 space-y-2">
                                            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                                                <span className="text-muted-foreground">Progress</span>
                                                <span className={progress === 100 ? "text-emerald-500" : "text-primary"}>{progress}%</span>
                                            </div>
                                            <Progress value={progress} className="h-2" />
                                            <div className="text-[10px] font-bold text-muted-foreground text-right">
                                                {completedTasks} / {totalTasks} Tasks Completed
                                            </div>
                                        </div>

                                        {currentUser?.role !== "CLIENT" && (
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100">
                                                    <MoreHorizontal className="w-4 h-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end" className="w-48 rounded-2xl">
                                                <div className="px-2 py-1.5 text-[10px] font-black uppercase tracking-widest text-muted-foreground">Update Status</div>
                                                <DropdownMenuItem onClick={() => handleStatusChange(milestone.id, "PENDING")} className="text-xs font-bold rounded-xl cursor-pointer">
                                                    <Clock className="w-3.5 h-3.5 mr-2" /> Pending
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleStatusChange(milestone.id, "IN_PROGRESS")} className="text-xs font-bold rounded-xl cursor-pointer">
                                                    <Flag className="w-3.5 h-3.5 mr-2" /> In Progress
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleStatusChange(milestone.id, "COMPLETED")} className="text-xs font-bold rounded-xl cursor-pointer text-emerald-500 focus:text-emerald-500">
                                                    <CheckCircle2 className="w-3.5 h-3.5 mr-2" /> Completed
                                                </DropdownMenuItem>
                                                <div className="h-px bg-border my-1" />
                                                <DropdownMenuItem onClick={() => handleDelete(milestone.id)} className="text-xs font-bold rounded-xl cursor-pointer text-red-500 focus:text-red-500 focus:bg-red-500/10">
                                                    <Trash2 className="w-3.5 h-3.5 mr-2" /> Delete Milestone
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                        )}
                                    </div>
                                    </div>
                                </div>

                                {isExpanded && (
                                    <div className="px-6 pb-6 pt-2 border-t border-border/10 bg-muted/5 animate-in slide-in-from-top-2 duration-300">
                                        <div className="space-y-2 pt-4">
                                            <div className="px-2 pb-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground">Linked Tasks</div>
                                            {totalTasks === 0 ? (
                                                <div className="p-6 text-center text-xs font-bold text-muted-foreground italic bg-muted/20 rounded-2xl border border-dashed border-border/40">
                                                    No tasks linked to this milestone yet.
                                                </div>
                                            ) : (
                                                <div className="grid gap-2">
                                                    {milestone.tasks.map((task: any) => (
                                                        <div 
                                                            key={task.id} 
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                setSelectedTask(task);
                                                            }}
                                                            className="flex items-center justify-between p-3 bg-card border border-border/40 rounded-2xl hover:border-primary/30 transition-all group/task cursor-pointer active:scale-[0.99]"
                                                        >
                                                            <div className="flex items-center gap-3">
                                                                <div className={cn("w-1.5 h-1.5 rounded-full", 
                                                                    task.status === 'DONE' ? 'bg-emerald-500' : 
                                                                    task.status === 'IN_PROGRESS' ? 'bg-blue-500' : 'bg-slate-500'
                                                                )} />
                                                                <span className="text-xs font-bold group-hover/task:text-primary transition-colors">{task.title}</span>
                                                            </div>
                                                            <div className="flex items-center gap-4">
                                                                <Badge variant="outline" className={cn(
                                                                    "text-[9px] font-black uppercase border-none px-2 py-0",
                                                                    task.priority === 'URGENT' ? 'bg-red-500/10 text-red-500' : 
                                                                    task.priority === 'HIGH' ? 'bg-amber-500/10 text-amber-500' :
                                                                    task.priority === 'MEDIUM' ? 'bg-blue-500/10 text-blue-500' : 'bg-slate-500/10 text-slate-500'
                                                                )}>
                                                                    {task.priority}
                                                                </Badge>
                                                                <Badge variant="secondary" className="text-[9px] font-black uppercase tracking-tighter opacity-60">
                                                                    {task.status.replace("_", " ")}
                                                                </Badge>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })
                )}
            </div>

            <TaskSheet 
                task={selectedTask}
                isOpen={!!selectedTask}
                onClose={() => {
                    setSelectedTask(null);
                    fetchMilestones(); // Refresh data in case task was updated in sheet
                }}
                users={users}
                currentUser={currentUser}
            />
        </div>
    );
}
