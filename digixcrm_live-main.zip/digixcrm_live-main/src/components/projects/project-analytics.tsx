"use client";

import { useMemo, useState, useEffect } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Cell,
    PieChart,
    Pie,
    LineChart,
    Line,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    Target, 
    Zap, 
    Clock, 
    TrendingUp, 
    AlertCircle, 
    CheckCircle2,
    DollarSign,
    Users
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format, subDays, isSameDay } from "date-fns";
import { canSeeFinancials } from "@/lib/permissions-base";

interface ProjectAnalyticsProps {
    project: any;
    tasks: any[];
    users: any[];
    role?: string;
}

export function ProjectAnalytics({ project, tasks, users, role }: ProjectAnalyticsProps) {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);
    const showFinancials = canSeeFinancials(role);

    // 1. Compute Status Distribution
    const statusData = useMemo(() => {
        const counts = tasks.reduce((acc: any, task) => {
            acc[task.status] = (acc[task.status] || 0) + 1;
            return acc;
        }, {});

        return [
            { name: "To Do", value: counts["TODO"] || 0, color: "#64748b" },
            { name: "In Progress", value: counts["IN_PROGRESS"] || 0, color: "#3b82f6" },
            { name: "In Review", value: counts["IN_REVIEW"] || 0, color: "#f59e0b" },
            { name: "Completed", value: counts["DONE"] || 0, color: "#10b981" },
            { name: "Blocked", value: counts["BLOCKED"] || 0, color: "#ef4444" },
        ].filter(d => d.value > 0);
    }, [tasks]);

    // 2. Compute Hours Burn (Actual vs Estimated)
    const hoursData = useMemo(() => {
        const estimated = tasks.reduce((sum, t) => sum + (t.estimatedHours || 0), 0);
        const actual = tasks.reduce((sum, t) => sum + (t.actualHours || 0), 0);
        
        return [
            { name: "Estimated", hours: estimated, color: "#94a3b8" },
            { name: "Actual", hours: actual, color: "#3b82f6" },
        ];
    }, [tasks]);

    // 3. Compute Velocity (Last 7 Days)
    const velocityData = useMemo(() => {
        const last7Days = Array.from({ length: 7 }, (_, i) => {
            const date = subDays(new Date(), 6 - i);
            const count = tasks.filter(t => 
                t.status === "DONE" && t.updatedAt && isSameDay(new Date(t.updatedAt), date)
            ).length;

            return {
                date: format(date, "MMM dd"),
                completed: count
            };
        });
        return last7Days;
    }, [tasks]);

    // 4. Budget Utilization
    const budgetUtilization = (showFinancials && project.budget > 0) ? (tasks.reduce((sum, t) => sum + (t.actualHours || 0) * 100, 0) / project.budget) * 100 : 0; 
    // ^ Assuming $100/hr internal cost for calculation

    const completionRate = tasks.length > 0 ? (tasks.filter(t => t.status === "DONE").length / tasks.length) * 100 : 0;

    // 5. Member Performance
    const memberStats = useMemo(() => {
        return users.map(user => {
            const userTasks = tasks.filter(t => t.assigneeId === user.id);
            const completed = userTasks.filter(t => t.status === "DONE").length;
            const progress = userTasks.length > 0 ? (completed / userTasks.length) * 100 : 0;
            return {
                ...user,
                total: userTasks.length,
                completed,
                progress
            };
        }).sort((a, b) => b.total - a.total);
    }, [tasks, users]);

    return (
        <div className="space-y-8 animate-in fade-in duration-500 pb-10">
            {/* Top Metrics Hierarchy */}
            <div className={cn(
                "grid gap-6",
                showFinancials 
                    ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-4" 
                    : "grid-cols-1 md:grid-cols-3"
            )}>
                <MetricCard 
                    title="Overall Completion" 
                    value={`${Math.round(completionRate)}%`} 
                    subtitle={`${tasks.filter(t => t.status === "DONE").length} of ${tasks.length} tasks`}
                    icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                    trend={+5.2}
                />
                {showFinancials && (
                    <MetricCard 
                        title="Budget Utilization" 
                        value={`${Math.round(budgetUtilization)}%`} 
                        subtitle={`Used of $${project.budget?.toLocaleString()}`}
                        icon={<DollarSign className="w-5 h-5 text-blue-500" />}
                        warning={budgetUtilization > 100}
                    />
                )}
                <MetricCard 
                    title="Time Velocity" 
                    value={`${(tasks.filter(t => t.status === 'DONE').length / 7).toFixed(1)}`} 
                    subtitle="Avg tasks per day"
                    icon={<Zap className="w-5 h-5 text-amber-500" />}
                />
                <MetricCard 
                    title="Team Load" 
                    value={`${(tasks.length / (users.length || 1)).toFixed(1)}`} 
                    subtitle="Tasks per member"
                    icon={<Users className="w-5 h-5 text-indigo-500" />}
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-10">
                {/* Task Distribution Bar Chart */}
                <Card className="lg:col-span-2 border-border/40 shadow-xl shadow-primary/5 rounded-[2rem] bg-card overflow-hidden">
                    <CardHeader className="p-8 pb-4">
                        <CardTitle className="text-xl font-black">Velocity Pulse</CardTitle>
                        <CardDescription className="text-sm font-bold opacity-60">Tasks completed in the last 7 days</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8 pt-0">
                        <div className="h-[300px] w-full mt-4">
                            {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <BarChart data={velocityData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.3} />
                                    <XAxis 
                                        dataKey="date" 
                                        stroke="var(--muted-foreground)" 
                                        fontSize={12} 
                                        fontWeight={800}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <YAxis 
                                        stroke="var(--muted-foreground)" 
                                        fontSize={12} 
                                        fontWeight={800}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <Tooltip 
                                        cursor={{ fill: 'var(--muted)', opacity: 0.1 }} 
                                        content={({ active, payload }) => {
                                            if (active && payload && payload.length) {
                                                return (
                                                    <div className="bg-background/95 backdrop-blur-xl border border-border/60 p-4 rounded-2xl shadow-2xl">
                                                        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">{payload[0].payload.date}</p>
                                                        <p className="text-sm font-black">{payload[0].value} Tasks Done</p>
                                                    </div>
                                                );
                                            }
                                            return null;
                                        }}
                                    />
                                    <Bar dataKey="completed" fill="var(--primary)" radius={[6, 6, 0, 0]} barSize={40} />
                                </BarChart>
                            </ResponsiveContainer>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Status Breakdown Pie Chart */}
                <Card className="border-border/40 shadow-xl shadow-primary/5 rounded-[2rem] bg-card overflow-hidden">
                    <CardHeader className="p-8 pb-0">
                        <CardTitle className="text-xl font-black text-center">Lifecycle Focus</CardTitle>
                        <CardDescription className="text-sm font-bold opacity-60 text-center">Workload distribution by status</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8 flex flex-col items-center">
                        <div className="h-[240px] w-full">
                            {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <PieChart>
                                    <Pie
                                        data={statusData}
                                        innerRadius={70}
                                        outerRadius={90}
                                        paddingAngle={8}
                                        dataKey="value"
                                        stroke="none"
                                    >
                                        {statusData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip 
                                        content={({ active, payload }) => {
                                            if (active && payload && payload.length) {
                                                return (
                                                    <div className="bg-background/95 backdrop-blur-xl border border-border/60 p-3 rounded-2xl shadow-2xl">
                                                        <p className="text-xs font-black" style={{ color: payload[0].payload.color }}>
                                                            {payload[0].name}: {payload[0].value}
                                                        </p>
                                                    </div>
                                                );
                                            }
                                            return null;
                                        }}
                                    />
                                </PieChart>
                            </ResponsiveContainer>
                            )}
                        </div>
                        <div className="grid grid-cols-2 gap-4 w-full mt-4">
                            {statusData.map((s, i) => (
                                <div key={i} className="flex items-center gap-2">
                                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                                    <span className="text-[10px] font-black uppercase tracking-tighter text-muted-foreground">{s.name} ({s.value})</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Member Performance Section */}
            <div className="mt-10">
                <Card className="border-border/40 shadow-xl shadow-primary/5 rounded-[2.5rem] bg-card overflow-hidden">
                    <CardHeader className="p-8 border-b border-border/40 bg-muted/20">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <CardTitle className="text-xl font-black">Resource Allocation</CardTitle>
                                <CardDescription className="text-sm font-bold opacity-60">Individual contributor performance and workload</CardDescription>
                            </div>
                            <Badge variant="outline" className="rounded-full px-3 py-1 font-black text-[10px] uppercase tracking-widest border-primary/20 bg-primary/5 text-primary">
                                {memberStats.length} Members
                            </Badge>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead>
                                    <tr className="border-b border-border/40 bg-muted/10">
                                        <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Member</th>
                                        <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Workload</th>
                                        <th className="px-8 py-4 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Progress</th>
                                        <th className="px-8 py-4 text-right text-[10px] font-black uppercase tracking-widest text-muted-foreground">Efficiency</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border/40">
                                    {memberStats.map((member) => (
                                        <tr key={member.id} className="group hover:bg-muted/30 transition-colors">
                                            <td className="px-8 py-5">
                                                <div className="flex items-center gap-3">
                                                    <Avatar className="h-8 w-8 border-2 border-background shadow-sm">
                                                        <AvatarImage src={member.image || ""} />
                                                        <AvatarFallback className="text-[10px] font-black">{member.name?.substring(0,2).toUpperCase()}</AvatarFallback>
                                                    </Avatar>
                                                    <span className="text-sm font-black">{member.name}</span>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-sm font-bold">{member.total} Tasks</span>
                                                    <Badge className="bg-muted/50 text-muted-foreground border-none text-[10px] font-bold">
                                                        {Math.round((member.total / (tasks.length || 1)) * 100)}% of project
                                                    </Badge>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 w-[240px]">
                                                <div className="space-y-2">
                                                    <div className="flex items-center justify-between text-[10px] font-black">
                                                        <span>{member.completed} DONE</span>
                                                        <span>{Math.round(member.progress)}%</span>
                                                    </div>
                                                    <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                                                        <div 
                                                            className="h-full bg-primary transition-all duration-1000" 
                                                            style={{ width: `${member.progress}%` }} 
                                                        />
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 text-right">
                                                <span className={cn(
                                                    "text-sm font-black",
                                                    member.progress > 80 ? "text-emerald-500" :
                                                    member.progress > 40 ? "text-blue-500" : "text-slate-400"
                                                )}>
                                                    {member.progress > 70 ? "High" : member.progress > 30 ? "Stable" : "Ramping"}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

function MetricCard({ title, value, subtitle, icon, trend, warning }: any) {
    return (
        <Card className="border-border/40 shadow-xl shadow-primary/5 rounded-[2rem] bg-card overflow-hidden group hover:border-primary/20 transition-all duration-500">
            <CardContent className="p-8">
                <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-2xl bg-muted/30 group-hover:scale-110 group-hover:bg-primary/5 transition-all duration-500">
                        {icon}
                    </div>
                    {trend && (
                        <div className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full border border-emerald-500/10">
                            +{trend}%
                        </div>
                    )}
                    {warning && (
                        <div className="text-[10px] font-black text-red-500 bg-red-500/10 px-2 py-1 rounded-full border border-red-500/10 animate-pulse">
                            Over Budget
                        </div>
                    )}
                </div>
                <div className="space-y-1">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/50">{title}</p>
                    <h3 className="text-3xl font-black tracking-tighter">{value}</h3>
                    <p className="text-xs font-bold text-muted-foreground/60">{subtitle}</p>
                </div>
            </CardContent>
        </Card>
    );
}
