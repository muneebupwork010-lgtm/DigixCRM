"use client";

import { Lock } from "lucide-react";

export function HeroVideo() {
    return (
        <div className="relative w-full max-w-3xl mx-auto lg:mx-0 group p-4 sm:p-6" style={{ perspective: "1400px" }}>
            {/* Ambient Glow */}
            <div className="absolute inset-0 bg-primary/20 blur-[80px] rounded-full scale-110 -z-10 transition-all duration-700 group-hover:bg-primary/30" />

            {/* Performance: Hoisted Preload for Lightning Fast Video Display */}
            <link rel="preload" href="/CRM-hero.webm" as="video" type="video/webm" />

            {/* 3D Browser Window Frame */}
            <div className="rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5)] overflow-hidden ring-1 ring-white/10 transition-all duration-700 group-hover:shadow-[0_30px_60px_-15px_rgba(0,0,0,0.6)] group-hover:-translate-y-2"
                style={{ transform: "rotateX(2deg) rotateY(-4deg)", transformStyle: "preserve-3d" }}>
                
                {/* macOS style browser header */}
                <div className="h-10 bg-muted/80 backdrop-blur-md border-b border-border/50 flex items-center px-4 gap-2 relative">
                    <div className="flex gap-1.5 absolute left-4">
                        <span className="w-3 h-3 rounded-full bg-[#ff5f56] shadow-sm" />
                        <span className="w-3 h-3 rounded-full bg-[#ffbd2e] shadow-sm" />
                        <span className="w-3 h-3 rounded-full bg-[#27c93f] shadow-sm" />
                    </div>
                    <div className="mx-auto flex items-center justify-center bg-background/50 border border-border/50 rounded-md px-3 py-1 shadow-sm w-full max-w-[240px]">
                        <Lock className="w-3 h-3 text-muted-foreground mr-1.5" />
                        <span className="text-[10px] font-mono text-muted-foreground truncate">digixcrm.com/overview</span>
                    </div>
                </div>

                {/* Video Player */}
                <div className="relative aspect-[16/9] bg-card/50 overflow-hidden flex items-center justify-center">
                    <video 
                        className="absolute inset-0 w-full h-full object-cover scale-[1.01]"
                        autoPlay 
                        muted 
                        loop 
                        playsInline
                        preload="auto"
                        disablePictureInPicture
                        disableRemotePlayback
                    >
                        <source src="/CRM-hero.webm" type="video/webm" />
                        Your browser does not support the video tag.
                    </video>
                    
                    {/* Overlay gradient for premium feel */}
                    <div className="absolute inset-0 bg-gradient-to-t from-background/10 to-transparent pointer-events-none" />
                </div>
            </div>

            {/* Floating Badges */}
            <div className="absolute top-0 right-0 sm:top-2 sm:right-2 bg-primary text-primary-foreground text-[10px] font-black px-3 py-1.5 rounded-full shadow-lg animate-bounce z-10 border-2 border-background shadow-primary/20">
                ● WATCH PREVIEW
            </div>
            <div className="absolute bottom-0 left-0 sm:bottom-2 sm:left-2 bg-background border border-border text-foreground text-[10px] font-bold px-3 py-2 rounded-xl shadow-xl z-10 flex items-center gap-2 transform transition-transform group-hover:scale-105">
                <span className="text-base">⚡</span> 
                <span className="uppercase tracking-wider">Lightning Fast</span>
            </div>
        </div>
    );
}
