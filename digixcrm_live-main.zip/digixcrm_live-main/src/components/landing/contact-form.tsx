"use client";

import { useState, useEffect } from "react";
import { Send, Mail, Globe, Shield, CheckCircle2, Clock } from "lucide-react";
import { Turnstile } from "@marsidev/react-turnstile";
import { toast } from "sonner";

export function ContactForm({ hideInfo = false }: { hideInfo?: boolean }) {
    const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
    const [countryCode, setCountryCode] = useState("+1");
    const [detectedLocation, setDetectedLocation] = useState<string>("Local/VPN");
    const [errors, setErrors] = useState<{ email?: string; phone?: string }>({});
    const [contactCaptcha, setContactCaptcha] = useState("");
    const [formSending, setFormSending] = useState(false);
    const [formSent, setFormSent] = useState(false);

    // Effort to get real location even on localhost
    useEffect(() => {
        async function fetchLocation() {
            try {
                // Using a more lenient service with better CORS support
                const res = await fetch("https://ipwho.is/");
                if (res.ok) {
                    const data = await res.json();
                    if (data.city && data.country) {
                        setDetectedLocation(`${data.city}, ${data.country}`);
                    }
                }
            } catch (err) {
                // Silently fail, it will fall back to "Local Development Site" on server
            }
        }
        fetchLocation();
    }, []);

    const validateForm = () => {
        const newErrors: { email?: string; phone?: string } = {};
        
        // Email validation
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
            newErrors.email = "Please enter a valid business email.";
        }

        // Strict Phone validation
        const digitsOnly = form.phone.replace(/\D/g, "");
        if (!form.phone || digitsOnly.length < 9 || digitsOnly.length > 11) {
            newErrors.phone = "Invalid length. Expected 9-11 digits.";
        } else if (/^(\d)\1+$/.test(digitsOnly)) {
            newErrors.phone = "Suspicious number format.";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleContact = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!validateForm()) {
            toast.error("Please correct the errors in the form.");
            return;
        }

        setFormSending(true);
        try {
            const res = await fetch("/api/contact", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    ...form,
                    phone: `${countryCode} ${form.phone}`, // Combine for CRM clarity
                    location: detectedLocation, // Inject client-detected location
                    captchaToken: contactCaptcha 
                }),
            });
            if (res.ok) { 
                setFormSent(true); 
                setForm({ name: "", email: "", phone: "", message: "" }); 
            }
            else { const d = await res.json(); toast.error(d.error || "Failed to send."); }
        } catch { toast.error("Server error."); }
        finally { setFormSending(false); }
    };

    const formContent = (
        <div className="bg-card border border-border rounded-3xl p-6 sm:p-10 shadow-2xl relative">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-[10px] font-black px-4 py-1.5 rounded-full shadow-lg uppercase tracking-widest whitespace-nowrap">
                Live Consultation Request
            </div>
            {formSent ? (
                <div className="text-center py-10">
                    <div className="w-14 h-14 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-4">
                        <CheckCircle2 className="w-7 h-7 text-green-500" />
                    </div>
                    <h3 className="text-lg font-bold text-foreground mb-2">Message Sent!</h3>
                    <p className="text-sm text-muted-foreground mb-6">Our sales team will reach out within 24 hours.</p>
                    <button onClick={() => setFormSent(false)} className="text-sm text-primary font-bold hover:underline">
                        Send Another Message →
                    </button>
                </div>
            ) : (
                <form onSubmit={handleContact} className="space-y-6">
                    <h3 className="text-xl font-black text-foreground mb-6 text-center lg:text-left">Details for your Strategy Session</h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Full Name</label>
                            <input required type="text" placeholder="e.g. Marcus Miller"
                                value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                                className="w-full bg-background border border-border rounded-xl px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-4 focus:ring-primary/5 focus:border-primary transition-all font-medium" />
                        </div>
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Work Email</label>
                            <input required type="email" placeholder="name@company.com"
                                value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                                className={`w-full bg-background border rounded-xl px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-4 focus:ring-primary/5 transition-all font-medium ${errors.email ? 'border-red-500 ring-4 ring-red-500/10' : 'border-border focus:border-primary'}`} />
                            {errors.email && <p className="text-[10px] text-red-500 font-bold mt-1 ml-1">{errors.email}</p>}
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="block text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Direct Phone</label>
                        <div className="flex gap-2">
                            <select 
                                value={countryCode} 
                                onChange={e => setCountryCode(e.target.value)}
                                className="bg-background border border-border rounded-xl px-3 py-3.5 text-xs font-black text-foreground focus:outline-none focus:ring-4 focus:ring-primary/5 focus:border-primary transition-all w-[90px]"
                            >
                                <option value="+1">🇺🇸 +1</option>
                                <option value="+44">🇬🇧 +44</option>
                                <option value="+92">🇵🇰 +92</option>
                                <option value="+971">🇦🇪 +971</option>
                                <option value="+966">🇸🇦 +966</option>
                                <option value="+91">🇮🇳 +91</option>
                                <option value="+61">🇦🇺 +61</option>
                                <option value="+49">🇩🇪 +49</option>
                            </select>
                            <input required type="tel" placeholder="300 1234567"
                                value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
                                className={`flex-1 bg-background border rounded-xl px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-4 focus:ring-primary/5 transition-all font-medium ${errors.phone ? 'border-red-500 ring-4 ring-red-500/10' : 'border-border focus:border-primary'}`} />
                        </div>
                        {errors.phone && <p className="text-[10px] text-red-500 font-bold mt-1 ml-1">{errors.phone}</p>}
                    </div>

                    <div className="space-y-2">
                        <label className="block text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">How can we help?</label>
                        <textarea required rows={4} placeholder="I'm interested in data migration and custom pipeline automation for my 20-person team..."
                            value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                            className="w-full bg-background border border-border rounded-xl px-4 py-4 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-4 focus:ring-primary/5 focus:border-primary transition-all resize-none font-medium leading-relaxed" />
                    </div>

                    <div className="flex flex-col items-center gap-3">
                        <div className="flex justify-center overflow-hidden h-[74px]">
                            <div className="scale-[0.8] sm:scale-[0.9] origin-center -my-2 flex items-center justify-center">
                                <Turnstile 
                                    siteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || "0x4AAAAAADI0uTZv1Atx9Nzb"} 
                                    onSuccess={setContactCaptcha}
                                />
                            </div>
                        </div>
                    </div>

                    <button type="submit" disabled={formSending}
                        className="group w-full flex items-center justify-center gap-3 py-4.5 bg-primary text-primary-foreground font-black text-sm rounded-xl hover:bg-primary/90 active:scale-[0.98] transition-all shadow-xl shadow-primary/20 disabled:opacity-50 disabled:grayscale disabled:scale-100 h-14">
                        {formSending
                            ? <><div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" /> Verifying...</>
                            : <><Send className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /> Start Consultation</>}
                    </button>
                    <div className="flex items-center justify-center gap-4 py-2 border-t border-border/50 mt-4">
                        <div className="flex items-center gap-1.5">
                            <Shield className="w-3 h-3 text-green-500" />
                            <span className="text-[10px] font-bold text-muted-foreground uppercase opacity-60">GDPR Ready</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                            <Clock className="w-3 h-3 text-primary" />
                            <span className="text-[10px] font-bold text-muted-foreground uppercase opacity-60">Reply &lt; 2h</span>
                        </div>
                    </div>
                </form>
            )}
        </div>
    );

    if (hideInfo) return formContent;

    return (
        <section id="contact" className="py-24 bg-background border-t border-border/50">
            <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                <div className="pt-2 text-center lg:text-left py-10 lg:py-0">
                    <p className="text-[10px] md:text-xs font-black text-primary uppercase tracking-[0.2em] mb-4">Start Your Growth Session</p>
                    <h2 className="text-3xl md:text-5xl font-black text-foreground tracking-tighter mb-6 leading-[1.1]">
                        Get Your <br className="hidden md:block" />Response Strategy.
                    </h2>
                    <p className="text-base text-muted-foreground mb-10 leading-relaxed max-w-md mx-auto lg:mx-0 font-medium">
                        Our solution architects provide one-on-one walkthroughs, custom ROI mapping, and white-glove migration plans for teams scaling to the next level.
                    </p>

                    <div className="space-y-4 max-w-sm mx-auto lg:mx-0">
                        {[
                            { icon: Shield, label: "Infrastructure", value: "SOC2-Ready & Private" },
                            { icon: Mail,   label: "Technical Sales", value: "Expert responses only" },
                        ].map((item) => (
                            <div key={item.label} className="flex items-center gap-4 p-4 rounded-2xl border border-border bg-muted/20 text-left">
                                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                                    <item.icon className="w-4 h-4 text-primary" />
                                </div>
                                <div>
                                    <p className="text-[10px] text-muted-foreground font-black uppercase tracking-widest leading-none mb-1.5">{item.label}</p>
                                    <p className="text-sm text-foreground font-bold">{item.value}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                {formContent}
            </div>
        </section>
    );
}
