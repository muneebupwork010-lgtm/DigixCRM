"use client";

import { useState } from "react";
import { Tag, Plus, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { updateTask } from "@/lib/actions/tasks";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// Some predefined tag colors based on content
const getTagColor = (tag: string) => {
    const t = tag.toLowerCase();
    if (t.includes("bug") || t.includes("urgent")) return "bg-red-500/10 text-red-500 border-red-500/20 hover:bg-red-500/20";
    if (t.includes("feature") || t.includes("enhancement")) return "bg-blue-500/10 text-blue-500 border-blue-500/20 hover:bg-blue-500/20";
    if (t.includes("design") || t.includes("ui")) return "bg-purple-500/10 text-purple-500 border-purple-500/20 hover:bg-purple-500/20";
    if (t.includes("frontend")) return "bg-sky-500/10 text-sky-500 border-sky-500/20 hover:bg-sky-500/20";
    if (t.includes("backend") || t.includes("api")) return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 hover:bg-emerald-500/20";
    return "bg-slate-500/10 text-slate-500 border-slate-500/20 hover:bg-slate-500/20";
};

export function TaskTags({ taskId, initialTags = [] }: { taskId: string, initialTags?: string[] }) {
    const [tags, setTags] = useState<string[]>(initialTags);
    const [newTag, setNewTag] = useState("");
    const [open, setOpen] = useState(false);

    const handleAddTag = async (e: React.FormEvent) => {
        e.preventDefault();
        const t = newTag.trim();
        if (!t || tags.includes(t)) return;

        const updatedTags = [...tags, t];
        setTags(updatedTags);
        setNewTag("");
        setOpen(false);

        const res = await updateTask(taskId, { tags: updatedTags });
        if (!res.success) {
            toast.error("Failed to add tag");
            setTags(tags); // revert
        }
    };

    const handleRemoveTag = async (tagToRemove: string) => {
        const updatedTags = tags.filter(t => t !== tagToRemove);
        setTags(updatedTags);

        const res = await updateTask(taskId, { tags: updatedTags });
        if (!res.success) {
            toast.error("Failed to remove tag");
            setTags(tags); // revert
        }
    };

    return (
        <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 p-1.5 rounded-lg bg-muted/30 border border-border/40 text-[9px] font-black uppercase tracking-widest text-muted-foreground/60 shadow-sm">
                    <Tag className="w-3 h-3" />
                    Labels
                </div>
                
                <Popover open={open} onOpenChange={setOpen}>
                    <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg hover:bg-primary/5 hover:text-primary transition-all">
                            <Plus className="w-3.5 h-3.5" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-60 p-3 rounded-xl border-border/40 shadow-xl" align="start">
                        <form onSubmit={handleAddTag} className="space-y-3">
                            <h4 className="text-xs font-black uppercase tracking-widest">New Label</h4>
                            <div className="flex items-center gap-2">
                                <Input 
                                    autoFocus
                                    placeholder="e.g. Bug, Feature..." 
                                    value={newTag} 
                                    onChange={(e) => setNewTag(e.target.value)}
                                    className="h-8 text-xs font-bold bg-muted/20 border-border/50"
                                />
                                <Button type="submit" size="sm" className="h-8 shrink-0">Add</Button>
                            </div>
                        </form>
                    </PopoverContent>
                </Popover>
            </div>

            <div className="flex flex-wrap items-center gap-2">
                {tags.length === 0 && (
                    <span className="text-xs font-bold text-muted-foreground/50 italic py-2">No labels</span>
                )}
                {tags.map(tag => (
                    <Badge 
                        key={tag} 
                        variant="outline" 
                        className={cn("px-2 py-0.5 text-[10px] font-black uppercase tracking-widest rounded-md border flex items-center gap-1", getTagColor(tag))}
                    >
                        {tag}
                        <X 
                            className="w-3 h-3 ml-1 cursor-pointer opacity-50 hover:opacity-100 transition-opacity" 
                            onClick={() => handleRemoveTag(tag)}
                        />
                    </Badge>
                ))}
            </div>
        </div>
    );
}
