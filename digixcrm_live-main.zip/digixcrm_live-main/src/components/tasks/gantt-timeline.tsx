"use client";

import { useMemo, useEffect, useRef } from "react";
import { format, addDays, startOfToday, differenceInDays, isSameDay } from "date-fns";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface GanttTimelineProps {
    tasks: any[];
}

export function GanttTimeline({ tasks }: GanttTimelineProps) {
    const today = startOfToday();
    const containerRef = useRef<HTMLDivElement>(null);

    const startDate = useMemo(() => {
        const dates = tasks.flatMap(t => [
            t.startDate ? new Date(t.startDate) : null,
            t.dueDate ? new Date(t.dueDate) : null
        ]).filter((d): d is Date => d !== null);
        
        if (dates.length === 0) return addDays(today, -7);
        const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
        return addDays(minDate, -7); // Padding
    }, [tasks, today]);

    const daysCount = 90; // Increased horizontal span
    const timeGrid = Array.from({ length: daysCount }, (_, i) => addDays(startDate, i));

    const dayWidth = 44; // Slightly wider for better readability

    // Scroll to today on mount
    useEffect(() => {
        if (containerRef.current) {
            const todayOffset = differenceInDays(today, startDate) * dayWidth;
            containerRef.current.scrollLeft = todayOffset - 400; // Center today roughly
        }
    }, [startDate, today]);

    return (
        <div className="bg-card rounded-[2.5rem] border border-border/40 shadow-2xl overflow-hidden flex flex-col h-full relative">
            {/* Timeline Header */}
            <div className="flex border-b border-border/40 bg-muted/30 overflow-x-auto scrollbar-none z-20">
                <div className="min-w-[280px] w-[280px] px-8 py-6 border-r border-border/40 font-black text-[10px] uppercase tracking-[0.2em] text-muted-foreground sticky left-0 bg-muted/80 backdrop-blur-xl z-30 shrink-0">
                    Project Roadmap
                </div>
                <div className="flex shrink-0">
                    {timeGrid.map((day, i) => {
                        const isToday = isSameDay(day, today);
                        const isWeekend = day.getDay() === 0 || day.getDay() === 6;
                        return (
                            <div 
                                key={i} 
                                className={cn(
                                    "flex flex-col items-center justify-center border-r border-border/20 shrink-0 py-3",
                                    isWeekend && "bg-muted/10",
                                    isToday && "bg-primary/5"
                                )}
                                style={{ width: dayWidth }}
                            >
                                <span className={cn("text-[8px] font-black uppercase tracking-tighter mb-1", isToday ? "text-primary" : "text-muted-foreground/40")}>
                                    {format(day, "EEE")}
                                </span>
                                <span className={cn(
                                    "text-xs font-black w-7 h-7 flex items-center justify-center rounded-full transition-all", 
                                    isToday ? "bg-primary text-white shadow-lg shadow-primary/30 scale-110" : "text-muted-foreground"
                                )}>
                                    {format(day, "d")}
                                </span>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Timeline Grid */}
            <div ref={containerRef} className="flex-1 overflow-auto scrollbar-none scroll-smooth">
                <div className="flex min-w-max relative pb-10 min-h-full">
                    
                    {/* Today Line Indicator */}
                    <div 
                        className="absolute top-0 bottom-0 w-px bg-primary/40 z-10 pointer-events-none"
                        style={{ left: 280 + (differenceInDays(today, startDate) * dayWidth) + (dayWidth/2) }}
                    >
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-2 h-2 rounded-full bg-primary" />
                    </div>

                    {/* Fixed Sidebar */}
                    <div className="w-[280px] sticky left-0 z-20 bg-card/95 backdrop-blur-md border-r border-border/40 shadow-2xl shrink-0">
                        {tasks.map((task) => (
                            <div key={task.id} className="h-[72px] px-8 flex flex-col justify-center border-b border-border/10 group hover:bg-muted/40 transition-all cursor-pointer">
                                <span className={cn(
                                    "text-xs font-bold truncate transition-all group-hover:translate-x-1", 
                                    task.status === 'DONE' ? "line-through opacity-40 text-muted-foreground" : "text-foreground"
                                )}>
                                    {task.title}
                                </span>
                                <div className="flex items-center gap-2 mt-1">
                                    <Badge variant="outline" className={cn(
                                        "text-[8px] px-1.5 py-0 h-3.5 border-none font-black uppercase tracking-widest",
                                        task.priority === 'URGENT' ? 'bg-red-500/10 text-red-500' :
                                        task.priority === 'HIGH' ? 'bg-orange-500/10 text-orange-500' :
                                        'bg-blue-500/10 text-blue-500'
                                    )}>
                                        {task.priority}
                                    </Badge>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Timeline Data Area */}
                    <div className="relative shrink-0 flex-1">
                        {/* Day Columns BG */}
                        <div className="absolute inset-0 flex pointer-events-none">
                            {timeGrid.map((_, i) => (
                                <div key={i} className="border-r border-border/5 h-full" style={{ width: dayWidth }} />
                            ))}
                        </div>

                        {/* Task Bars */}
                        {tasks.map((task, _rowIndex) => {
                            const tStart = task.startDate ? new Date(task.startDate) : (task.dueDate ? new Date(task.dueDate) : null);
                            const tEnd = task.dueDate ? new Date(task.dueDate) : (task.startDate ? new Date(task.startDate) : null);

                            if (!tStart || !tEnd) return <div key={task.id} className="h-[72px] border-b border-border/5" />;

                            const startOffset = differenceInDays(tStart, startDate);
                            const duration = Math.max(1, differenceInDays(tEnd, tStart) + 1);

                            return (
                                <div key={task.id} className="h-[72px] flex items-center border-b border-border/5 relative group/row hover:bg-muted/5 transition-colors">
                                    <div 
                                        className={cn(
                                            "h-10 rounded-2xl flex items-center px-4 gap-3 transition-all hover:scale-[1.01] hover:brightness-110 shadow-lg relative group overflow-hidden border",
                                            task.status === 'DONE' ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20 shadow-emerald-500/5" :
                                            task.status === 'IN_PROGRESS' ? "bg-blue-600 text-white border-blue-400/20 shadow-blue-500/20" :
                                            task.status === 'IN_REVIEW' ? "bg-amber-500/10 text-amber-600 border-amber-500/20" :
                                            "bg-slate-500/10 text-slate-600 border-slate-500/20"
                                        )}
                                        style={{ 
                                            position: 'absolute',
                                            left: (startOffset * dayWidth) + 8,
                                            width: (duration * dayWidth) - 16,
                                            minWidth: 44
                                        }}
                                    >
                                        <Avatar className="h-6 w-6 border-2 border-background/20 shrink-0 shadow-sm">
                                            <AvatarImage src={task.assignee?.image || ""} />
                                            <AvatarFallback className="text-[8px] font-black bg-background/50">{task.assignee?.name?.substring(0,2).toUpperCase()}</AvatarFallback>
                                        </Avatar>
                                        
                                        <div className="flex flex-col min-w-0 overflow-hidden">
                                            <span className="text-[10px] font-black tracking-tight whitespace-nowrap truncate leading-tight">
                                                {task.title}
                                            </span>
                                            {duration > 1 && (
                                                <span className="text-[8px] font-bold opacity-70 uppercase tracking-tighter">
                                                    {duration} days
                                                </span>
                                            )}
                                        </div>

                                        {/* Glow effect for active tasks */}
                                        {task.status === 'IN_PROGRESS' && (
                                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer pointer-events-none" />
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
}

