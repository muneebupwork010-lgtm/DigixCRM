"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    Calendar, 
    Clock, 
    User, 
    X, 
    BarChart3, 
    CheckCircle2, 
    AlertCircle,
    Layout,
    AlignLeft,
    Type,
    ExternalLink,
    Download,
    Trash2,
    AlertTriangle,
    Loader2,
    Flag
} from "lucide-react";
import { TaskActivityFeed } from "./task-activity-feed";
import { TimeTrackingSection } from "./time-tracking-section";
import { SubTasksSection } from "./sub-tasks-section";
import { TaskAttachments } from "./task-attachments";
import { TaskTags } from "./task-tags";
import { TaskWatchers } from "./task-watchers";
import { TaskStatus, Priority } from "@/generated/prisma/client";
import { updateTask, deleteTask } from "@/lib/actions/tasks";
import { getProjectMilestones } from "@/lib/actions/milestones";
import { toast } from "sonner";
import { TaskStatusEmailDialog } from "./task-status-email-dialog";
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Check, ChevronsUpDown, Search } from "lucide-react";
import { cn } from "@/lib/utils";

const TITLE_MAX_LENGTH = 100;
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface TaskSheetProps {
    task: any;
    isOpen: boolean;
    onClose: () => void;
    users: { id: string; name: string | null; image?: string | null }[];
    currentUser?: { id: string; role: string };
}

// Multi-assignee popover with search
function AssigneeMultiSelect({
    users,
    selectedIds,
    onChange,
    disabled,
}: {
    users: { id: string; name: string | null; image?: string | null }[];
    selectedIds: string[];
    onChange: (ids: string[]) => void;
    disabled?: boolean;
}) {
    const [open, setOpen] = useState(false);
    const [search, setSearch] = useState("");

    const filtered = users.filter((u) =>
        (u.name || "").toLowerCase().includes(search.toLowerCase())
    );

    const toggle = (id: string) => {
        if (selectedIds.includes(id)) {
            onChange(selectedIds.filter((x) => x !== id));
        } else {
            onChange([...selectedIds, id]);
        }
    };

    const selectedUsers = users.filter((u) => selectedIds.includes(u.id));

    return (
        <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
                <button
                    type="button"
                    disabled={disabled}
                    className="w-full rounded-2xl border border-border/50 bg-background/50 backdrop-blur-sm shadow-sm h-12 px-4 flex items-center justify-between text-left hover:bg-muted/30 transition-all focus:ring-2 focus:ring-primary/20 outline-none group disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent"
                >
                    <div className="flex items-center gap-3">
                        {selectedUsers.length === 0 ? (
                            <div className="flex items-center gap-2">
                                <div className="h-8 w-8 rounded-full border border-dashed border-border/60 flex items-center justify-center bg-muted/10 group-hover:bg-muted/30 transition-colors">
                                    <User className="w-3.5 h-3.5 text-muted-foreground/50" />
                                </div>
                                <span className="text-xs font-bold text-muted-foreground/60">Assign to...</span>
                            </div>
                        ) : selectedUsers.length === 1 ? (
                            <div className="flex items-center gap-2">
                                <Avatar className="h-8 w-8 ring-2 ring-background shadow-sm">
                                    <AvatarImage src={selectedUsers[0].image || ""} />
                                    <AvatarFallback className="text-[10px] font-black">{selectedUsers[0].name?.substring(0, 2).toUpperCase()}</AvatarFallback>
                                </Avatar>
                                <span className="text-xs font-black truncate max-w-[120px]">{selectedUsers[0].name}</span>
                            </div>
                        ) : (
                            <div className="flex items-center gap-2">
                                <div className="flex items-center -space-x-3">
                                    {selectedUsers.slice(0, 3).map((u, i) => (
                                        <Avatar key={u.id} className="h-8 w-8 ring-2 ring-background shadow-sm relative" style={{ zIndex: 10 - i }}>
                                            <AvatarImage src={u.image || ""} />
                                            <AvatarFallback className="text-[10px] font-black">{u.name?.substring(0, 2).toUpperCase()}</AvatarFallback>
                                        </Avatar>
                                    ))}
                                    {selectedUsers.length > 3 && (
                                        <div className="h-8 w-8 rounded-full bg-primary/10 border border-primary/20 text-primary flex items-center justify-center text-[10px] font-black ring-2 ring-background relative z-0">
                                            +{selectedUsers.length - 3}
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                    <ChevronsUpDown className="h-4 w-4 shrink-0 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
                </button>
            </PopoverTrigger>
            <PopoverContent className="w-[260px] p-0 rounded-2xl shadow-2xl border-border/50" align="start">
                <div className="p-2 border-b border-border/30">
                    <div className="flex items-center gap-2 px-2 py-1 rounded-xl bg-muted/30">
                        <Search className="w-3.5 h-3.5 text-muted-foreground/50" />
                        <input
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            placeholder="Search members..."
                            className="flex-1 bg-transparent border-none outline-none text-xs font-medium placeholder:text-muted-foreground/40"
                            autoFocus
                        />
                    </div>
                </div>
                <div className="max-h-[220px] overflow-y-auto p-1">
                    <button
                        type="button"
                        onClick={() => { onChange([]); setOpen(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold opacity-40 italic hover:bg-muted/50 transition-colors"
                    >
                        Unassigned
                    </button>
                    {filtered.map((u) => (
                        <button
                            key={u.id}
                            type="button"
                            onClick={() => toggle(u.id)}
                            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-primary/5 transition-colors cursor-pointer"
                        >
                            <div className={cn(
                                "flex h-4 w-4 items-center justify-center rounded-sm border border-primary shrink-0",
                                selectedIds.includes(u.id) ? "bg-primary text-primary-foreground" : "opacity-40"
                            )}>
                                {selectedIds.includes(u.id) && <Check className="h-3 w-3" />}
                            </div>
                            <Avatar className="h-5 w-5">
                                <AvatarImage src={u.image || ""} />
                                <AvatarFallback className="text-[7px]">{u.name?.substring(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs font-bold">{u.name}</span>
                        </button>
                    ))}
                    {filtered.length === 0 && (
                        <div className="px-3 py-4 text-center text-xs text-muted-foreground/50">No members found</div>
                    )}
                </div>
            </PopoverContent>
        </Popover>
    );
}

export function TaskSheet({ task, isOpen, onClose, users, currentUser }: TaskSheetProps) {
    const [title, setTitle] = useState(task?.title || "");
    const [description, setDescription] = useState(task?.description || "");
    const [status, setStatus] = useState<TaskStatus>(task?.status || "TODO");
    const [priority, setPriority] = useState<Priority>(task?.priority || "MEDIUM");
    const [assigneeId, setAssigneeId] = useState<string | null>(task?.assigneeId || null);
    const [assigneeIds, setAssigneeIds] = useState<string[]>(() => {
        const ids: string[] = [];
        if (task?.assigneeId) ids.push(task.assigneeId);
        // Include watchers as additional assignees for display
        if (task?.watchers) {
            task.watchers.forEach((w: any) => {
                if (!ids.includes(w.id)) ids.push(w.id);
            });
        }
        return ids;
    });
    const [startDate, setStartDate] = useState<string>(task?.startDate ? new Date(task.startDate).toISOString().split('T')[0] : "");
    const [dueDate, setDueDate] = useState<string>(task?.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : "");
    const [saving, setSaving] = useState(false);
    const [attachments, setAttachments] = useState<any[]>(task?.attachments || []);
    const [previewFile, setPreviewFile] = useState<any>(null);
    const [statusDialog, setStatusDialog] = useState<{isOpen: boolean, newStatus: TaskStatus | null}>({isOpen: false, newStatus: null});
    const [milestoneId, setMilestoneId] = useState<string | null>(task?.milestoneId || null);
    const [milestones, setMilestones] = useState<any[]>([]);
    const titleRef = useRef<HTMLTextAreaElement>(null);

    // Auto-resize title textarea
    const autoResizeTitle = useCallback(() => {
        const el = titleRef.current;
        if (el) {
            el.style.height = 'auto';
            el.style.height = el.scrollHeight + 'px';
        }
    }, []);

    useEffect(() => {
        autoResizeTitle();
    }, [title, autoResizeTitle]);

    // Fetch milestones for the project when the task sheet opens
    useEffect(() => {
        if (task?.projectId && isOpen) {
            getProjectMilestones(task.projectId).then(setMilestones).catch(() => setMilestones([]));
        }
    }, [task?.projectId, isOpen]);

    useEffect(() => {
        if (task) {
            setTitle(task.title);
            setDescription(task.description || "");
            setStatus(task.status);
            setPriority(task.priority);
            setAssigneeId(task.assigneeId);
            setMilestoneId(task.milestoneId || null);
            const ids: string[] = [];
            if (task.assigneeId) ids.push(task.assigneeId);
            if (task.watchers) {
                task.watchers.forEach((w: any) => {
                    if (!ids.includes(w.id)) ids.push(w.id);
                });
            }
            setAssigneeIds(ids);
            setStartDate(task.startDate ? new Date(task.startDate).toISOString().split('T')[0] : "");
            setDueDate(task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : "");
            setAttachments(task.attachments || []);
        }
    }, [task]);

    const handleUpdate = async (fields: any) => {
        if (!task) return;
        setSaving(true);
        const res = await updateTask(task.id, fields);
        if (res.success) {
            // Success
        } else {
            toast.error(res.error || "Failed to update task");
        }
        setSaving(false);
    };

    const handleDeleteTask = async () => {
        if (!task) return;
        try {
            const res = await deleteTask(task.id);
            if (res.success) {
                toast.success("Task deleted successfully");
                onClose(); // Close the sheet
            } else {
                toast.error(res.error || "Failed to delete task");
            }
        } catch (error) {
            toast.error("Something went wrong during deletion");
        }
    };

    if (!task) return null;
    
    const canEdit = currentUser?.role !== "CLIENT" || task.createdById === currentUser?.id;

    return (
        <>
            <Sheet open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <SheetContent 
                side="right" 
                className="w-full sm:max-w-[1100px] p-0 flex flex-col border-l border-border/40 shadow-2xl overflow-hidden bg-background"
                showCloseButton={false}
            >
                {/* Unified Header Strip */}
                <div className="h-14 border-b border-border/40 bg-muted/5 flex items-center justify-between px-6 shrink-0 z-50">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20">
                            <Layout className="w-4 h-4 text-primary" />
                        </div>
                        <h3 className="text-xs font-black uppercase tracking-widest text-foreground/70">Task Detail View</h3>
                    </div>
                    <button 
                        onClick={onClose}
                        className="w-9 h-9 rounded-xl bg-background border border-border/50 shadow-[0_4px_12px_-2px_rgba(15,23,42,0.12)] flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-primary/5 hover:border-primary/30 hover:shadow-[0_8px_20px_-4px_rgba(15,23,42,0.2)] transition-all active:scale-95 group"
                        title="Close (Esc)"
                    >
                        <X className="w-4 h-4 group-hover:rotate-90 transition-transform duration-300" />
                    </button>
                </div>

                <SheetHeader className="sr-only">
                    <SheetTitle>{title}</SheetTitle>
                    <SheetDescription>{description}</SheetDescription>
                </SheetHeader>

                {/* Main Content Area (Two Columns) */}
                <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
                    {/* Main Task Info (Left Scrollable) */}
                    <div className="flex-1 flex flex-col min-w-0 overflow-y-auto scrollbar-none bg-background border-r border-border/40">
                    {/* Header Banner - Contextual Color */}
                    <div className={cn(
                        "h-2 w-full",
                        status === 'DONE' ? 'bg-emerald-500' :
                        status === 'IN_PROGRESS' ? 'bg-blue-500' :
                        status === 'IN_REVIEW' ? 'bg-amber-500' : 'bg-slate-500'
                    )} />

                    <div className="p-8 space-y-8">
                        {/* Title & Context Block */}
                        <div className="space-y-6">
                            <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-3">
                                    <div className="p-2.5 rounded-xl bg-primary/5 border border-primary/10 shadow-sm">
                                        <Layout className="w-4 h-4 text-primary" />
                                    </div>
                                    <div className="flex flex-col">
                                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 leading-none mb-1">
                                            Project Execution
                                        </h4>
                                        <span className="text-xs font-bold text-foreground/80 leading-none">
                                            {task.project?.name || "Global Workspace"}
                                        </span>
                                    </div>
                                </div>

                                {canEdit && (
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-9 px-4 text-[10px] font-black uppercase tracking-widest text-red-500/60 hover:text-red-500 hover:bg-red-500/10 rounded-xl gap-2 transition-all border border-transparent hover:border-red-500/20"
                                        >
                                            <Trash2 className="w-3.5 h-3.5" />
                                            Delete Task
                                        </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent className="bg-background/95 backdrop-blur-2xl border-border/40 rounded-3xl p-8 max-w-[400px]">
                                        <AlertDialogHeader>
                                            <div className="w-12 h-12 rounded-2xl bg-red-500/10 flex items-center justify-center mb-4">
                                                <AlertTriangle className="w-6 h-6 text-red-500" />
                                            </div>
                                            <AlertDialogTitle className="text-xl font-black uppercase tracking-wider">Permanent Deletion?</AlertDialogTitle>
                                            <AlertDialogDescription className="text-xs font-medium text-muted-foreground/80 leading-relaxed pt-2">
                                                This will permanently remove the task, all its sub-tasks, comments, and <strong className="text-foreground">all associated media assets from R2 storage</strong>. This action cannot be undone.
                                            </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter className="mt-8 gap-3">
                                            <AlertDialogCancel className="rounded-2xl border-border/40 text-[10px] font-black uppercase tracking-widest h-11 flex-1">Cancel</AlertDialogCancel>
                                            <AlertDialogAction 
                                                onClick={handleDeleteTask}
                                                className="rounded-2xl bg-red-500 hover:bg-red-600 text-[10px] font-black uppercase tracking-widest h-11 flex-1 border-none shadow-lg shadow-red-500/20"
                                            >
                                                Confirm Delete
                                            </AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                                )}
                            </div>
                            
                            <div className="relative group/title">
                                {!canEdit && (
                                    <div 
                                        className="absolute inset-0 z-10 cursor-not-allowed" 
                                        onClick={(e) => { e.stopPropagation(); toast.error("You do not have permission to edit this task."); }}
                                    />
                                )}
                                <textarea
                                    ref={titleRef}
                                    value={title}
                                    onChange={(e) => {
                                        if (e.target.value.length <= TITLE_MAX_LENGTH) {
                                            setTitle(e.target.value);
                                        }
                                    }}
                                    onBlur={() => title !== task.title && handleUpdate({ title })}
                                    maxLength={TITLE_MAX_LENGTH}
                                    disabled={!canEdit}
                                    className="w-full text-5xl font-black bg-transparent border-none p-0 focus:ring-0 placeholder:text-muted-foreground/20 leading-[1.1] tracking-tighter resize-none overflow-hidden whitespace-pre-wrap break-words disabled:opacity-80"
                                    placeholder="Execution Name"
                                    rows={1}
                                />
                                <div className={cn(
                                    "text-[10px] font-black uppercase tracking-widest mt-1 transition-colors",
                                    title.length >= TITLE_MAX_LENGTH ? "text-red-500" :
                                    title.length >= TITLE_MAX_LENGTH * 0.8 ? "text-amber-500" :
                                    "text-muted-foreground/30"
                                )}>
                                    {title.length}/{TITLE_MAX_LENGTH}
                                </div>
                            </div>

                            {/* Integrated Tags & Watchers Context */}
                            <div className="flex flex-wrap items-start gap-12 pt-4">
                                <div className="space-y-3">
                                    <TaskTags taskId={task.id} initialTags={task.tags || []} />
                                </div>
                                <div className="space-y-3">
                                    <TaskWatchers taskId={task.id} initialWatchers={task.watchers || []} users={users} />
                                </div>
                            </div>
                        </div>

                        {/* Attribute Intelligence Grid */}
                        <div className="relative">
                            {!canEdit && (
                                <div 
                                    className="absolute inset-0 z-10 cursor-not-allowed" 
                                    onClick={(e) => { e.stopPropagation(); toast.error("You do not have permission to edit this task."); }}
                                />
                            )}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-12 gap-y-10 pb-12 border-b border-border/40">
                            <div className="space-y-4">
                                <Label icon={<CheckCircle2 />} label="Status" />
                                <Select value={status} onValueChange={(val: TaskStatus) => {
                                    // Open dialog instead of immediate update
                                    setStatusDialog({ isOpen: true, newStatus: val });
                                }} disabled={!canEdit}>
                                    <SelectTrigger className="w-full rounded-xl border-border/40 bg-muted/20 font-bold text-xs h-10 shadow-sm">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="TODO" className="text-xs font-bold">To Do</SelectItem>
                                        <SelectItem value="IN_PROGRESS" className="text-xs font-bold">In Progress</SelectItem>
                                        <SelectItem value="IN_REVIEW" className="text-xs font-bold">Review</SelectItem>
                                        <SelectItem value="DONE" className="text-xs font-bold">Completed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-4">
                                <Label icon={<AlertCircle />} label="Priority" />
                                <Select value={priority} onValueChange={(val: Priority) => {
                                    setPriority(val);
                                    handleUpdate({ priority: val });
                                }} disabled={!canEdit}>
                                    <SelectTrigger className="w-full rounded-xl border-border/40 bg-muted/20 font-bold text-xs h-10 shadow-sm">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="LOW" className="text-xs font-bold">Low</SelectItem>
                                        <SelectItem value="MEDIUM" className="text-xs font-bold">Medium</SelectItem>
                                        <SelectItem value="HIGH" className="text-xs font-bold text-amber-500">High</SelectItem>
                                        <SelectItem value="URGENT" className="text-xs font-bold text-red-500">Urgent</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-4">
                                <Label icon={<User />} label="Assignees" />
                                <AssigneeMultiSelect
                                    users={users}
                                    selectedIds={assigneeIds}
                                    disabled={!canEdit}
                                    onChange={async (ids) => {
                                        setAssigneeIds(ids);
                                        // First user = primary assignee, rest = watchers
                                        const primaryAssignee = ids.length > 0 ? ids[0] : null;
                                        setAssigneeId(primaryAssignee);
                                        
                                        const updateData: any = { assigneeId: primaryAssignee };
                                        updateData.watchers = { set: ids.slice(1).map(id => ({ id })) };
                                        
                                        await handleUpdate(updateData);
                                    }}
                                />
                            </div>

                            <div className="space-y-4">
                                <Label icon={<Clock />} label="Estimate (Hours)" />
                                <Input 
                                    type="number" 
                                    defaultValue={task.estimatedHours || 0}
                                    onBlur={(e) => handleUpdate({ estimatedHours: parseFloat(e.target.value) || 0 })}
                                    disabled={!canEdit}
                                    className="bg-muted/20 border-border/40 rounded-xl h-10 text-xs font-bold"
                                />
                            </div>

                            <div className="space-y-4">
                                <Label icon={<Calendar />} label="Start Date" />
                                <Input 
                                    type="date"
                                    value={startDate}
                                    onChange={(e) => setStartDate(e.target.value)}
                                    onBlur={() => startDate !== (task.startDate ? new Date(task.startDate).toISOString().split('T')[0] : "") && handleUpdate({ startDate: startDate ? new Date(startDate) : null })}
                                    disabled={!canEdit}
                                    className="bg-muted/20 border-border/40 rounded-xl h-10 text-xs font-bold"
                                />
                            </div>

                            <div className="space-y-4">
                                <Label icon={<Calendar />} label="Due Date" />
                                <Input 
                                    type="date"
                                    value={dueDate}
                                    onChange={(e) => setDueDate(e.target.value)}
                                    onBlur={() => dueDate !== (task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : "") && handleUpdate({ dueDate: dueDate ? new Date(dueDate) : null })}
                                    disabled={!canEdit}
                                    className="bg-muted/20 border-border/40 rounded-xl h-10 text-xs font-bold"
                                />
                            </div>

                            <div className="space-y-4">
                                <Label icon={<Flag />} label="Milestone" />
                                <Select 
                                    value={milestoneId || "__none__"} 
                                    disabled={!canEdit}
                                    onValueChange={(val) => {
                                        const newMilestoneId = val === "__none__" ? null : val;
                                        setMilestoneId(newMilestoneId);
                                        handleUpdate({ milestoneId: newMilestoneId });
                                    }}
                                >
                                    <SelectTrigger className="w-full rounded-xl border-border/40 bg-muted/20 font-bold text-xs h-10 shadow-sm">
                                        <SelectValue placeholder="No milestone" />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="__none__" className="text-xs font-bold text-muted-foreground">
                                            No Milestone
                                        </SelectItem>
                                        {milestones.map((m: any) => (
                                            <SelectItem key={m.id} value={m.id} className="text-xs font-bold">
                                                <div className="flex items-center gap-2">
                                                    <div className={cn(
                                                        "w-1.5 h-1.5 rounded-full shrink-0",
                                                        m.status === 'COMPLETED' ? 'bg-emerald-500' :
                                                        m.status === 'IN_PROGRESS' ? 'bg-blue-500' : 'bg-slate-400'
                                                    )} />
                                                    {m.title}
                                                </div>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            </div>
                        </div>

                        {/* Description */}
                        <div className="relative space-y-4">
                            {!canEdit && (
                                <div 
                                    className="absolute inset-0 z-10 cursor-not-allowed mt-6" 
                                    onClick={(e) => { e.stopPropagation(); toast.error("You do not have permission to edit this task."); }}
                                />
                            )}
                            <Label icon={<AlignLeft />} label="Description" />
                            <Textarea 
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                onBlur={() => description !== task.description && handleUpdate({ description })}
                                disabled={!canEdit}
                                className="min-h-[120px] max-h-[240px] overflow-y-auto bg-muted/20 border-border/40 rounded-2xl p-4 text-sm leading-relaxed focus:bg-background transition-colors disabled:opacity-80"
                                placeholder="Add more detailed context to this task..."
                                style={{ resize: 'vertical' }}
                            />
                        </div>

                        {/* Sub-Tasks (Moved to prominent full-width position) */}
                        <div className="relative pt-8 border-t border-border/40">
                            {!canEdit && (
                                <div 
                                    className="absolute inset-0 z-10 cursor-not-allowed" 
                                    onClick={(e) => { e.stopPropagation(); toast.error("You do not have permission to edit this task."); }}
                                />
                            )}
                            <div className={cn(!canEdit && "opacity-60 pointer-events-none")}>
                                <SubTasksSection taskId={task.id} projectId={task.projectId} mainTaskStatus={task.status} />
                            </div>
                        </div>

                        {/* Assets & Resources (Moved from sidebar to match Goal UI) */}
                        <div className="space-y-4 pt-6 border-t border-border/40">
                             <TaskAttachments 
                                taskId={task.id} 
                                initialAttachments={attachments} 
                                onPreview={setPreviewFile}
                                setAttachments={setAttachments}
                            />
                        </div>

                        {/* Time Tracking */}
                        <div className="relative pt-8 border-t border-border/40">
                            {!canEdit && (
                                <div 
                                    className="absolute inset-0 z-10 cursor-not-allowed" 
                                    onClick={(e) => { e.stopPropagation(); toast.error("You do not have permission to edit this task."); }}
                                />
                            )}
                            <div className={cn(!canEdit && "opacity-60 pointer-events-none")}>
                                <TimeTrackingSection taskId={task.id} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Activity & Metadata Feed (Right - 400px) */}
                <div className="w-full sm:w-[400px] flex-shrink-0 flex flex-col h-full border-l border-border/40 bg-muted/5">
                    <div className="flex-1 flex flex-col min-h-0">
                        {/* Activity Feed - Now takes full space and is wider */}
                        <div className="flex-1 min-h-0">
                            <TaskActivityFeed 
                                taskId={task.id} 
                                attachmentCount={attachments.length}
                                status={status}
                                priority={priority}
                                attachments={attachments}
                                onPreview={setPreviewFile}
                                setAttachments={setAttachments}
                            />
                        </div>
                    </div>
                    </div>
                </div>
            </SheetContent>
        </Sheet>

        {statusDialog.newStatus && (
            <TaskStatusEmailDialog
                isOpen={statusDialog.isOpen}
                onClose={() => setStatusDialog({ isOpen: false, newStatus: null })}
                task={task}
                newStatus={statusDialog.newStatus}
                users={users}
                onSuccess={(newStatus) => {
                    setStatus(newStatus);
                    setStatusDialog({ isOpen: false, newStatus: null });
                }}
            />
        )}

        {/* Global Preview Dialog */}
        <Dialog open={!!previewFile} onOpenChange={(open) => !open && setPreviewFile(null)}>
            <DialogContent className="max-w-5xl p-0 overflow-hidden bg-black/95 border-none shadow-2xl backdrop-blur-3xl">
                <DialogHeader className="sr-only">
                    <DialogTitle>{previewFile?.name}</DialogTitle>
                </DialogHeader>
                <div className="relative group">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className="absolute right-4 top-4 z-50 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white backdrop-blur-xl border border-white/10 transition-all opacity-0 group-hover:opacity-100"
                        onClick={() => setPreviewFile(null)}
                    >
                        <X className="h-5 w-5" />
                    </Button>

                    <div className="absolute left-1/2 -translate-x-1/2 bottom-8 z-50 flex items-center gap-3 p-2 rounded-2xl bg-white/10 backdrop-blur-2xl border border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-4 group-hover:translate-y-0">
                         <div className="px-4 py-2 border-r border-white/10 flex flex-col">
                            <span className="text-[10px] font-black uppercase text-white/40 tracking-widest">Filename</span>
                            <span className="text-xs font-bold text-white max-w-[200px] truncate">{previewFile?.name}</span>
                         </div>
                         <div className="flex items-center gap-2 px-2">
                            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-white hover:bg-white/10" asChild>
                                <a href={previewFile?.url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4" />
                                </a>
                            </Button>
                            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-white hover:bg-white/10" asChild>
                                <a href={previewFile?.url} download={previewFile?.name}>
                                    <Download className="h-4 w-4" />
                                </a>
                            </Button>
                         </div>
                    </div>

                    {previewFile?.fileType?.startsWith('image/') ? (
                        <div className="flex items-center justify-center min-h-[60vh] max-h-[90vh]">
                            <img src={previewFile.url} alt={previewFile.name} className="max-w-full max-h-[90vh] object-contain animate-in fade-in zoom-in duration-500" />
                        </div>
                    ) : previewFile?.fileType?.startsWith('video/') ? (
                        <div className="flex items-center justify-center min-h-[60vh] max-h-[90vh] bg-black">
                            <video src={previewFile.url} controls autoPlay className="max-w-full max-h-[90vh] shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700" />
                        </div>
                    ) : previewFile?.fileType === 'application/pdf' || previewFile?.name.endsWith('.pdf') ? (
                        <div className="w-full h-[85vh] bg-muted/20 animate-in fade-in duration-500">
                            <iframe 
                                src={`${previewFile.url}#toolbar=0`} 
                                className="w-full h-full border-none shadow-2xl"
                                title={previewFile.name}
                            />
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 animate-in fade-in duration-500">
                            <div className="w-24 h-24 rounded-3xl bg-primary/10 flex items-center justify-center ring-1 ring-primary/20">
                                {previewFile?.name.endsWith('.xlsx') || previewFile?.name.endsWith('.csv') ? (
                                    <BarChart3 className="w-12 h-12 text-primary" />
                                ) : (
                                    <X className="w-12 h-12 text-primary/40" />
                                )}
                            </div>
                            <div className="text-center space-y-2">
                                <h3 className="text-xl font-black uppercase tracking-widest text-white">Preview Unavailable</h3>
                                <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">This file type requires download to view</p>
                            </div>
                            <Button variant="secondary" className="rounded-2xl px-8 h-12 font-black uppercase tracking-widest bg-white text-black hover:bg-white/90 shadow-xl" asChild>
                                <a href={previewFile?.url} download={previewFile?.name}>
                                    Download File
                                </a>
                            </Button>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    </>
    );
}

function Label({ icon, label }: { icon: React.ReactNode, label: string }) {
    return (
        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground/50">
            {icon}
            {label}
        </div>
    );
}
