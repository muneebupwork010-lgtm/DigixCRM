"use client";

import { useState, useEffect } from "react";
import { getArchivedProjectTasks, updateTaskArchiveStatus } from "@/lib/actions/tasks";
import { 
    Archive, 
    ArchiveRestore, 
    Calendar, 
    User as UserIcon,
    Search,
    Filter,
    ArrowUpRight,
    MessageSquare,
    Clock
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";

interface TaskArchiveProps {
    projectId: string;
}

export function TaskArchive({ projectId }: TaskArchiveProps) {
    const [tasks, setTasks] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");

    const fetchTasks = async () => {
        setLoading(true);
        const data = await getArchivedProjectTasks(projectId);
        setTasks(data);
        setLoading(false);
    };

    useEffect(() => {
        fetchTasks();
    }, [projectId]);

    const handleReopen = async (taskId: string) => {
        const res = await updateTaskArchiveStatus(taskId, false);
        if (res.success) {
            toast.success("Task re-opened and moved back to board");
            setTasks(prev => prev.filter(t => t.id !== taskId));
        } else {
            toast.error(res.error || "Failed to re-open task");
        }
    };

    const filteredTasks = tasks.filter(t => 
        t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.assignee?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-64 gap-3">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Loading Archive...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-card p-4 rounded-[2rem] border border-border/40 shadow-sm">
                <div className="flex items-center gap-3 pl-2">
                    <div className="p-2 bg-emerald-500/10 rounded-xl">
                        <Archive className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                        <h3 className="text-sm font-black uppercase tracking-widest">Closed Tasks</h3>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">{tasks.length} tasks in repository</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <div className="relative flex-1 md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input 
                            placeholder="Search archive..." 
                            className="h-10 pl-10 rounded-xl bg-muted/50 border-none font-bold text-xs"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <Button variant="outline" size="icon" className="h-10 w-10 rounded-xl border-border/40 shrink-0">
                        <Filter className="w-4 h-4" />
                    </Button>
                </div>
            </div>

            <div className="grid gap-4">
                {filteredTasks.map((task) => (
                    <Card key={task.id} className="group overflow-hidden rounded-[1.5rem] border-border/40 bg-card/60 hover:bg-card hover:border-primary/20 transition-all duration-300 shadow-sm hover:shadow-md">
                        <CardContent className="p-0">
                            <div className="flex flex-col md:flex-row md:items-center p-5 gap-6">
                                <div className="flex-1 space-y-2">
                                    <div className="flex items-center gap-3">
                                        <Badge variant="outline" className="rounded-full px-2 py-0 text-[9px] font-black tracking-tighter uppercase border-none bg-emerald-500/10 text-emerald-500">
                                            Completed
                                        </Badge>
                                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-full">
                                            <Clock className="w-3 h-3" />
                                            Closed {task.closedAt ? format(new Date(task.closedAt), "MMM d, yyyy") : "N/A"}
                                        </div>
                                    </div>
                                    <h4 className="text-base font-bold group-hover:text-primary transition-colors">{task.title}</h4>
                                    <div className="flex items-center gap-4 text-[11px] font-bold text-muted-foreground">
                                        {task.assignee && (
                                            <div className="flex items-center gap-2">
                                                <Avatar className="h-5 w-5">
                                                    <AvatarImage src={task.assignee.image || ""} />
                                                    <AvatarFallback className="text-[7px]">{task.assignee.name?.substring(0,2).toUpperCase()}</AvatarFallback>
                                                </Avatar>
                                                <span>{task.assignee.name}</span>
                                            </div>
                                        )}
                                        {task.dueDate && (
                                            <div className="flex items-center gap-1.5">
                                                <Calendar className="w-3.5 h-3.5" />
                                                <span>Due {format(new Date(task.dueDate), "MMM d")}</span>
                                            </div>
                                        )}
                                        {task._count?.activities > 0 && (
                                            <div className="flex items-center gap-1.5">
                                                <MessageSquare className="w-3.5 h-3.5" />
                                                <span>{task._count.activities} updates</span>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="flex items-center gap-2 shrink-0 md:pl-6 md:border-l border-border/40">
                                    <Button 
                                        onClick={() => handleReopen(task.id)}
                                        variant="outline" 
                                        className="h-10 px-4 rounded-xl font-black text-[10px] uppercase tracking-widest gap-2 bg-primary/5 border-primary/20 hover:bg-primary hover:text-primary-foreground transition-all"
                                    >
                                        <ArchiveRestore className="w-4 h-4" />
                                        Re-open Task
                                    </Button>
                                    <Button variant="ghost" size="icon" className="h-10 w-10 text-muted-foreground hover:text-primary rounded-xl">
                                        <ArrowUpRight className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}

                {filteredTasks.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-20 bg-muted/20 border-2 border-dashed border-border/40 rounded-[2.5rem] text-center">
                        <div className="w-16 h-16 bg-muted/40 rounded-full flex items-center justify-center mb-4">
                            <Archive className="w-8 h-8 text-muted-foreground/30" />
                        </div>
                        <h3 className="text-lg font-black uppercase tracking-tight text-muted-foreground/50">Project Repository Empty</h3>
                        <p className="text-xs font-bold text-muted-foreground/40 mt-1 uppercase tracking-widest">Ongoing tasks will appear here once archived.</p>
                    </div>
                )}
            </div>
        </div>
    );
}
