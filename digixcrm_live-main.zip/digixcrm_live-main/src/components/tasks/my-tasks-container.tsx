"use client";

import { useState, useMemo } from "react";
import { 
    Search, 
    Filter, 
    ArrowUpDown, 
    Check,
    ChevronDown
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger,
    DropdownMenuSeparator,
    DropdownMenuCheckboxItem
} from "@/components/ui/dropdown-menu";
import { TaskTable } from "@/components/tasks/task-table";
import { cn } from "@/lib/utils";

interface MyTasksContainerProps {
    initialTasks: any[];
    users: any[];
}

export function MyTasksContainer({ initialTasks, users }: MyTasksContainerProps) {
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState<string[]>([]);
    const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

    const filteredAndSortedTasks = useMemo(() => {
        let result = [...initialTasks];

        // 1. Search Filter
        if (searchQuery) {
            result = result.filter(task => 
                task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                task.project?.name.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        // 2. Status Filter
        if (statusFilter.length > 0) {
            result = result.filter(task => statusFilter.includes(task.status));
        }

        // 3. Due Date Sorting
        result.sort((a, b) => {
            const dateA = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
            const dateB = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
            
            return sortOrder === "asc" ? dateA - dateB : dateB - dateA;
        });

        return result;
    }, [initialTasks, searchQuery, statusFilter, sortOrder]);

    const statuses = ["TODO", "IN_PROGRESS", "IN_REVIEW", "BLOCKED", "DONE", "CANCELED"];

    const toggleStatus = (status: string) => {
        setStatusFilter(prev => 
            prev.includes(status) 
                ? prev.filter(s => s !== status) 
                : [...prev, status]
        );
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-96 group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                    <Input 
                        placeholder="Find a specific task..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-11 rounded-2xl bg-card border-border/40 h-12 shadow-sm focus-visible:ring-primary/20 transition-all font-medium"
                    />
                </div>
                
                <div className="flex items-center gap-2 w-full sm:w-auto">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button 
                                variant="outline" 
                                className={cn(
                                    "rounded-2xl h-12 px-6 font-black uppercase tracking-widest text-[10px] border-border/40 bg-card hover:bg-muted transition-all gap-2",
                                    statusFilter.length > 0 && "border-primary text-primary bg-primary/5"
                                )}
                            >
                                <Filter className="w-4 h-4" />
                                Status {statusFilter.length > 0 && `(${statusFilter.length})`}
                                <ChevronDown className="w-3 h-3 opacity-50" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56 rounded-2xl border-border/40 p-2 shadow-2xl">
                            <div className="p-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground opacity-60">Filter by Status</div>
                            <DropdownMenuSeparator className="bg-border/40" />
                            {statuses.map((status) => (
                                <DropdownMenuCheckboxItem
                                    key={status}
                                    checked={statusFilter.includes(status)}
                                    onCheckedChange={() => toggleStatus(status)}
                                    className="rounded-xl font-bold text-xs py-2 focus:bg-primary/10 focus:text-primary cursor-pointer"
                                >
                                    {status.replace("_", " ")}
                                </DropdownMenuCheckboxItem>
                            ))}
                            {statusFilter.length > 0 && (
                                <>
                                    <DropdownMenuSeparator className="bg-border/40" />
                                    <DropdownMenuItem 
                                        onClick={() => setStatusFilter([])}
                                        className="rounded-xl font-black text-[10px] uppercase tracking-widest text-primary text-center justify-center py-2 cursor-pointer"
                                    >
                                        Clear Filters
                                    </DropdownMenuItem>
                                </>
                            )}
                        </DropdownMenuContent>
                    </DropdownMenu>

                    <Button 
                        variant="outline" 
                        onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
                        className={cn(
                            "rounded-2xl h-12 px-6 font-black uppercase tracking-widest text-[10px] border-border/40 bg-card hover:bg-muted transition-all gap-2",
                            sortOrder === "desc" && "border-amber-500/50 text-amber-500 bg-amber-500/5"
                        )}
                    >
                        <ArrowUpDown className="w-4 h-4" />
                        {sortOrder === "asc" ? "Due Date (nearest)" : "Due Date (latest)"}
                    </Button>
                </div>
            </div>

            {filteredAndSortedTasks.length > 0 ? (
                <TaskTable tasks={filteredAndSortedTasks} users={users} />
            ) : (
                <div className="py-20 bg-muted/10 border-2 border-dashed border-border/40 rounded-[3rem] flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-500">
                    <div className="p-4 rounded-3xl bg-card shadow-xl border border-border/40">
                        <Search className="w-8 h-8 text-muted-foreground opacity-20" />
                    </div>
                    <div className="space-y-1">
                        <h3 className="text-lg font-black tracking-tight">No tasks found</h3>
                        <p className="text-xs font-bold text-muted-foreground opacity-60 uppercase tracking-widest">Try adjusting your filters or search query</p>
                    </div>
                    <Button variant="ghost" className="font-bold text-primary" onClick={() => { setSearchQuery(""); setStatusFilter([]); }}>
                        Reset All Filters
                    </Button>
                </div>
            )}
        </div>
    );
}

