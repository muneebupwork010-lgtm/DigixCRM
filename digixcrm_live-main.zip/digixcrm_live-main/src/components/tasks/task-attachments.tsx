import { useState, useMemo } from "react";
import { 
    Paperclip, X, Download, Loader2, File, Image as ImageIcon, 
    LayoutGrid, Plus, Video, Play, ExternalLink, Search, Filter, 
    MoreVertical, Trash2, Eye, FileText, FileSpreadsheet, File as FileIcon,
    FileCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { uploadFile, deleteTaskAttachment } from "@/lib/actions/attachments";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function TaskAttachments({ 
    taskId, 
    initialAttachments = [], 
    onPreview,
    setAttachments 
}: { 
    taskId: string, 
    initialAttachments?: any[], 
    onPreview?: (file: any) => void,
    setAttachments?: React.Dispatch<React.SetStateAction<any[]>>
}) {
    const [isManagerOpen, setIsManagerOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [uploading, setUploading] = useState(false);
    const attachments = initialAttachments;

    const filteredAttachments = useMemo(() => {
        return attachments.filter(att => 
            att.name.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [attachments, searchQuery]);

    const stats = useMemo(() => {
        const images = attachments.filter(a => a.fileType?.startsWith('image/')).length;
        const videos = attachments.filter(a => a.fileType?.startsWith('video/')).length;
        const docs = attachments.length - images - videos;
        return { images, videos, docs, total: attachments.length };
    }, [attachments]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (file.size > 10 * 1024 * 1024) { 
            toast.error("File is too large. Limit is 10MB.");
            return;
        }

        setUploading(true);
        try {
            const formData = new FormData();
            formData.append("file", file);
            const res = await uploadFile(taskId, formData);
            
            if (res.success && res.attachment) {
                toast.success("File added to Media Hub");
                setAttachments?.(prev => [res.attachment, ...prev]);
            } else {
                toast.error(res.error || "Failed to upload file");
            }
        } catch (err: any) {
            toast.error("Something went wrong during upload");
        } finally {
            setUploading(false);
            e.target.value = ''; 
        }
    };

    const handleDelete = async (id: string) => {
        if (!window.confirm("Delete this asset permanently?")) return;
        const res = await deleteTaskAttachment(id);
        if (res.success) {
            setAttachments?.(prev => prev.filter(a => a.id !== id));
            toast.success("Asset removed");
        } else {
            toast.error(res.error || "Failed to remove asset");
        }
    };

    const getFileIcon = (fileType: string | null, fileName: string) => {
        if (fileType?.startsWith('image/')) return <ImageIcon className="w-5 h-5 text-primary/60" />;
        if (fileType?.startsWith('video/')) return <Video className="w-5 h-5 text-primary/60" />;
        if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) return <FileText className="w-5 h-5 text-red-500/60" />;
        if (fileType?.includes('sheet') || fileType?.includes('csv') || fileName.endsWith('.csv') || fileName.endsWith('.xlsx')) 
            return <FileSpreadsheet className="w-5 h-5 text-emerald-500/60" />;
        return <FileIcon className="w-5 h-5 text-primary/40" />;
    };

    return (
        <div className="space-y-4">
            {/* Compact Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2.5 rounded-xl ring-1 ring-primary/20">
                        <LayoutGrid className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                        <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground/80">
                            Media Hub
                        </h3>
                        <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[9px] font-bold text-muted-foreground/50 uppercase tracking-widest">
                                {stats.total} Total Resources
                            </span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <input 
                        type="file" 
                        id={`file-upload-hub-${taskId}`} 
                        className="hidden" 
                        onChange={handleFileChange}
                        disabled={uploading}
                    />
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 text-[9px] font-black uppercase tracking-widest gap-2 bg-muted/30 hover:bg-muted/50 rounded-lg transition-all"
                        onClick={() => setIsManagerOpen(true)}
                    >
                        Manage Assets
                        <div className="w-4 h-4 rounded-full bg-primary/10 text-primary flex items-center justify-center text-[8px]">
                            {stats.total}
                        </div>
                    </Button>
                    <div className="flex flex-col items-end gap-1">
                        <Button 
                            variant="secondary" 
                            size="sm" 
                            className="h-8 text-[9px] font-black uppercase tracking-widest gap-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 border-none transition-all"
                            onClick={() => document.getElementById(`file-upload-hub-${taskId}`)?.click()}
                            disabled={uploading}
                        >
                            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
                            Upload
                        </Button>
                        <span className="text-[7px] font-bold text-muted-foreground/30 uppercase tracking-[0.2em]">Max 10MB</span>
                    </div>
                </div>
            </div>

            {/* Quick Access Grid (Compact) */}
            {attachments.length > 0 ? (
                <div className="flex gap-2 overflow-x-auto scrollbar-none pb-2">
                    {attachments.slice(0, 6).map((att) => (
                        <div 
                            key={att.id} 
                            className="w-16 h-16 rounded-xl bg-muted/20 border border-border/40 shrink-0 overflow-hidden relative cursor-pointer group/item hover:ring-2 hover:ring-primary/40 transition-all shadow-sm"
                            onClick={() => onPreview?.(att)}
                        >
                            {att.fileType?.startsWith('image/') ? (
                                <img src={att.url} alt={att.name} className="w-full h-full object-cover transition-transform group-hover/item:scale-110" />
                            ) : att.fileType?.startsWith('video/') ? (
                                <div className="w-full h-full bg-slate-950 flex items-center justify-center relative">
                                    <Video className="w-4 h-4 text-white/40" />
                                    <Play className="absolute inset-0 m-auto w-3 h-3 text-white fill-white opacity-40" />
                                </div>
                            ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                    {getFileIcon(att.fileType, att.name)}
                                </div>
                            )}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/item:opacity-100 transition-opacity flex items-center justify-center">
                                <Eye className="w-4 h-4 text-white" />
                            </div>
                        </div>
                    ))}
                    {attachments.length > 6 && (
                        <button 
                            className="w-16 h-16 rounded-xl bg-muted/40 border border-border/40 flex flex-col items-center justify-center gap-1 hover:bg-muted/60 transition-all shrink-0"
                            onClick={() => setIsManagerOpen(true)}
                        >
                            <span className="text-xs font-black">+{attachments.length - 6}</span>
                            <span className="text-[7px] font-black uppercase tracking-tighter text-muted-foreground">More</span>
                        </button>
                    )}
                </div>
            ) : !uploading && (
                <div className="py-8 flex flex-col items-center justify-center border border-dashed border-border/40 rounded-2xl bg-muted/5 opacity-50">
                     <p className="text-[9px] font-black uppercase tracking-widest text-muted-foreground/40">No media assets found</p>
                </div>
            )}

            {/* Asset Manager Sheet */}
            <Sheet open={isManagerOpen} onOpenChange={setIsManagerOpen}>
                <SheetContent side="right" className="w-full sm:max-w-[500px] p-0 flex flex-col border-l border-border/40 bg-background/95 backdrop-blur-2xl">
                    <SheetHeader className="p-6 border-b border-border/40 bg-muted/5">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="bg-primary/10 p-3 rounded-2xl ring-1 ring-primary/20">
                                    <LayoutGrid className="w-5 h-5 text-primary" />
                                </div>
                                <div>
                                    <SheetTitle className="text-sm font-black uppercase tracking-[0.2em]">Asset Manager</SheetTitle>
                                    <SheetDescription className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60 mt-0.5">
                                        Manage all media & execution assets
                                    </SheetDescription>
                                </div>
                            </div>
                            <Button variant="ghost" size="icon" className="rounded-xl h-10 w-10" onClick={() => setIsManagerOpen(false)}>
                                <X className="h-5 w-5" />
                            </Button>
                        </div>

                        <div className="relative mt-6 group">
                            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/40 group-focus-within:text-primary transition-colors" />
                            <Input 
                                placeholder="Search by filename..." 
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10 h-11 bg-background/50 border-border/40 rounded-xl text-xs font-bold transition-all focus:ring-2 focus:ring-primary/20"
                            />
                        </div>
                    </SheetHeader>

                    <div className="flex-1 overflow-y-auto scrollbar-none p-6">
                        <Tabs defaultValue="all" className="w-full">
                            <TabsList className="grid grid-cols-4 w-full bg-muted/20 p-1 rounded-xl h-10 mb-6">
                                <TabsTrigger value="all" className="text-[9px] font-black uppercase tracking-widest rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">All</TabsTrigger>
                                <TabsTrigger value="images" className="text-[9px] font-black uppercase tracking-widest rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Images</TabsTrigger>
                                <TabsTrigger value="videos" className="text-[9px] font-black uppercase tracking-widest rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Videos</TabsTrigger>
                                <TabsTrigger value="docs" className="text-[9px] font-black uppercase tracking-widest rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Docs</TabsTrigger>
                            </TabsList>

                            {["all", "images", "videos", "docs"].map((tab) => (
                                <TabsContent key={tab} value={tab} className="mt-0 outline-none">
                                    <div className="grid grid-cols-1 gap-3">
                                        {filteredAttachments
                                            .filter(att => {
                                                if (tab === "images") return att.fileType?.startsWith('image/');
                                                if (tab === "videos") return att.fileType?.startsWith('video/');
                                                if (tab === "docs") return !att.fileType?.startsWith('image/') && !att.fileType?.startsWith('video/');
                                                return true;
                                            })
                                            .map((att) => (
                                                <div key={att.id} className="group relative flex items-center gap-4 p-3 rounded-2xl border border-border/40 bg-card hover:bg-muted/10 transition-all hover:shadow-md premium-shadow overflow-hidden">
                                                    <div 
                                                        className="w-14 h-14 rounded-xl bg-muted/40 flex items-center justify-center border border-border/40 shrink-0 overflow-hidden ring-2 ring-background relative cursor-pointer"
                                                        onClick={() => onPreview?.(att)}
                                                    >
                                                        {att.fileType?.startsWith('image/') ? (
                                                            <img src={att.url} alt={att.name} className="w-full h-full object-cover" />
                                                        ) : att.fileType?.startsWith('video/') ? (
                                                            <div className="relative w-full h-full flex items-center justify-center bg-slate-900/10">
                                                                <Video className="w-5 h-5 text-primary/60" />
                                                                <Play className="absolute inset-0 m-auto w-3 h-3 text-white fill-white opacity-40" />
                                                            </div>
                                                        ) : (
                                                            getFileIcon(att.fileType, att.name)
                                                        )}
                                                    </div>
                                                    
                                                    <div className="flex-1 min-w-0">
                                                        <p className="text-[11px] font-bold truncate text-foreground/80 pr-12">{att.name}</p>
                                                        <div className="flex items-center gap-3 mt-1.5">
                                                            <Badge variant="outline" className="px-1.5 py-0 text-[8px] font-black uppercase tracking-tighter bg-muted/30 border-none">
                                                                {(att.size / 1024 / 1024).toFixed(2)} MB
                                                            </Badge>
                                                            <span className="text-[9px] font-bold text-muted-foreground/30 uppercase tracking-widest">
                                                                {format(new Date(att.createdAt), "MMM d, h:mm a")}
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all z-10">
                                                        <Button variant="secondary" size="icon" className="h-8 w-8 rounded-lg bg-background border border-border/40 shadow-sm" asChild>
                                                            <a href={att.url} target="_blank" rel="noopener noreferrer" download>
                                                                <Download className="w-3.5 h-3.5 text-muted-foreground" />
                                                            </a>
                                                        </Button>
                                                        <Button 
                                                            variant="ghost" 
                                                            size="icon" 
                                                            className="h-8 w-8 rounded-lg text-red-500/50 hover:text-red-500 hover:bg-red-500/10" 
                                                            onClick={() => handleDelete(att.id)}
                                                        >
                                                            <Trash2 className="w-3.5 h-3.5" />
                                                        </Button>
                                                    </div>
                                                </div>
                                            ))}
                                        
                                        {filteredAttachments.length === 0 && (
                                            <div className="py-20 flex flex-col items-center justify-center opacity-40">
                                                <Search className="w-10 h-10 mb-4 text-muted-foreground/20" />
                                                <p className="text-[10px] font-black uppercase tracking-widest">No matching assets found</p>
                                            </div>
                                        )}
                                    </div>
                                </TabsContent>
                            ))}
                        </Tabs>
                    </div>

                    <div className="p-6 border-t border-border/40 bg-muted/5">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="p-3 rounded-2xl bg-background border border-border/40 flex flex-col gap-1">
                                <span className="text-[9px] font-black uppercase tracking-[0.1em] text-muted-foreground/50">Storage Used</span>
                                <span className="text-sm font-black">{(attachments.reduce((acc, a) => acc + a.size, 0) / 1024 / 1024).toFixed(1)} MB</span>
                            </div>
                            <div className="p-3 rounded-2xl bg-background border border-border/40 flex flex-col gap-1">
                                <span className="text-[9px] font-black uppercase tracking-[0.1em] text-muted-foreground/50">Total Assets</span>
                                <span className="text-sm font-black">{stats.total} Files</span>
                            </div>
                         </div>
                    </div>
                </SheetContent>
            </Sheet>
        </div>
    );
}
