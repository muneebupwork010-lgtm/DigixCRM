"use client";

import { useState, useCallback, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
    Upload, 
    FileSpreadsheet, 
    Sparkles, 
    Copy, 
    Check, 
    AlertCircle, 
    CheckCircle2, 
    ArrowRight,
    FileUp,
    Trash2,
    Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { bulkImportTasks } from "@/lib/actions/bulk-import";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

interface ImportTasksDialogProps {
    projectId: string;
    projectName: string;
}

interface ParsedTask {
    title: string;
    description: string;
    priority: string;
    status: string;
    milestone: string;
    dueDate: string;
    estimatedHours: number;
    tags: string[];
    valid: boolean;
    error?: string;
}

const AI_PROMPT_TEMPLATE = `You are a project planning assistant. Create a detailed project plan for: [DESCRIBE YOUR PROJECT HERE]

Output ONLY a CSV table with these exact columns (include the header row):
Title,Description,Priority,Status,Milestone,Due Date,Estimated Hours,Tags

Rules:
- Title: A clear, actionable task name
- Description: Brief 1-sentence description of what this task involves
- Priority: LOW, MEDIUM, HIGH, or URGENT
- Status: always TODO
- Milestone: Group related tasks under a phase name (e.g. "Phase 1 - Discovery")
- Due Date: YYYY-MM-DD format (use realistic dates starting from today)
- Estimated Hours: whole number
- Tags: comma-separated keywords inside double quotes (e.g. "design,frontend")
- Include 10-30 tasks covering the full project lifecycle
- Make sure tasks are in logical execution order

Important: Output ONLY the CSV data, no markdown formatting, no code blocks, no explanation text.`;

// Parse CSV handling quoted fields properly
function parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = "";
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = "";
        } else {
            current += char;
        }
    }
    result.push(current.trim());
    return result;
}

function parseCSV(csvText: string): ParsedTask[] {
    const lines = csvText.trim().split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) return []; // Need header + at least 1 data row

    // Skip header row
    const header = lines[0].toLowerCase();
    const startIndex = header.includes("title") ? 1 : 0;

    return lines.slice(startIndex).map(line => {
        const cols = parseCSVLine(line);
        const title = cols[0] || "";
        const description = cols[1] || "";
        const priority = (cols[2] || "MEDIUM").toUpperCase();
        const status = (cols[3] || "TODO").toUpperCase();
        const milestone = cols[4] || "";
        const dueDate = cols[5] || "";
        const estimatedHours = parseInt(cols[6]) || 0;
        const tagsRaw = cols[7] || "";
        const tags = tagsRaw
            .replace(/"/g, "")
            .split(",")
            .map(t => t.trim())
            .filter(Boolean);

        const valid = title.length > 0;
        const error = !valid ? "Missing task title" : undefined;

        return {
            title, description, priority, status, milestone,
            dueDate, estimatedHours, tags, valid, error
        };
    }).filter(t => t.title || t.description); // Skip completely empty rows
}

export function ImportTasksDialog({ projectId, projectName }: ImportTasksDialogProps) {
    const [open, setOpen] = useState(false);
    const [csvText, setCsvText] = useState("");
    const [parsedTasks, setParsedTasks] = useState<ParsedTask[]>([]);
    const [step, setStep] = useState<"input" | "preview">("input");
    const [importing, setImporting] = useState(false);
    const [copied, setCopied] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const router = useRouter();

    const handleCopyPrompt = () => {
        navigator.clipboard.writeText(AI_PROMPT_TEMPLATE);
        setCopied(true);
        toast.success("AI prompt copied to clipboard!");
        setTimeout(() => setCopied(false), 2000);
    };

    const handleParseCSV = useCallback(() => {
        const tasks = parseCSV(csvText);
        if (tasks.length === 0) {
            toast.error("No tasks found. Make sure your CSV has a header row and data rows.");
            return;
        }
        setParsedTasks(tasks);
        setStep("preview");
    }, [csvText]);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!file.name.endsWith(".csv")) {
            toast.error("Please upload a .csv file");
            return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
            const text = event.target?.result as string;
            setCsvText(text);
            const tasks = parseCSV(text);
            if (tasks.length === 0) {
                toast.error("No tasks found in the uploaded file.");
                return;
            }
            setParsedTasks(tasks);
            setStep("preview");
        };
        reader.readAsText(file);
    };

    const handleImport = async () => {
        const validTasks = parsedTasks.filter(t => t.valid);
        if (validTasks.length === 0) {
            toast.error("No valid tasks to import");
            return;
        }

        setImporting(true);
        const result = await bulkImportTasks(projectId, validTasks.map(t => ({
            title: t.title,
            description: t.description,
            priority: t.priority,
            status: t.status,
            milestone: t.milestone,
            dueDate: t.dueDate,
            estimatedHours: t.estimatedHours,
            tags: t.tags
        })));

        setImporting(false);

        if (result.success) {
            toast.success(`Imported ${result.tasksCreated} tasks${result.milestonesCreated ? ` and ${result.milestonesCreated} milestones` : ""}!`);
            setOpen(false);
            resetState();
            router.refresh();
        } else {
            toast.error(result.error || "Import failed");
        }
    };

    const resetState = () => {
        setCsvText("");
        setParsedTasks([]);
        setStep("input");
    };

    const validCount = parsedTasks.filter(t => t.valid).length;
    const invalidCount = parsedTasks.filter(t => !t.valid).length;
    const milestones = [...new Set(parsedTasks.map(t => t.milestone).filter(Boolean))];

    return (
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetState(); }}>
            <DialogTrigger asChild>
                <Button variant="outline" className="gap-2 rounded-xl border-dashed border-primary/30 text-primary hover:bg-primary/5 hover:border-primary/50 font-bold text-xs uppercase tracking-wider">
                    <Upload className="w-4 h-4" />
                    Bulk Import
                </Button>
            </DialogTrigger>

            <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto rounded-2xl">
                <DialogHeader>
                    <DialogTitle className="text-xl font-black flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-primary/10">
                            <FileSpreadsheet className="w-5 h-5 text-primary" />
                        </div>
                        Import Tasks into {projectName}
                    </DialogTitle>
                    <DialogDescription className="text-sm text-muted-foreground">
                        Bulk import tasks from a CSV file or paste output from ChatGPT, Claude, or Gemini.
                    </DialogDescription>
                </DialogHeader>

                {step === "input" ? (
                    <Tabs defaultValue="ai" className="mt-4">
                        <TabsList className="w-full bg-muted/30 p-1 rounded-xl h-12 gap-1">
                            <TabsTrigger value="ai" className="flex-1 rounded-lg gap-2 data-[state=active]:bg-card data-[state=active]:shadow text-xs font-black uppercase tracking-widest">
                                <Sparkles className="w-3.5 h-3.5" />
                                AI Template
                            </TabsTrigger>
                            <TabsTrigger value="paste" className="flex-1 rounded-lg gap-2 data-[state=active]:bg-card data-[state=active]:shadow text-xs font-black uppercase tracking-widest">
                                <FileSpreadsheet className="w-3.5 h-3.5" />
                                Paste CSV
                            </TabsTrigger>
                            <TabsTrigger value="upload" className="flex-1 rounded-lg gap-2 data-[state=active]:bg-card data-[state=active]:shadow text-xs font-black uppercase tracking-widest">
                                <FileUp className="w-3.5 h-3.5" />
                                Upload File
                            </TabsTrigger>
                        </TabsList>

                        {/* AI Template Tab */}
                        <TabsContent value="ai" className="mt-6 space-y-6">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <div className="space-y-1">
                                        <h3 className="text-sm font-black uppercase tracking-widest">Step 1: Copy this prompt</h3>
                                        <p className="text-xs text-muted-foreground">Paste it into ChatGPT, Claude, or Gemini</p>
                                    </div>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={handleCopyPrompt}
                                        className="gap-2 rounded-xl font-bold"
                                    >
                                        {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                                        {copied ? "Copied!" : "Copy Prompt"}
                                    </Button>
                                </div>

                                <div className="relative">
                                    <pre className="bg-muted/30 border border-border/50 rounded-xl p-4 text-xs font-mono text-muted-foreground whitespace-pre-wrap max-h-[200px] overflow-y-auto leading-relaxed">
                                        {AI_PROMPT_TEMPLATE}
                                    </pre>
                                </div>

                                <div className="flex items-center gap-3 text-xs text-muted-foreground bg-primary/5 p-4 rounded-xl border border-primary/10">
                                    <Sparkles className="w-4 h-4 text-primary shrink-0" />
                                    <span><strong>Step 2:</strong> After the AI generates the CSV output, switch to the <strong>"Paste CSV"</strong> tab and paste the result there.</span>
                                </div>
                            </div>
                        </TabsContent>

                        {/* Paste CSV Tab */}
                        <TabsContent value="paste" className="mt-6 space-y-4">
                            <div className="space-y-2">
                                <h3 className="text-sm font-black uppercase tracking-widest">Paste your CSV data</h3>
                                <p className="text-xs text-muted-foreground">Each row becomes a task. Include the header row.</p>
                            </div>
                            <textarea
                                value={csvText}
                                onChange={(e) => setCsvText(e.target.value)}
                                placeholder={`Title,Description,Priority,Status,Milestone,Due Date,Estimated Hours,Tags\nDesign Homepage,Create wireframes,HIGH,TODO,Phase 1,2026-05-15,8,"design,ui"\nBuild API,REST endpoints,URGENT,TODO,Phase 2,2026-05-20,16,"backend"`}
                                className="w-full h-[240px] bg-muted/20 border border-border/50 rounded-xl p-4 text-sm font-mono resize-none outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/40 transition-all placeholder:text-muted-foreground/40"
                            />
                            <div className="flex items-center justify-between">
                                <p className="text-xs text-muted-foreground">
                                    {csvText.trim().split('\n').length - 1} rows detected
                                </p>
                                <Button
                                    onClick={handleParseCSV}
                                    disabled={!csvText.trim()}
                                    className="gap-2 rounded-xl font-bold"
                                >
                                    Parse & Preview
                                    <ArrowRight className="w-4 h-4" />
                                </Button>
                            </div>
                        </TabsContent>

                        {/* Upload File Tab */}
                        <TabsContent value="upload" className="mt-6 space-y-4">
                            <input
                                ref={fileInputRef}
                                type="file"
                                accept=".csv"
                                onChange={handleFileUpload}
                                className="hidden"
                            />
                            <div
                                onClick={() => fileInputRef.current?.click()}
                                className="flex flex-col items-center justify-center gap-4 p-12 border-2 border-dashed border-border/60 rounded-2xl hover:border-primary/40 hover:bg-primary/5 transition-all cursor-pointer group"
                            >
                                <div className="p-4 rounded-2xl bg-muted/30 group-hover:bg-primary/10 transition-colors">
                                    <Upload className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
                                </div>
                                <div className="text-center space-y-1">
                                    <p className="text-sm font-black">Click to upload a CSV file</p>
                                    <p className="text-xs text-muted-foreground">Supports .csv files from Excel, Google Sheets, etc.</p>
                                </div>
                            </div>
                        </TabsContent>
                    </Tabs>
                ) : (
                    /* Preview Step */
                    <div className="mt-4 space-y-6">
                        {/* Summary Bar */}
                        <div className="flex items-center justify-between p-4 bg-muted/20 rounded-xl border border-border/40">
                            <div className="flex items-center gap-4">
                                <Badge className="bg-emerald-500/10 text-emerald-600 border-none font-black text-xs gap-1">
                                    <CheckCircle2 className="w-3 h-3" />
                                    {validCount} valid
                                </Badge>
                                {invalidCount > 0 && (
                                    <Badge className="bg-red-500/10 text-red-500 border-none font-black text-xs gap-1">
                                        <AlertCircle className="w-3 h-3" />
                                        {invalidCount} errors
                                    </Badge>
                                )}
                                {milestones.length > 0 && (
                                    <Badge variant="outline" className="font-bold text-xs gap-1">
                                        {milestones.length} milestones
                                    </Badge>
                                )}
                            </div>
                            <Button variant="ghost" size="sm" onClick={() => { setStep("input"); setParsedTasks([]); }} className="text-xs font-bold gap-1">
                                <Trash2 className="w-3 h-3" />
                                Reset
                            </Button>
                        </div>

                        {/* Task Preview Table */}
                        <div className="overflow-x-auto rounded-xl border border-border/40">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="bg-muted/30 border-b border-border/40">
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground w-8">#</th>
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Title</th>
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Priority</th>
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Milestone</th>
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Due Date</th>
                                        <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-muted-foreground">Hours</th>
                                        <th className="px-4 py-3 text-center text-[10px] font-black uppercase tracking-widest text-muted-foreground w-12">✓</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border/30">
                                    {parsedTasks.map((task, i) => (
                                        <tr key={i} className={cn(
                                            "transition-colors",
                                            !task.valid ? "bg-red-500/5" : "hover:bg-muted/20"
                                        )}>
                                            <td className="px-4 py-3 text-xs text-muted-foreground font-bold">{i + 1}</td>
                                            <td className="px-4 py-3">
                                                <div className="space-y-0.5">
                                                    <p className="font-bold text-xs truncate max-w-[200px]">{task.title || "—"}</p>
                                                    {task.description && <p className="text-[10px] text-muted-foreground truncate max-w-[200px]">{task.description}</p>}
                                                </div>
                                            </td>
                                            <td className="px-4 py-3">
                                                <Badge variant="outline" className={cn(
                                                    "text-[9px] font-black uppercase px-2 py-0 rounded-full border-none",
                                                    task.priority === "URGENT" ? "bg-red-500/10 text-red-500" :
                                                    task.priority === "HIGH" ? "bg-amber-500/10 text-amber-500" :
                                                    task.priority === "MEDIUM" ? "bg-blue-500/10 text-blue-500" :
                                                    "bg-slate-500/10 text-slate-500"
                                                )}>
                                                    {task.priority}
                                                </Badge>
                                            </td>
                                            <td className="px-4 py-3 text-xs font-bold text-muted-foreground truncate max-w-[120px]">{task.milestone || "—"}</td>
                                            <td className="px-4 py-3 text-xs font-bold text-muted-foreground">{task.dueDate || "—"}</td>
                                            <td className="px-4 py-3 text-xs font-bold text-muted-foreground">{task.estimatedHours || "—"}</td>
                                            <td className="px-4 py-3 text-center">
                                                {task.valid ? (
                                                    <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" />
                                                ) : (
                                                    <div title={task.error} className="mx-auto flex justify-center">
                                                        <AlertCircle className="w-4 h-4 text-red-500" />
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Import Button */}
                        <div className="flex items-center justify-between pt-2">
                            <p className="text-xs text-muted-foreground">
                                Ready to import <strong>{validCount}</strong> tasks{milestones.length > 0 && <> across <strong>{milestones.length}</strong> milestones</>}
                            </p>
                            <Button
                                onClick={handleImport}
                                disabled={importing || validCount === 0}
                                className="gap-2 rounded-xl font-bold px-6"
                            >
                                {importing ? (
                                    <>
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                        Importing...
                                    </>
                                ) : (
                                    <>
                                        <CheckCircle2 className="w-4 h-4" />
                                        Import {validCount} Tasks
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}
