"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TaskStatus } from "@/generated/prisma/client";
import { updateTaskStatusWithEmail } from "@/lib/actions/tasks";
import { toast } from "sonner";
import { Loader2, Mail } from "lucide-react";

interface TaskStatusEmailDialogProps {
    isOpen: boolean;
    onClose: () => void;
    task: any;
    newStatus: TaskStatus;
    users: { id: string; name: string | null; email?: string | null; image?: string | null }[];
    onSuccess: (newStatus: TaskStatus) => void;
}

export function TaskStatusEmailDialog({ isOpen, onClose, task, newStatus, users, onSuccess }: TaskStatusEmailDialogProps) {
    const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (isOpen) {
            // Pre-select all users by default
            setSelectedUserIds(users.map(u => u.id));
        }
    }, [isOpen, users]);

    if (!task) return null;

    const toggleUser = (id: string) => {
        setSelectedUserIds(prev => 
            prev.includes(id) ? prev.filter(userId => userId !== id) : [...prev, id]
        );
    };

    const getEmailPreview = () => {
        switch (newStatus) {
            case "IN_PROGRESS":
                return {
                    subject: `🚀 Task In Progress: ${task.title}`,
                    body: `The gears are turning! This task is now In Progress and being actively worked on. Let's keep the momentum going!`
                };
            case "IN_REVIEW":
                return {
                    subject: `👀 Ready for Review: ${task.title}`,
                    body: `This task is up for review. Your feedback and approval are appreciated to move it across the finish line!`
                };
            case "BLOCKED":
                return {
                    subject: `🛑 Roadblock Ahead: ${task.title}`,
                    body: `This task is currently blocked. We need to unblock it together to keep the project on track. Please check if you can help.`
                };
            case "DONE":
                return {
                    subject: `🎉 Task Completed: ${task.title}`,
                    body: `Woohoo! This task has been successfully completed. Great job team!`
                };
            default:
                return {
                    subject: `Task Status Updated: ${task.title}`,
                    body: `The status of this task has been updated to ${newStatus.replace("_", " ")}.`
                };
        }
    };

    const preview = getEmailPreview();

    const handleConfirm = async (sendEmail: boolean) => {
        setIsSubmitting(true);
        try {
            const res = await updateTaskStatusWithEmail(task.id, newStatus, sendEmail ? selectedUserIds : []);
            if (res.success) {
                toast.success(sendEmail ? "Status updated and emails sent!" : "Status updated successfully");
                onSuccess(newStatus);
                onClose();
            } else {
                toast.error(res.error || "Failed to update status");
            }
        } catch (error) {
            toast.error("Something went wrong");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && !isSubmitting && onClose()}>
            <DialogContent className="sm:max-w-[500px] border-border/40 rounded-3xl p-6 bg-background">
                <DialogHeader className="mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                        <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <DialogTitle className="text-xl font-black uppercase tracking-wider">
                        Notify Team
                    </DialogTitle>
                    <DialogDescription className="text-xs font-medium text-muted-foreground pt-1">
                        You are changing the status to <strong className="text-foreground">{newStatus.replace("_", " ")}</strong>. 
                        Select the team members you want to notify via email.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-6">
                    <div className="bg-muted/30 p-4 rounded-2xl border border-border/50">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-2">Email Preview</h4>
                        <div className="space-y-2">
                            <p className="text-sm font-bold truncate">Subject: {preview.subject}</p>
                            <p className="text-xs text-muted-foreground leading-relaxed">{preview.body}</p>
                        </div>
                    </div>

                    <div className="space-y-3">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Select Recipients</h4>
                        <div className="max-h-[160px] overflow-y-auto space-y-2 pr-2 scrollbar-none">
                            {users.map(user => (
                                <div key={user.id} className="flex items-center space-x-3 p-2 hover:bg-muted/50 rounded-xl transition-colors cursor-pointer" onClick={() => toggleUser(user.id)}>
                                    <Checkbox 
                                        id={`user-${user.id}`} 
                                        checked={selectedUserIds.includes(user.id)}
                                        onCheckedChange={() => toggleUser(user.id)}
                                    />
                                    <label htmlFor={`user-${user.id}`} className="flex items-center gap-3 flex-1 cursor-pointer">
                                        <Avatar className="h-6 w-6">
                                            <AvatarImage src={user.image || ""} />
                                            <AvatarFallback className="text-[8px] font-black">{user.name?.substring(0, 2).toUpperCase()}</AvatarFallback>
                                        </Avatar>
                                        <span className="text-xs font-bold">{user.name}</span>
                                    </label>
                                </div>
                            ))}
                            {users.length === 0 && (
                                <div className="text-xs text-muted-foreground italic p-2">No team members found.</div>
                            )}
                        </div>
                    </div>
                </div>

                <DialogFooter className="mt-8 flex-col sm:flex-row gap-3">
                    <Button 
                        variant="outline" 
                        onClick={() => handleConfirm(false)}
                        disabled={isSubmitting}
                        className="rounded-xl h-11 text-xs font-bold w-full sm:w-auto"
                    >
                        Update Status Only
                    </Button>
                    <Button 
                        onClick={() => handleConfirm(true)}
                        disabled={isSubmitting || selectedUserIds.length === 0}
                        className="rounded-xl h-11 text-xs font-bold w-full sm:w-auto flex-1"
                    >
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Update & Send Emails
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
