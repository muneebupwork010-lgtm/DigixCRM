"use client";

import { useState } from "react";
import { Eye, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { updateTask } from "@/lib/actions/tasks";
import { toast } from "sonner";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";

interface User {
    id: string;
    name: string | null;
    image?: string | null;
}

export function TaskWatchers({ taskId, initialWatchers = [], users = [] }: { taskId: string, initialWatchers?: User[], users?: User[] }) {
    const [watchers, setWatchers] = useState<User[]>(initialWatchers);
    const [open, setOpen] = useState(false);

    const handleAddWatcher = async (user: User) => {
        if (watchers.find(w => w.id === user.id)) {
            setOpen(false);
            return;
        }

        const updatedWatchers = [...watchers, user];
        setWatchers(updatedWatchers);
        setOpen(false);

        const res = await updateTask(taskId, { watchers: { connect: updatedWatchers.map(w => ({ id: w.id })) } });
        if (!res.success) {
            toast.error("Failed to add watcher");
            setWatchers(watchers); // revert
        }
    };

    const handleRemoveWatcher = async (userId: string) => {
        const updatedWatchers = watchers.filter(w => w.id !== userId);
        setWatchers(updatedWatchers);

        const res = await updateTask(taskId, { watchers: { set: updatedWatchers.map(w => ({ id: w.id })) } });
        if (!res.success) {
            toast.error("Failed to remove watcher");
            setWatchers(watchers); // revert
        }
    };

    // Filter out users who are already watching
    const availableUsers = users.filter(u => !watchers.find(w => w.id === u.id));

    return (
        <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 p-1.5 rounded-lg bg-muted/30 border border-border/40 text-[9px] font-black uppercase tracking-widest text-muted-foreground/60 shadow-sm">
                    <Eye className="w-3 h-3" />
                    Watchers
                </div>
                
                <Popover open={open} onOpenChange={setOpen}>
                    <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg hover:bg-primary/5 hover:text-primary transition-all">
                            <Plus className="w-3.5 h-3.5" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[240px] p-0 rounded-xl border-border/40 shadow-xl" align="start">
                        <Command>
                            <CommandInput placeholder="Search users..." className="text-xs font-bold" />
                            <CommandList>
                                <CommandEmpty className="text-xs py-4 text-center text-muted-foreground">No users found.</CommandEmpty>
                                <CommandGroup>
                                    {availableUsers.map((user) => (
                                        <CommandItem
                                            key={user.id}
                                            onSelect={() => handleAddWatcher(user)}
                                            className="text-xs font-bold cursor-pointer flex items-center gap-2 py-2"
                                        >
                                            <Avatar className="h-5 w-5">
                                                <AvatarImage src={user.image || ""} />
                                                <AvatarFallback className="text-[8px]">{user.name?.substring(0,2)}</AvatarFallback>
                                            </Avatar>
                                            {user.name}
                                        </CommandItem>
                                    ))}
                                </CommandGroup>
                            </CommandList>
                        </Command>
                    </PopoverContent>
                </Popover>
            </div>

            <div className="flex flex-wrap items-center gap-2">
                {watchers.length === 0 && (
                    <span className="text-xs font-bold text-muted-foreground/50 italic py-2">No watchers</span>
                )}
                {watchers.map(user => (
                    <div key={user.id} className="group relative flex items-center gap-2 bg-muted/20 border border-border/50 rounded-full pr-3 pl-1 py-1">
                        <Avatar className="h-5 w-5 border border-background">
                            <AvatarImage src={user.image || ""} />
                            <AvatarFallback className="text-[8px]">{user.name?.substring(0,2)}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs font-bold">{user.name}</span>
                        <X 
                            className="w-3 h-3 cursor-pointer text-muted-foreground hover:text-red-500 transition-colors ml-1" 
                            onClick={() => handleRemoveWatcher(user.id)}
                        />
                    </div>
                ))}
            </div>
        </div>
    );
}
