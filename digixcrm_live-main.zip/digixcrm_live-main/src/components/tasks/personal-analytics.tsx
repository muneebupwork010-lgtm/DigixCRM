"use client";

import { useMemo, useState, useEffect } from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    Cell,
    PieChart,
    Pie,
    AreaChart,
    Area,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
    Zap, 
    Clock, 
    CheckCircle2,
    Calendar,
    Target,
    ArrowUpRight,
    Layout
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format, subDays, isSameDay } from "date-fns";

interface PersonalAnalyticsProps {
    tasks: any[];
}

export function PersonalAnalytics({ tasks }: PersonalAnalyticsProps) {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => setIsMounted(true), []);
    // 1. Weekly Velocity (Personal)
    const velocityData = useMemo(() => {
        const last7Days = Array.from({ length: 7 }, (_, i) => {
            const date = subDays(new Date(), 6 - i);
            const count = tasks.filter(t => 
                t.status === "DONE" && t.updatedAt && isSameDay(new Date(t.updatedAt), date)
            ).length;

            return {
                date: format(date, "EEE"),
                completed: count
            };
        });
        return last7Days;
    }, [tasks]);

    // 2. Project Distribution
    const projectData = useMemo(() => {
        const counts: { [key: string]: number } = {};
        tasks.forEach(task => {
            const pName = task.project?.name || "Other";
            counts[pName] = (counts[pName] || 0) + 1;
        });

        return Object.entries(counts)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 5);
    }, [tasks]);

    // 3. Status Distribution
    const statusData = useMemo(() => {
        const counts = tasks.reduce((acc: any, task) => {
            acc[task.status] = (acc[task.status] || 0) + 1;
            return acc;
        }, {});

        return [
            { name: "To Do", value: counts["TODO"] || 0, color: "oklch(0.6 0.02 250)" },
            { name: "In Progress", value: counts["IN_PROGRESS"] || 0, color: "oklch(0.6 0.22 260)" },
            { name: "In Review", value: counts["IN_REVIEW"] || 0, color: "oklch(0.7 0.15 70)" },
            { name: "Done", value: counts["DONE"] || 0, color: "oklch(0.6 0.18 160)" },
        ].filter(d => d.value > 0);
    }, [tasks]);

    const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b'];

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-12">
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Personal Weekly Velocity */}
                <Card className="lg:col-span-2 border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden">
                    <CardHeader className="p-8 pb-0">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <CardTitle className="text-xl font-black">Performance Pulse</CardTitle>
                                <CardDescription className="text-xs font-bold opacity-60 uppercase tracking-widest">Tasks completed per day</CardDescription>
                            </div>
                            <Badge variant="outline" className="bg-primary/10 text-primary border-none font-black text-[10px] px-3 py-1">
                                Live Tracking
                            </Badge>
                        </div>
                    </CardHeader>
                    <CardContent className="p-8">
                        <div className="h-[280px] w-full">
                            {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <AreaChart data={velocityData}>
                                    <defs>
                                        <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" opacity={0.2} />
                                    <XAxis 
                                        dataKey="date" 
                                        stroke="var(--muted-foreground)" 
                                        fontSize={10} 
                                        fontWeight={800}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <YAxis 
                                        stroke="var(--muted-foreground)" 
                                        fontSize={10} 
                                        fontWeight={800}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <Tooltip 
                                        content={({ active, payload }) => {
                                            if (active && payload && payload.length) {
                                                return (
                                                    <div className="bg-background/95 backdrop-blur-xl border border-border/60 p-4 rounded-2xl shadow-2xl">
                                                        <p className="text-sm font-black">{payload[0].value} Tasks Completed</p>
                                                    </div>
                                                );
                                            }
                                            return null;
                                        }}
                                    />
                                    <Area 
                                        type="monotone" 
                                        dataKey="completed" 
                                        stroke="var(--primary)" 
                                        strokeWidth={4}
                                        fillOpacity={1} 
                                        fill="url(#colorValue)" 
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Status Breakdown */}
                <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card overflow-hidden">
                    <CardHeader className="p-8 pb-0">
                        <CardTitle className="text-xl font-black text-center">Workload Focus</CardTitle>
                        <CardDescription className="text-xs font-bold opacity-60 text-center uppercase tracking-widest">Tasks by priority & status</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8 flex flex-col items-center">
                        <div className="h-[200px] w-full">
                            {!isMounted ? <div className="w-full h-full bg-muted/20 animate-pulse rounded-2xl" /> : (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                                <PieChart>
                                    <Pie
                                        data={statusData}
                                        innerRadius={60}
                                        outerRadius={80}
                                        paddingAngle={10}
                                        dataKey="value"
                                        stroke="none"
                                    >
                                        {statusData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                            )}
                        </div>
                        <div className="space-y-3 w-full mt-6">
                            {statusData.map((s, i) => (
                                <div key={i} className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                                        <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{s.name}</span>
                                    </div>
                                    <span className="text-xs font-black">{s.value}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Project Heatmap / Contribution */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card p-8">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="p-3 rounded-2xl bg-primary/5 text-primary">
                            <Layout className="w-5 h-5" />
                        </div>
                        <div>
                            <h3 className="text-lg font-black tracking-tight">Project Contribution</h3>
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Where your time goes</p>
                        </div>
                    </div>
                    
                    <div className="space-y-6">
                        {projectData.map((p, i) => {
                            const percentage = (p.value / tasks.length) * 100;
                            return (
                                <div key={i} className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <span className="text-xs font-black">{p.name}</span>
                                        <span className="text-xs font-black opacity-40">{p.value} tasks</span>
                                    </div>
                                    <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                                        <div 
                                            className="h-full bg-primary transition-all duration-1000" 
                                            style={{ 
                                                width: `${percentage}%`,
                                                backgroundColor: COLORS[i % COLORS.length]
                                            }} 
                                        />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Card>

                <Card className="border-border/40 shadow-xl rounded-[2.5rem] bg-card p-8 flex flex-col justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-500">
                            <Target className="w-5 h-5" />
                        </div>
                        <div>
                            <h3 className="text-lg font-black tracking-tight">Critical Path</h3>
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Next 7 days strategy</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-8">
                        <div className="p-4 rounded-2xl bg-muted/20 border border-border/40">
                            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-1">Due Soon</p>
                            <p className="text-2xl font-black">{tasks.filter(t => t.dueDate && new Date(t.dueDate) < subDays(new Date(), -3)).length}</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-muted/20 border border-border/40">
                            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-1">Blocked</p>
                            <p className="text-2xl font-black">{tasks.filter(t => t.status === 'BLOCKED').length}</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-muted/20 border border-border/40">
                            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-1">Estimated</p>
                            <p className="text-2xl font-black">{tasks.reduce((sum, t) => sum + (t.estimatedHours || 0), 0)}h</p>
                        </div>
                        <div className="p-4 rounded-2xl bg-muted/20 border border-border/40">
                            <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-1">Projects</p>
                            <p className="text-2xl font-black">{new Set(tasks.map(t => t.projectId)).size}</p>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
}
