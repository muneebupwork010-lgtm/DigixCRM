"use client";

import { useState } from "react";
import { Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { createTask } from "@/lib/actions/tasks";
import { TaskStatus, Priority } from "@/generated/prisma/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function CreateTaskDialog({ 
    projectId,
    users = [] 
}: { 
    projectId: string;
    users?: { id: string; name: string | null; image?: string | null }[] 
}) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        title: "",
        description: "",
        status: "TODO" as TaskStatus,
        priority: "MEDIUM" as Priority,
        assigneeId: "",
        startDate: "",
        dueDate: "",
        estimatedHours: 0
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const res = await createTask({
                ...formData,
                projectId,
                dueDate: formData.dueDate ? new Date(formData.dueDate) : null,
                startDate: formData.startDate ? new Date(formData.startDate) : null,
                estimatedHours: Number(formData.estimatedHours),
                assigneeId: formData.assigneeId || null,
            });

            if (res.success) {
                toast.success("Task created successfully");
                setOpen(false);
                setFormData({
                    title: "",
                    description: "",
                    status: "TODO",
                    priority: "MEDIUM",
                    assigneeId: "",
                    startDate: "",
                    dueDate: "",
                    estimatedHours: 0
                });
            } else {
                toast.error(res.error || "Failed to create task");
            }
        } catch {
            toast.error("An unexpected error occurred");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button className="rounded-xl font-bold shadow-lg shadow-primary/20 gap-2 h-11">
                    <Plus className="w-4.5 h-4.5" />
                    New Task
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] rounded-3xl border-border/40 shadow-2xl p-0 overflow-hidden">
                <form onSubmit={handleSubmit}>
                    <DialogHeader className="p-8 pb-4">
                        <DialogTitle className="text-2xl font-black">Create New Task</DialogTitle>
                        <DialogDescription className="font-medium">
                            Add a new item to the project workflow.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="px-8 pb-8 space-y-5">
                        <div className="space-y-2">
                            <Label htmlFor="title" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Task Title</Label>
                            <Input
                                id="title"
                                value={formData.title}
                                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                placeholder="What needs to be done?"
                                className="rounded-xl bg-muted/30 border-border/50 h-12 text-sm font-bold placeholder:font-medium"
                                required
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Status</Label>
                                <Select 
                                    value={formData.status} 
                                    onValueChange={(val) => setFormData({ ...formData, status: val as TaskStatus })}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="TODO" className="font-bold">To Do</SelectItem>
                                        <SelectItem value="IN_PROGRESS" className="font-bold">In Progress</SelectItem>
                                        <SelectItem value="IN_REVIEW" className="font-bold">Review</SelectItem>
                                        <SelectItem value="DONE" className="font-bold">Done</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Priority</Label>
                                <Select 
                                    value={formData.priority} 
                                    onValueChange={(val) => setFormData({ ...formData, priority: val as Priority })}
                                >
                                    <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                        <SelectItem value="LOW" className="font-bold text-muted-foreground">Low</SelectItem>
                                        <SelectItem value="MEDIUM" className="font-bold text-blue-500">Medium</SelectItem>
                                        <SelectItem value="HIGH" className="font-bold text-amber-500">High</SelectItem>
                                        <SelectItem value="URGENT" className="font-bold text-red-500">Urgent</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Assignee</Label>
                            <Select 
                                value={formData.assigneeId} 
                                onValueChange={(val) => setFormData({ ...formData, assigneeId: val })}
                            >
                                <SelectTrigger className="rounded-xl bg-muted/30 border-border/50 h-12">
                                    <SelectValue placeholder="Unassigned" />
                                </SelectTrigger>
                                <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                    <SelectItem value="unassigned" className="font-bold">Unassigned</SelectItem>
                                    {users.map((user) => (
                                        <SelectItem key={user.id} value={user.id}>
                                            <div className="flex items-center gap-2">
                                                <Avatar className="h-5 w-5">
                                                    <AvatarImage src={user.image || ""} />
                                                    <AvatarFallback className="text-[8px] font-black">{user.name?.substring(0, 2).toUpperCase()}</AvatarFallback>
                                                </Avatar>
                                                <span className="font-bold text-xs">{user.name}</span>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="startDate" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Start Date</Label>
                                <Input
                                    id="startDate"
                                    type="date"
                                    value={formData.startDate}
                                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                                    className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="dueDate" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Due Date</Label>
                                <Input
                                    id="dueDate"
                                    type="date"
                                    value={formData.dueDate}
                                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                                    className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="est" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Est. Hours</Label>
                            <Input
                                id="est"
                                type="number"
                                value={formData.estimatedHours}
                                onChange={(e) => setFormData({ ...formData, estimatedHours: Number(e.target.value) })}
                                className="rounded-xl bg-muted/30 border-border/50 h-12 font-bold"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="tdesc" className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Full Description</Label>
                            <Textarea
                                id="tdesc"
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                placeholder="Describe the task in detail..."
                                className="rounded-xl bg-muted/30 border-border/50 min-h-[100px] resize-none font-medium"
                            />
                        </div>
                    </div>

                    <DialogFooter className="p-8 pt-0 gap-2 sm:gap-0">
                        <Button
                            type="button"
                            variant="ghost"
                            onClick={() => setOpen(false)}
                            className="rounded-xl font-bold"
                        >
                            Cancel
                        </Button>
                        <Button
                            type="submit"
                            disabled={loading}
                            className="rounded-xl font-bold bg-primary px-8 shadow-lg shadow-primary/20"
                        >
                            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                            Create Task
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
