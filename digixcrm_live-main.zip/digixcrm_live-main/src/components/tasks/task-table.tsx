"use client";

import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    Calendar, 
    MoreHorizontal, 
    MessageSquare, 
    Clock,
    User,
    ChevronDown,
    ChevronRight,
    Circle,
    Layers,
    CheckCircle2,
    Archive,
    Pencil,
    Trash2,
    Eye
} from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useState } from "react";
import { TaskStatus, Priority } from "@/generated/prisma/client";
import { Button } from "@/components/ui/button";
import { TaskSheet } from "./task-sheet";
import { 
    Select, 
    SelectContent, 
    SelectItem, 
    SelectTrigger, 
    SelectValue 
} from "@/components/ui/select";
import { updateTask, updateTaskArchiveStatus, deleteTask } from "@/lib/actions/tasks";
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger,
    DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

interface TaskTableProps {
    tasks: any[];
    users: { id: string; name: string | null; image?: string | null }[];
    currentUser?: { id: string; role: string };
}

const statusConfig: Record<string, { label: string, color: string, border: string }> = {
    TODO: { label: "To Do", color: "bg-slate-500", border: "border-l-slate-500" },
    IN_PROGRESS: { label: "In Progress", color: "bg-blue-500", border: "border-l-blue-500" },
    IN_REVIEW: { label: "Review", color: "bg-amber-500", border: "border-l-amber-500" },
    BLOCKED: { label: "Blocked", color: "bg-red-500", border: "border-l-red-500" },
    DONE: { label: "Done", color: "bg-emerald-500", border: "border-l-emerald-500" },
};

const priorityColors: Record<string, string> = {
    LOW: "text-muted-foreground",
    MEDIUM: "text-blue-500",
    HIGH: "text-amber-500",
    URGENT: "text-red-500",
};

export function TaskTable({ tasks, users, currentUser }: TaskTableProps) {
    const [selectedTask, setSelectedTask] = useState<any>(null);
    const router = useRouter();

    // Group tasks by status for a Monday.com style layout
    const groupedTasks = tasks.reduce((acc: any, task) => {
        if (!acc[task.status]) acc[task.status] = [];
        acc[task.status].push(task);
        return acc;
    }, {});

    const statuses = ["TODO", "IN_PROGRESS", "IN_REVIEW", "BLOCKED", "DONE"];

    const handleStatusChange = async (taskId: string, newStatus: TaskStatus) => {
        const res = await updateTask(taskId, { status: newStatus });
        if (res.success) {
            toast.success("Task status updated");
            router.refresh();
        } else {
            toast.error(res.error || "Failed to update status");
        }
    };

    return (
        <div className="space-y-10 pb-10">
            {statuses.map((status) => {
                const group = groupedTasks[status] || [];
                if (group.length === 0) return null;

                const config = statusConfig[status];

                return (
                    <div key={status} className="space-y-4">
                        <div className="flex items-center gap-3 ml-2 group cursor-pointer">
                            <div className={cn("flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-lg shadow-black/5", config.color)}>
                                {config.label}
                            </div>
                            <span className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.2em]">
                                {group.length} Tasks
                            </span>
                        </div>

                        <div className="bg-card rounded-3xl border border-border/40 shadow-xl overflow-hidden">
                            <Table>
                                <TableHeader className="bg-muted/30">
                                    <TableRow className="hover:bg-transparent border-none">
                                        <TableHead className="w-[400px] h-12 text-[10px] font-black uppercase tracking-widest pl-8">Task Name</TableHead>
                                        <TableHead className="h-12 text-[10px] font-black uppercase tracking-widest">Assignee</TableHead>
                                        <TableHead className="h-12 text-[10px] font-black uppercase tracking-widest">Priority</TableHead>
                                        <TableHead className="h-12 text-[10px] font-black uppercase tracking-widest">Status</TableHead>
                                        <TableHead className="h-12 text-[10px] font-black uppercase tracking-widest">Due Date</TableHead>
                                        <TableHead className="h-12 text-[10px] font-black uppercase tracking-widest text-right pr-6">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {group.map((task: any) => {
                                        const canEdit = currentUser?.role !== "CLIENT" || task.createdById === currentUser?.id;
                                        return (
                                        <TableRow key={task.id} className={cn(
                                            "group transition-all hover:bg-muted/20 border-border/40 border-l-[6px]",
                                            config.border
                                        )}>
                                            <TableCell className="pl-8 py-4">
                                                <div className="flex flex-col gap-1">
                                                    <div className="flex items-center gap-3">
                                                        <Circle className={cn("w-2 h-2", task.status === 'DONE' ? 'fill-emerald-500 text-emerald-500' : 'text-muted-foreground/30')} />
                                                        <span 
                                                            onClick={() => setSelectedTask(task)}
                                                            className="text-sm font-bold group-hover:text-primary transition-colors cursor-pointer capitalize"
                                                        >
                                                            {task.title}
                                                        </span>
                                                        {task._count?.activities > 0 && (
                                                            <div className="flex items-center gap-1 text-[10px] font-black text-muted-foreground/50">
                                                                <MessageSquare className="w-3 h-3" />
                                                                {task._count.activities}
                                                            </div>
                                                        )}
                                                    </div>
                                                    {task.project?.name && (
                                                        <div className="flex items-center gap-1 ml-5 text-[10px] font-black text-primary uppercase tracking-widest opacity-60">
                                                            <Layers className="w-2.5 h-2.5" />
                                                            {task.project.name}
                                                        </div>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <Avatar className="h-7 w-7 border border-border/50">
                                                        <AvatarImage src={task.assignee?.image || ""} />
                                                        <AvatarFallback className="text-[8px] font-black uppercase italic">
                                                            {task.assignee?.name?.substring(0, 2) || "?"}
                                                        </AvatarFallback>
                                                    </Avatar>
                                                    <span className="text-xs font-bold text-muted-foreground">{task.assignee?.name || "Unassigned"}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <span className={cn("text-[10px] font-black uppercase tracking-widest", priorityColors[task.priority])}>
                                                    {task.priority}
                                                </span>
                                            </TableCell>
                                            <TableCell>
                                                <Select 
                                                    value={task.status} 
                                                    onValueChange={(val: TaskStatus) => handleStatusChange(task.id, val)}
                                                    disabled={!canEdit}
                                                >
                                                    <SelectTrigger className="w-32 h-8 rounded-lg border-border/40 bg-muted/20 font-bold text-[10px] uppercase tracking-wider">
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent className="rounded-xl border-border/40 shadow-xl">
                                                        <SelectItem value="TODO" className="text-[10px] font-bold uppercase tracking-widest">To Do</SelectItem>
                                                        <SelectItem value="IN_PROGRESS" className="text-[10px] font-bold uppercase tracking-widest text-blue-500">In Progress</SelectItem>
                                                        <SelectItem value="IN_REVIEW" className="text-[10px] font-bold uppercase tracking-widest text-amber-500">Review</SelectItem>
                                                        <SelectItem value="BLOCKED" className="text-[10px] font-bold uppercase tracking-widest text-red-500">Blocked</SelectItem>
                                                        <SelectItem value="DONE" className="text-[10px] font-bold uppercase tracking-widest text-emerald-500">Completed</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </TableCell>
                                            <TableCell>
                                                {task.dueDate ? (
                                                     <div className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
                                                        <Calendar className="w-3.5 h-3.5" />
                                                        {format(new Date(task.dueDate), "MMM dd, yyyy")}
                                                     </div>
                                                ) : (
                                                    <span className="text-xs font-medium text-muted-foreground opacity-30">—</span>
                                                )}
                                            </TableCell>
                                            <TableCell className="text-right pr-6">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <MoreHorizontal className="w-4 h-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end" className="w-40 rounded-xl border-border/40 shadow-xl">
                                                        <DropdownMenuItem 
                                                            className="text-[10px] font-bold uppercase tracking-widest gap-2 cursor-pointer"
                                                            onClick={() => setSelectedTask(task)}
                                                        >
                                                            <Eye className="w-3.5 h-3.5" /> View Details
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem 
                                                            className="text-[10px] font-bold uppercase tracking-widest gap-2 cursor-pointer"
                                                            onClick={() => setSelectedTask(task)}
                                                        >
                                                            <Pencil className="w-3.5 h-3.5" /> Edit Task
                                                        </DropdownMenuItem>
                                                        
                                                        {task.status === 'DONE' && canEdit && (
                                                            <DropdownMenuItem 
                                                                className="text-[10px] font-bold uppercase tracking-widest gap-2 cursor-pointer text-emerald-500 focus:text-emerald-500 focus:bg-emerald-500/10"
                                                                onClick={async () => {
                                                                    const res = await updateTaskArchiveStatus(task.id, true);
                                                                    if (res.success) {
                                                                        toast.success("Task archived");
                                                                        router.refresh();
                                                                    } else {
                                                                        toast.error(res.error || "Failed to archive task");
                                                                    }
                                                                }}
                                                            >
                                                                <Archive className="w-3.5 h-3.5" /> Archive Task
                                                            </DropdownMenuItem>
                                                        )}

                                                        {canEdit && (
                                                            <>
                                                                <DropdownMenuSeparator className="bg-border/40" />
                                                                <DropdownMenuItem 
                                                                    className="text-[10px] font-bold uppercase tracking-widest gap-2 cursor-pointer text-destructive focus:text-destructive focus:bg-destructive/10"
                                                                    onClick={async () => {
                                                                        if (confirm("Are you sure you want to delete this task?")) {
                                                                            const res = await deleteTask(task.id);
                                                                            if (res.success) {
                                                                                toast.success("Task deleted");
                                                                                router.refresh();
                                                                            } else {
                                                                                toast.error(res.error || "Failed to delete task");
                                                                            }
                                                                        }
                                                                    }}
                                                                >
                                                                    <Trash2 className="w-3.5 h-3.5" /> Delete Task
                                                                </DropdownMenuItem>
                                                            </>
                                                        )}
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                );
            })}

            <TaskSheet 
                task={selectedTask}
                isOpen={!!selectedTask}
                onClose={() => setSelectedTask(null)}
                users={users}
                currentUser={currentUser}
            />
        </div>
    );
}
