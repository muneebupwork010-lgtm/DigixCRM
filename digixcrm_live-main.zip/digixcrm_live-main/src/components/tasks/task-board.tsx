"use client";

import { useState, useEffect, useRef } from "react";
import { 
    DndContext, 
    useSensor, 
    useSensors, 
    MouseSensor, 
    TouchSensor, 
    DragOverlay, 
    defaultDropAnimationSideEffects, 
    DragStartEvent, 
    DragEndEvent, 
    closestCenter 
} from "@dnd-kit/core";
import { useDraggable, useDroppable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { TaskStatus, Priority } from "@/generated/prisma/client";
import { updateTask, updateTaskArchiveStatus, bulkArchiveTasks } from "@/lib/actions/tasks";
import { toast } from "sonner";
import { TaskStatusEmailDialog } from "./task-status-email-dialog";
import { 
    Calendar, 
    Clock, 
    MoreHorizontal, 
    AlertCircle, 
    CheckCircle2, 
    GripVertical,
    MessageSquare,
    Paperclip,
    Archive,
    CheckSquare,
    ArchiveRestore,
    ChevronLeft,
    ChevronRight
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { TaskSheet } from "./task-sheet";

interface TaskBoardProps {
    projectId: string;
    initialTasks: any[];
    users: { id: string; name: string | null; image?: string | null }[];
    currentUser?: { id: string; role: string };
}

const statusConfig = [
    { value: "TODO", label: "To Do", color: "slate" },
    { value: "IN_PROGRESS", label: "In Progress", color: "blue" },
    { value: "IN_REVIEW", label: "Review", color: "amber" },
    { value: "BLOCKED", label: "Blocked", color: "red" },
    { value: "DONE", label: "Completed", color: "emerald" },
];

const priorityIcons: Record<string, any> = {
    LOW: { icon: ArrowDown, color: "text-slate-400" },
    MEDIUM: { icon: Minus, color: "text-blue-500" },
    HIGH: { icon: ArrowUp, color: "text-amber-500" },
    URGENT: { icon: AlertCircle, color: "text-red-500" },
};

function ArrowDown(props: any) { return <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg> }
function ArrowUp(props: any) { return <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg> }
function Minus(props: any) { return <svg {...props} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 12h14" /></svg> }

function DraggableTaskCard({ task, onClick, onArchive }: { task: any, onClick?: () => void, onArchive?: (id: string) => void }) {
    const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
        id: task.id,
        data: { task }
    });

    const style = {
        transform: CSS.Translate.toString(transform),
        opacity: isDragging ? 0.3 : 1,
    };

    const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'DONE';

    return (
        <div
            ref={setNodeRef}
            style={{ ...style, touchAction: 'pan-y' }}
            onClick={(e) => {
                // Prevent drag click from firing
                if (isDragging) return;
                onClick?.();
            }}
            {...attributes}
            {...listeners}
            className={cn(
                "bg-card p-4 rounded-2xl border border-border/50 shadow-sm hover:shadow-md hover:border-border transition-all group relative cursor-grab active:cursor-grabbing",
                isDragging && "opacity-30"
            )}
        >
            <div className="space-y-4">
                <div className="flex items-start justify-between gap-2">
                    <Badge variant="outline" className={cn(
                        "rounded-full px-2 py-0 text-[10px] font-black tracking-tighter uppercase border-none",
                        task.priority === 'URGENT' ? 'bg-red-500/10 text-red-500' : 
                        task.priority === 'HIGH' ? 'bg-amber-500/10 text-amber-500' :
                        task.priority === 'MEDIUM' ? 'bg-blue-500/10 text-blue-500' : 'bg-slate-500/10 text-slate-500'
                    )}>
                        {task.priority}
                    </Badge>
                    <GripVertical 
                        className="w-4 h-4 text-muted-foreground/20 group-hover:text-muted-foreground/40 transition-colors" 
                    />
                </div>

                <div className="space-y-1.5">
                    <h4 className="text-sm font-bold leading-snug line-clamp-2">{task.title}</h4>
                    {task.tags && task.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                            {task.tags.map((tag: string) => (
                                <Badge key={tag} variant="secondary" className="px-1 py-0 text-[8px] font-black uppercase tracking-widest bg-muted/50 text-muted-foreground">
                                    {tag}
                                </Badge>
                            ))}
                        </div>
                    )}
                </div>

                <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-3">
                        {task.dueDate && (
                            <div className={cn("flex items-center gap-1 text-[10px] font-black", isOverdue ? "text-red-500" : "text-muted-foreground")}>
                                <Calendar className="w-3 h-3" />
                                {format(new Date(task.dueDate), "MMM d")}
                            </div>
                        )}
                        {task._count?.activities > 0 && (
                             <div className="flex items-center gap-1 text-[10px] font-black text-muted-foreground">
                                <MessageSquare className="w-3 h-3" />
                                {task._count.activities}
                            </div>
                        )}
                        {task.attachments && task.attachments.length > 0 && (
                             <div className="flex items-center gap-1 text-[10px] font-black text-muted-foreground">
                                <Paperclip className="w-3 h-3" />
                                {task.attachments.length}
                            </div>
                        )}
                    </div>

                    <div className="flex items-center gap-2">
                        {task.status === 'DONE' && (
                            <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-emerald-500 hover:bg-emerald-500/10 rounded-full"
                                onClick={(e: React.MouseEvent) => {
                                    e.stopPropagation();
                                    onArchive?.(task.id);
                                }}
                                title="Close & Archive Task"
                            >
                                <CheckSquare className="w-3.5 h-3.5" />
                            </Button>
                        )}
                        <Avatar className="h-6 w-6 rounded-full border border-background ring-2 ring-muted">
                            <AvatarImage src={task.assignee?.image || ""} />
                            <AvatarFallback className="text-[8px] font-black">{task.assignee?.name?.substring(0, 2).toUpperCase() || "?"}</AvatarFallback>
                        </Avatar>
                    </div>
                </div>
            </div>
        </div>
    );
}

function DroppableColumn({ status, children, onArchiveAll }: { status: any, children: React.ReactNode, onArchiveAll?: () => void }) {
    const { setNodeRef, isOver } = useDroppable({ id: status.value });
    
    const colorClasses: Record<string, string> = {
        slate: "bg-slate-500/5 border-slate-500/10",
        blue: "bg-blue-500/5 border-blue-500/10",
        amber: "bg-amber-500/5 border-amber-500/10",
        red: "bg-red-500/5 border-red-500/10",
        emerald: "bg-emerald-500/5 border-emerald-500/10",
    };

    return (
        <div 
            ref={setNodeRef}
            className={cn(
                "flex flex-col w-[300px] min-w-[300px] self-stretch rounded-3xl border p-3 gap-4 transition-all duration-300",
                colorClasses[status.color],
                isOver && "ring-2 ring-primary/20 bg-primary/5 border-primary/20"
            )}
        >
            <div className="flex items-center justify-between px-2 pt-1">
                <div className="flex items-center gap-2">
                    <div className={cn("w-1.5 h-1.5 rounded-full", 
                        status.color === 'blue' ? 'bg-blue-500' : 
                        status.color === 'amber' ? 'bg-amber-500' : 
                        status.color === 'emerald' ? 'bg-emerald-500' : 
                        status.color === 'red' ? 'bg-red-500' : 'bg-slate-500'
                    )} />
                    <h3 className="text-xs font-black uppercase tracking-widest text-foreground">{status.label}</h3>
                </div>
                {status.value === 'DONE' && (
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-6 w-6 hover:bg-emerald-500/10 text-emerald-600 rounded-md"
                        onClick={onArchiveAll}
                        title="Archive all completed tasks"
                    >
                        <Archive className="w-3.5 h-3.5" />
                    </Button>
                )}
                <Badge variant="secondary" className="rounded-lg px-2 py-0.5 text-[10px] font-black opacity-60">
                    {Array.isArray(children) ? children.length : 0}
                </Badge>
            </div>
            <div className="flex-1 flex flex-col gap-3 overflow-y-auto pr-1 scrollbar-none">
                {children}
            </div>
        </div>
    );
}

export function TaskBoard({ projectId, initialTasks, users, currentUser }: TaskBoardProps) {
    const [tasks, setTasks] = useState(initialTasks);
    const [activeTask, setActiveTask] = useState<any>(null);
    const [selectedTask, setSelectedTask] = useState<any>(null);
    const [statusDialog, setStatusDialog] = useState<{isOpen: boolean, task: any, newStatus: TaskStatus | null, originalTasks: any[]}>({
        isOpen: false,
        task: null,
        newStatus: null,
        originalTasks: []
    });

    const sensors = useSensors(
        useSensor(MouseSensor, { activationConstraint: { distance: 5 } }),
        useSensor(TouchSensor, { activationConstraint: { delay: 250, tolerance: 5 } })
    );

    useEffect(() => {
        setTasks(initialTasks);
    }, [initialTasks]);

    // Scroll arrow logic
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const [showLeftArrow, setShowLeftArrow] = useState(false);
    const [showRightArrow, setShowRightArrow] = useState(true);

    const handleScroll = () => {
        if (!scrollContainerRef.current) return;
        const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
        setShowLeftArrow(scrollLeft > 20);
        setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 20);
    };

    useEffect(() => {
        handleScroll();
        window.addEventListener('resize', handleScroll);
        setTimeout(handleScroll, 100);
        return () => window.removeEventListener('resize', handleScroll);
    }, [tasks]);

    const scrollBy = (amount: number) => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollBy({ left: amount, behavior: "smooth" });
        }
    };

    const onDragStart = (e: DragStartEvent) => {
        const task = tasks.find(t => t.id === e.active.id);
        setActiveTask(task);
    };

    const onDragEnd = async (e: DragEndEvent) => {
        setActiveTask(null);
        const { active, over } = e;
        if (!over) return;

        const taskId = active.id as string;
        const newStatus = over.id as TaskStatus;

        const task = tasks.find(t => t.id === taskId);
        if (!task || task.status === newStatus) return;

        // Optimistic update
        const originalTasks = [...tasks];
        setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));

        // Open status email dialog instead of direct update
        setStatusDialog({
            isOpen: true,
            task,
            newStatus,
            originalTasks
        });
    };

    return (
        <DndContext 
            id="task-board" 
            sensors={sensors} 
            collisionDetection={closestCenter} 
            onDragStart={onDragStart} 
            onDragEnd={onDragEnd}
        >
            <div className="relative group/board h-[calc(100vh-380px)]">
                {/* Floating Left Arrow */}
                {showLeftArrow && (
                    <button 
                        onClick={() => scrollBy(-340)}
                        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-40 w-10 h-10 md:w-12 md:h-12 bg-background/90 backdrop-blur-md border border-border rounded-full shadow-xl flex items-center justify-center hover:bg-background hover:scale-110 hover:shadow-2xl transition-all text-primary hover:text-primary"
                    >
                        <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
                    </button>
                )}
                
                {/* Floating Right Arrow */}
                {showRightArrow && (
                    <button 
                        onClick={() => scrollBy(340)}
                        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-40 w-10 h-10 md:w-12 md:h-12 bg-background/90 backdrop-blur-md border border-border rounded-full shadow-xl flex items-center justify-center hover:bg-background hover:scale-110 hover:shadow-2xl transition-all text-primary hover:text-primary"
                    >
                        <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
                    </button>
                )}

            <div 
                ref={scrollContainerRef}
                onScroll={handleScroll}
                className="flex gap-6 h-full items-stretch overflow-x-auto pb-4 scrollbar-none"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
                {statusConfig.map(status => (
                    <DroppableColumn 
                        key={status.value} 
                        status={status}
                        onArchiveAll={status.value === 'DONE' ? async () => {
                            const res = await bulkArchiveTasks(projectId);
                            if (res.success) {
                                toast.success("All completed tasks archived");
                                setTasks(prev => prev.filter(t => !(t.status === 'DONE' && !t.isClosed)));
                            } else {
                                toast.error(res.error || "Failed to archive tasks");
                            }
                        } : undefined}
                    >
                        {tasks
                            .filter(t => t.status === status.value && !t.isClosed)
                            .map(task => (
                                <DraggableTaskCard 
                                    key={task.id} 
                                    task={task} 
                                    onClick={() => setSelectedTask(task)} 
                                    onArchive={async (id) => {
                                        const res = await updateTaskArchiveStatus(id, true);
                                        if (res.success) {
                                            toast.success("Task archived");
                                            setTasks(prev => prev.map(t => t.id === id ? { ...t, isClosed: true } : t));
                                        } else {
                                            toast.error(res.error || "Failed to archive task");
                                        }
                                    }}
                                />
                            ))}
                    </DroppableColumn>
                ))}
                <div className="min-w-[48px] shrink-0" aria-hidden="true" />
            </div>
            </div>

            <TaskSheet 
                task={selectedTask}
                isOpen={!!selectedTask}
                onClose={() => setSelectedTask(null)}
                users={users}
                currentUser={currentUser}
            />

            <TaskStatusEmailDialog
                isOpen={statusDialog.isOpen}
                onClose={() => {
                    // Revert optimistic update if dialog is closed without success
                    setTasks(statusDialog.originalTasks);
                    setStatusDialog(prev => ({ ...prev, isOpen: false }));
                }}
                task={statusDialog.task}
                newStatus={statusDialog.newStatus as TaskStatus}
                users={users}
                onSuccess={(newStatus) => {
                    // Success, keep the optimistic update
                    setStatusDialog(prev => ({ ...prev, isOpen: false }));
                    // Update the local task object so when we open TaskSheet it has the new status
                    const updatedTasks = statusDialog.originalTasks.map(t => t.id === statusDialog.task.id ? { ...t, status: newStatus } : t);
                    setTasks(updatedTasks);
                }}
            />

            <DragOverlay dropAnimation={{ sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: "0.4" } } }) }}>
                {activeTask ? (
                    <div className="bg-card p-4 rounded-2xl border border-primary/40 shadow-2xl rotate-2 w-[280px] cursor-grabbing">
                        <h4 className="text-sm font-bold leading-snug line-clamp-2">{activeTask.title}</h4>
                    </div>
                ) : null}
            </DragOverlay>
        </DndContext>
    );
}
