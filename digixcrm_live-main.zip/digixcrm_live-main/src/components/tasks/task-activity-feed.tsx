"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow, isToday, isYesterday, format } from "date-fns";
import { 
    MessageSquare, 
    Send, 
    Clock, 
    Paperclip,
    Smile,
    RotateCcw,
    Sparkles,
    CheckCircle2,
    Calendar,
    UserPlus,
    ArrowUpCircle,
    Plus,
    Video,
    Play,
    X,
    Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { MentionTextarea } from "@/components/ui/mention-textarea";
import { getTaskActivities, createActivity } from "@/lib/actions/activities";
import { uploadFile, deleteTaskAttachment } from "@/lib/actions/attachments";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface TaskActivityFeedProps {
    taskId: string;
    attachmentCount?: number;
    status?: string;
    priority?: string;
    attachments?: any[];
    onPreview?: (file: any) => void;
    setAttachments?: React.Dispatch<React.SetStateAction<any[]>>;
}

export function TaskActivityFeed({ 
    taskId, 
    attachmentCount = 0, 
    status = "TODO", 
    priority = "MEDIUM",
    attachments = [],
    onPreview,
    setAttachments
}: TaskActivityFeedProps) {
    const [activities, setActivities] = useState<any[]>([]);
    const [note, setNote] = useState("");
    const [loading, setLoading] = useState(false);
    const [fetching, setFetching] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        fetchActivities();
    }, [taskId]);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [activities]);

    const fetchActivities = async () => {
        setFetching(true);
        try {
            const res = await getTaskActivities(taskId);
            if (res.success && res.data) {
                setActivities(res.data.reverse()); // Show newest at bottom for chat feel
            }
        } catch (err) {
            console.error("Failed to fetch task activities:", err);
        } finally {
            setFetching(false);
        }
    };

    const handleSend = async () => {
        if (!note.trim()) return;
        setLoading(true);
        const res = await createActivity({
            type: "NOTE",
            notes: note,
            taskId: taskId
        });
        if (res.success) {
            setNote("");
            fetchActivities();
        } else {
            toast.error(res.error || "Failed to post comment");
        }
        setLoading(false);
    };

    const processFile = async (file: File) => {
        if (file.size > 10 * 1024 * 1024) {
            toast.error("File is too large. Limit is 10MB.");
            return;
        }

        setLoading(true);
        try {
            const formData = new FormData();
            formData.append("file", file);

            const res = await uploadFile(taskId, formData);
            if (!res.success) throw new Error(res.error);

            if (res.attachment) {
                setAttachments?.(prev => [res.attachment, ...prev]);
                
                // Use the final name from the server (it might have been changed to .webp)
                await createActivity({
                    type: "NOTE",
                    notes: `📎 Attached: ${res.attachment.name}`,
                    taskId: taskId
                });
            }

            toast.success("File attached via comment");
            fetchActivities();
        } catch (err: any) {
            toast.error(err.message || "Failed to attach file");
        } finally {
            setLoading(false);
        }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        await processFile(file);
        e.target.value = '';
    };

    const handlePaste = async (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
        const items = e.clipboardData?.items;
        if (!items) return;

        let imageFile: File | null = null;
        for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
                // If there's an image in the clipboard, grab it as a File
                imageFile = items[i].getAsFile();
                // Give it a default name since pasted images might just be 'image.png'
                if (imageFile && (!imageFile.name || imageFile.name === 'image.png')) {
                    const ext = imageFile.type.split('/')[1] || 'png';
                    const newFile = new File([imageFile], `pasted_image_${Date.now()}.${ext}`, { type: imageFile.type });
                    imageFile = newFile;
                }
                break;
            }
        }

        if (imageFile) {
            e.preventDefault();
            await processFile(imageFile);
        }
    };

    const groupedActivities = useMemo(() => {
        const groups: { [key: string]: any[] } = {};
        activities.forEach(activity => {
            const date = new Date(activity.createdAt);
            let label = format(date, "MMMM d, yyyy");
            if (isToday(date)) label = "Today";
            else if (isYesterday(date)) label = "Yesterday";
            
            if (!groups[label]) groups[label] = [];
            groups[label].push(activity);
        });
        return groups;
    }, [activities]);

    const renderActivity = (activity: any) => {
        const isSystem = activity.type.startsWith("SYSTEM_");
        
        if (isSystem) {
            let icon = <Clock className="w-3 h-3" />;
            if (activity.type === "SYSTEM_STATUS") icon = <CheckCircle2 className="w-3 h-3 text-emerald-500" />;
            if (activity.type === "SYSTEM_DATE") icon = <Calendar className="w-3 h-3 text-blue-500" />;
            if (activity.type === "SYSTEM_ASSIGNEE") icon = <UserPlus className="w-3 h-3 text-indigo-500" />;
            if (activity.type === "SYSTEM_PRIORITY") icon = <ArrowUpCircle className="w-3 h-3 text-amber-500" />;

            return (
                <div key={activity.id} className="flex justify-center my-6">
                    <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-muted/20 border border-border/10 text-[9px] font-black uppercase tracking-[0.1em] text-muted-foreground/60 backdrop-blur-md shadow-sm max-w-[90%] text-center break-words" style={{ overflowWrap: 'anywhere' }}>
                        {icon}
                        <span>{activity.user?.name} {activity.notes}</span>
                    </div>
                </div>
            );
        }

        const isAttachment = !isSystem && activity.notes.startsWith("📎 Attached:");
        const fileName = isAttachment ? activity.notes.replace("📎 Attached: ", "") : "";
        const attachmentObj = isAttachment ? attachments.find(a => a.name.toLowerCase() === fileName.toLowerCase()) : null;

        return (
            <div key={activity.id} className="flex flex-col gap-2 group animate-in slide-in-from-bottom-3 duration-500">
                <div className="flex items-center gap-2 ml-1">
                    <Avatar className="h-6 w-6 border border-border/40 shadow-sm ring-2 ring-background">
                        <AvatarImage src={activity.user?.image || ""} />
                        <AvatarFallback className="text-[7px] font-black bg-primary/10 text-primary">
                            {activity.user?.name?.substring(0,2).toUpperCase()}
                        </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black tracking-tight">{activity.user?.name}</span>
                        <span className="text-[8px] font-medium text-muted-foreground/50">{format(new Date(activity.createdAt), "h:mm a")}</span>
                    </div>
                </div>
                <div className="flex flex-col gap-1 max-w-[90%]">
                    {isAttachment ? (
                        <div 
                            className="relative p-3 rounded-2xl rounded-tl-none bg-primary/5 border border-primary/20 shadow-sm flex items-center gap-3 group/file transition-all hover:bg-primary/10 cursor-pointer"
                            onClick={() => attachmentObj && onPreview?.(attachmentObj)}
                        >
                            <div className="w-10 h-10 rounded-xl bg-background flex items-center justify-center border border-border/40 shrink-0 overflow-hidden relative">
                                {attachmentObj?.fileType?.startsWith('image/') ? (
                                    <img src={attachmentObj.url} alt={fileName} className="w-full h-full object-cover" />
                                ) : attachmentObj?.fileType?.startsWith('video/') ? (
                                    <div className="relative w-full h-full flex items-center justify-center bg-slate-900/10">
                                        <Video className="w-4 h-4 text-primary/60" />
                                        <Play className="absolute inset-0 m-auto w-2 h-2 text-white fill-white opacity-40" />
                                    </div>
                                ) : (
                                    <Paperclip className="w-4 h-4 text-primary" />
                                )}
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-[11px] font-bold truncate text-foreground/80">{fileName}</p>
                                <p className="text-[9px] font-black uppercase tracking-widest text-primary/40">
                                    {attachmentObj ? "Resource Attachment" : "File Ref Reference"}
                                </p>
                            </div>
                            {attachmentObj && (
                                        <div className="flex items-center gap-1 opacity-0 group-hover/file:opacity-100 transition-opacity">
                                            <Button 
                                                variant="ghost" 
                                                size="icon" 
                                                className="h-8 w-8 rounded-full hover:bg-primary/20"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    onPreview?.(attachmentObj);
                                                }}
                                            >
                                                {attachmentObj.fileType?.startsWith('video/') ? (
                                                    <Play className="w-4 h-4 text-primary fill-primary/20" />
                                                ) : (
                                                    <Eye className="w-4 h-4 text-primary" />
                                                )}
                                            </Button>
                                    <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        className="h-8 w-8 rounded-full text-red-500/40 hover:text-red-500 hover:bg-red-500/10"
                                        onClick={async (e) => {
                                            e.stopPropagation();
                                            if (window.confirm("Delete this attachment?")) {
                                                const res = await deleteTaskAttachment(attachmentObj.id);
                                                if (res.success) {
                                                    setAttachments?.(prev => prev.filter(a => a.id !== attachmentObj.id));
                                                    toast.success("Attachment deleted");
                                                } else {
                                                    toast.error(res.error || "Failed to delete");
                                                }
                                            }
                                        }}
                                    >
                                        <X className="w-3.5 h-3.5" />
                                    </Button>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="relative p-4 rounded-2xl rounded-tl-none bg-card border border-border/40 shadow-sm text-sm leading-relaxed group-hover:border-primary/20 transition-all premium-shadow group-hover:shadow-md break-words overflow-hidden" style={{ overflowWrap: 'anywhere', wordBreak: 'break-word' }}>
                            {activity.notes}
                            
                            <div className="absolute -right-10 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button variant="ghost" size="icon" className="h-7 w-7 rounded-full bg-background/80 backdrop-blur-sm border border-border/40 shadow-sm hover:text-primary">
                                    <Smile className="h-3.5 w-3.5 text-muted-foreground/50" />
                                </Button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="flex flex-col h-full bg-background/40 relative">
            {/* Premium Header Card - Matches Image 2 */}
            <div className="p-4 shrink-0">
                <div className="relative p-5 rounded-[2rem] bg-card border border-border/40 shadow-xl overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-50" />
                    <div className="relative flex items-start justify-between">
                        <div className="flex items-center gap-4">
                            <div className="bg-primary/10 p-3 rounded-2xl ring-1 ring-primary/20">
                                <MessageSquare className="w-5 h-5 text-primary" />
                            </div>
                            <div className="space-y-0.5">
                                <h3 className="text-xs font-black uppercase tracking-[0.15em] text-foreground">Task Conversation</h3>
                                <p className="text-[10px] font-bold text-muted-foreground/60 uppercase tracking-widest">Current Context</p>
                            </div>
                        </div>
                        <Badge variant="outline" className="rounded-xl px-2.5 py-1 bg-muted/30 border-border/20 text-[9px] font-black">
                            {activities.length} MESSAGES
                        </Badge>
                    </div>
                    
                    {/* Activity Meta Summary */}
                    <div className="relative mt-5 grid grid-cols-1 gap-2">
                        <div className="grid grid-cols-2 gap-2">
                            <div className="flex items-center gap-2 p-2 rounded-xl bg-muted/20 border border-border/10">
                                <div className={cn(
                                    "w-1.5 h-1.5 rounded-full animate-pulse",
                                    status === 'DONE' ? 'bg-emerald-500' :
                                    status === 'IN_PROGRESS' ? 'bg-blue-500' : 'bg-amber-500'
                                )} />
                                <span className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">State: {status.replace('_', ' ')}</span>
                            </div>
                            <div className="flex items-center gap-2 p-2 rounded-xl bg-muted/20 border border-border/10">
                                <ArrowUpCircle className={cn(
                                    "w-3 h-3",
                                    priority === 'URGENT' ? 'text-red-500' :
                                    priority === 'HIGH' ? 'text-amber-500' : 'text-blue-500'
                                )} />
                                <span className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">Urgency: {priority}</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 p-2 rounded-xl bg-muted/20 border border-border/10">
                            <Paperclip className="w-3 h-3 text-primary/60" />
                            <span className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">
                                Resources: {attachmentCount > 0 ? `${attachmentCount} Files` : "None"}
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Scrollable Feed Area */}
            <div 
                ref={scrollRef} 
                className="flex-1 overflow-y-auto px-6 space-y-6 scrollbar-none pb-4"
            >
                {fetching && activities.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20">
                        <div className="relative">
                            <div className="absolute inset-0 bg-primary/20 blur-3xl animate-pulse rounded-full" />
                            <Sparkles className="relative w-10 h-10 text-primary animate-bounce" />
                        </div>
                        <p className="mt-4 text-[10px] font-black uppercase tracking-[0.3em] text-primary/40 animate-pulse">Synchronizing Feed...</p>
                    </div>
                ) : Object.keys(groupedActivities).length > 0 ? (
                    Object.entries(groupedActivities).map(([label, items]) => (
                        <div key={label} className="space-y-6">
                            <div className="relative flex justify-center py-4">
                                <div className="absolute inset-0 flex items-center">
                                    <div className="w-full border-t border-border/10" />
                                </div>
                                <span className="relative px-5 py-1 text-[8px] font-black uppercase tracking-[0.2em] text-muted-foreground/40 bg-background/50 backdrop-blur-xl rounded-full border border-border/10 shadow-sm">
                                    {label}
                                </span>
                            </div>
                            {items.map(renderActivity)}
                        </div>
                    ))
                ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-center space-y-8 animate-in fade-in zoom-in duration-700">
                        <div className="relative">
                            <div className="absolute -inset-10 bg-primary/5 rounded-full blur-3xl" />
                            <div className="relative p-8 rounded-[2.5rem] bg-card/40 border border-border/20 shadow-2xl backdrop-blur-sm">
                                <Send className="w-12 h-12 text-primary/20 -rotate-12" />
                            </div>
                        </div>
                        <div className="space-y-3">
                          <p className="text-[11px] font-black uppercase tracking-[0.4em] text-foreground/40">Awaiting Initial Feed</p>
                          <p className="text-[9px] font-bold text-muted-foreground/40 max-w-[200px] leading-relaxed uppercase tracking-widest italic">
                            All data points will stream here
                          </p>
                        </div>
                    </div>
                )}
            </div>

            {/* Premium Sticky Input Area - Matches Image 2 */}
            <div className="p-4 pt-2 shrink-0">
                <div className="relative group transition-all duration-500">
                    <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-primary/5 to-primary/20 rounded-[2rem] blur-xl opacity-0 group-focus-within:opacity-100 transition duration-700" />
                    <div className="relative bg-card/80 backdrop-blur-2xl border border-border/40 rounded-[2rem] p-2 pr-3 focus-within:border-primary/40 transition-all flex items-center gap-2 shadow-2xl premium-shadow">
                        <input 
                            type="file" 
                            id={`comment-upload-${taskId}`} 
                            className="hidden" 
                            onChange={handleFileChange}
                            disabled={loading}
                        />
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            title="Attach file (Max 10MB)"
                            className="h-10 w-10 rounded-full text-muted-foreground/40 hover:text-primary hover:bg-primary/5 shrink-0"
                            onClick={() => document.getElementById(`comment-upload-${taskId}`)?.click()}
                            disabled={loading}
                        >
                            <Paperclip className="h-4 w-4" />
                        </Button>
                        
                        <MentionTextarea
                            placeholder="Write a comment..."
                            value={note}
                            onChange={(e: any) => setNote(e.target.value)}
                            onKeyDown={(e: any) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSend();
                                }
                            }}
                            onPaste={handlePaste}
                            className="min-h-[44px] h-[44px] max-h-[120px] bg-transparent border-0 ring-0 focus-visible:ring-0 text-[13px] font-medium resize-none scrollbar-none py-3 px-2 placeholder:text-muted-foreground/30 flex-1"
                        />

                        <Button 
                            size="icon" 
                            onClick={handleSend}
                            disabled={loading || !note.trim()}
                            className={cn(
                                "h-10 w-10 rounded-full transition-all duration-500 shrink-0",
                                note.trim() 
                                    ? "bg-primary text-white shadow-lg shadow-primary/30 scale-100 rotate-0" 
                                    : "bg-muted/50 text-muted-foreground/30 scale-90 -rotate-12 grayscale"
                            )}
                        >
                            {loading ? <Clock className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}


