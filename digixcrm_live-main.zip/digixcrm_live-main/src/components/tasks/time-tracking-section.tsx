"use client";

import { useState, useEffect } from "react";
import { getTaskTimeEntries, createTimeEntry, deleteTimeEntry } from "@/lib/actions/time-entries";
import { Clock, Plus, Trash2, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";
import { toast } from "sonner";
import { useSession } from "next-auth/react";

export function TimeTrackingSection({ taskId }: { taskId: string }) {
    const { data: session } = useSession();
    const [entries, setEntries] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [isAdding, setIsAdding] = useState(false);
    
    const [hours, setHours] = useState("");
    const [description, setDescription] = useState("");
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        fetchEntries();
    }, [taskId]);

    const fetchEntries = async () => {
        setLoading(true);
        const data = await getTaskTimeEntries(taskId);
        setEntries(data);
        setLoading(false);
    };

    const handleAdd = async () => {
        const h = parseFloat(hours);
        if (isNaN(h) || h <= 0) {
            toast.error("Please enter a valid number of hours");
            return;
        }

        setIsSubmitting(true);
        const res = await createTimeEntry({
            taskId,
            hours: h,
            description,
            date: new Date(date)
        });

        if (res.success) {
            toast.success("Time logged");
            setHours("");
            setDescription("");
            setIsAdding(false);
            fetchEntries();
        } else {
            toast.error(res.error || "Failed to log time");
        }
        setIsSubmitting(false);
    };

    const handleDelete = async (id: string) => {
        if (!confirm("Delete this time entry?")) return;
        const res = await deleteTimeEntry(id);
        if (res.success) {
            toast.success("Entry deleted");
            fetchEntries();
        } else {
            toast.error(res.error || "Failed to delete entry");
        }
    };

    const totalHours = entries.reduce((acc, curr) => acc + curr.hours, 0);

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground/50">
                    <Clock className="w-4 h-4" />
                    Time Tracking
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-muted-foreground">{totalHours}h Total</span>
                    <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setIsAdding(!isAdding)}
                        className="h-7 text-[10px] font-black uppercase tracking-widest rounded-lg"
                    >
                        <Plus className="w-3 h-3 mr-1" /> Add
                    </Button>
                </div>
            </div>

            {isAdding && (
                <div className="bg-muted/20 border border-border/40 p-4 rounded-2xl space-y-3 animate-in fade-in zoom-in-95">
                    <div className="flex gap-3">
                        <div className="space-y-1 w-24 shrink-0">
                            <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Hours</label>
                            <Input 
                                type="number" 
                                step="0.5"
                                min="0.1"
                                value={hours}
                                onChange={e => setHours(e.target.value)}
                                className="h-9 rounded-xl text-xs font-bold bg-background"
                                placeholder="0.0"
                            />
                        </div>
                        <div className="space-y-1 flex-1">
                            <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Date</label>
                            <Input 
                                type="date" 
                                value={date}
                                onChange={e => setDate(e.target.value)}
                                className="h-9 rounded-xl text-xs font-bold bg-background"
                            />
                        </div>
                    </div>
                    <div className="space-y-1">
                        <label className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Notes (Optional)</label>
                        <Textarea 
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            className="h-16 resize-none rounded-xl text-xs bg-background"
                            placeholder="What did you work on?"
                        />
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                        <Button variant="ghost" size="sm" onClick={() => setIsAdding(false)} className="h-8 text-[10px] uppercase font-bold">Cancel</Button>
                        <Button size="sm" onClick={handleAdd} disabled={isSubmitting || !hours} className="h-8 text-[10px] uppercase font-bold rounded-lg">
                            Save Entry
                        </Button>
                    </div>
                </div>
            )}

            <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2 scrollbar-none">
                {loading ? (
                    <div className="py-4 text-center text-xs text-muted-foreground font-medium">Loading...</div>
                ) : entries.length === 0 ? (
                    <div className="py-6 text-center text-[10px] font-black uppercase tracking-widest text-muted-foreground/40 border border-dashed border-border/40 rounded-2xl">
                        No time logged
                    </div>
                ) : (
                    entries.map(entry => {
                        return (
                            <div key={entry.id} className="flex items-start justify-between p-3 rounded-xl bg-muted/10 border border-border/40 group">
                                <div className="flex items-start gap-3">
                                    <Avatar className="h-6 w-6 mt-0.5">
                                        <AvatarImage src={entry.user?.image || ""} />
                                        <AvatarFallback className="text-[8px]">{entry.user?.name?.substring(0,2)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-xs font-bold">{entry.user?.name}</span>
                                            <span className="text-[10px] font-black text-primary bg-primary/10 px-1.5 py-0.5 rounded-md">{entry.hours}h</span>
                                        </div>
                                        {entry.description && (
                                            <p className="text-[11px] text-muted-foreground mt-1 leading-snug">{entry.description}</p>
                                        )}
                                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground/60 font-black tracking-widest uppercase mt-1.5">
                                            <Calendar className="w-3 h-3" />
                                            {format(new Date(entry.date), "MMM d, yyyy")}
                                        </div>
                                    </div>
                                </div>
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => handleDelete(entry.id)}
                                    className="h-6 w-6 opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-600 hover:bg-red-500/10 rounded-md transition-all"
                                >
                                    <Trash2 className="w-3 h-3" />
                                </Button>
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
}
