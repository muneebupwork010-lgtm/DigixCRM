"use client";

import { useState, useMemo } from "react";
import { 
    format, 
    addMonths, 
    subMonths, 
    startOfMonth, 
    endOfMonth, 
    startOfWeek, 
    endOfWeek, 
    isSameMonth, 
    isSameDay, 
    addDays, 
    eachDayOfInterval,
    parseISO,
    isToday
} from "date-fns";
import { 
    ChevronLeft, 
    ChevronRight, 
    Calendar as CalendarIcon,
    MoreHorizontal,
    Plus,
    Circle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { TaskSheet } from "./task-sheet";
import { Badge } from "@/components/ui/badge";

interface TaskCalendarProps {
    tasks: any[];
    users: any[];
}

const statusColors: Record<string, string> = {
    TODO: "bg-slate-500",
    IN_PROGRESS: "bg-blue-500",
    IN_REVIEW: "bg-amber-500",
    DONE: "bg-emerald-500",
};

export function TaskCalendar({ tasks, users }: TaskCalendarProps) {
    const [currentMonth, setCurrentMonth] = useState(new Date());
    const [selectedTask, setSelectedTask] = useState<any>(null);

    const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
    const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

    const days = useMemo(() => {
        const monthStart = startOfMonth(currentMonth);
        const monthEnd = endOfMonth(monthStart);
        const startDate = startOfWeek(monthStart);
        const endDate = endOfWeek(monthEnd);

        return eachDayOfInterval({
            start: startDate,
            end: endDate,
        });
    }, [currentMonth]);

    const tasksByDay = useMemo(() => {
        const map: Record<string, any[]> = {};
        tasks.forEach(task => {
            if (task.dueDate) {
                const dateKey = format(new Date(task.dueDate), "yyyy-MM-dd");
                if (!map[dateKey]) map[dateKey] = [];
                map[dateKey].push(task);
            }
        });
        return map;
    }, [tasks]);

    return (
        <div className="space-y-6">
            {/* Calendar Header */}
            <div className="flex items-center justify-between bg-card p-6 rounded-[2rem] border border-border/40 shadow-xl">
                <div className="flex items-center gap-4">
                    <div className="p-3 rounded-2xl bg-primary/10 text-primary">
                        <CalendarIcon className="w-6 h-6" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black tracking-tight capitalize">
                            {format(currentMonth, "MMMM yyyy")}
                        </h2>
                        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest opacity-60">
                            {tasks.filter(t => t.dueDate && isSameMonth(new Date(t.dueDate), currentMonth)).length} tasks this month
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={prevMonth}
                        className="rounded-xl border-border/40 hover:bg-muted"
                    >
                        <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button 
                        variant="outline" 
                        onClick={() => setCurrentMonth(new Date())}
                        className="rounded-xl border-border/40 hover:bg-muted font-bold text-xs uppercase tracking-widest px-4"
                    >
                        Today
                    </Button>
                    <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={nextMonth}
                        className="rounded-xl border-border/40 hover:bg-muted"
                    >
                        <ChevronRight className="w-4 h-4" />
                    </Button>
                </div>
            </div>

            {/* Calendar Grid */}
            <div className="bg-card rounded-[2.5rem] border border-border/40 shadow-2xl overflow-hidden">
                {/* Weekday Header */}
                <div className="grid grid-cols-7 border-b border-border/40 bg-muted/30">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                        <div key={day} className="py-4 text-center text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground opacity-60">
                            {day}
                        </div>
                    ))}
                </div>

                {/* Days Grid */}
                <div className="grid grid-cols-7 grid-rows-5 min-h-[600px]">
                    {days.map((day, i) => {
                        const dateKey = format(day, "yyyy-MM-dd");
                        const dayTasks = tasksByDay[dateKey] || [];
                        const isCurrentMonth = isSameMonth(day, currentMonth);

                        return (
                            <div 
                                key={dateKey} 
                                className={cn(
                                    "border-r border-b border-border/20 p-2 transition-all group hover:bg-muted/10 relative min-h-[120px]",
                                    !isCurrentMonth && "bg-muted/5 opacity-30",
                                    (i + 1) % 7 === 0 && "border-r-0"
                                )}
                            >
                                <div className="flex items-center justify-between mb-2 px-1">
                                    <span className={cn(
                                        "text-xs font-black w-7 h-7 flex items-center justify-center rounded-full transition-all",
                                        isToday(day) ? "bg-primary text-white shadow-lg shadow-primary/20 scale-110" : "text-muted-foreground group-hover:text-foreground"
                                    )}>
                                        {format(day, "d")}
                                    </span>
                                </div>

                                <div className="space-y-1.5 overflow-y-auto max-h-[100px] scrollbar-none px-1">
                                    {dayTasks.map((task) => (
                                        <div 
                                            key={task.id}
                                            onClick={() => setSelectedTask(task)}
                                            className="group/task flex items-center gap-2 p-1.5 rounded-lg bg-muted/30 hover:bg-primary/10 border border-transparent hover:border-primary/20 cursor-pointer transition-all"
                                        >
                                            <div className={cn("w-1.5 h-1.5 rounded-full shrink-0", statusColors[task.status] || "bg-slate-400")} />
                                            <span className="text-[10px] font-bold truncate group-hover/task:text-primary transition-colors">
                                                {task.title}
                                            </span>
                                        </div>
                                    ))}
                                    {dayTasks.length === 0 && isCurrentMonth && (
                                        <div className="h-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            {/* Optional shortcut to create task? */}
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            <TaskSheet 
                task={selectedTask}
                isOpen={!!selectedTask}
                onClose={() => setSelectedTask(null)}
                users={users}
            />
        </div>
    );
}
