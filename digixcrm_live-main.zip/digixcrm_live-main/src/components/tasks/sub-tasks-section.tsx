"use client";

import { useState, useEffect } from "react";
import { CheckCircle2, Circle, Plus, Trash2, ListTree, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { getSubTasks, createTask, updateTask, deleteTask } from "@/lib/actions/tasks";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";

export function SubTasksSection({ taskId, projectId, mainTaskStatus }: { taskId: string, projectId: string, mainTaskStatus?: string }) {
    const [subTasks, setSubTasks] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [newTitle, setNewTitle] = useState("");
    const [isAdding, setIsAdding] = useState(false);
    const router = useRouter();

    const fetchSubTasks = async () => {
        setLoading(true);
        const data = await getSubTasks(taskId);
        setSubTasks(data);
        setLoading(false);
    };

    useEffect(() => {
        fetchSubTasks();
    }, [taskId]);

    const handleAddSubTask = async (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        if (!newTitle.trim()) return;

        setIsAdding(true);
        const res = await createTask({
            title: newTitle,
            projectId: projectId,
            parentTaskId: taskId,
            status: "TODO"
        });

        if (res.success) {
            setNewTitle("");
            fetchSubTasks();
            toast.success("Sub-task added");
            router.refresh();
        } else {
            toast.error(res.error || "Failed to add sub-task");
        }
        setIsAdding(false);
    };

    const handleToggleStatus = async (subTaskId: string, currentStatus: string) => {
        const newStatus = currentStatus === "DONE" ? "TODO" : "DONE";
        const res = await updateTask(subTaskId, { status: newStatus });
        
        if (res.success) {
            const updatedSubTasks = subTasks.map(t => t.id === subTaskId ? { ...t, status: newStatus } : t);
            setSubTasks(updatedSubTasks);
            
            // Smart Status Automation
            const total = updatedSubTasks.length;
            const completed = updatedSubTasks.filter(t => t.status === "DONE").length;
            
            if (newStatus === "DONE" && completed === total && mainTaskStatus !== "DONE") {
                if (confirm("All sub-tasks are complete! Mark the main task as Done?")) {
                    await updateTask(taskId, { status: "DONE" });
                    toast.success("Main task marked as Done!");
                }
            } else if (newStatus === "DONE" && completed > 0 && mainTaskStatus === "TODO") {
                // Optionally move to IN_PROGRESS if first sub-task is done
                await updateTask(taskId, { status: "IN_PROGRESS" });
                toast.success("Main task automatically moved to In Progress");
            }

            router.refresh();
        } else {
            toast.error(res.error || "Failed to update status");
        }
    };

    const completedCount = subTasks.filter(t => t.status === "DONE").length;
    const totalCount = subTasks.length;
    const progress = totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100);

    const handleDeleteSubTask = async (subTaskId: string) => {
        if (!confirm("Are you sure you want to delete this sub-task?")) return;

        const res = await deleteTask(subTaskId);
        if (res.success) {
            setSubTasks(prev => prev.filter(t => t.id !== subTaskId));
            toast.success("Sub-task deleted");
            router.refresh();
        } else {
            toast.error(res.error || "Failed to delete sub-task");
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground/50">
                        <ListTree className="w-4 h-4 text-primary/40" />
                        Sub-tasks ({completedCount}/{totalCount})
                    </div>
                </div>
                {totalCount > 0 && (
                    <div className="flex items-center gap-3">
                        <div className="h-1.5 flex-1 bg-muted rounded-full overflow-hidden">
                            <div 
                                className="h-full bg-primary transition-all duration-500 ease-in-out" 
                                style={{ width: `${progress}%` }} 
                            />
                        </div>
                        <span className="text-[10px] font-black text-muted-foreground w-8 text-right">{progress}%</span>
                    </div>
                )}
            </div>
            
            <div className="space-y-2">
                {loading ? (
                    <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground/30" />
                    </div>
                ) : subTasks.length > 0 ? (
                    <div className="space-y-1">
                        {subTasks.map((st) => (
                            <div 
                                key={st.id} 
                                className="group flex items-center justify-between p-3 rounded-xl bg-muted/5 border border-transparent hover:border-border/40 hover:bg-muted/10 transition-all"
                            >
                                <div className="flex items-center gap-3 flex-1 min-w-0">
                                    <button 
                                        onClick={() => handleToggleStatus(st.id, st.status)}
                                        className="shrink-0 outline-none"
                                    >
                                        {st.status === "DONE" ? (
                                            <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-500/10" />
                                        ) : (
                                            <Circle className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary transition-colors" />
                                        )}
                                    </button>
                                    <span className={cn(
                                        "text-xs font-bold truncate transition-all",
                                        st.status === "DONE" ? "text-muted-foreground/40 line-through" : "text-foreground"
                                    )}>
                                        {st.title}
                                    </span>
                                </div>
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => handleDeleteSubTask(st.id)}
                                    className="h-7 w-7 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/10 hover:text-red-500"
                                >
                                    <Trash2 className="w-3.5 h-3.5" />
                                </Button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="py-8 text-center text-[10px] font-black uppercase tracking-widest text-muted-foreground/30 border border-dashed border-border/40 rounded-2xl bg-muted/5">
                        No sub-tasks yet
                    </div>
                )}

                <form onSubmit={handleAddSubTask} className="flex items-center gap-2 mt-4">
                    <Input 
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        placeholder="Add a sub-task..."
                        className="h-9 text-xs font-bold bg-muted/20 border-border/30 rounded-xl focus-visible:ring-primary/20"
                    />
                    <Button 
                        type="submit"
                        size="icon"
                        disabled={isAdding || !newTitle.trim()}
                        className="h-9 w-9 shrink-0 rounded-xl shadow-lg shadow-primary/10"
                    >
                        {isAdding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    </Button>
                </form>
            </div>
        </div>
    );
}
