"use client";

import { useState, useMemo } from "react";
import { useRoleFlags } from "@/components/layout/effective-role-provider";
import { useConfirm } from "@/components/providers/confirm-dialog-provider";
import {
    ColumnDef,
    flexRender,
    getCoreRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
    SortingState,
} from "@tanstack/react-table";
import { Organization, Lead } from "@/generated/prisma/client/client";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuLabel,
    DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { 
    Trash2, 
    ShieldAlert, 
    ExternalLink, 
    Globe, 
    Calendar, 
    Search, 
    FilterX, 
    MoreHorizontal, 
    ArrowUpDown, 
    ChevronUp, 
    ChevronDown,
    Building2,
    Users,
    ArrowRight
} from "lucide-react";
import { deleteOrganization, deleteOrganizations } from "@/lib/actions/organizations";
import { EditOrgDialog } from "./edit-org-dialog";
import { OrganizationSheet } from "./organization-sheet";
import { Input } from "@/components/ui/input";
import { DatePickerWithRange } from "@/components/ui/date-picker-with-range";
import { isWithinInterval, startOfDay, endOfDay } from "date-fns";
import { toast } from "sonner";

export type OrganizationWithLeads = any;

interface OrganizationListProps {
    data: OrganizationWithLeads[];
}

export function OrganizationList({ data }: OrganizationListProps) {
    const { confirm } = useConfirm();
    const [loadingId, setLoadingId] = useState<string | null>(null);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [sheetOpen, setSheetOpen] = useState(false);
    const [sheetOrg, setSheetOrg] = useState<OrganizationWithLeads | null>(null);
    const [sorting, setSorting] = useState<SortingState>([]);

    // --- Filter States ---
    const [searchQuery, setSearchQuery] = useState("");
    const [dateRange, setDateRange] = useState<{ from: Date | undefined; to?: Date | undefined } | undefined>();

    // Effective WORKSPACE role, not the global User.role on the session.
    const { isAdmin } = useRoleFlags();

    // --- Filter Logic ---
    const filteredData = useMemo(() => {
        const query = searchQuery.toLowerCase();
        return data.filter((org) => {
            const matchesSearch =
                (org.name || "").toLowerCase().includes(query) ||
                (org.website || "").toLowerCase().includes(query);

            let matchesDate = true;
            if (dateRange?.from) {
                const orgDate = new Date(org.createdAt);
                if (dateRange.to) {
                    matchesDate = isWithinInterval(orgDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.to)
                    });
                } else {
                    matchesDate = isWithinInterval(orgDate, {
                        start: startOfDay(dateRange.from),
                        end: endOfDay(dateRange.from)
                    });
                }
            }

            return matchesSearch && matchesDate;
        });
    }, [data, searchQuery, dateRange]);

    const toggleAll = () => {
        if (selectedIds.size === filteredData.length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(filteredData.map(org => org.id)));
        }
    };

    const toggleOrg = (id: string) => {
        const next = new Set(selectedIds);
        if (next.has(id)) {
            next.delete(id);
        } else {
            next.add(id);
        }
        setSelectedIds(next);
    };

    const handleBulkDelete = async () => {
        if (selectedIds.size === 0) return;
        const isConfirmed = await confirm({
            title: "Delete Organizations",
            description: `Are you sure you want to delete ${selectedIds.size} organizations? This cannot be undone.`,
            variant: "destructive",
            confirmText: "Eradicate Records"
        });
        if (!isConfirmed) return;

        setLoadingId("bulk_delete");
        const res = await deleteOrganizations(Array.from(selectedIds));
        if (res.success) {
            setSelectedIds(new Set());
            toast.success(`${res.count} Organizations purged successfully.`);
        } else {
            toast.error(res.error || "Failed to delete organizations.");
        }
        setLoadingId(null);
    };

    const columns: ColumnDef<OrganizationWithLeads>[] = [
        {
            id: "select",
            header: () => (
                <Checkbox
                    checked={selectedIds.size === filteredData.length && filteredData.length > 0}
                    onCheckedChange={toggleAll}
                    aria-label="Select all"
                    className="translate-y-[2px] border-border"
                />
            ),
            cell: ({ row }) => (
                <Checkbox
                    checked={selectedIds.has(row.original.id)}
                    onCheckedChange={() => toggleOrg(row.original.id)}
                    aria-label="Select row"
                    className="translate-y-[2px] border-border"
                    onClick={(e) => e.stopPropagation()}
                />
            ),
            enableSorting: false,
            enableHiding: false,
        },
        {
            accessorKey: "name",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Company Name
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => (
                <div className="font-bold text-foreground tracking-tight">{row.original.name}</div>
            )
        },
        {
            accessorKey: "website",
            header: "Website",
            cell: ({ row }) => {
                const website = row.original.website;
                if (!website) return <span className="text-muted-foreground text-[10px] uppercase font-bold opacity-30 italic">Not set</span>;
                return (
                    <a
                        href={website.startsWith("http") ? website : `https://${website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 hover:underline flex items-center gap-2 text-xs font-bold transition-colors"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <Globe className="w-3 h-3" />
                        {website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")}
                        <ExternalLink className="w-2.5 h-2.5 opacity-40 shrink-0" />
                    </a>
                );
            },
        },
        {
            accessorKey: "createdAt",
            header: ({ column }) => (
                <Button
                    variant="ghost"
                    className="text-[11px] font-black uppercase tracking-wider p-0 hover:bg-transparent"
                    onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
                >
                    Registration
                    {column.getIsSorted() === "asc" ? (
                        <ChevronUp className="ml-2 h-3 w-3" />
                    ) : column.getIsSorted() === "desc" ? (
                        <ChevronDown className="ml-2 h-3 w-3" />
                    ) : (
                        <ArrowUpDown className="ml-2 h-3 w-3 opacity-50" />
                    )}
                </Button>
            ),
            cell: ({ row }) => {
                const date = new Date(row.original.createdAt);
                return (
                    <div className="flex items-center gap-2 text-muted-foreground text-[11px] font-medium uppercase">
                        {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </div>
                );
            },
        },
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => {
                const org = row.original;
                return (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2.5 text-primary hover:text-primary hover:bg-primary/5 font-bold text-[11px]"
                            onClick={() => {
                                setSheetOrg(org);
                                setSheetOpen(true);
                            }}
                        >
                            Orchestration
                            <ArrowRight className="w-3 h-3 ml-1.5 opacity-40" />
                        </Button>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Open menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48 p-2 rounded-2xl shadow-2xl">
                                <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-2 py-1.5">Entity Control</DropdownMenuLabel>
                                <EditOrgDialog organization={org} />
                                {isAdmin && (
                                    <>
                                        <DropdownMenuSeparator className="opacity-50" />
                                        <DropdownMenuItem
                                            className="gap-2 py-2.5 font-bold text-red-500 focus:text-red-500 focus:bg-red-50 dark:focus:bg-red-900/20 rounded-xl"
                                            onClick={async () => {
                                                const isConfirmed = await confirm({
                                                    title: "Delete Organization",
                                                    description: "Are you sure you want to delete this organization? This cannot be undone.",
                                                    variant: "destructive",
                                                    confirmText: "Delete Entity"
                                                });
                                                if (isConfirmed) {
                                                    setLoadingId(`delete_${org.id}`);
                                                    const res = await deleteOrganization(org.id);
                                                    if (res.success) {
                                                        toast.success("Organization wiped.");
                                                    } else {
                                                        toast.error(res.error || "Failed to wipe organization.");
                                                    }
                                                    setLoadingId(null);
                                                }
                                            }}
                                            disabled={loadingId === `delete_${org.id}`}
                                        >
                                            <Trash2 className="w-4 h-4" />
                                            {loadingId === `delete_${org.id}` ? "Wiping..." : "Delete Permanently"}
                                        </DropdownMenuItem>
                                    </>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                );
            },
        },
    ];

    const table = useReactTable({
        data: filteredData,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        onSortingChange: setSorting,
        state: { sorting },
        initialState: {
            pagination: { pageSize: 15 },
            sorting: [{ id: "createdAt", desc: true }]
        },
    });

    return (
        <div className="flex flex-col gap-4">
            {/* Filter Toolbar */}
            <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center bg-card p-4 rounded-2xl border border-border/50 shadow-sm transition-all duration-300">
                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 w-full xl:w-auto flex-1">
                    <div className="relative w-full md:w-[300px] lg:w-[400px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                            placeholder="Search by company name, website..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 bg-muted/50 border-border focus:bg-background transition-all h-10 rounded-xl text-sm"
                        />
                    </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3 w-full xl:w-auto">
                    <div className="relative w-full sm:w-auto">
                        <DatePickerWithRange date={dateRange} setDate={setDateRange} />
                    </div>

                    {(searchQuery || dateRange) && (
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                                setSearchQuery("");
                                setDateRange(undefined);
                            }}
                            className="text-muted-foreground hover:text-foreground h-10 w-10 shrink-0 hidden sm:flex border border-border/60"
                            title="Clear all filters"
                        >
                            <FilterX className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>

            {selectedIds.size > 0 && (
                <div className="mb-4 p-3 bg-primary text-primary-foreground rounded-2xl flex items-center justify-between animate-in slide-in-from-top-2 duration-300 shadow-xl border border-white/10">
                    <div className="flex items-center gap-3">
                        <div className="bg-white/20 p-1.5 rounded-md">
                            <ShieldAlert className="w-4 h-4 text-indigo-300" />
                        </div>
                        <span className="text-sm font-medium">
                            <span className="font-black text-indigo-300">{selectedIds.size}</span> entities selected
                        </span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="text-primary-foreground/70 hover:text-primary-foreground hover:bg-white/10 rounded-xl"
                            onClick={() => setSelectedIds(new Set())}
                        >
                            Deselect
                        </Button>
                        <Button
                            variant="destructive"
                            size="sm"
                            className="bg-red-500 hover:bg-red-600 shadow-sm rounded-xl px-4"
                            onClick={handleBulkDelete}
                            disabled={loadingId === "bulk_delete"}
                        >
                            {loadingId === "bulk_delete" ? "Purging..." : (
                                <>
                                    <Trash2 className="w-3.5 h-3.5 mr-2" />
                                    Purge Selection
                                </>
                            )}
                        </Button>
                    </div>
                </div>
            )}

            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden pb-4">
                {filteredData.length > 0 ? (
                    filteredData.map((org) => (
                        <div
                            key={org.id}
                            className="p-5 rounded-3xl border border-border/60 bg-card shadow-sm active:scale-[0.98] transition-all duration-200"
                            onClick={() => {
                                setSheetOrg(org);
                                setSheetOpen(true);
                            }}
                        >
                            <div className="flex items-start justify-between mb-4">
                                <div className="flex items-center gap-3">
                                    <Checkbox
                                        checked={selectedIds.has(org.id)}
                                        onCheckedChange={() => toggleOrg(org.id)}
                                        onClick={(e) => e.stopPropagation()}
                                        className="h-5 w-5 rounded-lg border-border/60"
                                    />
                                    <div>
                                        <h3 className="text-base font-black text-foreground tracking-tight leading-none mb-1.5">
                                            {org.name}
                                        </h3>
                                        <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
                                            <Calendar className="w-2.5 h-2.5 opacity-50" />
                                            {new Date(org.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                        </div>
                                    </div>
                                </div>
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-9 w-9 p-0 rounded-2xl bg-muted/40">
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end" className="w-48 p-2 rounded-2xl shadow-2xl">
                                        <EditOrgDialog organization={org} />
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </div>

                            <div className="bg-muted/30 p-4 rounded-2xl border border-border/40 mb-2">
                                <div className="flex items-center justify-between gap-4">
                                    <div className="flex items-center gap-2.5 overflow-hidden">
                                        <Globe className="w-3.5 h-3.5 text-indigo-500/60 shrink-0" />
                                        <span className="text-xs font-bold text-foreground truncate">
                                            {org.website || "No URL provided"}
                                        </span>
                                    </div>
                                    {org.website && (
                                        <a 
                                            href={org.website.startsWith('http') ? org.website : `https://${org.website}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="shrink-0 p-1.5 bg-background rounded-lg border border-border/40 text-primary hover:bg-primary/5 transition-colors"
                                            onClick={(e) => e.stopPropagation()}
                                        >
                                            <ExternalLink className="w-3 h-3" />
                                        </a>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="py-20 flex flex-col items-center justify-center text-center text-muted-foreground font-medium bg-muted/20 rounded-3xl border-2 border-dashed border-border/40">
                         <Building2 className="w-10 h-10 opacity-20 mb-4" />
                         <p className="text-sm font-bold uppercase tracking-widest opacity-60">Zero Entities Isolated</p>
                    </div>
                )}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
                <Table>
                    <TableHeader className="bg-muted/40 font-bold">
                        {table.getHeaderGroups().map((headerGroup) => (
                            <TableRow key={headerGroup.id} className="hover:bg-transparent border-border/50">
                                {headerGroup.headers.map((header) => (
                                    <TableHead key={header.id} className="h-12 px-5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                                        {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map((row) => (
                                <TableRow
                                    key={row.id}
                                    className="cursor-pointer transition-colors border-border/40 hover:bg-muted/30"
                                    onClick={() => {
                                        setSheetOrg(row.original);
                                        setSheetOpen(true);
                                    }}
                                >
                                    {row.getVisibleCells().map((cell) => (
                                        <TableCell key={cell.id} className="px-5 py-4 text-[13px] whitespace-nowrap align-middle">
                                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={columns.length} className="h-32 text-center text-muted-foreground font-black italic opacity-30 uppercase tracking-[0.2em]">
                                    Database Null Sector
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Pagination Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-4 border-t border-border/50">
                <div className="text-sm text-muted-foreground font-medium text-center sm:text-left">
                    Isolated <span className="text-foreground font-black">{table.getRowModel().rows.length}</span> of <span className="text-foreground font-black">{filteredData.length}</span> total entities.
                </div>
                
                <div className="flex items-center gap-3 sm:gap-6 flex-wrap justify-center sm:justify-end w-full sm:w-auto">
                    <div className="flex items-center gap-2">
                        <p className="text-xs font-black text-muted-foreground uppercase tracking-widest hidden xs:block">Page Size</p>
                        <Select
                            value={`${table.getState().pagination.pageSize}`}
                            onValueChange={(value) => table.setPageSize(Number(value))}
                        >
                            <SelectTrigger className="h-8 w-[76px] bg-muted/50 border-border/50 font-black text-[10px] ring-0 rounded-lg">
                                <SelectValue placeholder={table.getState().pagination.pageSize} />
                            </SelectTrigger>
                            <SelectContent side="top" className="border-border shadow-2xl rounded-xl">
                                {[15, 30, 50, 100].map((pageSize) => (
                                    <SelectItem key={pageSize} value={`${pageSize}`} className="text-[10px] font-bold">
                                        {pageSize}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="flex items-center justify-center text-[10px] font-black min-w-[90px] whitespace-nowrap bg-muted/40 px-3 py-1 rounded-full border border-border/50 uppercase tracking-tighter">
                        Page {table.getState().pagination.pageIndex + 1} <span className="text-muted-foreground font-light mx-1.5">/</span> {table.getPageCount() || 1}
                    </div>

                    <div className="flex items-center gap-1.5">
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all rounded-lg border-border"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            <span className="sr-only">Previous</span>
                            <span className="text-lg leading-none mb-0.5">‹</span>
                        </Button>
                        <Button
                            variant="outline"
                            className="h-8 w-8 p-0 bg-background hover:bg-primary/5 hover:text-primary hover:border-primary/40 transition-all rounded-lg border-border"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            <span className="sr-only">Next</span>
                            <span className="text-lg leading-none mb-0.5">›</span>
                        </Button>
                    </div>
                </div>
            </div>

            <OrganizationSheet 
                organization={sheetOrg} 
                open={sheetOpen} 
                onOpenChange={setSheetOpen} 
            />
        </div>
    );
}
