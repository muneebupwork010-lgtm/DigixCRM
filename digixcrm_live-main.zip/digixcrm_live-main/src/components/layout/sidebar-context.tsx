"use client";

import React, { createContext, useContext, useState, useEffect } from "react";

type SidebarContextType = {
    isCollapsed: boolean;
    toggleSidebar: () => void;
    setIsCollapsed: (value: boolean) => void;
};

const SidebarContext = createContext<SidebarContextType | undefined>(undefined);

export function SidebarProvider({ children }: { children: React.ReactNode }) {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        const saved = localStorage.getItem("sidebar-collapsed");
        if (saved !== null) {
            setIsCollapsed(saved === "true");
        }
        setMounted(true);
    }, []);

    const toggleSidebar = () => {
        setIsCollapsed((prev) => {
            const newValue = !prev;
            localStorage.setItem("sidebar-collapsed", String(newValue));
            return newValue;
        });
    };

    const handleSetCollapsed = (value: boolean) => {
        setIsCollapsed(value);
        localStorage.setItem("sidebar-collapsed", String(value));
    };

    useEffect(() => {
        if (mounted) {
            document.documentElement.style.setProperty("--sidebar-width", isCollapsed ? "80px" : "260px");
        }
    }, [isCollapsed, mounted]);

    // Prevent hydration mismatch by not rendering anything that depends on state until mounted
    return (
        <SidebarContext.Provider value={{ isCollapsed: mounted ? isCollapsed : false, toggleSidebar, setIsCollapsed: handleSetCollapsed }}>
            {children}
        </SidebarContext.Provider>
    );
}

export function useSidebar() {
    const context = useContext(SidebarContext);
    if (context === undefined) {
        throw new Error("useSidebar must be used within a SidebarProvider");
    }
    return context;
}
