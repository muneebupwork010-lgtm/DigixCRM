"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import { getPusherClient } from "@/lib/pusher-client";
import { getUnreadChatCount } from "@/lib/actions/chat";
import {
    Users,
    Briefcase,
    Building2,
    LayoutDashboard,
    Activity,
    Settings,
    ChevronDown,
    Building,
    BarChart2,
    ClipboardCheck,
    ArchiveX,
    UserCircle2,
    Puzzle,
    FolderKanban,
    CheckSquare,
    Layers,
    CalendarClock,
    Calendar,
    Clock3,
    CalendarCheck,
    MessageSquare
} from "lucide-react";
import { cn } from "@/lib/utils";
import { switchWorkspace } from "@/lib/actions/workspaces";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Logo } from "@/components/brand/logo";
import { getEntitlements, PlanTier } from "@/lib/entitlements";
import { useSidebar } from "./sidebar-context";
import { motion, AnimatePresence } from "framer-motion";
import { PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../ui/tooltip";

const sidebarModules = [
    {
        id: "CRM",
        label: "Sales & CRM",
        icon: Briefcase,
        links: [
            { name: "Leads", href: "/dashboard/leads", icon: Users },
            { name: "Lead Gen", href: "/dashboard/lead-gen", icon: Layers },
            { name: "Contacts", href: "/dashboard/contacts", icon: UserCircle2 },
            { name: "Sales Pipeline", href: "/dashboard/deals", icon: Briefcase },
            { name: "Orders", href: "/dashboard/orders", icon: ClipboardCheck },
            { name: "Closed-Lost", href: "/dashboard/closed-lost", icon: ArchiveX },
        ]
    },
    {
        id: "PMS",
        label: "Project Management",
        icon: FolderKanban,
        links: [
            { name: "Projects", href: "/dashboard/projects", icon: FolderKanban },
            { name: "My Tasks", href: "/dashboard/tasks", icon: CheckSquare },
        ]
    },
    {
        id: "SCHEDULER",
        label: "Scheduler",
        icon: CalendarClock,
        links: [
            { name: "Calendar", href: "/dashboard/scheduler", icon: Calendar },
            { name: "My Slots", href: "/dashboard/scheduler/availability", icon: Clock3 },
            { name: "Bookings", href: "/dashboard/scheduler/bookings", icon: CalendarCheck },
        ]
    },
    {
        id: "SHARED",
        label: "Insight & Control",
        links: [
            { name: "Organizations", href: "/dashboard/organizations", icon: Building2 },
            { name: "Performance", href: "/dashboard/performance", icon: BarChart2 },
            { name: "Activities", href: "/dashboard/activities", icon: Activity },
            { name: "Add Ons", href: "/dashboard/addons", icon: Puzzle },
        ]
    }
];

export function Sidebar({
    role,
    workspaces = [],
    activeWorkspaceId,
    isMaster = false,
    planTier = "FREE",
    enabledModules = ["CRM", "PMS"],
    className,
    onItemClick,
    forceExpand = false
}: {
    role?: string,
    workspaces?: any[],
    activeWorkspaceId?: string | null,
    isMaster?: boolean,
    planTier?: string,
    enabledModules?: string[],
    className?: string,
    onItemClick?: () => void,
    forceExpand?: boolean
}) {
    const pathname = usePathname();
    const { isCollapsed: contextIsCollapsed, toggleSidebar } = useSidebar();
    
    const { data: session } = useSession();
    const userId = (session?.user as any)?.id;
    const [hasUnread, setHasUnread] = useState(false);
    
    useEffect(() => {
        if (!userId) return;

        const checkUnreads = async () => {
            const res = await getUnreadChatCount();
            if (res.success) {
                setHasUnread(res.count > 0);
            }
        };

        checkUnreads();

        const pusher = getPusherClient();
        if (!pusher) return;

        const channel = pusher.subscribe(`user-${userId}`);
        channel.bind("unread-update", () => {
            checkUnreads();
        });

        return () => {
            channel.unbind("unread-update");
            pusher.unsubscribe(`user-${userId}`);
        };
    }, [userId]);
    const isCollapsed = forceExpand ? false : contextIsCollapsed;
    const entitlements = getEntitlements(planTier as PlanTier);
    
    const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
    
    const toggleSection = (id: string) => {
        setCollapsedSections(prev => ({ ...prev, [id]: !prev[id] }));
    };
    const activeModules = Array.from(new Set([...(enabledModules || []), "CRM", "PMS", "SCHEDULER"]));

    const handleWorkspaceChange = async (id: string) => {
        const res = await switchWorkspace(id);
        if (res.success) {
            toast.success("Switched workspace");
            if (onItemClick) onItemClick();
            window.location.reload(); // Hard reload to clear all state
        } else {
            toast.error(res.error || "Failed to switch workspace");
        }
    };

    return (
        <aside
            id="main-sidebar"
            className={cn(
                "flex flex-col bg-card border-r border-border transition-all duration-300 ease-in-out shadow-sm",
                isCollapsed ? "w-[80px]" : "w-[260px]",
                "fixed top-0 left-0 h-screen z-50 hidden md:flex",
                className
            )}
        >
            <div className={cn(
                "h-16 flex items-center border-b border-border bg-card shrink-0 transition-all duration-300",
                isCollapsed ? "px-0 justify-center" : "px-6 justify-between"
            )}>
                <Link href="/dashboard" onClick={onItemClick} className="flex items-center gap-3 transition-opacity hover:opacity-80 group overflow-hidden">
                    <Logo showText={!isCollapsed} size={isCollapsed ? "sm" : "md"} />
                </Link>
                {!isCollapsed && !forceExpand && (
                    <button
                        onClick={toggleSidebar}
                        className="p-2 rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                        title="Collapse Sidebar"
                    >
                        <PanelLeftClose className="w-5 h-5" />
                    </button>
                )}
            </div>
            {isCollapsed && !forceExpand && (
                <div className="flex justify-center p-2 border-b border-border/50">
                    <button
                        onClick={toggleSidebar}
                        className="p-2 rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                        title="Expand Sidebar"
                    >
                        <PanelLeftOpen className="w-5 h-5" />
                    </button>
                </div>
            )}

            <div className="flex-1 py-4 overflow-y-auto px-4 space-y-6 scrollbar-none">
                {workspaces.length > 0 && (
                    <div id="workspace-switcher-hub" className="space-y-2 mb-2">
                        {!isCollapsed && (
                            <div className="px-3 text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em]">
                                Workspace hub
                            </div>
                        )}
                        <TooltipProvider>
                            <Tooltip delayDuration={0}>
                                <TooltipTrigger asChild>
                                    <div className="w-full">
                                        <Select value={activeWorkspaceId || ""} onValueChange={handleWorkspaceChange}>
                                            <SelectTrigger 
                                                hideChevron={isCollapsed}
                                                className={cn(
                                                    "w-full bg-background border border-border/60 hover:bg-muted/40 transition-all h-10 rounded-xl text-[13px] font-semibold text-foreground/90 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.05)]",
                                                    isCollapsed ? "px-0 justify-center w-10 mx-auto" : "px-3"
                                                )}
                                            >
                                                {isCollapsed ? (
                                                    <Building className="w-5 h-5 text-indigo-600 dark:text-blue-400" />
                                                ) : (
                                                    <SelectValue placeholder="Select Workspace" />
                                                )}
                                            </SelectTrigger>
                                            <SelectContent position="popper" side="right" align="start" className="rounded-xl shadow-2xl border-border/40 min-w-[200px]">
                                                {workspaces.map((ws: any) => (
                                                    <SelectItem key={ws.id} value={ws.id} className="rounded-lg m-1 text-[13px] font-medium">
                                                        <div className="flex items-center gap-2">
                                                            <Building className="w-4 h-4 text-muted-foreground/70" />
                                                            <span className="truncate">{ws.name}</span>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </TooltipTrigger>
                                {isCollapsed && (
                                    <TooltipContent side="right" className="font-bold border-border shadow-xl">
                                        Switch Workspace
                                    </TooltipContent>
                                )}
                            </Tooltip>
                        </TooltipProvider>
                    </div>
                )}

                <div>
                    <nav className="space-y-5">
                        {/* 1. PLATFORM CONTROL (Super Admin Only) */}
                        {isMaster && workspaces.length > 0 && (
                             <div className="mb-2">
                                {!isCollapsed && (
                                    <div 
                                        className="px-3 text-[10px] font-extrabold text-[#0d1b4b] dark:text-blue-400 uppercase tracking-[0.2em] mb-2 mt-2 flex items-center justify-between cursor-pointer group hover:opacity-80 transition-opacity"
                                        onClick={() => toggleSection("PLATFORM_CONTROL")}
                                    >
                                        <span>Platform Control</span>
                                        <ChevronDown className={cn("w-3.5 h-3.5 transition-transform duration-200 text-[#0d1b4b]/50 dark:text-blue-400/50 group-hover:text-[#0d1b4b] dark:group-hover:text-blue-400", collapsedSections["PLATFORM_CONTROL"] ? "-rotate-90" : "rotate-0")} />
                                    </div>
                                )}
                                <AnimatePresence initial={false}>
                                    {(!collapsedSections["PLATFORM_CONTROL"] || isCollapsed) && (
                                        <motion.div 
                                            initial={isCollapsed ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
                                            animate={{ height: "auto", opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            className="space-y-1 overflow-hidden"
                                        >
                                            <SidebarLink
                                                href="/dashboard/saas"
                                                icon={BarChart2}
                                                label="Control Room"
                                                isActive={pathname === "/dashboard/saas"}
                                                isCollapsed={isCollapsed}
                                                onItemClick={onItemClick}
                                            />
                                            <SidebarLink
                                                href="/dashboard/saas/accounts"
                                                icon={Building}
                                                label="Platform Accounts"
                                                isActive={pathname === "/dashboard/saas/accounts"}
                                                isCollapsed={isCollapsed}
                                                onItemClick={onItemClick}
                                            />
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                             </div>
                        )}

                        <SidebarLink
                            href="/dashboard"
                            icon={LayoutDashboard}
                            label="Overview"
                            isActive={pathname === "/dashboard"}
                            isCollapsed={isCollapsed}
                            onItemClick={onItemClick}
                        />

                        <SidebarLink
                            href="/dashboard/inbox"
                            icon={MessageSquare}
                            label="Inbox"
                            isActive={pathname === "/dashboard/inbox"}
                            isCollapsed={isCollapsed}
                            onItemClick={onItemClick}
                            showDot={hasUnread}
                        />

                        {sidebarModules.map((module) => {
                            const isAvailableInPlan = module.id === "SHARED" || entitlements.availableModules.includes(module.id);
                            const isActivatedInWorkspace = module.id === "SHARED" || activeModules.includes(module.id);

                            if (module.id === "CRM" && (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT")) return null;
                            if (module.id === "PMS" && role === "REP") return null;
                            if (module.id === "SCHEDULER" && (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT")) return null;
                            if (module.id === "SHARED" && role === "CLIENT") return null;
                            if (!isAvailableInPlan || !isActivatedInWorkspace) return null;

                            return (
                                <div key={module.id} className="space-y-2">
                                    {!isCollapsed && (
                                        <div 
                                            className="px-3 text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] flex items-center justify-between cursor-pointer group hover:text-foreground transition-colors"
                                            onClick={() => toggleSection(module.id)}
                                        >
                                            <span>{module.label}</span>
                                            <ChevronDown className={cn("w-3.5 h-3.5 transition-transform duration-200 text-muted-foreground/50 group-hover:text-foreground/80", collapsedSections[module.id] ? "-rotate-90" : "rotate-0")} />
                                        </div>
                                    )}
                                    <AnimatePresence initial={false}>
                                        {(!collapsedSections[module.id] || isCollapsed) && (
                                            <motion.div 
                                                initial={isCollapsed ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
                                                animate={{ height: "auto", opacity: 1 }}
                                                exit={{ height: 0, opacity: 0 }}
                                                className="space-y-1 overflow-hidden"
                                            >
                                                {module.links.map((link) => {
                                                    if (link.name === "Add Ons" && !isMaster && planTier !== "PRO" && planTier !== "ENTERPRISE") return null;
                                                    
                                                    if (link.name === "Lead Gen") {
                                                        const isAllowedRole = role === "MANAGER" || role === "ADMIN" || role === "ACCOUNT_OWNER" || isMaster;
                                                        const isAllowedPlan = planTier === "PRO" || planTier === "ENTERPRISE";
                                                        if (!isAllowedRole || !isAllowedPlan) return null;
                                                    }

                                                    const isActive = pathname === link.href || (pathname.startsWith(link.href) && link.href !== '/dashboard' && !pathname.startsWith('/dashboard/saas'));

                                                    return (
                                                        <SidebarLink
                                                            key={link.name}
                                                            href={link.href}
                                                            icon={link.icon}
                                                            label={link.name}
                                                            isActive={isActive}
                                                            isCollapsed={isCollapsed}
                                                            onItemClick={onItemClick}
                                                        />
                                                    );
                                                })}
                                            </motion.div>
                                        )}
                                    </AnimatePresence>
                                </div>
                            );
                        })}
                    </nav>
                </div>
            </div>

            <div className="p-4 border-t border-border bg-muted/20 shrink-0">
                <SidebarLink
                    href="/dashboard/settings"
                    icon={Settings}
                    label="System Settings"
                    isActive={pathname === "/dashboard/settings"}
                    isCollapsed={isCollapsed}
                    onItemClick={onItemClick}
                />
            </div>
        </aside>
    );
}

function SidebarLink({ href, icon: Icon, label, isActive, isCollapsed, onItemClick, showDot }: any) {
    const link = (
        <Link
            href={href}
            prefetch={true}
            onClick={onItemClick}
            className={cn(
                "flex items-center transition-all duration-200 group text-sm rounded-xl relative",
                isCollapsed ? "px-0 justify-center h-12" : "px-3 py-3 gap-3",
                isActive
                    ? "bg-primary text-primary-foreground font-bold shadow-lg shadow-primary/20 scale-[1.02]"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground font-medium"
            )}
        >
            <div className="relative flex items-center justify-center shrink-0">
                <Icon className={cn(
                    "transition-colors",
                    isCollapsed ? "w-5 h-5" : "w-4.5 h-4.5",
                    isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-foreground"
                )} />
                {isCollapsed && showDot && (
                    <span className="absolute -top-1 -right-1 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                    </span>
                )}
            </div>
            <AnimatePresence mode="wait">
                {!isCollapsed && (
                    <motion.span
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="whitespace-nowrap overflow-hidden flex-1"
                    >
                        {label}
                    </motion.span>
                )}
            </AnimatePresence>
            {!isCollapsed && showDot && (
                <span className="flex h-2 w-2 ml-auto shrink-0 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
            )}
        </Link>
    );

    if (isCollapsed) {
        return (
            <TooltipProvider>
                <Tooltip delayDuration={0}>
                    <TooltipTrigger asChild>
                        {link}
                    </TooltipTrigger>
                    <TooltipContent side="right" className="font-bold border-border shadow-xl">
                        {label}
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
        );
    }

    return link;
}
