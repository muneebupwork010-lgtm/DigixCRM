"use client";

import { createContext, useContext } from "react";

/**
 * Supplies the user's EFFECTIVE role (their WorkspaceMember role for the active
 * workspace, falling back to the global User.role) to client components.
 *
 * Why this exists: `session.user.role` is the GLOBAL User.role column — the JWT is
 * built from `select: { role: true }` in src/lib/auth.ts and never consults
 * WorkspaceMember. Client components that gated UI on it therefore disagreed with
 * the server, which resolves permissions via getEffectiveRole(). A user who is a
 * MANAGER in a workspace but a REP globally was shown the REP interface even though
 * every server action would have accepted the manager-level request.
 *
 * The value is resolved once, server-side, in src/app/dashboard/layout.tsx (which
 * already calls getEffectiveRole) and passed down — so this adds no extra query and
 * stays correct across workspace switches, which a JWT claim would not.
 *
 * This is a UI-affordance source only. It is NOT an authorization boundary —
 * server actions must keep calling getEffectiveRole() themselves.
 */
const EffectiveRoleContext = createContext<string | null>(null);

export function EffectiveRoleProvider({
    role,
    children,
}: {
    role: string;
    children: React.ReactNode;
}) {
    return (
        <EffectiveRoleContext.Provider value={role}>
            {children}
        </EffectiveRoleContext.Provider>
    );
}

/**
 * Returns the effective workspace role. Falls back to "REP" (least privilege) when
 * used outside the dashboard layout, so a missing provider hides UI rather than
 * revealing it.
 */
export function useEffectiveRole(): string {
    return useContext(EffectiveRoleContext) ?? "REP";
}

/** Convenience helpers so call sites stop re-deriving these checks by hand. */
export function useRoleFlags() {
    const role = useEffectiveRole();
    return {
        role,
        isAdmin: role === "ADMIN",
        isManagerOrAdmin: role === "ADMIN" || role === "MANAGER",
        isRep: role === "REP" || role === "STAFF",
    };
}
