"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { createPortal } from "react-dom";
import { Command } from "cmdk";
import { 
    Search, Users, Briefcase, Building2, 
    Plus, Settings, LayoutDashboard, CheckSquare, 
    Zap, Rocket, Command as CommandIcon, X,
    UserCircle2, FolderKanban, Clock, ArrowRight, Loader2, RefreshCw
} from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Types for the search index
interface SearchIndex {
    leads: { id: string; firstName: string; lastName: string; email?: string | null; phone?: string | null; status: string; service?: string | null }[];
    deals: { id: string; title: string; value: number; stage: string }[];
    organizations: { id: string; name: string; website?: string | null }[];
    contacts: { id: string; firstName: string; lastName: string; email?: string | null }[];
    projects: { id: string; name: string; status: string }[];
    tasks: { id: string; title: string; status: string; projectId: string }[];
}

const EMPTY_INDEX: SearchIndex = { leads: [], deals: [], organizations: [], contacts: [], projects: [], tasks: [] };

// Fast case-insensitive substring match
function matches(text: string | null | undefined, query: string): boolean {
    if (!text) return false;
    return text.toLowerCase().includes(query);
}

// Status badge
function StatusBadge({ status }: { status?: string }) {
    if (!status) return null;
    const colors: Record<string, string> = {
        NEW: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
        CONTACTED: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
        QUALIFIED: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
        CONVERTED: "bg-purple-500/15 text-purple-600 dark:text-purple-400",
        PENDING_APPROVAL: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
        WON: "bg-emerald-500/15 text-emerald-600",
        LOST: "bg-red-500/15 text-red-600",
        QUALIFICATION: "bg-blue-500/15 text-blue-600",
        PROPOSAL: "bg-indigo-500/15 text-indigo-600",
        NEGOTIATION: "bg-amber-500/15 text-amber-600",
        ACTIVE: "bg-emerald-500/15 text-emerald-600",
        PLANNING: "bg-blue-500/15 text-blue-600",
        ON_HOLD: "bg-amber-500/15 text-amber-600",
        COMPLETED: "bg-purple-500/15 text-purple-600",
        CANCELLED: "bg-red-500/15 text-red-600",
        TODO: "bg-slate-500/15 text-slate-600",
        IN_PROGRESS: "bg-amber-500/15 text-amber-600",
        IN_REVIEW: "bg-indigo-500/15 text-indigo-600",
        DONE: "bg-emerald-500/15 text-emerald-600",
        BLOCKED: "bg-red-500/15 text-red-600",
    };
    return (
        <span className={cn("text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md", colors[status] || "bg-muted text-muted-foreground")}>
            {status.replace(/_/g, " ")}
        </span>
    );
}

// Loading skeleton
function SearchSkeleton() {
    return (
        <div className="p-3 space-y-3 animate-pulse">
            {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center gap-3 px-3 py-2">
                    <div className="h-8 w-8 rounded-lg bg-muted" />
                    <div className="flex-1 space-y-1.5">
                        <div className="h-3.5 w-32 rounded bg-muted" />
                        <div className="h-2.5 w-48 rounded bg-muted/60" />
                    </div>
                </div>
            ))}
        </div>
    );
}

export function GlobalSearch() {
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState("");
    const [index, setIndex] = useState<SearchIndex | null>(null);
    const [indexLoading, setIndexLoading] = useState(false);
    const [mounted, setMounted] = useState(false);
    const [recentSearches, setRecentSearches] = useState<string[]>([]);
    const router = useRouter();

    // Load recent searches from localStorage
    useEffect(() => {
        setMounted(true);
        try {
            const saved = localStorage.getItem("digix_recent_searches");
            if (saved) setRecentSearches(JSON.parse(saved));
        } catch {}
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                setOpen((o) => !o);
            }
        };
        document.addEventListener("keydown", handleKeyDown);
        return () => document.removeEventListener("keydown", handleKeyDown);
    }, []);

    // Preload search index when dialog opens (or on first mount)
    const loadIndex = useCallback(async () => {
        if (indexLoading) return;
        setIndexLoading(true);
        try {
            const { getSearchIndex } = await import("@/lib/actions/search");
            const data = await getSearchIndex();
            if (data) setIndex(data);
        } catch (err) {
            console.error("Failed to load search index:", err);
        } finally {
            setIndexLoading(false);
        }
    }, [indexLoading]);

    // Load index when dialog opens for the first time
    useEffect(() => {
        if (open && !index && !indexLoading) {
            loadIndex();
        }
    }, [open, index, indexLoading, loadIndex]);

    // CLIENT-SIDE FILTERING — instant, zero server calls
    const results = useMemo(() => {
        if (!index || !query || query.length < 2) {
            return { leads: [], deals: [], organizations: [], contacts: [], projects: [], tasks: [] };
        }

        const q = query.toLowerCase();

        return {
            leads: index.leads.filter(l => 
                matches(l.firstName, q) || matches(l.lastName, q) || 
                matches(l.email, q) || matches(l.phone, q) ||
                matches(`${l.firstName} ${l.lastName}`, q)
            ).slice(0, 5),

            deals: index.deals.filter(d => 
                matches(d.title, q)
            ).slice(0, 5),

            organizations: index.organizations.filter(o => 
                matches(o.name, q) || matches(o.website, q)
            ).slice(0, 5),

            contacts: index.contacts.filter(c => 
                matches(c.firstName, q) || matches(c.lastName, q) || 
                matches(c.email, q) || matches(`${c.firstName} ${c.lastName}`, q)
            ).slice(0, 4),

            projects: index.projects.filter(p => 
                matches(p.name, q)
            ).slice(0, 4),

            tasks: index.tasks.filter(t => 
                matches(t.title, q)
            ).slice(0, 4),
        };
    }, [index, query]);

    // Save a recent search
    const saveRecentSearch = useCallback((term: string) => {
        if (!term || term.length < 2) return;
        setRecentSearches(prev => {
            const updated = [term, ...prev.filter(s => s !== term)].slice(0, 5);
            try { localStorage.setItem("digix_recent_searches", JSON.stringify(updated)); } catch {}
            return updated;
        });
    }, []);

    // Reset when closing
    useEffect(() => {
        if (!open) {
            setTimeout(() => setQuery(""), 200);
        }
    }, [open]);

    const runCommand = (command: () => void) => {
        setOpen(false);
        command();
    };

    const hasResults = results.leads.length > 0 || results.deals.length > 0 || results.organizations.length > 0 || results.contacts.length > 0 || results.projects.length > 0 || results.tasks.length > 0;
    const totalResults = results.leads.length + results.deals.length + results.organizations.length + results.contacts.length + results.projects.length + results.tasks.length;

    return (
        <div className="w-full max-w-md relative group">
            {/* Desktop Trigger */}
            <button
                type="button"
                onMouseDown={() => setOpen(true)}
                className="hidden sm:flex relative z-[110] pointer-events-auto cursor-pointer w-full h-10 px-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/40 hover:border-primary/40 hover:bg-card transition-all items-center justify-between group shadow-sm active:scale-[0.98] outline-none"
            >
                <div className="flex items-center gap-3">
                    <Search className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    <span className="text-sm text-muted-foreground font-medium">Search or press <kbd className="font-sans text-[10px] font-black opacity-50 px-1 py-0.5 rounded border border-border bg-muted">⌘K</kbd></span>
                </div>
            </button>

            {/* Mobile Trigger */}
            <Button
                variant="ghost"
                size="icon"
                onClick={() => setOpen(true)}
                className="sm:hidden h-9 w-9 text-muted-foreground hover:text-primary"
            >
                <Search className="h-5 w-5" />
            </Button>

            {mounted && open && createPortal(
                <div 
                    className="fixed inset-0 z-[9999] flex items-start justify-center pt-[12vh] bg-[#020617]/60 backdrop-blur-sm animate-in fade-in duration-150"
                    onKeyDown={(e) => { if (e.key === 'Escape') { setOpen(false); } }}
                    onClick={(e) => { if (e.target === e.currentTarget) setOpen(false); }}
                >
                    <div className="relative w-full max-w-[640px] m-4 overflow-hidden rounded-2xl border border-white/10 bg-card shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] animate-in slide-in-from-top-4 fade-in duration-200">
                        <Command className="flex h-full w-full flex-col" shouldFilter={false}>
                            <div className="flex items-center border-b border-border/50 px-4">
                                <CommandIcon className="mr-3 h-5 w-5 text-primary shrink-0" />
                                <Command.Input
                                    autoFocus
                                    placeholder="Search leads, deals, contacts, projects..."
                                    value={query}
                                    onValueChange={setQuery}
                                    className="flex h-14 w-full bg-transparent py-3 text-[15px] outline-none placeholder:text-muted-foreground"
                                />
                                {indexLoading && (
                                    <Loader2 className="h-4 w-4 text-primary animate-spin shrink-0" />
                                )}
                                {!indexLoading && query && (
                                    <span className="text-[10px] font-bold text-muted-foreground/60 shrink-0 mr-2 whitespace-nowrap">
                                        {totalResults} {totalResults === 1 ? "result" : "results"}
                                    </span>
                                )}
                                {!indexLoading && index && (
                                    <button 
                                        onClick={loadIndex} 
                                        title="Refresh search data"
                                        className="mr-1 p-1.5 rounded-md hover:bg-muted transition-colors shrink-0"
                                    >
                                        <RefreshCw className="h-3.5 w-3.5 text-muted-foreground/50 hover:text-foreground" />
                                    </button>
                                )}
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => setOpen(false)}
                                    className="ml-1 h-8 w-8 rounded-full shrink-0"
                                >
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>

                            <Command.List className="max-h-[450px] overflow-y-auto p-2 custom-scrollbar overflow-x-hidden">
                                {/* LOADING INDEX */}
                                {indexLoading && <SearchSkeleton />}

                                {/* EMPTY STATE */}
                                {!indexLoading && index && query.length >= 2 && !hasResults && (
                                    <div className="py-12 text-center">
                                        <div className="flex flex-col items-center gap-2">
                                            <Search className="h-8 w-8 text-muted-foreground/30" />
                                            <p className="text-sm text-muted-foreground">No matches for <span className="font-bold text-foreground">"{query}"</span></p>
                                            <p className="text-xs text-muted-foreground/60">Try a different search term</p>
                                        </div>
                                    </div>
                                )}

                                {/* RECENT SEARCHES (when idle) */}
                                {!query && recentSearches.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Recent Searches</span>}>
                                        {recentSearches.map((term) => (
                                            <CommandItem 
                                                key={term} 
                                                icon={<Clock className="h-4 w-4 text-muted-foreground/50" />} 
                                                label={term} 
                                                onSelect={() => setQuery(term)} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {/* NAVIGATION GROUP */}
                                {!query && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Main Navigation</span>}>
                                        <CommandItem icon={<LayoutDashboard className="h-4 w-4" />} label="Dashboard" onSelect={() => runCommand(() => router.push("/dashboard"))} />
                                        <CommandItem icon={<Users className="h-4 w-4" />} label="Leads" onSelect={() => runCommand(() => router.push("/dashboard/leads"))} />
                                        <CommandItem icon={<Briefcase className="h-4 w-4" />} label="Deals" onSelect={() => runCommand(() => router.push("/dashboard/deals"))} />
                                        <CommandItem icon={<UserCircle2 className="h-4 w-4" />} label="Contacts" onSelect={() => runCommand(() => router.push("/dashboard/contacts"))} />
                                        <CommandItem icon={<FolderKanban className="h-4 w-4" />} label="Projects" onSelect={() => runCommand(() => router.push("/dashboard/projects"))} />
                                        <CommandItem icon={<CheckSquare className="h-4 w-4" />} label="Tasks" onSelect={() => runCommand(() => router.push("/dashboard/tasks"))} />
                                        <CommandItem icon={<Settings className="h-4 w-4" />} label="Settings" onSelect={() => runCommand(() => router.push("/dashboard/settings"))} />
                                    </Command.Group>
                                )}

                                {/* QUICK ACTIONS GROUP */}
                                {!query && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Quick Actions</span>} className="mt-2">
                                        <CommandItem icon={<Plus className="h-4 w-4 text-emerald-500" />} label="Create New Lead" shortcut="L" onSelect={() => runCommand(() => router.push("/dashboard/leads?action=new"))} />
                                        <CommandItem icon={<Plus className="h-4 w-4 text-blue-500" />} label="Add New Deal" shortcut="D" onSelect={() => runCommand(() => router.push("/dashboard/deals?action=new"))} />
                                        <CommandItem icon={<Plus className="h-4 w-4 text-purple-500" />} label="New Task" shortcut="T" onSelect={() => runCommand(() => router.push("/dashboard/tasks?action=new"))} />
                                    </Command.Group>
                                )}

                                {/* === INSTANT SEARCH RESULTS (client-side filtered) === */}

                                {results.leads.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Leads</span>} className="mt-1">
                                        {results.leads.map((lead) => (
                                            <CommandItem 
                                                key={lead.id} 
                                                icon={<Users className="h-4 w-4 text-primary" />} 
                                                label={`${lead.firstName} ${lead.lastName}`} 
                                                subLabel={[lead.email, lead.service].filter(Boolean).join(" · ")}
                                                badge={<StatusBadge status={lead.status} />}
                                                onSelect={() => { saveRecentSearch(`${lead.firstName} ${lead.lastName}`); runCommand(() => router.push(`/dashboard/leads?highlight=${lead.id}`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {results.deals.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Deals</span>} className="mt-1">
                                        {results.deals.map((deal) => (
                                            <CommandItem 
                                                key={deal.id} 
                                                icon={<Briefcase className="h-4 w-4 text-emerald-500" />} 
                                                label={deal.title} 
                                                subLabel={deal.value ? `$${Number(deal.value).toLocaleString()}` : undefined}
                                                badge={<StatusBadge status={deal.stage} />}
                                                onSelect={() => { saveRecentSearch(deal.title); runCommand(() => router.push(`/dashboard/deals?highlight=${deal.id}`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {results.contacts.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Contacts</span>} className="mt-1">
                                        {results.contacts.map((contact) => (
                                            <CommandItem 
                                                key={contact.id} 
                                                icon={<UserCircle2 className="h-4 w-4 text-indigo-500" />} 
                                                label={`${contact.firstName} ${contact.lastName}`} 
                                                subLabel={contact.email}
                                                onSelect={() => { saveRecentSearch(`${contact.firstName} ${contact.lastName}`); runCommand(() => router.push(`/dashboard/contacts`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {results.organizations.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Organizations</span>} className="mt-1">
                                        {results.organizations.map((org) => (
                                            <CommandItem 
                                                key={org.id} 
                                                icon={<Building2 className="h-4 w-4 text-blue-500" />} 
                                                label={org.name} 
                                                subLabel={org.website}
                                                onSelect={() => { saveRecentSearch(org.name); runCommand(() => router.push(`/dashboard/organizations`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {results.projects.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Projects</span>} className="mt-1">
                                        {results.projects.map((project) => (
                                            <CommandItem 
                                                key={project.id} 
                                                icon={<FolderKanban className="h-4 w-4 text-orange-500" />} 
                                                label={project.name} 
                                                badge={<StatusBadge status={project.status} />}
                                                onSelect={() => { saveRecentSearch(project.name); runCommand(() => router.push(`/dashboard/projects/${project.id}`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}

                                {results.tasks.length > 0 && (
                                    <Command.Group heading={<span className="px-2 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">Tasks</span>} className="mt-1">
                                        {results.tasks.map((task) => (
                                            <CommandItem 
                                                key={task.id} 
                                                icon={<CheckSquare className="h-4 w-4 text-violet-500" />} 
                                                label={task.title} 
                                                badge={<StatusBadge status={task.status} />}
                                                onSelect={() => { saveRecentSearch(task.title); runCommand(() => router.push(`/dashboard/tasks?task=${task.id}`)); }} 
                                            />
                                        ))}
                                    </Command.Group>
                                )}
                            </Command.List>

                            <div className="flex items-center justify-between border-t border-border/40 px-4 py-3 bg-muted/20">
                                <div className="flex items-center gap-4">
                                    <kbd className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
                                        <span className="px-1.5 py-0.5 rounded border border-border bg-background">↑↓</span> Navigate
                                    </kbd>
                                    <kbd className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
                                        <span className="px-1.5 py-0.5 rounded border border-border bg-background">↵</span> Select
                                    </kbd>
                                    <kbd className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
                                        <span className="px-1.5 py-0.5 rounded border border-border bg-background">Esc</span> Close
                                    </kbd>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-[10px] font-black uppercase tracking-widest text-primary italic">DigiX Command v4.0</span>
                                </div>
                            </div>
                        </Command>
                    </div>
                </div>,
                document.body
            )}
        </div>
    );
}

function CommandItem({ icon, label, subLabel, shortcut, badge, onSelect }: any) {
    return (
        <Command.Item
            onSelect={onSelect}
            value={label}
            className="group flex cursor-pointer select-none items-center rounded-xl px-3 py-2.5 text-sm outline-none m-0.5 aria-selected:bg-primary/10 transition-all duration-150"
        >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted border border-border/50 group-aria-selected:bg-primary/20 group-aria-selected:border-primary/30 transition-all shrink-0">
                {icon}
            </div>
            <div className="ml-3 flex flex-col flex-1 min-w-0">
                <div className="flex items-center gap-2">
                    <span className="font-semibold text-[13px] text-foreground group-aria-selected:text-primary transition-colors truncate">{label}</span>
                    {badge}
                </div>
                {subLabel && <span className="text-[11px] text-muted-foreground/70 font-medium truncate">{subLabel}</span>}
            </div>
            {shortcut && (
                <kbd className="ml-auto pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-border/60 bg-muted px-1.5 font-sans text-[10px] font-black text-muted-foreground/60 shadow-sm shrink-0">
                    {shortcut}
                </kbd>
            )}
            <ArrowRight className="ml-2 h-3.5 w-3.5 text-muted-foreground/30 group-aria-selected:text-primary/50 transition-colors shrink-0" />
        </Command.Item>
    );
}
