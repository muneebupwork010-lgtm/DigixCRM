"use client";

import { useEffect, useState, useRef } from "react";
import { useSession } from "next-auth/react";
import { getPusherClient } from "@/lib/pusher-client";
import { sendMessage, getConversationMessages } from "@/lib/actions/chat";
import { Send, User, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { MentionTextarea } from "@/components/ui/mention-textarea";

interface ChatBoxProps {
    conversationId: string;
    title?: string;
    subtitle?: string;
    projectLink?: string;
}

export function ChatBox({ conversationId, title, subtitle, projectLink }: ChatBoxProps) {
    const { data: session } = useSession();
    const [messages, setMessages] = useState<any[]>([]);
    const [input, setInput] = useState("");
    const [loading, setLoading] = useState(true);
    const scrollRef = useRef<HTMLDivElement>(null);

    const projectId = conversationId.startsWith("project-")
        ? conversationId.replace("project-", "")
        : undefined;

    useEffect(() => {
        // Load initial messages
        const loadMessages = async () => {
            const res = await getConversationMessages(conversationId);
            if (res.success && res.messages) {
                setMessages(res.messages);
            }
            setLoading(false);
        };
        loadMessages();

        // Subscribe to Pusher
        const pusher = getPusherClient();
        if (!pusher) return;

        const channel = pusher.subscribe(`chat-${conversationId}`);

        const messageHandler = (newMessage: any) => {
            setMessages((prev) => {
                // Prevent duplicate messages
                if (prev.some(m => m.id === newMessage.id)) return prev;
                return [...prev, newMessage];
            });
        };

        channel.bind("new-message", messageHandler);

        return () => {
            channel.unbind("new-message", messageHandler);
            pusher.unsubscribe(`chat-${conversationId}`);
        };
    }, [conversationId]);

    // Scroll to bottom when messages change
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        const userId = (session?.user as any)?.id;
        if (!input.trim() || !userId) return;

        const content = input;
        setInput(""); // Optimistic clear

        // Optimistic UI Append
        const tempId = `temp-${Date.now()}`;
        const optimisticMsg = {
            id: tempId,
            content,
            senderId: userId,
            createdAt: new Date().toISOString(),
            sender: {
                id: userId,
                name: (session?.user as any)?.name || "You",
                image: (session?.user as any)?.image || "",
            }
        };

        setMessages((prev) => [...prev, optimisticMsg]);
        
        const result = await sendMessage(conversationId, content);
        
        // If the message successfully saved, update or remove the temporary ID
        if (result && result.success && result.message) {
            setMessages((prev) => {
                const pusherAlreadyAdded = prev.some(m => m.id === result.message.id);
                if (pusherAlreadyAdded) {
                    return prev.filter(m => m.id !== tempId);
                }
                return prev.map(m => m.id === tempId ? result.message : m);
            });
        }
    };

    if (loading) {
        return <div className="flex h-full items-center justify-center text-muted-foreground animate-pulse">Loading chat...</div>;
    }

    return (
        <div className="flex flex-col h-full w-full border border-border rounded-xl bg-card overflow-hidden shadow-sm">
            {/* Premium Header */}
            {title && (
                <div className="px-6 py-4 border-b border-border bg-card flex justify-between items-center shrink-0">
                    <div className="flex flex-col">
                        <h3 className="font-bold text-foreground tracking-tight text-base">
                            {title}
                        </h3>
                        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
                    </div>
                    {projectLink && (
                        <a
                            href={projectLink}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary/10 text-primary hover:bg-primary/20 transition-all border border-primary/20"
                        >
                            Go to Project
                            <ArrowUpRight className="w-3.5 h-3.5" />
                        </a>
                    )}
                </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
                {messages.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                        No messages yet. Say hello!
                    </div>
                ) : (
                    messages.map((msg) => {
                        const userId = (session?.user as any)?.id;
                        const isMe = msg.senderId === userId;
                        return (
                            <div key={msg.id} className={cn("flex w-full gap-2", isMe ? "justify-end" : "justify-start")}>
                                {!isMe && (
                                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                                        <User className="w-4 h-4 text-muted-foreground" />
                                    </div>
                                )}
                                <div className={cn(
                                    "px-4 py-2 rounded-2xl max-w-[80%] text-sm",
                                    isMe 
                                        ? "bg-primary text-primary-foreground rounded-tr-sm" 
                                        : "bg-muted text-foreground rounded-tl-sm"
                                )}>
                                    {!isMe && <div className="text-xs font-bold mb-1 opacity-70">{msg.sender?.name}</div>}
                                    <div className="break-words">{msg.content}</div>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>

            <div className="p-3 border-t border-border bg-muted/20">
                <form onSubmit={handleSend} className="flex items-center gap-2 relative">
                    <MentionTextarea
                        value={input}
                        onChange={(e: any) => setInput(e.target.value)}
                        onKeyDown={(e: any) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSend(e);
                            }
                        }}
                        projectId={projectId}
                        placeholder="Type a message..."
                        className="flex-1 min-h-[40px] h-[40px] max-h-[120px] resize-none scrollbar-none bg-background border border-border rounded-2xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                    />
                    <button
                        type="submit"
                        disabled={!input.trim()}
                        className="w-9 h-9 flex items-center justify-center rounded-full bg-primary text-primary-foreground disabled:opacity-50 transition-colors shrink-0"
                    >
                        <Send className="w-4 h-4" />
                    </button>
                </form>
            </div>
        </div>
    );
}
