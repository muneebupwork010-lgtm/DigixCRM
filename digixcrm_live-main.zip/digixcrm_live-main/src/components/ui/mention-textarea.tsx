"use client";

import { useState, useEffect, useRef } from "react";
import { Textarea } from "./textarea";
import { getUsers } from "@/lib/actions/users";
import { getProjectMembers } from "@/lib/actions/projects";
import { Avatar, AvatarFallback, AvatarImage } from "./avatar";
import { cn } from "@/lib/utils";
import { Search } from "lucide-react";

interface MentionTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    value: string;
    onChange: (e: any) => void;
    onKeyDown?: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
    projectId?: string;
}

export function MentionTextarea({ value, onChange, onKeyDown, className, projectId, ...props }: MentionTextareaProps) {
    const [users, setUsers] = useState<any[]>([]);
    const [cursorPos, setCursorPos] = useState(0);
    const [popupSearch, setPopupSearch] = useState("");
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (projectId) {
            getProjectMembers(projectId).then(res => setUsers(res || []));
        } else {
            getUsers().then(res => setUsers(res || []));
        }
    }, [projectId]);

    // Very simple mention detection based on cursor position
    const textBeforeCursor = value.slice(0, cursorPos);
    const lastWordRegex = /(?:\s|^)@([^\s]*)$/;
    const match = textBeforeCursor.match(lastWordRegex);
    const isMentioning = !!match;
    const filter = match ? match[1].toLowerCase() : "";

    // Sync input filter text to popover search state
    useEffect(() => {
        if (isMentioning) {
            setPopupSearch(filter);
        } else {
            setPopupSearch("");
        }
    }, [isMentioning, filter]);

    const filteredUsers = isMentioning 
        ? users.filter(u => {
            const q = popupSearch.toLowerCase();
            return u.name?.toLowerCase().includes(q) || u.email?.toLowerCase().includes(q);
          }).slice(0, 5)
        : [];

    const handleSelectUser = (user: any) => {
        if (!match) return;
        const textBeforeMention = textBeforeCursor.slice(0, match.index! + (textBeforeCursor[match.index!] === ' ' ? 1 : 0));
        const textAfterCursor = value.slice(cursorPos);
        const newText = `${textBeforeMention}@${user.name} ${textAfterCursor}`;
        
        // Create a synthetic event
        onChange({ target: { value: newText } });
        setPopupSearch("");
        
        // Focus back
        setTimeout(() => {
            if (textareaRef.current) {
                textareaRef.current.focus();
                const newPos = textBeforeMention.length + user.name.length + 2;
                textareaRef.current.setSelectionRange(newPos, newPos);
            }
        }, 10);
    };

    return (
        <div className="relative w-full flex-1 flex flex-col">
            {isMentioning && (
                <div className="absolute bottom-full left-0 mb-2 w-64 bg-card border border-border shadow-xl rounded-2xl overflow-hidden z-50 animate-in fade-in slide-in-from-bottom-2 flex flex-col">
                    <div className="p-2 border-b border-border bg-muted/20 flex items-center gap-2">
                        <Search className="w-3.5 h-3.5 text-muted-foreground/60" />
                        <input
                            type="text"
                            placeholder="Search member..."
                            value={popupSearch}
                            onChange={(e) => setPopupSearch(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    e.preventDefault();
                                    if (filteredUsers.length > 0) {
                                        handleSelectUser(filteredUsers[0]);
                                    }
                                }
                            }}
                            className="bg-transparent border-none outline-none text-xs w-full text-foreground placeholder:text-muted-foreground/40"
                            autoFocus
                        />
                    </div>
                    <div className="max-h-48 overflow-y-auto p-1">
                        {filteredUsers.length === 0 ? (
                            <div className="text-xs text-muted-foreground p-2 text-center">No members found</div>
                        ) : (
                            filteredUsers.map((user, i) => (
                                <div 
                                    key={user.id}
                                    className={cn(
                                        "flex items-center gap-3 px-3 py-2 hover:bg-primary/10 cursor-pointer transition-colors rounded-xl border-b border-border/50 last:border-0",
                                        i === 0 && "bg-primary/5" // Auto-highlight first
                                    )}
                                    onClick={() => handleSelectUser(user)}
                                >
                                    <Avatar className="h-6 w-6">
                                        <AvatarImage src={user.image} />
                                        <AvatarFallback className="text-[10px] bg-primary text-primary-foreground font-black">{user.name?.substring(0,2).toUpperCase()}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex flex-col min-w-0">
                                        <span className="text-xs font-bold truncate">{user.name}</span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
            
            <Textarea
                {...props}
                ref={textareaRef}
                value={value}
                onChange={(e) => {
                    setCursorPos(e.target.selectionStart || 0);
                    onChange(e);
                }}
                onKeyUp={(e) => setCursorPos(e.currentTarget.selectionStart || 0)}
                onClick={(e) => setCursorPos(e.currentTarget.selectionStart || 0)}
                onKeyDown={(e) => {
                    if (isMentioning && filteredUsers.length > 0 && e.key === 'Enter') {
                        e.preventDefault();
                        handleSelectUser(filteredUsers[0]);
                        return;
                    }
                    if (onKeyDown) onKeyDown(e);
                }}
                className={className}
            />
        </div>
    );
}
