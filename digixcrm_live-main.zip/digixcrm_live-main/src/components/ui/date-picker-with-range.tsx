"use client"

import * as React from "react"
import { format } from "date-fns"
import { Calendar as CalendarIcon } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "@/components/ui/popover"

interface DatePickerWithRangeProps {
    className?: string
    date?: {
        from: Date | undefined
        to?: Date | undefined
    }
    setDate: (date: { from: Date | undefined; to?: Date | undefined } | undefined) => void
}

export function DatePickerWithRange({
    className,
    date,
    setDate,
}: DatePickerWithRangeProps) {

    return (
        <div className={cn("relative", className)}>
            <Popover>
                <PopoverTrigger asChild>
                    <Button
                        id="date"
                        variant={"outline"}
                        className={cn(
                            "w-full justify-start text-left font-medium bg-muted/50 border-border hover:bg-background h-10 rounded-xl text-xs",
                            !date && "text-muted-foreground"
                        )}
                    >
                        <CalendarIcon className="mr-2 h-3.5 w-3.5 shrink-0 opacity-50" />
                        <span className="truncate">
                            {date?.from ? (
                                date.to ? (
                                    <>
                                        {format(date.from, "LLL dd")} -{" "}
                                        {format(date.to, "LLL dd")}
                                    </>
                                ) : (
                                    format(date.from, "LLL dd")
                                )
                            ) : (
                                <span>Date Range</span>
                            )}
                        </span>
                    </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 border-border/50 bg-card shadow-2xl rounded-2xl" align="end">
                    <Calendar
                        initialFocus
                        mode="range"
                        defaultMonth={date?.from}
                        selected={{ from: date?.from, to: date?.to }}
                        onSelect={setDate as any}
                        numberOfMonths={1}
                        className="rounded-2xl"
                    />
                </PopoverContent>
            </Popover>
        </div>
    )
}
