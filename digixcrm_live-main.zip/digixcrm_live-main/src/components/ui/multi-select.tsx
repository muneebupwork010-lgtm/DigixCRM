"use client";

import * as React from "react";
import { Check, ChevronsUpDown, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export interface Option {
  label: string;
  value: string;
}

interface MultiSelectProps {
  options: Option[];
  selected: string[];
  onChange: (selected: string[]) => void;
  placeholder?: string;
  className?: string;
}

export function MultiSelect({
  options,
  selected,
  onChange,
  placeholder = "Select options...",
  className,
}: MultiSelectProps) {
  const [open, setOpen] = React.useState(false);

  const handleUnselect = (item: string) => {
    onChange(selected.filter((i) => i !== item));
  };

  const handleSelect = (item: string) => {
    if (selected.includes(item)) {
      onChange(selected.filter((i) => i !== item));
    } else {
      onChange([...selected, item]);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "w-full justify-between h-10 rounded-xl bg-muted/50 border-border hover:bg-background transition-all",
            selected.length > 0 ? "h-auto min-h-10 py-1" : "",
            className
          )}
        >
          <div className="flex flex-wrap gap-1 items-center overflow-hidden max-w-[calc(100%-20px)]">
            {selected.length === 0 && (
              <span className="text-muted-foreground text-xs font-medium">{placeholder}</span>
            )}
            {selected.length > 2 ? (
              <div className="flex items-center gap-1">
                <Badge
                  variant="secondary"
                  className="bg-primary/10 text-primary border-primary/20 rounded-lg py-0 px-2 text-[10px] font-bold"
                >
                  {options.find((o) => o.value === selected[0])?.label || selected[0]}
                </Badge>
                <Badge
                  variant="secondary"
                  className="bg-primary/10 text-primary border-primary/20 rounded-lg py-0 px-2 text-[10px] font-bold"
                >
                  +{selected.length - 1} more
                </Badge>
              </div>
            ) : (
              selected.map((item) => (
                <Badge
                  key={item}
                  variant="secondary"
                  className="bg-primary/10 text-primary hover:bg-primary/20 border-primary/20 rounded-lg py-0 px-2 flex items-center gap-1 text-[10px] font-bold"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleUnselect(item);
                  }}
                >
                  {options.find((o) => o.value === item)?.label || item}
                  <X className="h-3 w-3 hover:text-destructive transition-colors" />
                </Badge>
              ))
            )}
          </div>
          <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[200px] p-0 rounded-2xl shadow-2xl border-border/50" align="start">
        <Command className="rounded-2xl">
          <CommandInput placeholder={`Search ${placeholder.toLowerCase()}...`} className="h-9" />
          <CommandList className="max-h-[300px] overflow-y-auto">
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup>
              {options.map((option) => (
                <CommandItem
                  key={option.value}
                  onSelect={() => handleSelect(option.value)}
                  className="flex items-center gap-2 px-3 py-2 cursor-pointer aria-selected:bg-primary/10"
                >
                  <div
                    className={cn(
                      "flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                      selected.includes(option.value)
                        ? "bg-primary text-primary-foreground"
                        : "opacity-50"
                    )}
                  >
                    {selected.includes(option.value) && (
                      <Check className="h-3 w-3" />
                    )}
                  </div>
                  <span className="text-xs font-medium">{option.label}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
