"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
    value?: number;
    max?: number;
    indicatorClassName?: string;
}

const Progress = React.forwardRef<HTMLDivElement, ProgressProps>(
    ({ className, value = 0, max = 100, indicatorClassName, ...props }, ref) => {
        const percentage = Math.min(Math.max(value, 0), max) / (max / 100);

        return (
            <div
                ref={ref}
                className={cn(
                    "relative h-4 w-full overflow-hidden rounded-full bg-muted shadow-inner",
                    className
                )}
                {...props}
            >
                <motion.div
                    className={cn(
                        "h-full w-full flex-1 bg-primary transition-all duration-500 ease-in-out shadow-[0_0_15px_rgba(var(--primary),0.3)]",
                        indicatorClassName
                    )}
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ 
                        type: "spring", 
                        bounce: 0.2, 
                        duration: 1.2,
                        delay: 0.2 
                    }}
                />
                
                {/* Glossy Overlay */}
                <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
            </div>
        );
    }
);
Progress.displayName = "Progress";

export { Progress };
