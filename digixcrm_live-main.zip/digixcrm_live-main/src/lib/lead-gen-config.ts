export type ProviderType = "FREE" | "PAID" | "PREMIUM";

export interface LeadGenProvider {
    id: string;
    name: string;
    type: ProviderType;
    description: string;
    requiresKey: boolean;
}

export const PROVIDERS: LeadGenProvider[] = [
    {
        id: "MOCK",
        name: "Synthetic AI Engine",
        type: "FREE",
        description: "Generate highly realistic, AI-driven synthetic prospect profiles to instantly populate your pipeline.",
        requiresKey: false
    },
    {
        id: "GOOGLE_NEWS",
        name: "Google News Signals",
        type: "FREE",
        description: "Find companies in the news for expansion, funding, or new projects.",
        requiresKey: false
    },
    {
        id: "YELP",
        name: "Yelp Fusion",
        type: "PAID",
        description: "High-quality local business data with phone numbers and ratings.",
        requiresKey: true
    },
    {
        id: "GOOGLE_PLACES",
        name: "Google Places",
        type: "PAID",
        description: "Global business data from the world's largest map database.",
        requiresKey: true
    },
    {
        id: "APOLLO",
        name: "Apollo.io",
        type: "PREMIUM",
        description: "Elite B2B contact data with verified emails and direct dials.",
        requiresKey: true
    },
    {
        id: "CRUNCHBASE",
        name: "Crunchbase",
        type: "PREMIUM",
        description: "Deep insights into funded startups and high-growth companies.",
        requiresKey: true
    }
];
