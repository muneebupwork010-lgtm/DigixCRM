export type PlanTier = "FREE" | "STARTER" | "PRO" | "ENTERPRISE";

export interface PlanEntitlements {
    maxLeads: number;
    maxPipelines: number;
    maxWorkspaces: number;
    maxUsers: number;
    canUseWorkflowAutomations: boolean;
    canUseEmailSequences: boolean;
    canUseCustomRoles: boolean;
    canUseDataExport: boolean;
    
    // 🆕 Module Access
    availableModules: string[];         // ["CRM"] or ["CRM", "PMS"]
    
    // 🆕 PMS Limits
    maxProjects: number;
    maxTasksPerProject: number;
    canUseTimeTracking: boolean;
    canUseGanttView: boolean;

    // 📅 Scheduler Limits
    canUseScheduler: boolean;
    maxMeetingTypes: number;
    maxBookingsPerMonth: number;
}

export const PLAN_ENTITLEMENTS: Record<PlanTier, PlanEntitlements> = {
    FREE: {
        maxLeads: 100,
        maxPipelines: 1,
        maxWorkspaces: 1,
        maxUsers: 2,
        canUseWorkflowAutomations: false,
        canUseEmailSequences: false,
        canUseCustomRoles: false,
        canUseDataExport: false,
        availableModules: ["CRM", "PMS", "SCHEDULER"],
        maxProjects: 10,
        maxTasksPerProject: 100,
        canUseTimeTracking: false,
        canUseGanttView: false,
        canUseScheduler: true,
        maxMeetingTypes: 2,
        maxBookingsPerMonth: 20,
    },
    STARTER: {
        maxLeads: 10000,
        maxPipelines: 1,
        maxWorkspaces: 3,
        maxUsers: 5,
        canUseWorkflowAutomations: false,
        canUseEmailSequences: false,
        canUseCustomRoles: false,
        canUseDataExport: true,
        availableModules: ["CRM", "PMS", "SCHEDULER"],
        maxProjects: 3,
        maxTasksPerProject: 50,
        canUseTimeTracking: false,
        canUseGanttView: true,
        canUseScheduler: true,
        maxMeetingTypes: 5,
        maxBookingsPerMonth: 100,
    },
    PRO: {
        maxLeads: 999999999, // Unlimited
        maxPipelines: 5,
        maxWorkspaces: 10,
        maxUsers: 20,
        canUseWorkflowAutomations: true,
        canUseEmailSequences: true,
        canUseCustomRoles: false,
        canUseDataExport: true,
        availableModules: ["CRM", "PMS", "SCHEDULER"],
        maxProjects: 25,
        maxTasksPerProject: 200,
        canUseTimeTracking: true,
        canUseGanttView: true,
        canUseScheduler: true,
        maxMeetingTypes: 20,
        maxBookingsPerMonth: 999999,
    },
    ENTERPRISE: {
        maxLeads: 999999999, // Unlimited
        maxPipelines: 999,   // Unlimited
        maxWorkspaces: 999,  // Unlimited
        maxUsers: 10000,     // Effectively unlimited
        canUseWorkflowAutomations: true,
        canUseEmailSequences: true,
        canUseCustomRoles: true,
        canUseDataExport: true,
        availableModules: ["CRM", "PMS", "SCHEDULER"],
        maxProjects: 999999,
        maxTasksPerProject: 999999,
        canUseTimeTracking: true,
        canUseGanttView: true,
        canUseScheduler: true,
        maxMeetingTypes: 999999,
        maxBookingsPerMonth: 999999,
    }
};

/**
 * Helper strictly for client-side and pure rendering checks.
 * For true security, always verify against the database state on the server.
 */
export function getEntitlements(tier: PlanTier | null | undefined): PlanEntitlements {
    if (!tier) return PLAN_ENTITLEMENTS.FREE;
    return PLAN_ENTITLEMENTS[tier] || PLAN_ENTITLEMENTS.FREE;
}
