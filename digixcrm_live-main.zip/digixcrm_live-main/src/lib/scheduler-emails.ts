import { sendEmail } from "./sendEmail";
import { format } from "date-fns";

export async function sendBookingConfirmationEmail(booking: any) {
    const startTime = new Date(booking.startTime);
    const tz = booking.timezone || "UTC";
    const dateStr = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(startTime);
    const timeStr = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", hour12: true }).format(startTime);

    const mode = booking.meetingType.mode === "ONLINE" ? "Online Meeting" : "In-Person Meeting";
    const locationStr = booking.meetingType.mode === "ONLINE" 
        ? `<p><strong>Meeting Link:</strong> <a href="${booking.meetingLink || "#"}">Join Zoom Meeting</a></p>`
        : `<p><strong>Location:</strong> ${booking.location || "TBD"}</p>`;

    const consultantName = booking.profile.displayName || booking.profile.user.name;

    // Send to Guest
    const guestHtml = `
        <div style="font-family: Arial, sans-serif; max-w-lg mx-auto; color: #333;">
            <h2 style="color: #6366f1;">Booking Confirmed!</h2>
            <p>Hi ${booking.guestName},</p>
            <p>Your meeting with <strong>${consultantName}</strong> has been confirmed.</p>
            
            <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 10px 0;"><strong>Meeting:</strong> ${booking.meetingType.name}</p>
                <p style="margin: 0 0 10px 0;"><strong>Date:</strong> ${dateStr}</p>
                <p style="margin: 0 0 10px 0;"><strong>Time:</strong> ${timeStr}</p>
                ${locationStr}
            </div>
            
            <p>If you need to reschedule or cancel, please contact us.</p>
            <p>Best regards,<br/>${booking.workspace.name}</p>
        </div>
    `;

    await sendEmail({
        to: booking.guestEmail,
        subject: `Confirmed: ${booking.meetingType.name} with ${consultantName}`,
        html: guestHtml,
    });

    // Send to Host (Consultant)
    const hostHtml = `
        <div style="font-family: Arial, sans-serif; max-w-lg mx-auto; color: #333;">
            <h2 style="color: #6366f1;">New Booking</h2>
            <p>Hi ${consultantName},</p>
            <p>A new meeting has been booked with <strong>${booking.guestName}</strong>.</p>
            
            <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 10px 0;"><strong>Meeting:</strong> ${booking.meetingType.name}</p>
                <p style="margin: 0 0 10px 0;"><strong>Date:</strong> ${dateStr}</p>
                <p style="margin: 0 0 10px 0;"><strong>Time:</strong> ${timeStr}</p>
                <p style="margin: 0 0 10px 0;"><strong>Client Email:</strong> <a href="mailto:${booking.guestEmail}">${booking.guestEmail}</a></p>
                ${booking.guestPhone ? `<p style="margin: 0 0 10px 0;"><strong>Client Phone:</strong> ${booking.guestPhone}</p>` : ""}
                ${booking.guestNotes ? `<p style="margin: 0 0 10px 0;"><strong>Notes:</strong> ${booking.guestNotes}</p>` : ""}
            </div>
        </div>
    `;

    await sendEmail({
        to: booking.profile.user.email,
        subject: `New Booking: ${booking.meetingType.name} with ${booking.guestName}`,
        html: hostHtml,
    });
}

export async function sendBookingCancellationEmail(booking: any, reason?: string) {
    const startTime = new Date(booking.startTime);
    const tz = booking.timezone || "UTC";
    const dateStr = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(startTime);
    const consultantName = booking.profile.displayName || booking.profile.user.name;

    const guestHtml = `
        <div style="font-family: Arial, sans-serif; max-w-lg mx-auto; color: #333;">
            <h2 style="color: #ef4444;">Booking Cancelled</h2>
            <p>Hi ${booking.guestName},</p>
            <p>Your meeting with <strong>${consultantName}</strong> on ${dateStr} has been cancelled.</p>
            ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ""}
            <p>Please reach out if you would like to reschedule.</p>
            <p>Best regards,<br/>${booking.workspace?.name || "Our Team"}</p>
        </div>
    `;

    await sendEmail({
        to: booking.guestEmail,
        subject: `Cancelled: ${booking.meetingType.name} with ${consultantName}`,
        html: guestHtml,
    });
}

export async function sendBookingReminderEmail(booking: any) {
    const startTime = new Date(booking.startTime);
    const tz = booking.timezone || "UTC";
    const dateStr = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(startTime);
    const timeStr = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", hour12: true }).format(startTime);
    const consultantName = booking.profile.displayName || booking.profile.user.name;

    const mode = booking.meetingType.mode === "ONLINE" ? "Online Meeting" : "In-Person Meeting";
    const locationStr = booking.meetingType.mode === "ONLINE" 
        ? `<p><strong>Meeting Link:</strong> <a href="${booking.meetingLink || "#"}">Join Meeting</a></p>`
        : `<p><strong>Location:</strong> ${booking.location || "TBD"}</p>`;

    const sharedHtml = `
        <div style="font-family: Arial, sans-serif; max-w-lg mx-auto; color: #333;">
            <h2 style="color: #f59e0b;">Meeting Reminder</h2>
            <p>Your meeting is starting in <strong>1 hour</strong>.</p>
            
            <div style="background-color: #f3f4f6; padding: 16px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 10px 0;"><strong>Meeting:</strong> ${booking.meetingType.name}</p>
                <p style="margin: 0 0 10px 0;"><strong>Date:</strong> ${dateStr}</p>
                <p style="margin: 0 0 10px 0;"><strong>Time:</strong> ${timeStr}</p>
                ${locationStr}
            </div>
            <p>Please be ready on time.</p>
        </div>
    `;

    // Send to guest
    try {
        await sendEmail({
            to: booking.guestEmail,
            subject: `Reminder: Meeting in 1 hour with ${consultantName}`,
            html: sharedHtml,
        });
    } catch (e) { console.error("Guest reminder failed:", e); }

    // Send to host
    try {
        await sendEmail({
            to: booking.profile.user.email,
            subject: `Reminder: Meeting in 1 hour with ${booking.guestName}`,
            html: sharedHtml,
        });
    } catch (e) { console.error("Host reminder failed:", e); }
}
