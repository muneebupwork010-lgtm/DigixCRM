/**
 * SOC 2 C1.1 — Application-Layer AES-256-GCM Encryption
 * 
 * Encrypts sensitive fields (API keys, SMTP passwords, webhook secrets)
 * before they are stored in the database.
 * 
 * Format: iv:authTag:ciphertext (all hex-encoded)
 * 
 * GRACEFUL DEGRADATION:
 * - If ENCRYPTION_KEY is not set, values pass through unmodified
 * - decrypt() auto-detects plaintext vs encrypted values, so old
 *   unencrypted data continues to work seamlessly
 */

import crypto from "crypto";

const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;

function getKey(): Buffer | null {
    const envKey = process.env.ENCRYPTION_KEY;
    if (!envKey) return null;

    // Expect a 64-char hex string (32 bytes)
    if (envKey.length !== 64) {
        console.warn("[ENCRYPTION] ENCRYPTION_KEY must be a 64-character hex string (32 bytes). Encryption disabled.");
        return null;
    }

    return Buffer.from(envKey, "hex");
}

/**
 * Encrypt a plaintext string. Returns "iv:authTag:ciphertext" format.
 * If ENCRYPTION_KEY is not configured, returns the original value unchanged.
 */
export function encrypt(plaintext: string | null | undefined): string | null | undefined {
    if (!plaintext) return plaintext;

    const key = getKey();
    if (!key) return plaintext; // Graceful degradation

    try {
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv(ALGORITHM, key, iv, { authTagLength: AUTH_TAG_LENGTH });

        let encrypted = cipher.update(plaintext, "utf8", "hex");
        encrypted += cipher.final("hex");

        const authTag = cipher.getAuthTag().toString("hex");

        return `${iv.toString("hex")}:${authTag}:${encrypted}`;
    } catch (error) {
        console.error("[ENCRYPTION] Encrypt failed:", error);
        return plaintext; // Fail-safe: return plaintext rather than losing data
    }
}

/**
 * Decrypt an encrypted string in "iv:authTag:ciphertext" format.
 * If the value doesn't match the encrypted format, returns it as-is (plaintext passthrough).
 */
export function decrypt(encrypted: string | null | undefined): string | null | undefined {
    if (!encrypted) return encrypted;

    // Auto-detect: if it doesn't match "hex:hex:hex" pattern, it's plaintext
    const parts = encrypted.split(":");
    if (parts.length !== 3) return encrypted; // Plaintext passthrough

    const [ivHex, authTagHex, ciphertext] = parts;

    // Validate hex format (quick sanity check)
    if (ivHex.length !== IV_LENGTH * 2 || authTagHex.length !== AUTH_TAG_LENGTH * 2) {
        return encrypted; // Not our format — plaintext passthrough
    }

    const key = getKey();
    if (!key) return encrypted; // No key — return as-is

    try {
        const iv = Buffer.from(ivHex, "hex");
        const authTag = Buffer.from(authTagHex, "hex");
        const decipher = crypto.createDecipheriv(ALGORITHM, key, iv, { authTagLength: AUTH_TAG_LENGTH });
        decipher.setAuthTag(authTag);

        let decrypted = decipher.update(ciphertext, "hex", "utf8");
        decrypted += decipher.final("utf8");

        return decrypted;
    } catch (error) {
        console.error("[ENCRYPTION] Decrypt failed — value may be plaintext or key mismatch:", error);
        return encrypted; // Fail-safe: return raw value
    }
}
