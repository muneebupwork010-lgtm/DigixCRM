import { sendEmail } from "./sendEmail";

interface UnreadMessageEmailParams {
    recipientName: string;
    recipientEmail: string;
    senderName: string;
    messagePreview: string;
    conversationType: "DIRECT" | "PROJECT" | "GROUP";
    conversationName: string; // Other user name or project name
    unreadCount: number;
    appUrl: string;
}

export async function sendUnreadMessageEmail({
    recipientName,
    recipientEmail,
    senderName,
    messagePreview,
    conversationType,
    conversationName,
    unreadCount,
    appUrl,
}: UnreadMessageEmailParams) {
    const inboxUrl = `${appUrl}/dashboard/inbox`;
    const firstName = recipientName?.split(" ")[0] || "there";

    const contextLabel =
        conversationType === "PROJECT"
            ? `the project channel <strong>${conversationName}</strong>`
            : `a direct message`;

    const countLabel =
        unreadCount > 1
            ? `You have <strong>${unreadCount} unread messages</strong>`
            : `You have <strong>1 unread message</strong>`;

    const html = `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 520px; margin: 0 auto; color: #1a1a2e;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #1e3a5f 0%, #0d1b4b 100%); padding: 28px 24px; border-radius: 12px 12px 0 0; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 22px; font-weight: 700; letter-spacing: -0.5px;">
                    💬 You have unread messages
                </h1>
            </div>
            
            <!-- Body -->
            <div style="background-color: #ffffff; padding: 28px 24px; border-left: 1px solid #e5e7eb; border-right: 1px solid #e5e7eb;">
                <p style="margin: 0 0 16px 0; font-size: 15px; line-height: 1.6;">
                    Hi ${firstName},
                </p>
                <p style="margin: 0 0 20px 0; font-size: 15px; line-height: 1.6;">
                    ${countLabel} in ${contextLabel}.
                </p>
                
                <!-- Message Preview Card -->
                <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #6366f1; padding: 16px; border-radius: 8px; margin: 0 0 24px 0;">
                    <p style="margin: 0 0 6px 0; font-size: 13px; font-weight: 700; color: #6366f1;">
                        ${senderName}
                    </p>
                    <p style="margin: 0; font-size: 14px; color: #475569; line-height: 1.5; font-style: italic;">
                        "${messagePreview.length > 120 ? messagePreview.substring(0, 120) + "..." : messagePreview}"
                    </p>
                </div>
                
                <!-- CTA Button -->
                <div style="text-align: center; margin: 24px 0;">
                    <a href="${inboxUrl}" 
                       style="display: inline-block; background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: #ffffff; text-decoration: none; padding: 14px 36px; border-radius: 10px; font-weight: 700; font-size: 14px; letter-spacing: 0.3px; box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35);">
                        Open Inbox →
                    </a>
                </div>
                
                <p style="margin: 24px 0 0 0; font-size: 12px; color: #94a3b8; text-align: center; line-height: 1.5;">
                    This is an automated notification from DigiXCRM.<br/>
                    You received this because you have unread messages in your inbox.
                </p>
            </div>
            
            <!-- Footer -->
            <div style="background-color: #f8fafc; padding: 16px 24px; border-radius: 0 0 12px 12px; border: 1px solid #e5e7eb; border-top: none; text-align: center;">
                <p style="margin: 0; font-size: 11px; color: #94a3b8;">
                    © ${new Date().getFullYear()} DigiXCRM — All rights reserved.
                </p>
            </div>
        </div>
    `;

    await sendEmail({
        to: recipientEmail,
        subject: `💬 ${senderName} sent you a message${conversationType === "PROJECT" ? ` in ${conversationName}` : ""}`,
        html,
    });
}
