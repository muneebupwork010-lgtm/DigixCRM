/**
 * SOC 2 C1.1 — PII Field-Level Encryption (Secure Vault)
 * 
 * AES-256-GCM + HKDF Per-Field Key Derivation
 * 
 * SECURITY MODEL:
 * 1. Master key is stored as FIELD_ENCRYPTION_KEY in env (64-char hex = 32 bytes)
 * 2. HKDF derives a UNIQUE key per (contactId + fieldName) combination
 *    - Even if one derived key leaks, other fields remain safe
 *    - Same pattern used by TLS 1.3, Signal Protocol, AWS KMS
 * 3. AES-256-GCM provides authenticated encryption (confidentiality + integrity)
 * 4. STRICT MODE: Unlike encryption.ts, this module REFUSES to operate without a key
 *    (no graceful degradation — plaintext PII must never reach the database)
 * 
 * Format: iv:authTag:ciphertext (all hex-encoded)
 * 
 * SEPARATE FROM encryption.ts:
 * - encryption.ts uses ENCRYPTION_KEY for integration secrets (API keys, SMTP)
 * - This module uses FIELD_ENCRYPTION_KEY exclusively for PII (SSN, DOB)
 * - Key compromise in one domain does NOT affect the other
 */

import crypto from "crypto";

const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 16;          // 128-bit IV
const AUTH_TAG_LENGTH = 16;    // 128-bit auth tag
const HKDF_HASH = "sha512";   // SHA-512 for HKDF (stronger than SHA-256, negligible cost)
const DERIVED_KEY_LENGTH = 32; // 256-bit derived key

// ============================================
// KEY MANAGEMENT
// ============================================

function getMasterKey(): Buffer {
    const envKey = process.env.FIELD_ENCRYPTION_KEY;
    if (!envKey) {
        throw new Error(
            "[SECURE VAULT] FIELD_ENCRYPTION_KEY is not configured. " +
            "PII encryption CANNOT proceed without a key. " +
            "Generate one with: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\""
        );
    }

    if (envKey.length !== 64) {
        throw new Error(
            "[SECURE VAULT] FIELD_ENCRYPTION_KEY must be a 64-character hex string (32 bytes). " +
            `Current length: ${envKey.length}`
        );
    }

    return Buffer.from(envKey, "hex");
}

/**
 * Derive a unique encryption key for a specific (contactId, fieldName) combination.
 * Uses HKDF (RFC 5869) with SHA-512.
 * 
 * This means:
 * - SSN for Contact A has a different key than SSN for Contact B
 * - SSN for Contact A has a different key than DOB for Contact A
 * - Compromising one derived key reveals nothing about others
 */
function deriveFieldKey(contactId: string, fieldName: string): Buffer {
    const masterKey = getMasterKey();
    
    // Salt: contactId (unique per contact)
    const salt = Buffer.from(contactId, "utf8");
    
    // Info: fieldName context (unique per field type)
    const info = Buffer.from(`digixcrm:secure_vault:${fieldName}`, "utf8");
    
    // HKDF: Extract → Expand
    return Buffer.from(crypto.hkdfSync(HKDF_HASH, masterKey, salt, info, DERIVED_KEY_LENGTH));
}

// ============================================
// ENCRYPTION / DECRYPTION
// ============================================

/**
 * Encrypt a plaintext PII value using AES-256-GCM with a per-field HKDF-derived key.
 * Returns "iv:authTag:ciphertext" format (hex-encoded).
 * 
 * STRICT: Throws if FIELD_ENCRYPTION_KEY is not configured.
 */
export function encryptField(
    plaintext: string,
    contactId: string,
    fieldName: string
): string {
    if (!plaintext || plaintext.trim() === "") {
        throw new Error("[SECURE VAULT] Cannot encrypt empty value");
    }

    const derivedKey = deriveFieldKey(contactId, fieldName);

    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, derivedKey, iv, {
        authTagLength: AUTH_TAG_LENGTH,
    });

    let encrypted = cipher.update(plaintext, "utf8", "hex");
    encrypted += cipher.final("hex");

    const authTag = cipher.getAuthTag().toString("hex");

    return `${iv.toString("hex")}:${authTag}:${encrypted}`;
}

/**
 * Decrypt an encrypted PII value using AES-256-GCM with a per-field HKDF-derived key.
 * Expects "iv:authTag:ciphertext" format (hex-encoded).
 * 
 * STRICT: Throws on any failure (no plaintext passthrough).
 */
export function decryptField(
    encryptedValue: string,
    contactId: string,
    fieldName: string
): string {
    if (!encryptedValue) {
        throw new Error("[SECURE VAULT] Cannot decrypt empty value");
    }

    const parts = encryptedValue.split(":");
    if (parts.length !== 3) {
        throw new Error("[SECURE VAULT] Invalid encrypted format — expected iv:authTag:ciphertext");
    }

    const [ivHex, authTagHex, ciphertext] = parts;

    if (ivHex.length !== IV_LENGTH * 2 || authTagHex.length !== AUTH_TAG_LENGTH * 2) {
        throw new Error("[SECURE VAULT] Invalid IV or AuthTag length — data may be corrupted");
    }

    const derivedKey = deriveFieldKey(contactId, fieldName);

    const iv = Buffer.from(ivHex, "hex");
    const authTag = Buffer.from(authTagHex, "hex");
    const decipher = crypto.createDecipheriv(ALGORITHM, derivedKey, iv, {
        authTagLength: AUTH_TAG_LENGTH,
    });
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(ciphertext, "hex", "utf8");
    decrypted += decipher.final("utf8");

    return decrypted;
}

// ============================================
// MASKING UTILITIES
// ============================================

/** Supported secure field types and their display labels */
export const SECURE_FIELD_TYPES = {
    SSN: { label: "Social Security Number", placeholder: "XXX-XX-XXXX", inputType: "text" },
    DOB_CLIENT: { label: "Client Date of Birth", placeholder: "MM/DD/YYYY", inputType: "date" },
    DOB_SPOUSE: { label: "Spouse Date of Birth", placeholder: "MM/DD/YYYY", inputType: "date" },
    DRIVERS_LICENSE: { label: "Driver's License", placeholder: "License Number", inputType: "text" },
    PASSPORT: { label: "Passport Number", placeholder: "Passport Number", inputType: "text" },
    TAX_ID: { label: "Tax ID / EIN", placeholder: "XX-XXXXXXX", inputType: "text" },
} as const;

export type SecureFieldName = keyof typeof SECURE_FIELD_TYPES;

/**
 * Generate a fully masked display value.
 * NO partial data is ever revealed — complete masking per client requirement.
 * 
 * Examples:
 *   SSN: "•••••••••" (not "•••-••-1234")
 *   DOB: "••/••/••••"
 *   Driver's License: "•••••••••••"
 */
export function generateMask(fieldName: string): string {
    switch (fieldName) {
        case "SSN":
            return "•••-••-••••";
        case "DOB_CLIENT":
        case "DOB_SPOUSE":
            return "••/••/••••";
        case "DRIVERS_LICENSE":
        case "PASSPORT":
        case "TAX_ID":
            return "••••••••••";
        default:
            return "••••••••";
    }
}

/**
 * Format SSN input as XXX-XX-XXXX while typing.
 * Works on the raw digit string from the client.
 */
export function formatSSN(value: string): string {
    const digits = value.replace(/\D/g, "").slice(0, 9);
    if (digits.length <= 3) return digits;
    if (digits.length <= 5) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
    return `${digits.slice(0, 3)}-${digits.slice(3, 5)}-${digits.slice(5)}`;
}

/**
 * Validate SSN format (XXX-XX-XXXX, 9 digits).
 */
export function isValidSSN(value: string): boolean {
    const digits = value.replace(/\D/g, "");
    return digits.length === 9;
}
