"use client";

/**
 * Client-side bridge for making phone calls.
 * This simply relies on native tel: links to trigger the user's default desktop calling app
 * (e.g. RingCentral Desktop, Skype, FaceTime).
 */

export type CallContext = {
    /** Number to auto-dial. */
    number?: string | null;
    /** Lead the call relates to (kept for future backend webhook syncing) */
    leadId?: string | null;
    /** Deal the call relates to (kept for future backend webhook syncing) */
    dealId?: string | null;
    /** Display name */
    contactName?: string | null;
};

/**
 * Place a call using native OS protocol handlers.
 */
export function dial(ctx: CallContext): void {
    if (typeof window === "undefined" || !ctx.number) return;
    
    // Trigger native tel: link to open the desktop app
    window.location.href = `tel:${ctx.number}`;
}
