/**
 * SOC 2 CC6.1 — In-Memory Rate Limiter (Sliding Window)
 * 
 * Zero-dependency rate limiting for login and sensitive endpoints.
 * Auto-cleans expired entries to prevent memory leaks.
 */

interface RateLimitEntry {
    count: number;
    resetAt: number;
}

const store = new Map<string, RateLimitEntry>();

// Auto-cleanup every 5 minutes to prevent memory leaks
const CLEANUP_INTERVAL = 5 * 60 * 1000;
let lastCleanup = Date.now();

function cleanup() {
    const now = Date.now();
    if (now - lastCleanup < CLEANUP_INTERVAL) return;
    lastCleanup = now;

    for (const [key, entry] of store.entries()) {
        if (now > entry.resetAt) {
            store.delete(key);
        }
    }
}

/**
 * Check if a request is rate-limited.
 * 
 * @param key - Unique identifier (e.g., email or IP)
 * @param limit - Max number of requests allowed in the window
 * @param windowMs - Time window in milliseconds
 * @returns { success: boolean, remaining: number, resetAt: number }
 */
export function rateLimit(key: string, limit: number, windowMs: number) {
    cleanup();

    const now = Date.now();
    const entry = store.get(key);

    // First request or window expired — reset
    if (!entry || now > entry.resetAt) {
        store.set(key, { count: 1, resetAt: now + windowMs });
        return { success: true, remaining: limit - 1, resetAt: now + windowMs };
    }

    // Within window — increment
    entry.count++;

    if (entry.count > limit) {
        return { success: false, remaining: 0, resetAt: entry.resetAt };
    }

    return { success: true, remaining: limit - entry.count, resetAt: entry.resetAt };
}

/**
 * Failed login attempt tracker for account lockout.
 * Separate from rate limiting — tracks consecutive failures per account.
 */
interface LockoutEntry {
    failures: number;
    lockedUntil: number | null;
}

const lockoutStore = new Map<string, LockoutEntry>();

const MAX_FAILURES = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

/**
 * Record a failed login attempt. Returns true if account is now locked.
 */
export function recordFailedAttempt(email: string): boolean {
    const normalizedEmail = email.toLowerCase();
    const entry = lockoutStore.get(normalizedEmail) || { failures: 0, lockedUntil: null };

    entry.failures++;

    if (entry.failures >= MAX_FAILURES) {
        entry.lockedUntil = Date.now() + LOCKOUT_DURATION;
        lockoutStore.set(normalizedEmail, entry);
        return true;
    }

    lockoutStore.set(normalizedEmail, entry);
    return false;
}

/**
 * Check if an account is currently locked out.
 */
export function isAccountLocked(email: string): boolean {
    const normalizedEmail = email.toLowerCase();
    const entry = lockoutStore.get(normalizedEmail);

    if (!entry || !entry.lockedUntil) return false;

    if (Date.now() > entry.lockedUntil) {
        // Lockout expired — reset
        lockoutStore.delete(normalizedEmail);
        return false;
    }

    return true;
}

/**
 * Clear failed attempts on successful login.
 */
export function clearFailedAttempts(email: string): void {
    lockoutStore.delete(email.toLowerCase());
}
