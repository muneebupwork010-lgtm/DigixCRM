import { PrismaClient } from "../generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new pg.Pool({ connectionString });
const adapter = new PrismaPg(pool as any);

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

export const prisma =
    globalForPrisma.prisma || new PrismaClient({ 
        adapter,
        log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"]
    } as any);

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
