/**
 * DigiX Template Engine
 * Renders email templates by interpolating {{variable}} placeholders with real data.
 */

export interface TemplateContext {
    // Lead / Contact fields
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    service?: string;
    quotation?: number;
    status?: string;
    location?: string;
    remarks?: string;
    // Organization
    organization?: string;
    // Sender / System
    senderName?: string;
    companyName?: string;
    // Auto-generated
    currentDate?: string;
    currentYear?: string;
}

// All available template variables with descriptions
export const TEMPLATE_VARIABLES = [
    { key: "firstName", label: "First Name", example: "John", group: "Lead" },
    { key: "lastName", label: "Last Name", example: "Doe", group: "Lead" },
    { key: "fullName", label: "Full Name", example: "John Doe", group: "Lead" },
    { key: "email", label: "Email", example: "john@example.com", group: "Lead" },
    { key: "phone", label: "Phone", example: "+1 555-1234", group: "Lead" },
    { key: "service", label: "Service", example: "Web Development", group: "Lead" },
    { key: "quotation", label: "Quotation Value", example: "$5,000", group: "Lead" },
    { key: "status", label: "Lead Status", example: "New", group: "Lead" },
    { key: "location", label: "Location", example: "New York", group: "Lead" },
    { key: "organization", label: "Organization", example: "Acme Corp", group: "Company" },
    { key: "senderName", label: "Sender Name", example: "Muhammad", group: "Sender" },
    { key: "companyName", label: "Company Name", example: "DigixCRM", group: "Sender" },
    { key: "currentDate", label: "Current Date", example: "May 12, 2026", group: "System" },
    { key: "currentYear", label: "Current Year", example: "2026", group: "System" },
] as const;

// Sample context for live preview
export const SAMPLE_CONTEXT: TemplateContext = {
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    service: "Web Development",
    quotation: 5000,
    status: "New",
    location: "New York, NY",
    remarks: "Interested in enterprise package",
    organization: "Acme Corporation",
    senderName: "Muhammad",
    companyName: "DigiCareSolutions",
    currentDate: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
    currentYear: new Date().getFullYear().toString(),
};

/**
 * Renders a template string by replacing all {{variable}} placeholders with context values.
 */
export function renderTemplate(template: string, context: TemplateContext): string {
    if (!template) return "";

    // Auto-populate system fields
    const fullContext: Record<string, string> = {
        firstName: context.firstName || "",
        lastName: context.lastName || "",
        fullName: [context.firstName, context.lastName].filter(Boolean).join(" ") || "",
        email: context.email || "",
        phone: context.phone || "",
        service: context.service || "",
        quotation: context.quotation ? `$${Number(context.quotation).toLocaleString()}` : "$0",
        status: context.status || "",
        location: context.location || "",
        remarks: context.remarks || "",
        organization: context.organization || "",
        senderName: context.senderName || "",
        companyName: context.companyName || "",
        currentDate: context.currentDate || new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }),
        currentYear: context.currentYear || new Date().getFullYear().toString(),
    };

    return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        return fullContext[key] !== undefined ? fullContext[key] : match;
    });
}

/**
 * Default templates seeded for new workspaces.
 */
export const DEFAULT_TEMPLATES = [
    {
        name: "Welcome Introduction",
        subject: "Hi {{firstName}}, Welcome from {{companyName}}!",
        body: `Hi {{firstName}},\n\nThank you for your interest in our services! My name is {{senderName}} from {{companyName}}, and I'm reaching out to help you with {{service}}.\n\nI'd love to schedule a quick call to understand your requirements better. When would be a good time for you?\n\nLooking forward to connecting!\n\nBest regards,\n{{senderName}}\n{{companyName}}`,
        category: "ONBOARDING",
    },
    {
        name: "Follow-Up Reminder",
        subject: "Following up — {{service}} for {{organization}}",
        body: `Hi {{firstName}},\n\nI hope you're doing well! I wanted to follow up on our previous conversation about {{service}}.\n\nWe discussed a quotation of {{quotation}} for your project. I wanted to check if you had any questions or if there's anything else I can help clarify.\n\nPlease feel free to reply to this email or call me directly.\n\nWarm regards,\n{{senderName}}\n{{companyName}}`,
        category: "FOLLOW_UP",
    },
    {
        name: "Proposal Sent",
        subject: "Your {{service}} Proposal is Ready — {{companyName}}",
        body: `Dear {{fullName}},\n\nThank you for considering {{companyName}} for your {{service}} needs.\n\nI've prepared a detailed proposal based on our discussion. The estimated investment for the project is {{quotation}}.\n\nPlease review the attached proposal at your convenience. I'm available to walk you through any details and answer questions.\n\nBest regards,\n{{senderName}}\n{{companyName}}`,
        category: "GENERAL",
    },
    {
        name: "Thank You — Deal Closed",
        subject: "Welcome aboard, {{firstName}}! 🎉",
        body: `Dear {{firstName}},\n\nThank you for choosing {{companyName}}! We're thrilled to have {{organization}} as our valued partner.\n\nOur team is already working on your {{service}} project and will be in touch shortly with next steps and timelines.\n\nIf you need anything in the meantime, don't hesitate to reach out.\n\nWelcome to the family!\n\nCheers,\n{{senderName}}\n{{companyName}}`,
        category: "GENERAL",
    },
    {
        name: "Meeting Reminder",
        subject: "Reminder: Our Call Tomorrow — {{companyName}}",
        body: `Hi {{firstName}},\n\nJust a friendly reminder about our scheduled call tomorrow to discuss {{service}} for {{organization}}.\n\nPlease let me know if the time still works for you, or if you'd prefer to reschedule.\n\nSee you soon!\n\n{{senderName}}\n{{companyName}}`,
        category: "FOLLOW_UP",
    },
];
