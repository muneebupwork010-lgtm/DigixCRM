import PusherClient from "pusher-js";

let pusherClientInstance: PusherClient | null = null;

export const getPusherClient = () => {
  if (!process.env.NEXT_PUBLIC_PUSHER_APP_KEY) {
    console.warn("Pusher API Key not found in environment variables");
    return null;
  }

  if (!pusherClientInstance) {
    pusherClientInstance = new PusherClient(process.env.NEXT_PUBLIC_PUSHER_APP_KEY, {
      cluster: process.env.NEXT_PUBLIC_PUSHER_CLUSTER || "",
      authEndpoint: "/api/pusher/auth",
    });
  }

  return pusherClientInstance;
};
