import fs from "fs";
import path from "path";
import matter from "gray-matter";

const BLOG_DIR = path.join(process.cwd(), "content/blog");

export interface BlogPost {
    slug: string;
    title: string;
    excerpt: string;
    date: string;
    author: string;
    category: string;
    readTime: string;
    coverImage?: string;
    tags: string[];
    featured: boolean;
    content: string;
    faq?: { q: string; a: string }[];
}

export function getAllPosts(): BlogPost[] {
    if (!fs.existsSync(BLOG_DIR)) return [];

    // Get both files and directories
    const items = fs.readdirSync(BLOG_DIR);
    const posts: BlogPost[] = [];

    items.forEach(item => {
        let filePath = "";
        let slug = "";

        // Case 1: It's a direct .mdx file (e.g., blog/my-post.mdx)
        if (item.endsWith(".mdx") || item.endsWith(".md")) {
            filePath = path.join(BLOG_DIR, item);
            slug = item.replace(/\.(mdx|md)$/, "");
        } 
        // Case 2: It's a directory (e.g., blog/my-post/index.mdx)
        else {
            const dirPath = path.join(BLOG_DIR, item);
            if (fs.statSync(dirPath).isDirectory()) {
                const innerIndex = fs.readdirSync(dirPath).find(f => f.startsWith("index.md") || f.startsWith("article.md"));
                if (innerIndex) {
                    filePath = path.join(dirPath, innerIndex);
                    slug = item;
                }
            }
        }

        if (filePath) {
            const raw = fs.readFileSync(filePath, "utf-8");
            const { data, content } = matter(raw);

            posts.push({
                slug: data.slug || slug,
                title: data.title || "Untitled",
                excerpt: data.excerpt || "",
                date: data.date || new Date().toISOString().split("T")[0],
                author: data.author || "DigixCRM Team",
                category: data.category || "General",
                readTime: data.readTime || "5 min read",
                coverImage: data.coverImage || null,
                tags: data.tags || [],
                featured: data.featured || false,
                content,
                faq: data.faq || [],
            } as BlogPost);
        }
    });

    // Sort by date descending (newest first)
    return posts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function getPostBySlug(slug: string): BlogPost | null {
    const posts = getAllPosts();
    return posts.find(p => p.slug === slug) || null;
}

export function getFeaturedPosts(): BlogPost[] {
    return getAllPosts().filter(p => p.featured);
}

export function getPostsByCategory(category: string): BlogPost[] {
    return getAllPosts().filter(p => p.category.toLowerCase() === category.toLowerCase());
}

export function getAllCategories(): string[] {
    const posts = getAllPosts();
    const categories = [...new Set(posts.map(p => p.category))];
    return categories;
}

export function getAllTags(): string[] {
    const posts = getAllPosts();
    const tags = [...new Set(posts.flatMap(p => p.tags))];
    return tags;
}

/** Simple markdown to HTML converter with ToC and Image support */
export function markdownToHtml(markdown: string): string {
    return markdown
        // Images
        .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<div className="my-8 rounded-2xl overflow-hidden border border-border shadow-xl"><img src="$2" alt="$1" className="w-full h-auto object-cover" /></div>')
        // Headers with IDs for ToC
        .replace(/^### (.*$)/gim, (match, title) => {
            const id = title.toLowerCase().replace(/[^\w]+/g, "-");
            return `<h3 id="${id}" class="text-xl font-bold text-foreground mt-8 mb-3 scroll-mt-24 group">${title} <a href="#${id}" class="opacity-0 group-hover:opacity-100 transition-opacity ml-2 text-primary">#</a></h3>`;
        })
        .replace(/^## (.*$)/gim, (match, title) => {
            const id = title.toLowerCase().replace(/[^\w]+/g, "-");
            return `<h2 id="${id}" class="text-2xl font-black text-foreground mt-10 mb-4 scroll-mt-24 group">${title} <a href="#${id}" class="opacity-0 group-hover:opacity-100 transition-opacity ml-2 text-primary">#</a></h2>`;
        })
        .replace(/^# (.*$)/gim, (match, title) => {
            const id = title.toLowerCase().replace(/[^\w]+/g, "-");
            return `<h1 id="${id}" class="text-3xl font-black text-foreground mt-10 mb-5 scroll-mt-24 group">${title} <a href="#${id}" class="opacity-0 group-hover:opacity-100 transition-opacity ml-2 text-primary">#</a></h1>`;
        })
        // Bold and italic
        .replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>')
        .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-foreground">$1</strong>')
        .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
        // Code inline
        .replace(/`(.*?)`/g, '<code class="bg-muted px-1.5 py-0.5 rounded text-sm font-mono text-primary border border-border/50">$1</code>')
        // GitHub Alerts & Magazine Callouts
        .replace(/> \[!SUMMARY\]\s*(.*$)/gim, '<div class="bg-blue-500/5 border border-blue-200 dark:border-blue-500/20 p-6 md:p-8 rounded-3xl my-10 shadow-sm"><h4 class="text-blue-600 font-black uppercase text-[10px] tracking-widest mb-3 flex items-center gap-2"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="w-3.5 h-3.5"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg> Executive Summary</h4><p class="text-sm md:text-base text-blue-900/80 dark:text-blue-100/90 leading-relaxed font-medium italic">"$1"</p></div>')
        .replace(/> \[!DISCLAIMER\]\s*(.*$)/gim, '<div class="bg-muted/30 border border-border p-5 rounded-2xl my-8 text-xs text-muted-foreground flex items-start gap-3"><strong>⚠️ Disclaimer:</strong> <span>$1</span></div>')
        .replace(/> \[!NOTE\]\s*(.*$)/gim, '<div class="bg-orange-500/5 border-l-4 border-orange-500 p-6 rounded-r-2xl my-8"><h4 class="text-orange-600 font-bold text-[11px] uppercase tracking-wider mb-2">Worth Noting</h4><p class="text-sm leading-relaxed">$1</p></div>')
        .replace(/> \[!PROTIP\]\s*(.*$)/gim, '<div class="bg-green-500/5 border border-green-500/20 p-5 rounded-2xl my-8 flex items-start gap-3"><div class="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center shrink-0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg></div><div><h4 class="text-green-600 font-bold text-xs mb-1">Pro Tip</h4><p class="text-sm text-muted-foreground">$1</p></div></div>')
        .replace(/> \[!TIP\]\s*(.*$)/gim, '<div class="bg-blue-500/5 border-l-4 border-blue-500 p-4 rounded-r-xl my-6 text-sm"><strong>💡 Tip:</strong> $1</div>')
        .replace(/> \[!IMPORTANT\]\s*(.*$)/gim, '<div class="bg-primary/5 border-l-4 border-primary p-4 rounded-r-xl my-6 text-sm font-bold">📢 Important: $1</div>')
        // Horizontal rule
        .replace(/^---$/gim, '<hr class="border-border my-8" />')
        // Blockquote
        .replace(/^> (.*$)/gim, '<blockquote class="border-l-4 border-primary pl-4 italic text-muted-foreground my-4 bg-muted/30 py-2 rounded-r-lg">$1</blockquote>')
        // Tables
        .replace(/^\|(.+)\|$/gm, (match) => {
            const cells = match.split("|").filter(c => c.trim());
            return `<tr>${cells.map(c => `<td class="px-4 py-2 border border-border text-sm">${c.trim()}</td>`).join("")}</tr>`;
        })
        // Links
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-primary font-semibold hover:underline">$1</a>')
        // Unordered list items
        .replace(/^- (.*$)/gim, '<li class="mb-1.5 flex gap-2"><span class="text-primary mt-1">•</span><span>$1</span></li>')
        // Ordered list items
        .replace(/^\d+\. (.*$)/gim, '<li class="mb-1.5 flex gap-2"><span class="text-primary font-bold min-w-[20px]">$1</span></li>')
        // Paragraphs - lines that don't start with HTML tags
        .replace(/^(?!<[h|l|b|h|c|a|t|i|d|g])(.+)$/gim, '<p class="text-muted-foreground leading-relaxed mb-4">$1</p>')
        // Wrap list items
        .replace(/(<li.*<\/li>\n?)+/g, match => `<ul class="space-y-1 my-4 ml-2">${match}</ul>`);
}
