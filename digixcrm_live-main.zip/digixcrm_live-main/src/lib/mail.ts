import nodemailer from "nodemailer";
import { Resend } from "resend";
import { prisma } from "@/lib/prisma";
import { decrypt } from "@/lib/encryption";

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

const systemTransporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVER_HOST,
  port: parseInt(process.env.EMAIL_SERVER_PORT || "587"),
  auth: {
    user: process.env.EMAIL_SERVER_USER,
    pass: process.env.EMAIL_SERVER_PASSWORD,
  },
  secure: process.env.EMAIL_SERVER_PORT === "465",
});

interface SendEmailParams {
  to: string;
  subject: string;
  html: string;
  text?: string;
  workspaceId?: string; // Optional: Send via workspace custom SMTP if provided & active
}

export async function sendEmail({ to, subject, html, text, workspaceId }: SendEmailParams) {
  let activeTransporter = systemTransporter;
  let fromEmail = process.env.EMAIL_FROM || '"DigixCRM" <noreply@crm.com>';
  let useCustomSmtp = false;

  // DYNAMIC SMTP ROUTING: Use workspace SMTP if it exists and is active
  if (workspaceId) {
    try {
      const integration = await prisma.integration.findUnique({
        where: {
          workspaceId_provider: {
            workspaceId,
            provider: "SMTP"
          }
        }
      });

      if (integration?.isActive && integration.smtpHost) {
        activeTransporter = nodemailer.createTransport({
          host: integration.smtpHost,
          port: integration.smtpPort || 587,
          secure: integration.smtpPort === 465,
          auth: {
            user: integration.smtpUser || "",
            pass: decrypt(integration.smtpPass) || "",
          },
        });
        if (integration.smtpFrom) {
          fromEmail = integration.smtpFrom;
        }
        useCustomSmtp = true;
      }
    } catch (e) {
      console.error("Custom SMTP Lookup Failed, falling back to system default:", e);
    }
  }

  try {
    if (!useCustomSmtp && resend) {
      // Send using Resend if no custom SMTP is provided and RESEND_API_KEY exists
      const data = await resend.emails.send({
        from: fromEmail,
        to: [to],
        subject: subject,
        html: html,
        text: text || "Please view the HTML version of this email.",
      });

      if (data.error) {
        console.error("Resend API Error:", data.error);
        return { success: false, error: data.error };
      }

      return { success: true, messageId: data.data?.id };
    } else {
      // Fallback to Nodemailer (System default or Custom SMTP)
      const info = await activeTransporter.sendMail({
        from: fromEmail,
        to,
        subject,
        text: text || "Please view the HTML version of this email.",
        html,
      });

      return { success: true, messageId: info.messageId };
    }
  } catch (error) {
    console.error("Error sending email:", error);
    return { success: false, error };
  }
}
