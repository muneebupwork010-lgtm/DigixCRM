import { prisma } from "./prisma";
import { getEntitlements, PlanTier } from "./entitlements";

export type ModuleName = "CRM" | "PMS" | "SCHEDULER";

/**
 * Checks if a module is enabled for a specific workspace.
 * This checks both the plan entitlements and the workspace settings.
 */
export async function isModuleEnabled(workspaceId: string, module: ModuleName): Promise<boolean> {
    if (!workspaceId) return false;

    const workspace = await (prisma as any).workspace.findUnique({
        where: { id: workspaceId },
        include: { account: true }
    });

    if (!workspace) return false;

    // 1. Check Plan Entitlements
    const planTier = workspace.account?.planTier as PlanTier || "FREE";
    const entitlements = getEntitlements(planTier);
    
    if (!entitlements.availableModules.includes(module)) {
        return false;
    }

    // 2. Check Workspace Settings
    const enabledModules = workspace.enabledModules as string[] || ["CRM"];
    return enabledModules.includes(module);
}

/**
 * Returns a list of all modules enabled for a workspace.
 */
export async function getEnabledModules(workspaceId: string): Promise<ModuleName[]> {
    if (!workspaceId) return ["CRM"];

    const workspace = await (prisma as any).workspace.findUnique({
        where: { id: workspaceId },
        include: { account: true }
    });

    if (!workspace) return ["CRM"];

    const planTier = workspace.account?.planTier as PlanTier || "FREE";
    const entitlements = getEntitlements(planTier);
    const workspaceModules = workspace.enabledModules as ModuleName[] || ["CRM"];

    // Return the intersection of plan-allowed modules and workspace-enabled modules
    return workspaceModules.filter(m => entitlements.availableModules.includes(m));
}

/**
 * Helper to check if a user has access to a module based on their role and workspace settings.
 */
export async function canUserAccessModule(user: any, module: ModuleName): Promise<boolean> {
    if (!user?.activeWorkspaceId) return module === "CRM";
    
    // Super Admins see everything if the workspace is enabled
    const { isSuperAdmin } = await import("./permissions");
    const master = await isSuperAdmin(user);
    
    if (master) return true;

    return await isModuleEnabled(user.activeWorkspaceId, module);
}
