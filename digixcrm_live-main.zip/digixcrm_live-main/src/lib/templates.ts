export interface TaskTemplateDef {
    title: string;
    description?: string;
    priority: "LOW" | "MEDIUM" | "HIGH" | "URGENT";
    estimatedHours: number;
    tags: string[];
}

export interface ProjectTemplateDef {
    id: string;
    name: string;
    description: string;
    icon: string;
    tasks: TaskTemplateDef[];
}

export const PROJECT_TEMPLATES: ProjectTemplateDef[] = [
    {
        id: "web-dev",
        name: "Website Development",
        description: "Standard workflow for designing and developing a new website.",
        icon: "Layout",
        tasks: [
            {
                title: "Requirements Gathering",
                description: "Meet with client to finalize features, sitemap, and design language.",
                priority: "HIGH",
                estimatedHours: 4,
                tags: ["Planning", "Client"]
            },
            {
                title: "UI/UX Design Mockups",
                description: "Create high-fidelity mockups in Figma for desktop and mobile.",
                priority: "MEDIUM",
                estimatedHours: 12,
                tags: ["Design", "UI"]
            },
            {
                title: "Frontend Development",
                description: "Convert designs into responsive HTML/React components.",
                priority: "HIGH",
                estimatedHours: 20,
                tags: ["Frontend", "Development"]
            },
            {
                title: "Backend / CMS Integration",
                description: "Setup database, API, and CMS.",
                priority: "MEDIUM",
                estimatedHours: 16,
                tags: ["Backend", "Development"]
            },
            {
                title: "QA & Testing",
                description: "Cross-browser testing, accessibility, and performance audits.",
                priority: "HIGH",
                estimatedHours: 8,
                tags: ["QA", "Bug"]
            },
            {
                title: "Deployment & Handoff",
                description: "Deploy to production server and hand off documentation to client.",
                priority: "URGENT",
                estimatedHours: 4,
                tags: ["Deployment"]
            }
        ]
    },
    {
        id: "marketing-campaign",
        name: "Marketing Campaign",
        description: "Launch sequence for a new product or seasonal marketing push.",
        icon: "Megaphone",
        tasks: [
            {
                title: "Campaign Strategy & Budgeting",
                description: "Define target audience, channels, and ad spend allocation.",
                priority: "HIGH",
                estimatedHours: 4,
                tags: ["Planning"]
            },
            {
                title: "Copywriting & Creatives",
                description: "Write ad copy and design banners/video assets.",
                priority: "MEDIUM",
                estimatedHours: 10,
                tags: ["Content", "Design"]
            },
            {
                title: "Setup Tracking & Analytics",
                description: "Configure UTM parameters, Meta pixel, and Google Analytics goals.",
                priority: "HIGH",
                estimatedHours: 3,
                tags: ["Technical"]
            },
            {
                title: "Launch Ad Campaigns",
                description: "Push campaigns live on Google Ads and Meta.",
                priority: "URGENT",
                estimatedHours: 2,
                tags: ["Deployment"]
            },
            {
                title: "Post-Launch Optimization",
                description: "Review performance after 3 days, adjust bids and A/B test creatives.",
                priority: "MEDIUM",
                estimatedHours: 5,
                tags: ["Analysis"]
            }
        ]
    }
];
