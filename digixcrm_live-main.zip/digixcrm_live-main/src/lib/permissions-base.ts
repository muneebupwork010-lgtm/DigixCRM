/**
 * CORE PERMISSION HELPERS (Base)
 * 
 * This file contains "pure" permission functions that do NOT import Prisma or Node.js modules.
 * This makes it safe for use in both Client Components (Browser) and Server Components/Actions (Node).
 */

/**
 * Checks if a role is allowed to see high-level financial data (Deal values, Project budgets, etc.)
 */
export function canSeeFinancials(role: string | null | undefined) {
    if (!role) return false;
    // Admins and Managers see everything. 
    // Reps see their own Sales financials.
    // Project Managers and Staff see NOTHING financial (costs/prices).
    return role === "ADMIN" || role === "MANAGER" || role === "REP";
}

/**
 * Checks if a role can VIEW (decrypt/reveal) secure PII fields (SSN, DOB, etc.)
 * ONLY ADMIN can view decrypted PII once stored.
 */
export function canViewSecureFields(role: string | null | undefined): boolean {
    if (!role) return false;
    return role === "ADMIN";
}

/**
 * Checks if a role can INPUT secure PII fields.
 * ONLY ADMIN can input secure data. Once saved, it cannot be viewed or edited.
 */
export function canEditSecureFields(role: string | null | undefined): boolean {
    if (!role) return false;
    return role === "ADMIN";
}

/**
 * Checks if a user can see global CRM data (Leads, Deals).
 */
export function canAccessCRM(role: string | null | undefined) {
    if (!role) return false;
    // CRM is for Admins, Managers, and Reps.
    // Project Managers and Staff are restricted to Production (PMS) only.
    return role === "ADMIN" || role === "MANAGER" || role === "REP";
}

/**
 * Checks if a user can see global PMS data (Projects, Tasks).
 */
export function canAccessPMS(role: string | null | undefined) {
    if (!role) return false;
    // PMS is for Admins, Managers, Project Managers, and Staff.
    // Sales Reps are restricted to Sales (CRM) only.
    return role === "ADMIN" || role === "MANAGER" || role === "PROJECT_MANAGER" || role === "STAFF" || role === "CLIENT";
}

/**
 * Simple role string match helper
 */
export function hasPermission(userRole: string | undefined | null, allowedRoles: string[]) {
    if (!userRole) return false;
    return allowedRoles.includes(userRole);
}

/**
 * Scoping helpers for database queries
 * Note: Returns the 'where' object structure.
 */
export function getScopeWhere(userRole: string | undefined, userId: string, activeWorkspaceId?: string | null, userIdField: string = "ownerId") {
    const scope: any = {};
    if (activeWorkspaceId) {
        scope.workspaceId = activeWorkspaceId;
    }

    // Admins and Managers get global scope for everything.
    if (userRole === "ADMIN" || userRole === "MANAGER") {
        return scope;
    }

    // Project Managers get global scope for PRODUCTION but this generic helper 
    // is often used for CRM too. In CRM context, PMs should see nothing.
    // However, for simplicity here, we'll keep PM global and handle CRM restriction in the specific actions.
    if (userRole === "PROJECT_MANAGER") {
        return scope;
    }

    // Reps & Staff strictly see items assigned to them (Current Owner model)
    scope[userIdField] = userId;
    return scope;
}
