"use server";

import { S3Client, PutObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { revalidatePath } from "next/cache";
import sharp from "sharp";

function getS3Client() {
    return new S3Client({
        region: "auto",
        endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
        credentials: {
            accessKeyId: process.env.R2_ACCESS_KEY_ID || "",
            secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || "",
        },
        forcePathStyle: true,
    });
}

/**
 * Uploads a file directly from the server to Cloudflare R2.
 * This avoids CORS issues that can occur with client-side presigned URL uploads.
 */
export async function uploadFile(taskId: string, formData: FormData) {
    try {
        const session = await getServerSession(authOptions) as any;
        if (!session?.user?.id) return { success: false, error: "Unauthorized" };

        const file = formData.get("file") as File;
        if (!file) return { success: false, error: "No file provided" };

        if (file.size > 10 * 1024 * 1024) {
            return { success: false, error: "File size exceeds 10MB limit" };
        }

        const bucketName = process.env.R2_BUCKET_NAME;
        if (!bucketName) return { success: false, error: "Storage bucket is not configured" };

        let buffer = Buffer.from(await file.arrayBuffer());
        let contentType = file.type;
        let fileName = file.name;

        // Optimize images
        if (file.type.startsWith('image/') && !file.type.includes('svg')) {
            try {
                const optimizedBuffer = await sharp(buffer)
                    .resize({ width: 1920, withoutEnlargement: true }) // Don't upscale small images
                    .webp({ quality: 80 }) // High quality WebP
                    .toBuffer();
                
                buffer = optimizedBuffer as any;
                contentType = 'image/webp';
                fileName = file.name.split('.').slice(0, -1).join('.') + '.webp';
            } catch (err) {
                console.error("Image optimization failed, uploading original:", err);
            }
        }

        const user = await prisma.user.findUnique({ where: { id: session.user.id } });
        const workspaceId = (user as any)?.activeWorkspaceId || "global";
        const uniqueFileName = `workspaces/${workspaceId}/tasks/${taskId}/${Date.now()}-${fileName.replace(/[^a-zA-Z0-9.-]/g, '_')}`;

        const command = new PutObjectCommand({
            Bucket: bucketName,
            Key: uniqueFileName,
            ContentType: contentType,
            Body: buffer,
        });

        const s3 = getS3Client();
        await s3.send(command);

        const finalUrl = process.env.R2_PUBLIC_DOMAIN 
            ? `https://${process.env.R2_PUBLIC_DOMAIN}/${uniqueFileName}` 
            : `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${bucketName}/${uniqueFileName}`;

        // Save to database
        const saveRes = await saveTaskAttachment(taskId, fileName, finalUrl, contentType, buffer.length);
        
        if (saveRes.success) {
            revalidatePath(`/dashboard/projects`);
            return { success: true, attachment: saveRes.attachment };
        } else {
            return { success: false, error: saveRes.error };
        }

    } catch (error: any) {
        console.error("Upload Error:", error);
        return { success: false, error: error.message || "Failed to upload file" };
    }
}

/**
 * Generates a presigned URL that the client browser can use to upload a file directly to Cloudflare R2
 */
export async function getPresignedUploadUrl(taskId: string, fileName: string, fileType: string) {
    try {
        const session = await getServerSession(authOptions) as any;
        if (!session?.user?.id) return { success: false, error: "Unauthorized" };

        const bucketName = process.env.R2_BUCKET_NAME;
        if (!bucketName) return { success: false, error: "Storage bucket is not configured" };

        // Ensure unique filename
        const user = await prisma.user.findUnique({ where: { id: session.user.id } });
        const workspaceId = (user as any)?.activeWorkspaceId || "global";
        const uniqueFileName = `workspaces/${workspaceId}/tasks/${taskId}/${Date.now()}-${fileName.replace(/[^a-zA-Z0-9.-]/g, '_')}`;

        const command = new PutObjectCommand({
            Bucket: bucketName,
            Key: uniqueFileName,
            ContentType: fileType,
        });

        // URL expires in 15 minutes
        const s3 = getS3Client();
        const signedUrl = await getSignedUrl(s3, command, { expiresIn: 900 });

        return { 
            success: true, 
            uploadUrl: signedUrl, 
            objectKey: uniqueFileName,
            // Construct the final public/accessible URL
            // If using a custom domain: `https://${process.env.R2_PUBLIC_DOMAIN}/${uniqueFileName}`
            // R2 by default does not provide public URLs without a custom domain or allowing public bucket access
            // Assuming bucket is configured for public access or custom domain routing is set up later
            finalUrl: process.env.R2_PUBLIC_DOMAIN 
                ? `https://${process.env.R2_PUBLIC_DOMAIN}/${uniqueFileName}` 
                : `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${bucketName}/${uniqueFileName}`
        };

    } catch (error: any) {
        console.error("Presigned URL Error:", error);
        return { success: false, error: error.message };
    }
}

/**
 * Saves the attachment record in the database after successful upload
 */
export async function saveTaskAttachment(taskId: string, name: string, url: string, fileType: string, size: number) {
    try {
        const session = await getServerSession(authOptions) as any;
        if (!session?.user?.id) return { success: false, error: "Unauthorized" };

        const attachment = await (prisma as any).taskAttachment.create({
            data: {
                taskId,
                name,
                url,
                fileType,
                size,
                uploadedBy: session.user.id
            }
        });

        return { success: true, attachment };
    } catch (error: any) {
        console.error("Save Attachment Error:", error);
        return { success: false, error: "Failed to save attachment record" };
    }
}

/**
 * Deletes an attachment from both R2 and the database
 */
export async function deleteTaskAttachment(attachmentId: string) {
    try {
        const session = await getServerSession(authOptions) as any;
        if (!session?.user?.id) return { success: false, error: "Unauthorized" };

        const attachment = await (prisma as any).taskAttachment.findUnique({
            where: { id: attachmentId }
        });

        if (!attachment) return { success: false, error: "Attachment not found" };

        // Attempt to delete from R2 if it's an R2 URL
        if (attachment.url.includes('r2.cloudflarestorage.com') || (process.env.R2_PUBLIC_DOMAIN && attachment.url.includes(process.env.R2_PUBLIC_DOMAIN))) {
            const bucketName = process.env.R2_BUCKET_NAME;
            // Extract key from URL
            const urlObj = new URL(attachment.url);
            let objectKey = urlObj.pathname.startsWith('/') ? urlObj.pathname.substring(1) : urlObj.pathname;
            
            // If it includes the bucket name in the path, remove it
            if (objectKey.startsWith(`${bucketName}/`)) {
                objectKey = objectKey.substring(bucketName!.length + 1);
            }

            if (bucketName && objectKey) {
                const command = new DeleteObjectCommand({
                    Bucket: bucketName,
                    Key: objectKey,
                });
                const s3 = getS3Client();
                await s3.send(command);
            }
        }

        await (prisma as any).taskAttachment.delete({
            where: { id: attachmentId }
        });

        return { success: true };
    } catch (error: any) {
        console.error("Delete Attachment Error:", error);
        return { success: false, error: "Failed to delete attachment" };
    }
}
