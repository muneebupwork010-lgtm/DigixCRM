"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { getVerifiedRecord, getEffectiveRole } from "@/lib/permissions";
import { canEditSecureFields } from "@/lib/permissions-base";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";
import { encryptField, SECURE_FIELD_TYPES, type SecureFieldName } from "@/lib/field-encryption";

const contactSchema = z.object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    email: z.string().email().optional().or(z.literal("")),
    phone: z.string().optional().or(z.literal("")),
    organizationId: z.string().optional().nullable(),
    dob: z.string().optional().nullable(),
    familyMembers: z.any().optional().nullable(),
});

export async function createContact(rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");
        
        // Extract dob and familyMembers before strict parse if needed, but we added them to schema.
        const data = contactSchema.parse(rawData);

        const workspaceId = (user as any).activeWorkspaceId || null;

        let parsedDob = undefined;
        if (data.dob) {
            parsedDob = new Date(data.dob);
        } else if (data.dob === "") {
            parsedDob = null;
        }

        const newContact = await prisma.contact.create({
            data: {
                firstName: data.firstName,
                lastName: data.lastName,
                email: data.email || null,
                phone: data.phone || null,
                organizationId: data.organizationId || null,
                ownerId: user.id,
                workspaceId,
                ...(parsedDob !== undefined ? { dob: parsedDob } : {}),
                familyMembers: data.familyMembers || null
            }
        });

        await createAuditLog({
            action: "CREATE",
            entityType: "CONTACT",
            entityId: newContact.id,
            details: `Created contact: ${newContact.firstName} ${newContact.lastName}`
        });

        await touchWorkspace(workspaceId);

        revalidatePath("/dashboard/contacts");
        return { success: true, data: newContact };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to create contact" };
    }
}

export async function updateContact(id: string, rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId || null;
        await getVerifiedRecord(prisma.contact, id, user.id, effectiveRole, workspaceId);

        const data = contactSchema.partial().parse(rawData);

        let parsedDob = undefined;
        if (data.dob) {
            parsedDob = new Date(data.dob);
        } else if (data.dob === "") {
            parsedDob = null;
        }

        const updatedContact = await prisma.contact.update({
            where: { id },
            data: {
                firstName: data.firstName,
                lastName: data.lastName,
                email: data.email || null,
                phone: data.phone || null,
                organizationId: data.organizationId || null,
                ...(parsedDob !== undefined ? { dob: parsedDob } : {}),
                ...(data.familyMembers !== undefined ? { familyMembers: data.familyMembers } : {})
            }
        });

        await createAuditLog({
            action: "UPDATE",
            entityType: "CONTACT",
            entityId: updatedContact.id,
            details: `Updated contact: ${updatedContact.firstName} ${updatedContact.lastName}`
        });

        await touchWorkspace(workspaceId);

        revalidatePath("/dashboard/contacts");
        return { success: true, data: updatedContact };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update contact" };
    }
}

export async function deleteContact(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId || null;
        await getVerifiedRecord(prisma.contact, id, user.id, effectiveRole, workspaceId);

        const deletedContact = await prisma.contact.delete({
            where: { id }
        });

        await createAuditLog({
            action: "DELETE",
            entityType: "CONTACT",
            entityId: id,
            details: `Deleted contact: ${deletedContact.firstName} ${deletedContact.lastName}`
        });

        await touchWorkspace(workspaceId);

        revalidatePath("/dashboard/contacts");
        return { success: true, data: deletedContact };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete contact" };
    }
}

export async function importBulkContacts(contacts: any[]) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId || null;
        const canSaveSecure = canEditSecureFields(effectiveRole);

        let newCount = 0;
        let updateCount = 0;
        let secureFieldsSaved = 0;

        // Process sequentially so we can encrypt fields with the contact ID
        for (const contact of contacts) {
            const email = contact.email || contact.Email || null;
            const phone = String(contact.phone || contact.Phone || "").trim();

            let existingContact = null;
            
            // 1. Try to find an existing contact by Email or Phone to prevent duplicates
            if (email) {
                existingContact = await prisma.contact.findFirst({
                    where: { email, workspaceId },
                    orderBy: { createdAt: "desc" }
                });
            }
            if (!existingContact && phone) {
                existingContact = await prisma.contact.findFirst({
                    where: { phone, workspaceId },
                    orderBy: { createdAt: "desc" }
                });
            }

            let targetContactId = "";

            if (existingContact) {
                // Update existing contact with any new basic data provided
                await prisma.contact.update({
                    where: { id: existingContact.id },
                    data: {
                        firstName: contact.firstName || contact["First Name"] || existingContact.firstName,
                        lastName: contact.lastName || contact["Last Name"] || existingContact.lastName,
                        updatedAt: new Date()
                    }
                });
                targetContactId = existingContact.id;
                updateCount++;
            } else {
                // Create a completely new contact
                const newContact = await prisma.contact.create({
                    data: {
                        firstName: contact.firstName || contact["First Name"] || "Unknown",
                        lastName: contact.lastName || contact["Last Name"] || "Unknown",
                        email,
                        phone,
                        organizationId: contact.organizationId || null,
                        ownerId: user.id,
                        workspaceId,
                        createdAt: contact.createdAt ? new Date(contact.createdAt) : new Date(),
                        updatedAt: new Date()
                    }
                });
                targetContactId = newContact.id;
                newCount++;
            }

            // Check and save any secure fields mapped in this row
            if (canSaveSecure) {
                const secureFieldsToSave = [];
                for (const fieldName of Object.keys(SECURE_FIELD_TYPES)) {
                    const label = SECURE_FIELD_TYPES[fieldName as SecureFieldName].label;
                    // Check for key by internal name (e.g. SSN) or display label (e.g. Social Security Number)
                    const val = contact[fieldName] || contact[label];
                    if (val && String(val).trim() !== "") {
                        secureFieldsToSave.push({
                            contactId: targetContactId,
                            fieldName: fieldName,
                            encryptedValue: encryptField(String(val).trim(), targetContactId, fieldName),
                            createdById: user.id,
                            updatedById: user.id
                        });
                    }
                }

                if (secureFieldsToSave.length > 0) {
                    // skipDuplicates ensures we don't overwrite if the field already exists (Write-Once enforcement)
                    const res = await (prisma as any).secureField.createMany({
                        data: secureFieldsToSave,
                        skipDuplicates: true
                    });
                    secureFieldsSaved += res.count;
                }
            }
        }

        await createAuditLog({
            action: "BULK_IMPORT",
            entityType: "CONTACT",
            details: `Imported/Updated ${newCount + updateCount} contacts (${newCount} new) with ${secureFieldsSaved} encrypted fields via CSV`
        });

        await touchWorkspace(workspaceId);

        revalidatePath("/dashboard/contacts");
        return { success: true, count: newCount + updateCount, secureFieldsSaved };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to import contacts" };
    }
}
