"use server";

import { prisma } from "@/lib/prisma";
import { getUserSession, getEffectiveRole } from "@/lib/permissions";
import { addMinutes, startOfDay, endOfDay, format, addDays, isBefore, isAfter, parseISO, setHours, setMinutes } from "date-fns";
import { createZoomMeeting } from "@/lib/zoom";
import { createGoogleMeetMeeting } from "@/lib/google-meet";
import { sendBookingConfirmationEmail, sendBookingCancellationEmail } from "@/lib/scheduler-emails";

// ============================================
// HELPERS
// ============================================

async function getSchedulerUser() {
    const session = await getUserSession();
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({
        where: { email: session.user.email },
    });
    if (!user) throw new Error("User not found");

    const role = await getEffectiveRole(user);

    // Only ADMIN, MANAGER, REP can use scheduler
    if (role === "STAFF" || role === "PROJECT_MANAGER" || role === "CLIENT") {
        throw new Error("Forbidden: Your role does not have scheduler access");
    }

    return { user, role, workspaceId: (user as any).activeWorkspaceId as string };
}

function generateSlug(name: string): string {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "")
        .substring(0, 50);
}

// ============================================
// SCHEDULER PROFILE
// ============================================

export async function getMySchedulerProfile() {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const profile = await (prisma as any).schedulerProfile.findUnique({
            where: { userId_workspaceId: { userId: user.id, workspaceId } },
            include: {
                meetingTypes: { orderBy: { order: "asc" } },
                user: { select: { name: true, email: true, image: true, jobTitle: true } },
            },
        });

        return { success: true, profile };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function upsertSchedulerProfile(data: {
    displayName?: string;
    title?: string;
    bio?: string;
    timezone?: string;
    bufferBefore?: number;
    bufferAfter?: number;
    minNotice?: number;
    maxAdvance?: number;
    weeklySchedule?: any[];
    blockedDates?: string[];
}) {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const slug = generateSlug(data.displayName || user.name || "consultant");

        // Check if slug is taken by another profile in same workspace
        const existingSlug = await (prisma as any).schedulerProfile.findFirst({
            where: { workspaceId, slug, NOT: { userId: user.id } },
        });

        const finalSlug = existingSlug ? `${slug}-${user.id.slice(-4)}` : slug;

        const profile = await (prisma as any).schedulerProfile.upsert({
            where: { userId_workspaceId: { userId: user.id, workspaceId } },
            update: {
                displayName: data.displayName,
                title: data.title,
                bio: data.bio,
                timezone: data.timezone || "America/New_York",
                bufferBefore: data.bufferBefore ?? 5,
                bufferAfter: data.bufferAfter ?? 5,
                minNotice: data.minNotice ?? 60,
                maxAdvance: data.maxAdvance ?? 30,
                weeklySchedule: data.weeklySchedule || [],
                blockedDates: data.blockedDates || [],
                slug: finalSlug,
            },
            create: {
                userId: user.id,
                workspaceId,
                displayName: data.displayName || user.name,
                title: data.title || (user as any).jobTitle,
                bio: data.bio,
                timezone: data.timezone || "America/New_York",
                bufferBefore: data.bufferBefore ?? 5,
                bufferAfter: data.bufferAfter ?? 5,
                minNotice: data.minNotice ?? 60,
                maxAdvance: data.maxAdvance ?? 30,
                weeklySchedule: data.weeklySchedule || [
                    { day: 1, startTime: "09:00", endTime: "17:00", enabled: true },
                    { day: 2, startTime: "09:00", endTime: "17:00", enabled: true },
                    { day: 3, startTime: "09:00", endTime: "17:00", enabled: true },
                    { day: 4, startTime: "09:00", endTime: "17:00", enabled: true },
                    { day: 5, startTime: "09:00", endTime: "17:00", enabled: true },
                    { day: 6, startTime: "09:00", endTime: "12:00", enabled: false },
                    { day: 0, startTime: "09:00", endTime: "12:00", enabled: false },
                ],
                blockedDates: data.blockedDates || [],
                slug: finalSlug,
            },
        });

        return { success: true, profile };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// ============================================
// MEETING TYPES
// ============================================

export async function createMeetingType(data: {
    name: string;
    description?: string;
    duration: number;
    color?: string;
    mode: "ONLINE" | "IN_PERSON";
    onlinePlatform?: "ZOOM" | "GOOGLE_MEET";
    location?: string;
    locationNotes?: string;
    maxPerDay?: number;
}) {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        // Ensure profile exists
        let profile = await (prisma as any).schedulerProfile.findUnique({
            where: { userId_workspaceId: { userId: user.id, workspaceId } },
        });

        if (!profile) {
            // Auto-create profile
            const result = await upsertSchedulerProfile({});
            if (!result.success) return result;
            profile = result.profile;
        }

        const count = await (prisma as any).meetingType.count({
            where: { profileId: profile.id },
        });

        const meetingType = await (prisma as any).meetingType.create({
            data: {
                profileId: profile.id,
                name: data.name,
                description: data.description,
                duration: data.duration,
                color: data.color || "#6366f1",
                mode: data.mode,
                onlinePlatform: data.mode === "ONLINE" ? (data.onlinePlatform || "ZOOM") : null,
                location: data.mode === "IN_PERSON" ? data.location : null,
                locationNotes: data.mode === "IN_PERSON" ? data.locationNotes : null,
                maxPerDay: data.maxPerDay,
                order: count,
            },
        });

        return { success: true, meetingType };
    } catch (error: any) {
        console.error("CREATE MEETING TYPE ERROR:", error);
        return { success: false, error: error.message };
    }
}

export async function updateMeetingType(id: string, data: {
    name?: string;
    description?: string;
    duration?: number;
    color?: string;
    mode?: "ONLINE" | "IN_PERSON";
    onlinePlatform?: "ZOOM" | "GOOGLE_MEET";
    location?: string;
    locationNotes?: string;
    maxPerDay?: number | null;
    isActive?: boolean;
}) {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const meetingType = await (prisma as any).meetingType.findUnique({
            where: { id },
            include: { profile: true },
        });

        if (!meetingType || meetingType.profile.workspaceId !== workspaceId) {
            return { success: false, error: "Meeting type not found" };
        }

        const updated = await (prisma as any).meetingType.update({
            where: { id },
            data,
        });

        return { success: true, meetingType: updated };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function deleteMeetingType(id: string) {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const meetingType = await (prisma as any).meetingType.findUnique({
            where: { id },
            include: { profile: true },
        });

        if (!meetingType || meetingType.profile.workspaceId !== workspaceId) {
            return { success: false, error: "Meeting type not found" };
        }

        await (prisma as any).meetingType.delete({ where: { id } });
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// ============================================
// AVAILABILITY / SLOT CALCULATION
// ============================================

export async function getAvailableSlots(profileId: string, meetingTypeId: string, dateStr: string) {
    try {
        const profile = await (prisma as any).schedulerProfile.findUnique({
            where: { id: profileId },
        });

        if (!profile || !profile.isActive) {
            return { success: false, error: "Profile not found or inactive" };
        }

        const meetingType = await (prisma as any).meetingType.findUnique({
            where: { id: meetingTypeId },
        });

        if (!meetingType || !meetingType.isActive) {
            return { success: false, error: "Meeting type not found or inactive" };
        }

        const date = parseISO(dateStr);
        const dayOfWeek = date.getDay(); // 0=Sunday

        // Check blocked dates
        const blockedDates: string[] = (profile.blockedDates as string[]) || [];
        if (blockedDates.includes(format(date, "yyyy-MM-dd"))) {
            return { success: true, slots: [] };
        }

        // Get schedule for this day
        const schedule: any[] = (profile.weeklySchedule as any[]) || [];
        const daySchedule = schedule.find((s: any) => s.day === dayOfWeek);

        if (!daySchedule || !daySchedule.enabled) {
            return { success: true, slots: [] };
        }

        // Parse start/end times
        const [startH, startM] = daySchedule.startTime.split(":").map(Number);
        const [endH, endM] = daySchedule.endTime.split(":").map(Number);

        let slotStart = setMinutes(setHours(date, startH), startM);
        const dayEnd = setMinutes(setHours(date, endH), endM);

        // Get existing bookings for the day
        const existingBookings = await (prisma as any).booking.findMany({
            where: {
                profileId: profile.id,
                startTime: { gte: startOfDay(date), lte: endOfDay(date) },
                status: { in: ["CONFIRMED", "PENDING"] },
            },
            select: { startTime: true, endTime: true },
        });

        // Check max per day limit
        if (meetingType.maxPerDay) {
            const todayBookings = await (prisma as any).booking.count({
                where: {
                    meetingTypeId: meetingType.id,
                    startTime: { gte: startOfDay(date), lte: endOfDay(date) },
                    status: { in: ["CONFIRMED", "PENDING"] },
                },
            });
            if (todayBookings >= meetingType.maxPerDay) {
                return { success: true, slots: [] };
            }
        }

        // Min notice check
        const now = new Date();
        const minNoticeTime = addMinutes(now, profile.minNotice);

        // Generate slots
        const slots: string[] = [];
        const duration = meetingType.duration;
        const bufferBefore = profile.bufferBefore;
        const bufferAfter = profile.bufferAfter;
        const totalSlotDuration = bufferBefore + duration + bufferAfter;

        while (addMinutes(slotStart, duration) <= dayEnd) {
            const slotEnd = addMinutes(slotStart, duration);
            const slotWithBufferStart = addMinutes(slotStart, -bufferBefore);
            const slotWithBufferEnd = addMinutes(slotEnd, bufferAfter);

            // Check if slot is in the future (respecting minNotice)
            if (isAfter(slotStart, minNoticeTime)) {
                // Check for conflicts with existing bookings
                const hasConflict = existingBookings.some((b: any) => {
                    const bStart = new Date(b.startTime);
                    const bEnd = new Date(b.endTime);
                    return (
                        (slotWithBufferStart < bEnd && slotWithBufferEnd > bStart)
                    );
                });

                if (!hasConflict) {
                    slots.push(format(slotStart, "HH:mm"));
                }
            }

            // Move to next slot (duration increments)
            slotStart = addMinutes(slotStart, 30); // 30-min slot intervals
        }

        return { success: true, slots };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function getAvailableDates(profileId: string, meetingTypeId: string) {
    try {
        const profile = await (prisma as any).schedulerProfile.findUnique({
            where: { id: profileId },
        });

        if (!profile) return { success: false, error: "Profile not found" };

        const schedule: any[] = (profile.weeklySchedule as any[]) || [];
        const blockedDates: string[] = (profile.blockedDates as string[]) || [];
        const maxAdvance = profile.maxAdvance;

        const now = new Date();
        const availableDates: string[] = [];

        for (let i = 0; i <= maxAdvance; i++) {
            const date = addDays(now, i);
            const dayOfWeek = date.getDay();
            const dateStr = format(date, "yyyy-MM-dd");

            const daySchedule = schedule.find((s: any) => s.day === dayOfWeek);

            if (daySchedule && daySchedule.enabled && !blockedDates.includes(dateStr)) {
                availableDates.push(dateStr);
            }
        }

        return { success: true, dates: availableDates };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// ============================================
// BOOKINGS
// ============================================

export async function createBooking(data: {
    meetingTypeId: string;
    profileId: string;
    startTime: string;
    guestName: string;
    guestEmail: string;
    guestPhone?: string;
    guestNotes?: string;
    timezone?: string;
}) {
    try {
        const profile = await (prisma as any).schedulerProfile.findUnique({
            where: { id: data.profileId },
            include: { workspace: true, user: true },
        });

        if (!profile || !profile.isActive) {
            return { success: false, error: "This consultant is not currently accepting bookings" };
        }

        const meetingType = await (prisma as any).meetingType.findUnique({
            where: { id: data.meetingTypeId },
        });

        if (!meetingType || !meetingType.isActive) {
            return { success: false, error: "This meeting type is no longer available" };
        }

        const startTime = new Date(data.startTime);
        const endTime = addMinutes(startTime, meetingType.duration);

        // Check for conflicts
        const conflicts = await (prisma as any).booking.findMany({
            where: {
                profileId: data.profileId,
                status: { in: ["CONFIRMED", "PENDING"] },
                OR: [
                    { startTime: { lt: endTime }, endTime: { gt: startTime } },
                ],
            },
        });

        if (conflicts.length > 0) {
            return { success: false, error: "This time slot is no longer available. Please choose another time." };
        }

        // ============================================
        // CRM BRIDGE: Link or Create Lead/Contact
        // ============================================
        let contactId = null;
        let leadId = null;

        // 1. Try to find an existing Contact
        const existingContact = await prisma.contact.findFirst({
            where: { workspaceId: profile.workspaceId, email: data.guestEmail },
        });

        if (existingContact) {
            contactId = existingContact.id;
        } else {
            // 2. Try to find an existing Lead
            const existingLead = await prisma.lead.findFirst({
                where: { workspaceId: profile.workspaceId, email: data.guestEmail },
            });

            if (existingLead) {
                leadId = existingLead.id;
            } else {
                // 3. Create a new Lead
                const [firstName, ...lastNames] = data.guestName.trim().split(" ");
                const lastName = lastNames.join(" ") || "Unknown";

                const newLead = await prisma.lead.create({
                    data: {
                        workspaceId: profile.workspaceId,
                        firstName,
                        lastName,
                        email: data.guestEmail,
                        phone: data.guestPhone,
                        status: "NEW", // Default status
                        source: "SCHEDULER_PUBLIC_PAGE",
                    },
                });
                leadId = newLead.id;
            }
        }

        // ============================================
        // VIDEO INTEGRATION (ZOOM / GOOGLE MEET)
        // ============================================
        let meetingLink = null;
        let meetingId = null;

        if (meetingType.mode === "ONLINE") {
            if (meetingType.onlinePlatform === "ZOOM") {
                const zoomDetails = await createZoomMeeting({
                    topic: `${meetingType.name} - ${data.guestName}`,
                    startTime,
                    durationMinutes: meetingType.duration,
                    hostEmail: profile.user.email || "",
                });
                
                if (zoomDetails) {
                    meetingLink = zoomDetails.joinUrl;
                    meetingId = zoomDetails.meetingId;
                }
            } else if (meetingType.onlinePlatform === "GOOGLE_MEET") {
                const meetDetails = await createGoogleMeetMeeting({
                    topic: `${meetingType.name} - ${data.guestName}`,
                    startTime,
                    durationMinutes: meetingType.duration,
                    hostEmail: profile.user.email || "",
                    guestEmail: data.guestEmail,
                });
                
                if (meetDetails) {
                    meetingLink = meetDetails.joinUrl;
                    meetingId = meetDetails.meetingId;
                }
            }
        }

        const booking = await (prisma as any).booking.create({
            data: {
                meetingTypeId: data.meetingTypeId,
                profileId: data.profileId,
                workspaceId: profile.workspaceId,
                startTime,
                endTime,
                timezone: data.timezone || profile.timezone,
                guestName: data.guestName,
                guestEmail: data.guestEmail,
                guestPhone: data.guestPhone,
                guestNotes: data.guestNotes,
                status: "CONFIRMED",
                location: meetingType.mode === "IN_PERSON" ? meetingType.location : null,
                contactId,
                leadId,
                meetingLink,
                meetingId,
            },
            include: {
                meetingType: true,
                profile: { include: { user: { select: { name: true, email: true } } } },
                workspace: true,
            },
        });

        // ============================================
        // NOTIFICATIONS
        // ============================================
        try {
            await sendBookingConfirmationEmail(booking);
        } catch (e) {
            console.error("Failed to send booking confirmation email:", e);
        }

        return { success: true, booking };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function createBookingOnBehalf(data: {
    consultantProfileId: string;
    meetingTypeId: string;
    startTime: string;
    guestName: string;
    guestEmail: string;
    guestPhone?: string;
    guestNotes?: string;
    timezone?: string;
}) {
    try {
        const { user, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const profile = await (prisma as any).schedulerProfile.findUnique({
            where: { id: data.consultantProfileId },
            include: { user: true },
        });

        if (!profile || profile.workspaceId !== workspaceId) {
            return { success: false, error: "Consultant not found in this workspace" };
        }

        const meetingType = await (prisma as any).meetingType.findUnique({
            where: { id: data.meetingTypeId },
        });

        if (!meetingType) return { success: false, error: "Meeting type not found" };

        const startTime = new Date(data.startTime);
        const endTime = addMinutes(startTime, meetingType.duration);

        // Check for conflicts
        const conflicts = await (prisma as any).booking.findMany({
            where: {
                profileId: data.consultantProfileId,
                status: { in: ["CONFIRMED", "PENDING"] },
                OR: [
                    { startTime: { lt: endTime }, endTime: { gt: startTime } },
                ],
            },
        });

        if (conflicts.length > 0) {
            return { success: false, error: "This slot conflicts with an existing booking" };
        }

        // ============================================
        // CRM BRIDGE: Link or Create Lead/Contact
        // ============================================
        let contactId = null;
        let leadId = null;

        const existingContact = await prisma.contact.findFirst({
            where: { workspaceId, email: data.guestEmail },
        });

        if (existingContact) {
            contactId = existingContact.id;
        } else {
            const existingLead = await prisma.lead.findFirst({
                where: { workspaceId, email: data.guestEmail },
            });

            if (existingLead) {
                leadId = existingLead.id;
            } else {
                const [firstName, ...lastNames] = data.guestName.trim().split(" ");
                const lastName = lastNames.join(" ") || "Unknown";

                const newLead = await prisma.lead.create({
                    data: {
                        workspaceId,
                        firstName,
                        lastName,
                        email: data.guestEmail,
                        phone: data.guestPhone,
                        status: "NEW",
                        source: "SCHEDULER_REP_BOOKED",
                        createdById: user.id,
                    },
                });
                leadId = newLead.id;
            }
        }

        // ============================================
        // VIDEO INTEGRATION (ZOOM / GOOGLE MEET)
        // ============================================
        let meetingLink = null;
        let meetingId = null;

        if (meetingType.mode === "ONLINE") {
            if (meetingType.onlinePlatform === "ZOOM") {
                const zoomDetails = await createZoomMeeting({
                    topic: `${meetingType.name} - ${data.guestName}`,
                    startTime,
                    durationMinutes: meetingType.duration,
                    hostEmail: profile.user.email || "",
                });
                
                if (zoomDetails) {
                    meetingLink = zoomDetails.joinUrl;
                    meetingId = zoomDetails.meetingId;
                }
            } else if (meetingType.onlinePlatform === "GOOGLE_MEET") {
                const meetDetails = await createGoogleMeetMeeting({
                    topic: `${meetingType.name} - ${data.guestName}`,
                    startTime,
                    durationMinutes: meetingType.duration,
                    hostEmail: profile.user.email || "",
                    guestEmail: data.guestEmail,
                });
                
                if (meetDetails) {
                    meetingLink = meetDetails.joinUrl;
                    meetingId = meetDetails.meetingId;
                }
            }
        }

        const booking = await (prisma as any).booking.create({
            data: {
                meetingTypeId: data.meetingTypeId,
                profileId: data.consultantProfileId,
                workspaceId,
                startTime,
                endTime,
                timezone: data.timezone || profile.timezone,
                guestName: data.guestName,
                guestEmail: data.guestEmail,
                guestPhone: data.guestPhone,
                guestNotes: data.guestNotes,
                status: "CONFIRMED",
                bookedByUserId: user.id,
                location: meetingType.mode === "IN_PERSON" ? meetingType.location : null,
                contactId,
                leadId,
                meetingLink,
                meetingId,
            },
            include: {
                meetingType: true,
                profile: { include: { user: { select: { name: true, email: true } } } },
                workspace: true,
            },
        });

        // ============================================
        // NOTIFICATIONS
        // ============================================
        try {
            await sendBookingConfirmationEmail(booking);
        } catch (e) {
            console.error("Failed to send booking confirmation email:", e);
        }

        return { success: true, booking };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function getBookings(filter?: "upcoming" | "past" | "cancelled") {
    try {
        const { user, role, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const now = new Date();
        const where: any = { workspaceId };

        // REP can only see their own bookings (as host)
        if (role === "REP") {
            where.profile = { userId: user.id };
        }

        if (filter === "upcoming") {
            where.startTime = { gte: now };
            where.status = { in: ["CONFIRMED", "PENDING"] };
        } else if (filter === "past") {
            where.startTime = { lt: now };
            where.status = { not: "CANCELLED" };
        } else if (filter === "cancelled") {
            where.status = "CANCELLED";
        }

        const bookings = await (prisma as any).booking.findMany({
            where,
            include: {
                meetingType: true,
                profile: {
                    include: { user: { select: { name: true, email: true, image: true } } },
                },
            },
            orderBy: { startTime: filter === "past" ? "desc" : "asc" },
            take: 100,
        });

        return { success: true, bookings };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function cancelBooking(bookingId: string, reason?: string) {
    try {
        const { user, role, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const booking = await (prisma as any).booking.findUnique({
            where: { id: bookingId },
            include: { profile: true },
        });

        if (!booking || booking.workspaceId !== workspaceId) {
            return { success: false, error: "Booking not found" };
        }

        // REP can only cancel their own bookings
        if (role === "REP" && booking.profile.userId !== user.id) {
            return { success: false, error: "You can only cancel your own bookings" };
        }

        const updated = await (prisma as any).booking.update({
            where: { id: bookingId },
            data: { status: "CANCELLED", cancelReason: reason },
            include: {
                meetingType: true,
                profile: { include: { user: { select: { name: true, email: true } } } },
                workspace: true,
            },
        });

        try {
            await sendBookingCancellationEmail(updated, reason);
        } catch (e) {
            console.error("Failed to send cancellation email:", e);
        }

        return { success: true, booking: updated };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function completeBooking(bookingId: string) {
    try {
        const { user, role, workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const booking = await (prisma as any).booking.findUnique({
            where: { id: bookingId },
            include: { profile: true },
        });

        if (!booking || booking.workspaceId !== workspaceId) {
            return { success: false, error: "Booking not found" };
        }

        const updated = await (prisma as any).booking.update({
            where: { id: bookingId },
            data: { status: "COMPLETED" },
        });

        return { success: true, booking: updated };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// ============================================
// WORKSPACE CONSULTANTS (for book-on-behalf)
// ============================================

export async function getWorkspaceConsultants() {
    try {
        const { workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        const profiles = await (prisma as any).schedulerProfile.findMany({
            where: { workspaceId, isActive: true },
            include: {
                user: { select: { id: true, name: true, email: true, image: true, jobTitle: true } },
                meetingTypes: { where: { isActive: true }, orderBy: { order: "asc" } },
            },
        });

        return { success: true, profiles };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function searchWorkspaceClients(query: string) {
    try {
        const { workspaceId } = await getSchedulerUser();
        if (!workspaceId) return { success: false, error: "No active workspace" };

        if (!query || query.length < 2) return { success: true, clients: [] };

        const leads = await prisma.lead.findMany({
            where: {
                workspaceId,
                OR: [
                    { firstName: { contains: query, mode: "insensitive" } },
                    { lastName: { contains: query, mode: "insensitive" } },
                    { email: { contains: query, mode: "insensitive" } },
                ],
            },
            select: { id: true, firstName: true, lastName: true, email: true, phone: true },
            take: 5,
        });

        const contacts = await prisma.contact.findMany({
            where: {
                workspaceId,
                OR: [
                    { firstName: { contains: query, mode: "insensitive" } },
                    { lastName: { contains: query, mode: "insensitive" } },
                    { email: { contains: query, mode: "insensitive" } },
                ],
            },
            select: { id: true, firstName: true, lastName: true, email: true, phone: true },
            take: 5,
        });

        // Combine and map to a uniform shape
        const combined = [
            ...leads.map(l => ({ id: l.id, name: `${l.firstName} ${l.lastName}`.trim(), email: l.email, phone: l.phone, type: "Lead" })),
            ...contacts.map(c => ({ id: c.id, name: `${c.firstName} ${c.lastName}`.trim(), email: c.email, phone: c.phone, type: "Contact" }))
        ];

        return { success: true, clients: combined.slice(0, 8) };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// ============================================
// PUBLIC PROFILE LOOKUP (no auth)
// ============================================

export async function getPublicProfile(workspaceId: string, slug: string) {
    try {
        const profile = await (prisma as any).schedulerProfile.findFirst({
            where: { workspaceId, slug, isActive: true },
            include: {
                meetingTypes: { where: { isActive: true }, orderBy: { order: "asc" } },
                user: { select: { name: true, image: true } },
                workspace: { select: { name: true, logo: true } },
            },
        });

        if (!profile) return { success: false, error: "Profile not found" };

        return { success: true, profile };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}
