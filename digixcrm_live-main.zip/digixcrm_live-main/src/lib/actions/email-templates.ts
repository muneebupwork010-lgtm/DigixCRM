"use server";

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getEffectiveRole } from "@/lib/permissions";
import { revalidatePath } from "next/cache";
import { DEFAULT_TEMPLATES } from "@/lib/template-engine";

// ---------- GET ALL TEMPLATES ----------
export async function getEmailTemplates() {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const workspaceId = (user as any).activeWorkspaceId;

        const templates = await (prisma as any).emailTemplate.findMany({
            where: { workspaceId },
            orderBy: [{ isDefault: "desc" }, { updatedAt: "desc" }],
            include: {
                createdBy: { select: { name: true, email: true } }
            }
        });

        return { success: true, data: templates };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to fetch templates" };
    }
}

// ---------- CREATE TEMPLATE ----------
export async function createEmailTemplate(data: {
    name: string;
    subject: string;
    body: string;
    category?: string;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const role = await getEffectiveRole(user);
        if (!["ADMIN", "MANAGER"].includes(role)) throw new Error("Only Admins and Managers can create templates.");

        const workspaceId = (user as any).activeWorkspaceId;

        const template = await (prisma as any).emailTemplate.create({
            data: {
                name: data.name,
                subject: data.subject,
                body: data.body,
                category: data.category || "GENERAL",
                createdById: user.id,
                workspaceId,
            }
        });

        revalidatePath("/dashboard/settings");
        return { success: true, data: template };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to create template" };
    }
}

// ---------- UPDATE TEMPLATE ----------
export async function updateEmailTemplate(id: string, data: {
    name?: string;
    subject?: string;
    body?: string;
    category?: string;
    isActive?: boolean;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const role = await getEffectiveRole(user);
        if (!["ADMIN", "MANAGER"].includes(role)) throw new Error("Only Admins and Managers can edit templates.");

        const template = await (prisma as any).emailTemplate.update({
            where: { id },
            data
        });

        revalidatePath("/dashboard/settings");
        return { success: true, data: template };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update template" };
    }
}

// ---------- DELETE TEMPLATE ----------
export async function deleteEmailTemplate(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const role = await getEffectiveRole(user);
        if (!["ADMIN", "MANAGER"].includes(role)) throw new Error("Only Admins and Managers can delete templates.");

        await (prisma as any).emailTemplate.delete({ where: { id } });

        revalidatePath("/dashboard/settings");
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete template" };
    }
}

// ---------- SEED DEFAULTS ----------
export async function seedDefaultTemplates() {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const workspaceId = (user as any).activeWorkspaceId;
        if (!workspaceId) throw new Error("No active workspace");

        // Check if defaults already seeded
        const existing = await (prisma as any).emailTemplate.count({
            where: { workspaceId, isDefault: true }
        });
        if (existing > 0) {
            return { success: true, message: "Default templates already exist.", count: 0 };
        }

        const templates = DEFAULT_TEMPLATES.map(t => ({
            ...t,
            isDefault: true,
            createdById: user.id,
            workspaceId,
        }));

        await (prisma as any).emailTemplate.createMany({ data: templates });

        revalidatePath("/dashboard/settings");
        return { success: true, count: templates.length };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to seed templates" };
    }
}

// ---------- DUPLICATE TEMPLATE ----------
export async function duplicateEmailTemplate(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const role = await getEffectiveRole(user);
        if (!["ADMIN", "MANAGER"].includes(role)) throw new Error("Only Admins and Managers can duplicate templates.");

        const original = await (prisma as any).emailTemplate.findUnique({ where: { id } });
        if (!original) throw new Error("Template not found");

        const template = await (prisma as any).emailTemplate.create({
            data: {
                name: `${original.name} (Copy)`,
                subject: original.subject,
                body: original.body,
                category: original.category,
                isDefault: false,
                createdById: user.id,
                workspaceId: original.workspaceId,
            }
        });

        revalidatePath("/dashboard/settings");
        return { success: true, data: template };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to duplicate template" };
    }
}
