"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { touchWorkspace } from "./workspaces";
import { isSuperAdmin } from "@/lib/permissions";

export async function createActivity(data: {
    type: string;
    notes: string;
    leadId?: string | null;
    dealId?: string | null;
    taskId?: string | null;
    projectId?: string | null;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) {
            throw new Error("Unauthorized");
        }

        const user = await prisma.user.findUnique({
            where: { email: session.user.email }
        });

        if (!user) {
            throw new Error("User not found");
        }

        const newActivity = await prisma.activity.create({
            data: {
                type: data.type,
                notes: data.notes,
                leadId: data.leadId || null,
                dealId: data.dealId || null,
                taskId: data.taskId || null,
                projectId: data.projectId || null,
                userId: user.id,
                workspaceId: (user as any).activeWorkspaceId || null
            }
        });

        await touchWorkspace((user as any).activeWorkspaceId || null);

        // Revalidate multiple paths since activity can show up in different places
        revalidatePath("/dashboard/activities");
        revalidatePath("/dashboard/leads");
        revalidatePath("/dashboard/deals");
        revalidatePath("/dashboard/projects");

        return { success: true, data: newActivity };
    } catch (error: unknown) {
        return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
}

/**
 * Logs a phone call as a CALL activity. Invoked by the global RingCentral
 * softphone when a call ends. Scoped to the user's active workspace like
 * every other activity.
 */
export async function logCall(data: {
    leadId?: string | null;
    dealId?: string | null;
    number?: string | null;
    direction?: string | null;      // "Inbound" | "Outbound"
    durationSec?: number | null;
    result?: string | null;          // e.g. "Call connected", "Voicemail", "Missed"
    contactName?: string | null;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) {
            throw new Error("Unauthorized");
        }

        const user = await prisma.user.findUnique({
            where: { email: session.user.email }
        });
        if (!user) {
            throw new Error("User not found");
        }

        const dir = (data.direction || "").toLowerCase() === "inbound" ? "Inbound" : "Outbound";
        const arrow = dir === "Inbound" ? "from" : "to";
        const who = data.contactName ? `${data.contactName}` : data.number || "unknown number";

        let duration = "";
        if (typeof data.durationSec === "number" && data.durationSec > 0) {
            const m = Math.floor(data.durationSec / 60);
            const s = data.durationSec % 60;
            duration = m > 0 ? `${m}m ${s}s` : `${s}s`;
        }

        const parts = [
            `📞 ${dir} call ${arrow} ${who}`,
            data.number && data.contactName ? `(${data.number})` : null,
            duration ? `· ${duration}` : null,
            data.result ? `· ${data.result}` : null,
        ].filter(Boolean);

        const newActivity = await prisma.activity.create({
            data: {
                type: "CALL",
                notes: parts.join(" "),
                leadId: data.leadId || null,
                dealId: data.dealId || null,
                userId: user.id,
                workspaceId: (user as any).activeWorkspaceId || null
            }
        });

        await touchWorkspace((user as any).activeWorkspaceId || null);

        revalidatePath("/dashboard/activities");
        revalidatePath("/dashboard/leads");
        revalidatePath("/dashboard/deals");

        return { success: true, data: newActivity };
    } catch (error: unknown) {
        return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
}

export async function getDealActivities(dealId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const master = await isSuperAdmin(user);
        const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || "admin@crm.com";

        const activities = await prisma.activity.findMany({
            where: {
                dealId,
                ...(master ? {} : { user: { email: { not: superAdminEmail } } })
            },
            include: { user: { select: { name: true, image: true } } },
            orderBy: { createdAt: "desc" }
        });

        return { success: true, data: activities };
    } catch (error: unknown) {
        return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
}

export async function getLeadActivities(leadId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const master = await isSuperAdmin(user);
        const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || "admin@crm.com";

        const activities = await prisma.activity.findMany({
            where: {
                leadId,
                ...(master ? {} : { user: { email: { not: superAdminEmail } } })
            },
            include: { user: { select: { name: true, image: true } } },
            orderBy: { createdAt: "desc" }
        });

        return { success: true, data: activities };
    } catch (error: unknown) {
        return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
}

export async function getTaskActivities(taskId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized (getTaskActivities)");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const master = await isSuperAdmin(user);
        const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || "admin@crm.com";

        const activities = await prisma.activity.findMany({
            where: {
                taskId,
                ...(master ? {} : { user: { email: { not: superAdminEmail } } })
            },
            include: { user: { select: { name: true, image: true } } },
            orderBy: { createdAt: "desc" }
        });

        return { success: true, data: activities };
    } catch (error: unknown) {
        return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
}
