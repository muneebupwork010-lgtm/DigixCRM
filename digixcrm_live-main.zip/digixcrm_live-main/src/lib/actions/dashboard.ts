"use server";

import { prisma } from "@/lib/prisma";
import { unstable_cache } from "next/cache";
import { subMonths, startOfMonth, subDays } from "date-fns";

/**
 * Optimized Server Action to fetch dashboard metrics with caching.
 * This dramatically reduces database load and speeds up the main dashboard.
 */
export async function getCachedDashboardData(
    userId: string, 
    activeWorkspaceId: string, 
    effectiveRole: string,
    showFinancials: boolean,
    scopeWhere: any,
    periodMonths: number = 6
) {
    // We cache based on workspace, role, and period to ensure data isolation
    const cacheKey = `dashboard-${activeWorkspaceId}-${effectiveRole}-${periodMonths}-${showFinancials}`;

    const { canAccessCRM, canAccessPMS } = await import("@/lib/permissions-base");
    const hasCRM = canAccessCRM(effectiveRole);
    const hasPMS = canAccessPMS(effectiveRole);

    return await unstable_cache(
        async () => {
            const now = new Date();
            const periodStart = startOfMonth(subMonths(now, periodMonths - 1));
            const periodFilter = { gte: periodStart };

            const [
                totalLeads,
                convertedLeads,
                wonDealsReq,
                activeDeals,
                totalActivities,
                dealsByStage,
                allDeals,
                myActiveTasksCount,
                myOverdueTasksCount,
                weeklyTaskActivity,
                overdueTasksList,
                topProjects,
                weeklyLeadActivity,
                recentLeads,
                hotDeals
            ] = await Promise.all([
                hasCRM ? prisma.lead.count({ where: { ...scopeWhere, createdAt: periodFilter } }) : Promise.resolve(0),
                hasCRM ? prisma.lead.count({ where: { status: "CONVERTED", ...scopeWhere, createdAt: periodFilter } }) : Promise.resolve(0),
                (hasCRM && showFinancials) ? prisma.deal.aggregate({
                    _sum: { value: true },
                    where: {
                        OR: [
                            { stage: "WON", ...scopeWhere },
                            { customStage: "ONBOARDED", ...scopeWhere }
                        ]
                    }
                }) : Promise.resolve({ _sum: { value: 0 } }),
                hasCRM ? prisma.deal.count({
                    where: { stage: { notIn: ["WON", "LOST"] }, ...scopeWhere, createdAt: periodFilter }
                }) : Promise.resolve(0),
                prisma.activity.count({
                    where: { 
                        workspaceId: activeWorkspaceId,
                        createdAt: periodFilter
                    }
                }),
                (hasCRM && showFinancials) ? prisma.deal.findMany({
                    where: { ...scopeWhere, createdAt: periodFilter },
                    select: { value: true, stage: true, customStage: true }
                }) : Promise.resolve([]),
                (hasCRM && showFinancials) ? prisma.deal.findMany({
                    where: { ...scopeWhere, updatedAt: periodFilter },
                    select: { value: true, stage: true, customStage: true, createdAt: true, updatedAt: true }
                }) : Promise.resolve([]),
                hasPMS ? prisma.task.count({
                    where: { workspaceId: activeWorkspaceId, assigneeId: userId, status: { not: "DONE" } }
                }) : Promise.resolve(0),
                hasPMS ? prisma.task.count({
                    where: { workspaceId: activeWorkspaceId, assigneeId: userId, status: { not: "DONE" }, dueDate: { lt: new Date() } }
                }) : Promise.resolve(0),
                hasPMS ? prisma.task.findMany({
                    where: {
                        workspaceId: activeWorkspaceId,
                        OR: [
                            { createdAt: { gte: subDays(new Date(), 7) } },
                            { updatedAt: { gte: subDays(new Date(), 7) }, status: "DONE" }
                        ]
                    },
                    select: { createdAt: true, updatedAt: true, status: true }
                }) : Promise.resolve([]),
                hasPMS ? prisma.task.findMany({
                    where: {
                        assigneeId: userId,
                        status: { not: "DONE" },
                        dueDate: { lt: new Date() }
                    },
                    take: 4,
                    orderBy: { dueDate: "asc" },
                    include: { project: { select: { name: true } } }
                }) : Promise.resolve([]),
                hasPMS ? prisma.project.findMany({
                    where: {
                        workspaceId: activeWorkspaceId,
                        status: "ACTIVE"
                    },
                    take: 3,
                    orderBy: { updatedAt: "desc" },
                    include: {
                        _count: { select: { tasks: true } },
                        tasks: { where: { status: "DONE" }, select: { id: true } }
                    }
                }) : Promise.resolve([]),
                hasCRM ? prisma.lead.findMany({
                    where: {
                        workspaceId: activeWorkspaceId,
                        createdAt: { gte: subDays(new Date(), 7) }
                    },
                    select: { createdAt: true, status: true }
                }) : Promise.resolve([]),
                hasCRM ? prisma.lead.findMany({
                    where: { ...scopeWhere },
                    take: 5,
                    orderBy: { createdAt: "desc" },
                    select: { id: true, firstName: true, lastName: true, email: true, service: true, createdAt: true }
                }) : Promise.resolve([]),
                hasCRM ? prisma.deal.findMany({
                    where: { ...scopeWhere, stage: { notIn: ["WON", "LOST"] } },
                    take: 5,
                    orderBy: { value: "desc" },
                    select: { id: true, title: true, value: true, stage: true, updatedAt: true }
                }) : Promise.resolve([])
            ]);

            return {
                totalLeads,
                convertedLeads,
                totalWon: wonDealsReq._sum.value || 0,
                activeDeals,
                totalActivities,
                dealsByStage,
                allDeals,
                myActiveTasksCount,
                myOverdueTasksCount,
                weeklyTaskActivity,
                overdueTasksList,
                topProjects,
                weeklyLeadActivity,
                recentLeads,
                hotDeals,
                timestamp: new Date().toISOString()
            };
        },
        [cacheKey],
        {
            revalidate: 60, // Cache for 1 minute
            tags: [`dashboard-${activeWorkspaceId}`]
        }
    )();
}
