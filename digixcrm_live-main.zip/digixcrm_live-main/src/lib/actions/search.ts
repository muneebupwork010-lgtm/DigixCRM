"use server";

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

/**
 * Fetches a lightweight search index for ALL searchable entities in the workspace.
 * Called ONCE on mount — all subsequent filtering happens client-side (instant).
 */
export async function getSearchIndex() {
    const session = await getServerSession(authOptions);
    if (!session?.user || !(session.user as any).id) return null;

    const user = await prisma.user.findUnique({
        where: { id: (session.user as any).id },
        select: { id: true, email: true, role: true, activeWorkspaceId: true }
    });
    if (!user || !user.activeWorkspaceId) return null;

    const wsId = user.activeWorkspaceId;

    // Resolve role inline
    let role: string = user.role as string;
    if (user.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com") || user.role === "ADMIN") {
        role = "ADMIN";
    } else {
        const membership = await (prisma as any).workspaceMember.findUnique({
            where: { workspaceId_userId: { workspaceId: wsId, userId: user.id } }
        });
        if (membership?.role) {
            if (((user.role as string) === "ADMIN" || (user.role as string) === "MANAGER") &&
                (membership.role === "REP" || membership.role === "STAFF")) {
                role = user.role as string;
            } else {
                role = membership.role;
            }
        }
    }

    const canCRM = role !== "STAFF" && role !== "PROJECT_MANAGER";
    const canPMS = role !== "REP";
    const isScoped = role === "REP" || role === "STAFF";
    const ownFilter = isScoped ? { ownerId: user.id } : {};

    // Fetch lightweight index for all entities in parallel
    const [leads, deals, organizations, contacts, projects, tasks] = await Promise.all([
        canCRM ? prisma.lead.findMany({
            where: { workspaceId: wsId, ...ownFilter },
            select: { id: true, firstName: true, lastName: true, email: true, phone: true, status: true, service: true },
            orderBy: { updatedAt: "desc" },
            take: 500
        }) : [],

        canCRM ? prisma.deal.findMany({
            where: { workspaceId: wsId, ...ownFilter },
            select: { id: true, title: true, value: true, stage: true },
            orderBy: { updatedAt: "desc" },
            take: 300
        }) : [],

        canCRM ? prisma.organization.findMany({
            where: { workspaceId: wsId },
            select: { id: true, name: true, website: true },
            orderBy: { updatedAt: "desc" },
            take: 200
        }) : [],

        canCRM ? prisma.contact.findMany({
            where: { workspaceId: wsId, ...ownFilter },
            select: { id: true, firstName: true, lastName: true, email: true },
            orderBy: { updatedAt: "desc" },
            take: 300
        }) : [],

        canPMS ? prisma.project.findMany({
            where: { workspaceId: wsId },
            select: { id: true, name: true, status: true },
            orderBy: { updatedAt: "desc" },
            take: 100
        }) : [],

        canPMS ? prisma.task.findMany({
            where: { workspaceId: wsId },
            select: { id: true, title: true, status: true, projectId: true },
            orderBy: { updatedAt: "desc" },
            take: 300
        }) : [],
    ]);

    return { leads, deals, organizations, contacts, projects, tasks };
}
