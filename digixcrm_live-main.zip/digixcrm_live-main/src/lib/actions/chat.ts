"use server";

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { pusherServer } from "@/lib/pusher-server";
import { unstable_noStore as noStore } from "next/cache";

export async function sendMessage(conversationId: string, content: string) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    // 1. Verify user is part of the conversation
    const participant = await prisma.conversationParticipant.findUnique({
      where: {
        userId_conversationId: {
          userId,
          conversationId,
        },
      },
    });

    if (!participant) {
      throw new Error("You are not part of this conversation");
    }

    // 2. Parse Mentions (e.g. @John)
    const mentionRegex = /@([a-zA-Z0-9_]+)/g;
    const mentionMatches = [...content.matchAll(mentionRegex)].map(m => m[1]);
    const mentionedUsers: any[] = [];

    if (mentionMatches.length > 0) {
      for (const handle of mentionMatches) {
        const u = await prisma.user.findFirst({
          where: { name: { startsWith: handle, mode: 'insensitive' } }
        });
        if (u) mentionedUsers.push(u);
      }
    }

    // 3. Save the message to the database
    const message = await prisma.message.create({
      data: {
        content,
        conversationId,
        senderId: userId,
      },
      include: {
        sender: {
          select: { id: true, name: true, image: true },
        },
      },
    });

    // 4. Process Mentions
    if (mentionedUsers.length > 0) {
      // Ensure they are part of the conversation so it appears in their Inbox
      for (const u of mentionedUsers) {
        const isParticipant = await prisma.conversationParticipant.findUnique({
          where: { userId_conversationId: { userId: u.id, conversationId } }
        });
        if (!isParticipant) {
          await prisma.conversationParticipant.create({
            data: { userId: u.id, conversationId }
          });
        }
      }

      // Create Mention records
      await prisma.mention.createMany({
        data: mentionedUsers.map(u => ({
          messageId: message.id,
          userId: u.id
        }))
      });
    }

    // 5. Trigger the Pusher event to everyone in the room instantly
    await pusherServer.trigger(
      `chat-${conversationId}`,
      "new-message",
      message
    );

    // 6. Create Notification records for other participants AND mentioned users
    const otherParticipants = await prisma.conversationParticipant.findMany({
      where: {
        conversationId,
        userId: { not: userId }
      }
    });

    if (otherParticipants.length > 0) {
      await prisma.notification.createMany({
        data: otherParticipants.map(p => {
          const isMentioned = mentionedUsers.some(u => u.id === p.userId);
          return {
            userId: p.userId,
            title: isMentioned ? "You were mentioned!" : "New Message",
            message: `${message.sender.name || 'Someone'} ${isMentioned ? 'mentioned you' : 'sent'}: ${content.substring(0, 50)}...`,
            type: "MESSAGE",
            link: "/dashboard/inbox"
          };
        })
      });

      // Trigger Pusher notification update for each participant
      for (const p of otherParticipants) {
        await pusherServer.trigger(`user-${p.userId}`, "unread-update", {});
      }
    }

    return { success: true, message };
  } catch (error) {
    console.error("SEND_MESSAGE_ERROR", error);
    return { success: false, error: "Failed to send message" };
  }
}

export async function getConversationMessages(conversationId: string) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    const messages = await prisma.message.findMany({
      where: { conversationId },
      include: {
        sender: {
          select: { id: true, name: true, image: true },
        },
      },
      orderBy: { createdAt: "asc" },
      take: 50, // Load last 50 messages by default
    });

    return { success: true, messages };
  } catch (error) {
    console.error("GET_MESSAGES_ERROR", error);
    return { success: false, error: "Failed to load messages" };
  }
}

export async function getOrCreateDirectConversation(otherUserId: string) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    // Check if conversation already exists
    const existing = await prisma.conversation.findFirst({
      where: {
        type: "DIRECT",
        participants: {
          every: {
            userId: { in: [userId, otherUserId] }
          }
        }
      },
      include: {
        participants: {
          include: { user: { select: { id: true, name: true, image: true } } }
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    });

    if (existing) {
      return { success: true, conversation: existing };
    }

    // Create new
    const newConv = await prisma.conversation.create({
      data: {
        type: "DIRECT",
        participants: {
          create: [
            { userId },
            { userId: otherUserId }
          ]
        }
      },
      include: {
        participants: {
          include: { user: { select: { id: true, name: true, image: true } } }
        },
        messages: true
      }
    });

    return { success: true, conversation: newConv };
  } catch (error) {
    console.error("CREATE_CONV_ERROR", error);
    return { success: false, error: "Failed to create conversation" };
  }
}

export async function getOrCreateProjectConversation(projectId: string) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    const conversationId = `project-${projectId}`;

    // Fetch all project members to ensure everyone is a participant
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      select: {
        ownerId: true,
        members: { select: { userId: true } }
      }
    });

    const projectMemberIds = new Set<string>();
    if (project) {
      if (project.ownerId) projectMemberIds.add(project.ownerId);
      project.members.forEach(m => projectMemberIds.add(m.userId));
    }
    projectMemberIds.add(userId);
    const uniqueMemberIds = Array.from(projectMemberIds);

    // Check if conversation already exists
    const existing = await prisma.conversation.findUnique({
      where: { id: conversationId },
      include: {
        participants: {
          include: { user: { select: { id: true, name: true, image: true } } }
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      }
    });

    if (existing) {
      const existingParticipantUserIds = new Set(existing.participants.map(p => p.userId));
      const missingUserIds = uniqueMemberIds.filter(id => !existingParticipantUserIds.has(id));

      if (missingUserIds.length > 0) {
        await prisma.conversationParticipant.createMany({
          data: missingUserIds.map(id => ({
            conversationId,
            userId: id
          }))
        });
      }

      // Sync projectId if not set
      if (!existing.projectId) {
        await prisma.conversation.update({
          where: { id: conversationId },
          data: { projectId }
        });
        existing.projectId = projectId;
      }
      return { success: true, conversation: existing };
    }

    // Create new
    const newConv = await prisma.conversation.create({
      data: {
        id: conversationId,
        type: "PROJECT",
        projectId: projectId,
        participants: {
          create: uniqueMemberIds.map(id => ({ userId: id }))
        }
      },
      include: {
        participants: {
          include: { user: { select: { id: true, name: true, image: true } } }
        },
        messages: true
      }
    });

    return { success: true, conversation: newConv };
  } catch (error) {
    console.error("CREATE_PROJECT_CONV_ERROR", error);
    return { success: false, error: "Failed to create project conversation" };
  }
}

export async function markConversationAsRead(conversationId: string) {
  noStore();
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    await prisma.conversationParticipant.update({
      where: {
        userId_conversationId: {
          userId,
          conversationId,
        },
      },
      data: {
        lastReadAt: new Date(),
      },
    });

    // Trigger Pusher notification update for current user to clear red dots
    await pusherServer.trigger(`user-${userId}`, "unread-update", {});

    return { success: true };
  } catch (error) {
    console.error("MARK_READ_ERROR", error);
    return { success: false, error: "Failed to mark conversation as read" };
  }
}

export async function getUnreadChatCount() {
  noStore();
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) return { success: true, count: 0 };

    const participants = await prisma.conversationParticipant.findMany({
      where: { userId },
      select: { conversationId: true, lastReadAt: true }
    });

    let totalUnread = 0;
    for (const p of participants) {
      const lastRead = p.lastReadAt || new Date(0);
      const unreadCount = await prisma.message.count({
        where: {
          conversationId: p.conversationId,
          senderId: { not: userId },
          createdAt: { gt: lastRead }
        }
      });
      if (unreadCount > 0) {
        totalUnread += 1;
      }
    }

    return { success: true, count: totalUnread };
  } catch (error) {
    console.error("GET_UNREAD_COUNT_ERROR", error);
    return { success: false, count: 0 };
  }
}
