"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { getVerifiedRecord, getEffectiveRole, getScopeWhere } from "@/lib/permissions";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";
import { MilestoneStatus } from "@/generated/prisma/client";

const milestoneSchema = z.object({
  title: z.string().min(1, "Milestone title is required"),
  description: z.string().optional(),
  status: z.nativeEnum(MilestoneStatus).optional(),
  dueDate: z.coerce.date().optional().nullable(),
  projectId: z.string()
});

export async function getProjectMilestones(projectId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");
    
        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");
    
        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
    
        // Verify project access
        const project = await prisma.project.findFirst({
            where: {
                id: projectId,
                ...getScopeWhere(effectiveRole, user.id, workspaceId)
            }
        });
    
        if (!project) throw new Error("Project not found or access denied");
    
        const milestones = await prisma.milestone.findMany({
            where: { projectId },
            include: {
                tasks: {
                    select: {
                        id: true,
                        title: true,
                        description: true,
                        status: true,
                        priority: true,
                        assigneeId: true,
                        startDate: true,
                        dueDate: true,
                        estimatedHours: true,
                        actualHours: true,
                        tags: true,
                        projectId: true,
                        project: { select: { name: true } },
                        attachments: true,
                        watchers: true,
                        _count: { select: { activities: true } }
                    }
                }
            },
            orderBy: [{ dueDate: "asc" }, { order: "asc" }, { createdAt: "asc" }],
        });
    
        return milestones;
    } catch (error) {
        console.error("Failed to fetch milestones:", error);
        return [];
    }
}

export async function createMilestone(rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");
    
        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");
    
        const data = milestoneSchema.parse(rawData);
        
        // Verify project and workspace
        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const project = await getVerifiedRecord(prisma.project, data.projectId, user.id, effectiveRole, workspaceId);
        if (!project) throw new Error("Project access denied");
    
        const lastMilestone = await prisma.milestone.findFirst({
            where: { projectId: data.projectId },
            orderBy: { order: "desc" }
        });
        const nextOrder = (lastMilestone?.order ?? -1) + 1;
    
        const newMilestone = await prisma.milestone.create({
            data: {
                title: data.title,
                description: data.description,
                status: data.status || "PENDING",
                dueDate: data.dueDate,
                projectId: data.projectId,
                order: nextOrder
            } as any,
        });
    
        await createAuditLog({
            action: "CREATE",
            entityType: "MILESTONE",
            entityId: newMilestone.id,
            details: `Created milestone: ${newMilestone.title} in project ${project.name}`,
        });
    
        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${data.projectId}`);
    
        return { success: true, data: newMilestone };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to create milestone" };
    }
}

export async function updateMilestone(id: string, rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const data = milestoneSchema.partial().parse(rawData);

        // We need to verify access via the project
        const milestone = await prisma.milestone.findUnique({ where: { id } });
        if (!milestone) throw new Error("Milestone not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const project = await getVerifiedRecord(prisma.project, milestone.projectId, user.id, effectiveRole, workspaceId);
        if (!project) throw new Error("Project access denied");

        const updated = await prisma.milestone.update({
            where: { id },
            data: data as any
        });

        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${updated.projectId}`);

        return { success: true, data: updated };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update milestone" };
    }
}

export async function deleteMilestone(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const milestone = await prisma.milestone.findUnique({ where: { id } });
        if (!milestone) throw new Error("Milestone not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const project = await getVerifiedRecord(prisma.project, milestone.projectId, user.id, effectiveRole, workspaceId);
        if (!project) throw new Error("Project access denied");

        await prisma.milestone.delete({ where: { id } });

        await createAuditLog({
            action: "DELETE",
            entityType: "MILESTONE",
            entityId: id,
            details: `Deleted milestone ${milestone.title}`
        });

        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${milestone.projectId}`);

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete milestone" };
    }
}
