"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { createNotification } from "./notifications";
import { getVerifiedRecord, getEffectiveRole, getScopeWhere } from "@/lib/permissions";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";
import { TaskStatus, Priority } from "@/generated/prisma/client";

const emptyToNull = (val: any) => val === "" ? null : val;

const taskSchema = z.object({
  title: z.string().min(1, "Task title is required"),
  description: z.string().optional(),
  status: z.nativeEnum(TaskStatus).optional(),
  priority: z.nativeEnum(Priority).optional(),
  dueDate: z.coerce.date().optional().nullable(),
  startDate: z.coerce.date().optional().nullable(),
  estimatedHours: z.coerce.number().min(0).optional(),
  actualHours: z.coerce.number().min(0).optional(),
  assigneeId: z.preprocess(emptyToNull, z.string().optional().nullable()),
  projectId: z.string(),
  milestoneId: z.preprocess(emptyToNull, z.string().optional().nullable()),
  parentTaskId: z.preprocess(emptyToNull, z.string().optional().nullable()),
  tags: z.array(z.string()).optional(),
  watchers: z.any().optional(),
});

export async function getProjectTasks(projectId: string) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const effectiveRole = await getEffectiveRole(user);
    const workspaceId = (user as any).activeWorkspaceId;

    // Verify project access
    const project = await prisma.project.findFirst({
        where: {
            id: projectId,
            workspaceId,
            ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
              OR: [
                { ownerId: user.id },
                { members: { some: { userId: user.id } } }
              ]
            } : {})
        }
    });

    if (!project) throw new Error("Project not found or access denied");

    const tasks = await prisma.task.findMany({
      where: {
        projectId,
      },
      include: {
        assignee: { select: { id: true, name: true, image: true } },
        watchers: { select: { id: true, name: true, image: true } },
        attachments: { orderBy: { createdAt: "desc" } },
        _count: { select: { subTasks: true, activities: true, timeEntries: true } },
      },
      orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    });

    return tasks;
  } catch (error) {
    console.error("Failed to fetch tasks:", error);
    return [];
  }
}

export async function getMyTasks() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const workspaceId = (user as any).activeWorkspaceId;
    if (!workspaceId) return [];

    const tasks = await prisma.task.findMany({
      where: {
        workspaceId,
        assigneeId: user.id
      },
      include: {
        project: { select: { id: true, name: true } },
        assignee: { select: { id: true, name: true, image: true } },
        watchers: { select: { id: true, name: true, image: true } },
        attachments: { orderBy: { createdAt: "desc" } },
        _count: { select: { subTasks: true, activities: true, timeEntries: true } }
      },
      orderBy: [
        { dueDate: "asc" },
        { priority: "desc" }
      ]
    });

    return tasks;
  } catch (error) {
    console.error("Failed to fetch my tasks:", error);
    return [];
  }
}

export async function createTask(rawData: any) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const data = taskSchema.parse(rawData);
    
    // Verify project and workspace
    const effectiveRole = await getEffectiveRole(user);
    const workspaceId = (user as any).activeWorkspaceId;
    const project = await prisma.project.findFirst({
        where: {
            id: data.projectId,
            workspaceId,
            ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
              OR: [
                { ownerId: user.id },
                { members: { some: { userId: user.id } } }
              ]
            } : {})
        }
    });
    if (!project) throw new Error("Project access denied");

    // --- ENFORCE SUBSCRIPTION LIMITS ---
    const { checkWorkspaceCapacity } = await import("@/lib/billing");
    const capacity = await checkWorkspaceCapacity(workspaceId);
    if (capacity.isOverCapacity) {
      throw new Error(`SUBSCRIPTION_LIMIT: ${capacity.reason}`);
    }

    // Get max order for positioning
    const lastTask = await prisma.task.findFirst({
        where: { projectId: data.projectId, status: data.status || "TODO" },
        orderBy: { order: "desc" }
    });
    const nextOrder = (lastTask?.order ?? -1) + 1;

    const newTask = await prisma.task.create({
      data: {
        title: data.title,
        description: data.description,
        status: data.status || "TODO",
        priority: data.priority || "MEDIUM",
        dueDate: data.dueDate,
        startDate: data.startDate,
        estimatedHours: data.estimatedHours || 0,
        assigneeId: data.assigneeId || user.id,
        projectId: data.projectId,
        milestoneId: data.milestoneId,
        parentTaskId: data.parentTaskId,
        createdById: user.id,
        workspaceId,
        order: nextOrder
      } as any,
    });

    await createAuditLog({
      action: "CREATE",
      entityType: "TASK",
      entityId: newTask.id,
      details: `Created task: ${newTask.title} in project ${project.name}`,
    });

    // Notify assignee
    if (newTask.assigneeId && newTask.assigneeId !== user.id) {
      await createNotification({
          userId: newTask.assigneeId,
          title: "New Task Assigned",
          message: `You have been assigned to: ${newTask.title}`,
          type: "TASK_ASSIGNED",
          link: `/dashboard/projects/${newTask.projectId}?tab=board`,
          workspaceId
      });
    }

    // Trigger Workflows
    import("@/lib/workflow-engine").then((m) => {
      m.executeWorkflows("TASK_CREATED", workspaceId, newTask).catch(console.error);
    });

    await touchWorkspace(workspaceId);
    revalidatePath(`/dashboard/projects/${data.projectId}`);

    return { success: true, data: newTask };
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to create task" };
  }
}

export async function updateTask(id: string, rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized (updateTask)");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        
        const record = await prisma.task.findUnique({ where: { id } });
        if (!record || record.workspaceId !== workspaceId) throw new Error("Task not found");

        if (effectiveRole === "CLIENT") {
            if (record.createdById !== user.id && record.assigneeId !== user.id) {
                throw new Error("Forbidden: Clients can only modify tasks they created or are assigned to");
            }
        } else if (effectiveRole !== "ADMIN" && effectiveRole !== "MANAGER" && effectiveRole !== "PROJECT_MANAGER") {
            // Reps and Staff can modify if they are a member of the project
            const project = await prisma.project.findFirst({
                where: {
                    id: record.projectId,
                    OR: [
                        { ownerId: user.id },
                        { members: { some: { userId: user.id } } }
                    ]
                }
            });
            if (!project) throw new Error("Forbidden: You do not have permission to modify this record");
        }

        const data = taskSchema.partial().parse(rawData);

        const updated = await prisma.task.update({
            where: { id },
            data: data as any
        });

        // --- ACTIVITY LOGGING ---
        const { createActivity } = await import("./activities");

        if (data.status && data.status !== record.status) {
            await createActivity({
                type: "SYSTEM_STATUS",
                notes: `changed status from ${record.status} to ${data.status}`,
                taskId: id
            });
            
            // Workflow trigger
            if (data.status === "DONE") {
                import("@/lib/workflow-engine").then((m) => {
                    m.executeWorkflows("TASK_COMPLETED", record.workspaceId, updated).catch(console.error);
                });
            }
        }

        if (data.priority && data.priority !== record.priority) {
            await createActivity({
                type: "SYSTEM_PRIORITY",
                notes: `set priority to ${data.priority}`,
                taskId: id
            });
        }

        if (data.assigneeId !== undefined && data.assigneeId !== record.assigneeId) {
            const newAssignee = data.assigneeId 
                ? await prisma.user.findUnique({ where: { id: data.assigneeId } })
                : null;
            await createActivity({
                type: "SYSTEM_ASSIGNEE",
                notes: `assigned this task to ${newAssignee?.name || "Unassigned"}`,
                taskId: id
            });
        }

        if (data.dueDate && data.dueDate.getTime() !== record.dueDate?.getTime()) {
            await createActivity({
                type: "SYSTEM_DATE",
                notes: `changed due date to ${data.dueDate.toLocaleDateString()}`,
                taskId: id
            });
        }

        // Notify new assignee
        if (data.assigneeId && data.assigneeId !== record.assigneeId && data.assigneeId !== user.id) {
            await createNotification({
                userId: data.assigneeId,
                title: "Task Assigned",
                message: `You have been assigned to: ${updated.title}`,
                type: "TASK_ASSIGNED",
                link: `/dashboard/projects/${updated.projectId}?tab=board`,
                workspaceId
            });
        }

        // Notify creator when task is completed
        if (data.status === "DONE" && record.status !== "DONE" && updated.createdById && updated.createdById !== user.id) {
            await createNotification({
                userId: updated.createdById,
                title: "Task Completed",
                message: `Task "${updated.title}" was completed by ${user.name}`,
                type: "TASK_COMPLETED",
                link: `/dashboard/projects/${updated.projectId}?tab=board`,
                workspaceId
            });
        }

        await touchWorkspace(record.workspaceId);
        revalidatePath(`/dashboard/projects/${updated.projectId}`);

        return { success: true, data: updated };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update task" };
    }
}

export async function deleteTask(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const record = await getVerifiedRecord(prisma.task, id, user.id, effectiveRole, workspaceId);
        if (!record) throw new Error("Task not found or access denied");
        
        // Fetch attachments for cleanup
        const taskWithAttachments = await prisma.task.findUnique({
            where: { id },
            include: { attachments: true }
        });

        if (!taskWithAttachments) throw new Error("Task not found or access denied");

        // Clean up R2 storage
        const { deleteTaskAttachment } = await import("./attachments");
        for (const attachment of taskWithAttachments.attachments) {
            try {
                await deleteTaskAttachment(attachment.id);
            } catch (err) {
                console.error(`Failed to delete R2 asset for attachment ${attachment.id}:`, err);
            }
        }

        // Now delete the task (Prisma handles database cascades for subtasks/activities)
        await prisma.task.delete({ where: { id } });

        await createAuditLog({
            action: "DELETE",
            entityType: "TASK",
            entityId: id,
            details: `Deleted task ${id} and cleaned up its storage assets`
        });

        await touchWorkspace(record.workspaceId!);
        revalidatePath(`/dashboard/projects/${record.projectId}`);

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete task" };
    }
}

export async function updateTaskArchiveStatus(id: string, isClosed: boolean) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        
        const record = await prisma.task.findUnique({ where: { id } });
        if (!record || record.workspaceId !== workspaceId) throw new Error("Task not found");

        if (effectiveRole === "CLIENT") {
            if (record.createdById !== user.id && record.assigneeId !== user.id) {
                throw new Error("Forbidden: Clients can only modify tasks they created or are assigned to");
            }
        } else if (effectiveRole !== "ADMIN" && effectiveRole !== "MANAGER" && effectiveRole !== "PROJECT_MANAGER") {
            // Reps and Staff can modify if they are a member of the project
            const project = await prisma.project.findFirst({
                where: {
                    id: record.projectId,
                    OR: [
                        { ownerId: user.id },
                        { members: { some: { userId: user.id } } }
                    ]
                }
            });
            if (!project) throw new Error("Forbidden: You do not have permission to modify this record");
        }

        const updated = await prisma.task.update({
            where: { id },
            data: { 
                isClosed,
                closedAt: isClosed ? new Date() : null
            }
        });

        await touchWorkspace(record.workspaceId);
        revalidatePath(`/dashboard/projects/${updated.projectId}`);

        return { success: true, data: updated };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update task archive status" };
    }
}

export async function bulkArchiveTasks(projectId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        
        // Verify project access
        const project = await prisma.project.findFirst({
            where: {
                id: projectId,
                workspaceId,
                ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
                  OR: [
                    { ownerId: user.id },
                    { members: { some: { userId: user.id } } }
                  ]
                } : {})
            }
        });

        if (!project) throw new Error("Project access denied");

        await prisma.task.updateMany({
            where: {
                projectId,
                status: "DONE",
                isClosed: false
            },
            data: {
                isClosed: true,
                closedAt: new Date()
            }
        });

        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${projectId}`);

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to bulk archive tasks" };
    }
}

export async function getArchivedProjectTasks(projectId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;

        // Verify project access
        const project = await prisma.project.findFirst({
            where: {
                id: projectId,
                workspaceId,
                ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
                  OR: [
                    { ownerId: user.id },
                    { members: { some: { userId: user.id } } }
                  ]
                } : {})
            }
        });

        if (!project) throw new Error("Project access denied");

        const tasks = await prisma.task.findMany({
            where: {
                projectId,
                isClosed: true
            },
            include: {
                assignee: { select: { id: true, name: true, image: true } },
                _count: { select: { activities: true } }
            },
            orderBy: { closedAt: "desc" }
        });

        return tasks;
    } catch (error) {
        console.error("Failed to fetch archived tasks:", error);
        return [];
    }
}


export async function getSubTasks(taskId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized (getSubTasks)");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const subTasks = await prisma.task.findMany({
            where: { parentTaskId: taskId },
            include: {
                assignee: { select: { id: true, name: true, image: true } },
                _count: { select: { activities: true, timeEntries: true } }
            },
            orderBy: { createdAt: "asc" }
        });

        return subTasks;
    } catch (error) {
        console.error("Failed to fetch sub-tasks:", error);
        return [];
    }
}

export async function updateTaskStatusWithEmail(taskId: string, newStatus: TaskStatus, notifyUserIds: string[]) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const updateRes = await updateTask(taskId, { status: newStatus });
        if (!updateRes.success || !updateRes.data) throw new Error(updateRes.error || "Update failed without data");

        const taskData = updateRes.data;

        if (notifyUserIds && notifyUserIds.length > 0) {
            const usersToNotify = await prisma.user.findMany({
                where: { id: { in: notifyUserIds } },
                select: { email: true, name: true }
            });

            const { sendEmail } = await import("@/lib/mail");

            let subject = `Task Status Updated: ${taskData.title}`;
            let headline = "Status Updated";
            let bodyText = `The status of the task "${taskData.title}" has been changed to ${newStatus.replace("_", " ")}.`;
            let color = "#3b82f6"; // blue

            if (newStatus === "IN_PROGRESS") {
                subject = `🚀 Task In Progress: ${taskData.title}`;
                headline = "The Gears Are Turning!";
                bodyText = `This task is now <strong>In Progress</strong> and being actively worked on. Let's keep the momentum going!`;
                color = "#3b82f6";
            } else if (newStatus === "IN_REVIEW") {
                subject = `👀 Ready for Review: ${taskData.title}`;
                headline = "Ready for a Look!";
                bodyText = `This task is up for <strong>Review</strong>. Your feedback and approval are appreciated to move it across the finish line!`;
                color = "#f59e0b"; // amber
            } else if (newStatus === "BLOCKED") {
                subject = `🛑 Roadblock Ahead: ${taskData.title}`;
                headline = "We Hit a Snag!";
                bodyText = `This task is currently <strong>Blocked</strong>. We need to unblock it together to keep the project on track. Please check if you can help.`;
                color = "#ef4444"; // red
            } else if (newStatus === "DONE") {
                subject = `🎉 Task Completed: ${taskData.title}`;
                headline = "Woohoo! Great Job!";
                bodyText = `This task has been successfully <strong>Completed</strong>. Great job team!`;
                color = "#10b981"; // emerald
            }

            const htmlContent = `
                <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e5e7eb; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
                    <div style="background-color: ${color}; padding: 24px; text-align: center;">
                        <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 800; letter-spacing: 0.5px;">${headline}</h1>
                    </div>
                    <div style="padding: 32px 24px; background-color: #ffffff;">
                        <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-top: 0;">${bodyText}</p>
                        <div style="background-color: #f3f4f6; border-radius: 8px; padding: 16px; margin: 24px 0;">
                            <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px;">Task Details</h3>
                            <p style="margin: 0; font-size: 16px; font-weight: 600; color: #111827;">${taskData.title}</p>
                        </div>
                        <p style="font-size: 14px; color: #6b7280; margin-bottom: 0;">
                            Log in to your workspace to view the full details and collaborate with the team.
                        </p>
                    </div>
                    <div style="background-color: #f9fafb; padding: 16px; text-align: center; border-top: 1px solid #e5e7eb;">
                        <p style="margin: 0; font-size: 12px; color: #9ca3af;">This is an automated notification from DigixCRM.</p>
                    </div>
                </div>
            `;

            for (const u of usersToNotify) {
                if (u.email) {
                    await sendEmail({
                        to: u.email,
                        subject,
                        html: htmlContent,
                        workspaceId: taskData.workspaceId ?? undefined
                    });
                }
            }
        }

        return { success: true, data: taskData };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update status and send emails" };
    }
}
