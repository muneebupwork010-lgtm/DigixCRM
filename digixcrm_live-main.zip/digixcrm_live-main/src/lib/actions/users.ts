"use server";

import { S3Client, PutObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { revalidatePath } from "next/cache";
import sharp from "sharp";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { z } from "zod";
import { createAuditLog } from "./audit";
import { sendEmail } from "@/lib/mail";
import { validateTurnstileToken } from "@/lib/turnstile";

// SOC 2 PI1.1 — Zod Schemas for Input Validation
const createUserSchema = z.object({
    name: z.string().min(1).optional(),
    email: z.string().email("Valid email is required"),
    password: z.string().min(6, "Password must be at least 6 characters").optional(),
    role: z.enum(["ADMIN", "MANAGER", "PROJECT_MANAGER", "STAFF", "REP", "CLIENT"]).optional(),
    workspaceAssignments: z.array(z.object({
        workspaceId: z.string(),
        role: z.enum(["ADMIN", "MANAGER", "PROJECT_MANAGER", "STAFF", "REP", "CLIENT"]),
        customRoleId: z.string().nullable().optional(),
    })).optional(),
});

const updateSettingsSchema = z.object({
    name: z.string().min(1).optional(),
    jobTitle: z.string().optional().nullable(),
    phoneNumber: z.string().optional().nullable(),
    bio: z.string().optional().nullable(),
    timezone: z.string().optional().nullable(),
    language: z.string().optional().nullable(),
});

const resetPasswordSchema = z.object({
    email: z.string().email("Valid email is required"),
    token: z.string().min(1, "Reset token is required"),
    password: z.string().min(6, "Password must be at least 6 characters"),
});

function getS3Client() {
    return new S3Client({
        region: "auto",
        endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
        credentials: {
            accessKeyId: process.env.R2_ACCESS_KEY_ID || "",
            secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || "",
        },
        forcePathStyle: true,
    });
}

/**
 * Fetch users with optional workspace filtering
 */
export async function getUsers(workspaceId?: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return [];

        const currentUser = await prisma.user.findUnique({
            where: { email: session.user.email },
            select: { id: true, accountId: true, email: true }
        });

        if (!currentUser) return [];

        const isSuperAdmin = currentUser.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com");

        const where: any = {};
        // Multi-tenant boundary: restrict to the current user's SubscriptionAccount
        if (!isSuperAdmin) {
            const adminMemberships = await prisma.workspaceMember.findMany({
                where: { userId: currentUser.id, role: { in: ["ADMIN", "MANAGER"] } },
                select: { workspaceId: true }
            });
            const adminWorkspaceIds = adminMemberships.map(m => m.workspaceId);

            const tenantConditions: any[] = [];
            
            if (currentUser.accountId) {
                tenantConditions.push({ accountId: currentUser.accountId });
            } else {
                // If they have no account, they should only see themselves
                tenantConditions.push({ id: currentUser.id });
            }

            if (adminWorkspaceIds.length > 0) {
                tenantConditions.push({
                    workspaceMemberships: {
                        some: { workspaceId: { in: adminWorkspaceIds } }
                    }
                });
            }

            where.OR = tenantConditions;
        }

        if (workspaceId) {
            where.workspaceMemberships = {
                some: { workspaceId }
            };
        }

        // Hide Master Admin from non-SuperAdmins
        if (!isSuperAdmin) {
            where.email = { not: process.env.SUPER_ADMIN_EMAIL || "admin@crm.com" };
        }

        return await prisma.user.findMany({
            where,
            orderBy: { createdAt: "desc" },
            include: {
                workspaceMemberships: true
            }
        });
    } catch (error) {
        console.error("getUsers error:", error);
        return [];
    }
}

/**
 * Create a new user (usually via invite)
 */
export async function createUser(data: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const inviter = await prisma.user.findUnique({
            where: { email: session.user.email },
            select: { accountId: true, email: true, name: true }
        });

        if (!inviter) return { success: false, error: "Unauthorized" };

        const isSuperAdmin = inviter.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com");
        if (!inviter.accountId && !isSuperAdmin) {
            return { success: false, error: "You must belong to a billing account to invite users." };
        }

        const validated = createUserSchema.parse(data);
        const { workspaceAssignments, ...userData } = validated;

        // Check if user already exists
        const existingUser = await prisma.user.findUnique({ 
            where: { email: data.email },
            include: { workspaceMemberships: true }
        });

        if (existingUser) {
            // Check if they are already in the assigned workspaces
            if (!workspaceAssignments || workspaceAssignments.length === 0) {
                return { success: false, error: "User already exists." };
            }

            // Find which workspaces they are NOT already in
            const existingWorkspaceIds = new Set(existingUser.workspaceMemberships.map((m: any) => m.workspaceId));
            const newAssignments = workspaceAssignments.filter(a => !existingWorkspaceIds.has(a.workspaceId));

            if (newAssignments.length === 0) {
                return { success: false, error: "User is already a member of the selected workspace(s)." };
            }

            // Add them to the new workspaces
            await Promise.all(newAssignments.map(async (assignment) => {
                await (prisma as any).workspaceMember.create({
                    data: {
                        userId: existingUser.id,
                        workspaceId: assignment.workspaceId,
                        role: assignment.role,
                        customRoleId: assignment.customRoleId || null,
                    }
                });
            }));

            // Fetch workspace names for the email
            const workspacesData = await prisma.workspace.findMany({
                where: { id: { in: newAssignments.map(a => a.workspaceId) } },
                select: { name: true }
            });
            const workspaceNames = workspacesData.map(w => w.name);

            // Send notification email
            const inviterName = inviter.name || inviter.email || "Your team admin";
            const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
            
            await sendEmail({
                to: existingUser.email || data.email,
                subject: `You've been added to new workspaces in DigiXCRM`,
                html: `
                    <div style="font-family: 'Segoe UI', Arial, sans-serif; padding: 32px; max-width: 540px; border: 1px solid #e5e5e5; border-radius: 16px; background: #fafafa;">
                        <div style="text-align: center; margin-bottom: 24px;">
                            <h1 style="color: #1e1b4b; font-size: 24px; margin: 0;">Workspace Update</h1>
                        </div>
                        <div style="background: #fff; border: 1px solid #e5e5e5; border-radius: 12px; padding: 24px; margin: 0 0 20px 0;">
                            <p style="font-size: 14px; color: #444; margin: 0 0 16px 0;">Hi <strong>${existingUser.name || 'there'}</strong>,</p>
                            <p style="font-size: 14px; color: #444;">${inviterName} has added you to the following workspaces:</p>
                            <ul style="font-size: 14px; color: #444; padding-left: 20px;">
                                ${workspaceNames.map(name => `<li><strong>${name}</strong></li>`).join('')}
                            </ul>
                            <p style="font-size: 14px; color: #444; margin: 16px 0 0 0;">You can access them by switching workspaces in your dashboard.</p>
                        </div>
                        <div style="text-align: center;">
                            <a href="${baseUrl}/dashboard" style="display: inline-block; padding: 14px 32px; background: #4f46e5; color: #fff; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 14px;">Go to Dashboard →</a>
                        </div>
                    </div>
                `,
            }).catch((err) => console.error("Failed to send update email:", err));

            await createAuditLog({
                action: "UPDATE",
                entityType: "USER",
                entityId: existingUser.id,
                details: `Added existing user ${existingUser.email || data.email} to ${newAssignments.length} workspace(s)`
            });

            revalidatePath("/dashboard/settings");
            return { success: true, user: existingUser };
        }

        // Default name from email prefix if not provided
        const userName = userData.name || userData.email.split("@")[0];

        const user = await prisma.user.create({
            data: {
                ...userData,
                name: userName,
                password: null, // User will set this during setup
                accountId: inviter.accountId, // Multi-tenant binding
                isActive: true,
                hasCompletedOnboarding: false
            }
        });

        // Generate magic link token for setup
        const token = crypto.randomUUID();
        const expires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
        
        await prisma.verificationToken.deleteMany({
            where: { identifier: userData.email }
        });
        await prisma.verificationToken.create({
            data: {
                identifier: userData.email,
                token,
                expires
            }
        });

        // Create workspace memberships from assignments
        let workspaceNames: string[] = [];
        if (workspaceAssignments && workspaceAssignments.length > 0) {
            await Promise.all(workspaceAssignments.map(async (assignment) => {
                await (prisma as any).workspaceMember.create({
                    data: {
                        userId: user.id,
                        workspaceId: assignment.workspaceId,
                        role: assignment.role,
                        customRoleId: assignment.customRoleId || null,
                    }
                });
            }));

            // Set the first workspace as the active workspace
            await prisma.user.update({
                where: { id: user.id },
                data: { activeWorkspaceId: workspaceAssignments[0].workspaceId } as any,
            });

            // Fetch workspace names for the email
            const workspacesData = await prisma.workspace.findMany({
                where: { id: { in: workspaceAssignments.map(a => a.workspaceId) } },
                select: { name: true }
            });
            workspaceNames = workspacesData.map(w => w.name);
        }

        // Send setup magic link email
        const setupUrl = `${process.env.NEXTAUTH_URL || "http://localhost:3000"}/auth/setup?email=${encodeURIComponent(userData.email)}&token=${encodeURIComponent(token)}`;
        const inviterName = inviter.name || inviter.email || "Your team admin";
        const wsListHtml = workspaceNames.length > 0
            ? `<p style="font-size: 14px; color: #444;">You've been assigned to: <strong>${workspaceNames.join(", ")}</strong></p>`
            : "";

        await sendEmail({
            to: userData.email,
            subject: `You're invited to DigiXCRM — Set up your account`,
            html: `
                <div style="font-family: 'Segoe UI', Arial, sans-serif; padding: 32px; max-width: 540px; border: 1px solid #e5e5e5; border-radius: 16px; background: #fafafa;">
                    <div style="text-align: center; margin-bottom: 24px;">
                        <h1 style="color: #1e1b4b; font-size: 24px; margin: 0;">Welcome to DigiXCRM 🎉</h1>
                        <p style="color: #888; font-size: 13px; margin: 6px 0 0 0;">You have been invited by ${inviterName}</p>
                    </div>
                    <div style="background: #fff; border: 1px solid #e5e5e5; border-radius: 12px; padding: 24px; margin: 0 0 20px 0;">
                        <p style="font-size: 14px; color: #444; margin: 0 0 16px 0;">Hi <strong>${userName}</strong>, you have been invited to join the team!</p>
                        ${wsListHtml}
                        <p style="font-size: 14px; color: #444; margin: 16px 0 0 0;">Please click the secure link below to set up your profile and password:</p>
                    </div>
                    <div style="text-align: center;">
                        <a href="${setupUrl}" style="display: inline-block; padding: 14px 32px; background: #4f46e5; color: #fff; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 14px; letter-spacing: 0.3px;">Set Up Your Account →</a>
                    </div>
                    <p style="font-size: 12px; color: #aaa; text-align: center; margin: 24px 0 0 0;">
                        This link will expire in 24 hours for security reasons.<br/>
                        DigiXCRM Security Team
                    </p>
                </div>
            `,
        }).catch((err) => console.error("Failed to send invite email:", err));

        await createAuditLog({
            action: "CREATE",
            entityType: "USER",
            entityId: user.id,
            details: `Invited user: ${userName} (${user.email})${workspaceAssignments?.length ? ` — assigned to ${workspaceAssignments.length} workspace(s)` : ""}`
        });

        revalidatePath("/dashboard/settings");
        return { success: true, user };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to create user" };
    }
}



/**
 * Update user profile settings
 */
export async function updateUserSettings(data: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const { dob, ...restData } = data;
        const validated = updateSettingsSchema.parse(restData);

        let parsedDob = undefined;
        if (dob) {
            parsedDob = new Date(dob);
        } else if (dob === "") {
            parsedDob = null;
        }

        await prisma.user.update({
            where: { email: session.user.email },
            data: {
                ...validated,
                ...(parsedDob !== undefined ? { dob: parsedDob } : {})
            }
        });

        revalidatePath("/dashboard/settings");
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update settings" };
    }
}

/**
 * Toggle user active status (suspend/activate)
 */
export async function toggleUserStatus(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const requester = await prisma.user.findUnique({
            where: { email: session.user.email },
            select: { accountId: true, email: true }
        });

        const isSuperAdmin = requester?.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com");

        const user = await prisma.user.findUnique({ where: { id } });
        if (!user) return { success: false, error: "User not found" };

        // Multi-tenant boundary check
        if (!isSuperAdmin && user.accountId !== requester?.accountId) {
            return { success: false, error: "Forbidden: Access denied" };
        }

        const updated = await prisma.user.update({
            where: { id },
            data: { isActive: !user.isActive }
        });

        await createAuditLog({
            action: updated.isActive ? "ACTIVATE_USER" : "SUSPEND_USER",
            entityType: "USER",
            entityId: id,
            details: `${updated.isActive ? "Activated" : "Suspended"} user: ${user.name} (${user.email})`
        });

        revalidatePath("/dashboard/settings");
        return { success: true, isActive: updated.isActive };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to toggle status" };
    }
}

/**
 * Delete a user and cleanup their data
 */
export async function deleteUser(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const requester = await prisma.user.findUnique({
            where: { email: session.user.email },
            select: { accountId: true, email: true }
        });

        const isSuperAdmin = requester?.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com");

        const targetUser = await prisma.user.findUnique({ where: { id }, select: { id: true, name: true, email: true, accountId: true, isAccountOwner: true } });
        if (!targetUser) return { success: false, error: "User not found" };

        if (targetUser.email === (process.env.SUPER_ADMIN_EMAIL || "admin@crm.com")) {
            return { success: false, error: "The Master Admin cannot be deleted." };
        }

        if (targetUser.isAccountOwner && !isSuperAdmin) {
            return { success: false, error: "Account Owners cannot be deleted by team members." };
        }

        // Multi-tenant boundary check
        if (!isSuperAdmin && targetUser.accountId !== requester?.accountId) {
            return { success: false, error: "Forbidden: Access denied" };
        }

        await prisma.user.delete({ where: { id } });

        await createAuditLog({
            action: "DELETE",
            entityType: "USER",
            entityId: id,
            details: `Deleted user: ${targetUser?.name} (${targetUser?.email})`
        });

        revalidatePath("/dashboard/settings");
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete user" };
    }
}

/**
 * Complete initial user setup after registration
 */
export async function completeUserSetup(data: any) {
    try {
        const { email, token, name, jobTitle, phoneNumber, password } = data;
        
        if (!email || !token || !password) return { success: false, error: "Missing required fields" };

        const normalizedEmail = email.toLowerCase().trim();

        const verify = await prisma.verificationToken.findFirst({
            where: { identifier: normalizedEmail, token }
        });

        if (!verify || verify.expires < new Date()) {
            return { success: false, error: "Link has expired or is invalid." };
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await prisma.user.update({
            where: { email: normalizedEmail },
            data: {
                name,
                jobTitle,
                phoneNumber,
                password: hashedPassword,
                hasCompletedOnboarding: true,
                isActive: true
            }
        });

        // Clean up token
        await prisma.verificationToken.deleteMany({
            where: { identifier: normalizedEmail }
        });

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to complete setup" };
    }
}

export async function requestPasswordReset(email: string, captchaToken?: string) {
    try {
        if (!email) return { success: false, error: "Email is required" };

        const normalizedEmail = email.toLowerCase().trim();
        const user = await prisma.user.findUnique({ where: { email: normalizedEmail } });

        // SOC 2: Always return success to prevent email enumeration
        if (!user) return { success: true, message: "If an account exists, a reset link has been sent." };

        // Generate cryptographically secure token
        const token = crypto.randomUUID();
        const expires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour expiry

        // Clean up any existing tokens for this user
        await prisma.verificationToken.deleteMany({
            where: { identifier: normalizedEmail }
        });

        // Store the new token
        await prisma.verificationToken.create({
            data: {
                identifier: normalizedEmail,
                token,
                expires
            }
        });

        // Send the reset email
        const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
        const resetLink = `${baseUrl}/auth/reset-password?email=${encodeURIComponent(normalizedEmail)}&token=${encodeURIComponent(token)}`;

        await sendEmail({
            to: normalizedEmail,
            subject: "Password Reset — DigiXCRM",
            html: `
                <div style="font-family: Arial, sans-serif; padding: 24px; max-width: 520px; border: 1px solid #e5e5e5; border-radius: 12px;">
                    <h2 style="color: #1e1b4b; margin-bottom: 16px;">Password Reset Request</h2>
                    <p>We received a request to reset your DigiXCRM password. Click the button below to set a new password:</p>
                    <a href="${resetLink}" style="display: inline-block; margin: 20px 0; padding: 12px 24px; background: #4f46e5; color: #fff; border-radius: 8px; text-decoration: none; font-weight: bold;">Reset Password</a>
                    <p style="font-size: 13px; color: #888;">This link expires in 1 hour. If you didn't request this, you can safely ignore this email.</p>
                    <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
                    <p style="font-size: 12px; color: #aaa;">DigiXCRM Security Team</p>
                </div>
            `
        });

        await createAuditLog({
            action: "PASSWORD_RESET_REQUESTED",
            entityType: "USER",
            entityId: user.id,
            details: `Password reset link sent to ${normalizedEmail}`
        });

        return { success: true, message: "If an account exists, a reset link has been sent." };
    } catch (error: any) {
        console.error("Password reset request error:", error);
        return { success: false, error: "Failed to process request" };
    }
}

/**
 * Reset password with a verified token (SOC 2 CC6.1 — Secure Token Verification)
 */
export async function resetPassword(data: any) {
    try {
        const validated = resetPasswordSchema.parse(data);
        const normalizedEmail = validated.email.toLowerCase().trim();

        // Verify the token exists and is not expired
        const verificationToken = await prisma.verificationToken.findFirst({
            where: { identifier: normalizedEmail, token: validated.token }
        });

        if (!verificationToken) {
            return { success: false, error: "Invalid or expired reset link. Please request a new one." };
        }

        if (verificationToken.expires < new Date()) {
            // Clean up expired token
            await prisma.verificationToken.deleteMany({
                where: { identifier: normalizedEmail, token: validated.token }
            });
            return { success: false, error: "This reset link has expired. Please request a new one." };
        }

        // Hash and update the password
        const hashedPassword = await bcrypt.hash(validated.password, 10);

        await prisma.user.update({
            where: { email: normalizedEmail },
            data: { password: hashedPassword }
        });

        // Delete the used token (one-time use)
        await prisma.verificationToken.deleteMany({
            where: { identifier: normalizedEmail, token: validated.token }
        });

        const user = await prisma.user.findUnique({
            where: { email: normalizedEmail },
            select: { id: true }
        });

        await createAuditLog({
            action: "PASSWORD_RESET_COMPLETED",
            entityType: "USER",
            entityId: user?.id,
            details: `Password successfully reset for ${normalizedEmail}`
        });

        return { success: true };
    } catch (error: any) {
        console.error("Password reset error:", error);
        return { success: false, error: error.message || "Failed to reset password" };
    }
}

/**
 * Uploads a user avatar to Cloudflare R2 under the /avatars prefix
 * Optimizes the image to 400x400 WebP
 */
export async function updateUserAvatar(formData: FormData) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const user = await prisma.user.findUnique({
            where: { email: session.user.email }
        });

        if (!user) return { success: false, error: "User not found" };

        const file = formData.get("file") as File;
        if (!file) return { success: false, error: "No file provided" };

        if (file.size > 5 * 1024 * 1024) {
            return { success: false, error: "Avatar must be under 5MB" };
        }

        const bucketName = process.env.R2_BUCKET_NAME;
        if (!bucketName) return { success: false, error: "Storage bucket not configured" };

        // Clean up old avatar if it exists in R2
        if (user.image && user.image.includes(process.env.R2_PUBLIC_DOMAIN || "")) {
            try {
                const oldKey = user.image.split(`${process.env.R2_PUBLIC_DOMAIN}/`)[1];
                if (oldKey) {
                    const s3 = getS3Client();
                    await s3.send(new DeleteObjectCommand({
                        Bucket: bucketName,
                        Key: oldKey
                    }));
                }
            } catch (err) {
                console.error("Failed to delete old avatar:", err);
            }
        }

        let buffer = Buffer.from(await file.arrayBuffer());
        
        try {
            const optimized = await sharp(buffer)
                .resize(400, 400, {
                    fit: 'cover',
                    position: 'center'
                })
                .webp({ quality: 85 })
                .toBuffer();
            buffer = optimized as any;
        } catch (err) {
            console.error("Avatar optimization failed:", err);
        }

        const workspaceId = (user as any).activeWorkspaceId || "global";
        const fileName = `workspaces/${workspaceId}/avatars/${user.id}/${Date.now()}.webp`;
        const s3 = getS3Client();

        await s3.send(new PutObjectCommand({
            Bucket: bucketName,
            Key: fileName,
            ContentType: 'image/webp',
            Body: buffer,
        }));

        const finalUrl = process.env.R2_PUBLIC_DOMAIN 
            ? `https://${process.env.R2_PUBLIC_DOMAIN}/${fileName}` 
            : `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${bucketName}/${fileName}`;

        await prisma.user.update({
            where: { id: user.id },
            data: { image: finalUrl }
        });

        revalidatePath("/dashboard/settings");

        return { success: true, url: finalUrl };
    } catch (error: any) {
        console.error("Avatar Upload Error:", error);
        return { success: false, error: error.message || "Failed to upload avatar" };
    }
}
