"use server";

/**
 * SECURE PII VAULT — Server Actions
 * 
 * CRUD operations for encrypted PII fields (SSN, DOB, etc.)
 * 
 * SECURITY:
 * - All encryption/decryption happens server-side only
 * - Every operation is audit-logged
 * - Reveal (decrypt) requires ADMIN role
 * - Input (encrypt) requires CRM access (ADMIN, MANAGER, REP)
 * - Custom roles can also be granted "secure_fields:view" capability
 */

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { getEffectiveRole, hasCapability } from "@/lib/permissions";
import { canViewSecureFields, canEditSecureFields } from "@/lib/permissions-base";
import {
    encryptField,
    decryptField,
    generateMask,
    SECURE_FIELD_TYPES,
    type SecureFieldName,
} from "@/lib/field-encryption";
import { revalidatePath } from "next/cache";

// ============================================
// HELPERS
// ============================================

async function getAuthenticatedUser() {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({
        where: { email: session.user.email },
    });
    if (!user) throw new Error("User not found");

    return user;
}

// ============================================
// SAVE (CREATE / UPDATE) SECURE FIELD
// ============================================

/**
 * Encrypt and store a PII field value.
 * If the field already exists for this contact, it updates it.
 * 
 * Any CRM user (ADMIN, MANAGER, REP) can input/update.
 * The value is encrypted immediately — the user who inputs it
 * may NOT be able to view it afterwards (unless they're ADMIN).
 */
export async function saveSecureField(
    contactId: string,
    fieldName: SecureFieldName,
    plaintext: string
) {
    try {
        const user = await getAuthenticatedUser();
        const effectiveRole = await getEffectiveRole(user);

        // Permission check: can this role input secure data?
        if (!canEditSecureFields(effectiveRole)) {
            throw new Error("Forbidden: You do not have permission to edit secure fields");
        }

        // Validate field name
        if (!SECURE_FIELD_TYPES[fieldName]) {
            throw new Error(`Invalid secure field type: ${fieldName}`);
        }

        // Validate the contact exists and belongs to this workspace
        const workspaceId = (user as any).activeWorkspaceId;
        const contact = await prisma.contact.findFirst({
            where: { id: contactId, workspaceId },
        });
        if (!contact) {
            throw new Error("Contact not found or access denied");
        }

        // Encrypt the value with per-field HKDF-derived key
        const encryptedValue = encryptField(plaintext, contactId, fieldName);

        // Upsert: create or update
        const existing = await (prisma as any).secureField.findUnique({
            where: {
                contactId_fieldName: { contactId, fieldName },
            },
        });

        if (existing) {
            throw new Error("Write-once violation: Secure fields cannot be modified once saved.");
        }

        await (prisma as any).secureField.create({
            data: {
                contactId,
                fieldName,
                encryptedValue,
                createdById: user.id,
                updatedById: user.id,
            },
        });

        await createAuditLog({
            action: "SECURE_FIELD_CREATED",
            entityType: "SECURE_FIELD",
            entityId: contactId,
            details: `Added encrypted ${SECURE_FIELD_TYPES[fieldName].label} for contact: ${contact.firstName} ${contact.lastName}`,
        });

        revalidatePath("/dashboard/contacts");
        return { success: true };
    } catch (error: any) {
        console.error("[SECURE VAULT] Save failed:", error.message);
        return { success: false, error: error.message || "Failed to save secure field" };
    }
}

// ============================================
// REVEAL (DECRYPT) SECURE FIELD
// ============================================

/**
 * Decrypt and return a SINGLE secure field value.
 * 
 * ADMIN ONLY — this is the most sensitive operation in the system.
 * Every reveal is audit-logged with the user's identity.
 * 
 * Returns plaintext for ONE field only. No bulk reveal endpoint exists.
 */
export async function revealSecureField(
    contactId: string,
    fieldName: SecureFieldName
) {
    try {
        const user = await getAuthenticatedUser();
        const effectiveRole = await getEffectiveRole(user);

        // Permission check: ADMIN only, or custom role with secure_fields:view
        const hasCustomAccess = await hasCapability(user, "secure_fields:view");
        if (!canViewSecureFields(effectiveRole) && !hasCustomAccess) {
            throw new Error("Forbidden: Only authorized administrators can reveal secure fields");
        }

        // Fetch the encrypted record
        const secureField = await (prisma as any).secureField.findUnique({
            where: {
                contactId_fieldName: { contactId, fieldName },
            },
        });

        if (!secureField) {
            throw new Error("Secure field not found");
        }

        // Decrypt
        const plaintext = decryptField(secureField.encryptedValue, contactId, fieldName);

        // Get contact name for audit
        const contact = await prisma.contact.findUnique({
            where: { id: contactId },
            select: { firstName: true, lastName: true },
        });

        // AUDIT LOG: This is critical — every reveal is tracked
        await createAuditLog({
            action: "SECURE_FIELD_VIEWED",
            entityType: "SECURE_FIELD",
            entityId: contactId,
            details: `Revealed ${SECURE_FIELD_TYPES[fieldName]?.label || fieldName} for contact: ${contact?.firstName || "?"} ${contact?.lastName || "?"}`,
        });

        return { success: true, value: plaintext };
    } catch (error: any) {
        console.error("[SECURE VAULT] Reveal failed:", error.message);
        return { success: false, error: error.message || "Failed to reveal secure field" };
    }
}

// ============================================
// DELETE SECURE FIELD
// ============================================

/**
 * Remove an encrypted PII field.
 * ADMIN ONLY — permanent deletion of sensitive data.
 */
export async function deleteSecureField(
    contactId: string,
    fieldName: SecureFieldName
) {
    try {
        const user = await getAuthenticatedUser();
        const effectiveRole = await getEffectiveRole(user);

        if (effectiveRole !== "ADMIN") {
            throw new Error("Forbidden: Only administrators can delete secure fields");
        }

        const secureField = await (prisma as any).secureField.findUnique({
            where: {
                contactId_fieldName: { contactId, fieldName },
            },
        });

        if (!secureField) {
            throw new Error("Secure field not found");
        }

        await (prisma as any).secureField.delete({
            where: { id: secureField.id },
        });

        const contact = await prisma.contact.findUnique({
            where: { id: contactId },
            select: { firstName: true, lastName: true },
        });

        await createAuditLog({
            action: "SECURE_FIELD_DELETED",
            entityType: "SECURE_FIELD",
            entityId: contactId,
            details: `Deleted ${SECURE_FIELD_TYPES[fieldName]?.label || fieldName} for contact: ${contact?.firstName || "?"} ${contact?.lastName || "?"}`,
        });

        revalidatePath("/dashboard/contacts");
        return { success: true };
    } catch (error: any) {
        console.error("[SECURE VAULT] Delete failed:", error.message);
        return { success: false, error: error.message || "Failed to delete secure field" };
    }
}

// ============================================
// GET MASKED FIELDS (Safe for all CRM users)
// ============================================

/**
 * Returns all secure fields for a contact with MASKS only.
 * No decryption occurs. Safe for display to any CRM user.
 * 
 * Returns: [{ fieldName: "SSN", maskedValue: "•••-••-••••", hasValue: true }, ...]
 */
export async function getSecureFieldMasks(contactId: string) {
    try {
        const user = await getAuthenticatedUser();
        const effectiveRole = await getEffectiveRole(user);

        if (!canEditSecureFields(effectiveRole)) {
            return { success: true, fields: [] };
        }

        const secureFields = await (prisma as any).secureField.findMany({
            where: { contactId },
            select: { fieldName: true, updatedAt: true },
        });

        // Build response with masks — never send encryptedValue to client
        const fields = Object.keys(SECURE_FIELD_TYPES).map((fieldName) => {
            const existing = secureFields.find((f: any) => f.fieldName === fieldName);
            return {
                fieldName,
                label: SECURE_FIELD_TYPES[fieldName as SecureFieldName].label,
                maskedValue: existing ? generateMask(fieldName) : null,
                hasValue: !!existing,
                updatedAt: existing?.updatedAt || null,
            };
        });

        return { success: true, fields };
    } catch (error: any) {
        return { success: false, fields: [], error: error.message };
    }
}

// ============================================
// BULK SAVE (for Create/Edit Contact dialogs)
// ============================================

/**
 * Save multiple secure fields at once (used by the contact form).
 * Each field is encrypted individually with its own derived key.
 */
export async function saveSecureFieldsBulk(
    contactId: string,
    fields: { fieldName: SecureFieldName; value: string }[]
) {
    try {
        const user = await getAuthenticatedUser();
        const effectiveRole = await getEffectiveRole(user);

        if (!canEditSecureFields(effectiveRole)) {
            throw new Error("Forbidden: You do not have permission to edit secure fields");
        }

        const contact = await prisma.contact.findFirst({
            where: { id: contactId, workspaceId: (user as any).activeWorkspaceId },
        });
        if (!contact) throw new Error("Contact not found");

        const results = [];
        for (const field of fields) {
            if (!field.value || field.value.trim() === "") continue;
            if (!SECURE_FIELD_TYPES[field.fieldName]) continue;

            const encryptedValue = encryptField(field.value, contactId, field.fieldName);

            // Enforce write-once: skip if it already exists
            const existing = await (prisma as any).secureField.findUnique({
                where: { contactId_fieldName: { contactId, fieldName: field.fieldName } }
            });

            if (existing) continue;

            await (prisma as any).secureField.create({
                data: {
                    contactId,
                    fieldName: field.fieldName,
                    encryptedValue,
                    createdById: user.id,
                    updatedById: user.id,
                }
            });

            results.push(field.fieldName);
        }

        if (results.length > 0) {
            await createAuditLog({
                action: "SECURE_FIELDS_BULK_SAVED",
                entityType: "SECURE_FIELD",
                entityId: contactId,
                details: `Encrypted ${results.length} secure field(s) for contact: ${contact.firstName} ${contact.lastName} [${results.join(", ")}]`,
            });
        }

        revalidatePath("/dashboard/contacts");
        return { success: true, savedFields: results };
    } catch (error: any) {
        console.error("[SECURE VAULT] Bulk save failed:", error.message);
        return { success: false, error: error.message || "Failed to save secure fields" };
    }
}
