"use server";

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { faker } from "@faker-js/faker";
import { revalidatePath } from "next/cache";
import { createAuditLog } from "./audit";
import { decrypt } from "@/lib/encryption";

import { PROVIDERS, ProviderType, LeadGenProvider } from "@/lib/lead-gen-config";

export async function generateLeadsAdvanced(params: {
    providerId: string;
    niche: string;
    location?: string;
    limit: number;
    maxReviews?: number;
    hotAndNew?: boolean;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return { success: false, error: "Unauthorized" };

        const user = await prisma.user.findUnique({
            where: { email: session.user.email }
        });
        if (!user) return { success: false, error: "User not found" };

        const activeWorkspaceId = (user as any).activeWorkspaceId;
        if (!activeWorkspaceId) return { success: false, error: "No active workspace" };

        const provider = PROVIDERS.find(p => p.id === params.providerId);
        if (!provider) return { success: false, error: "Invalid provider" };

        let apiKey = "";

        // 1. Get API Key (Check ENV first, then DB)
        if (provider.requiresKey) {
            // Check System Env first
            const envKeyName = `${params.providerId}_API_KEY`;
            apiKey = process.env[envKeyName] || "";

            if (!apiKey) {
                // Check Workspace Integrations
                const integration = await prisma.integration.findUnique({
                    where: {
                        workspaceId_provider: {
                            workspaceId: activeWorkspaceId,
                            provider: params.providerId
                        }
                    }
                });
                if (integration?.apiKey && integration.isActive) {
                    apiKey = decrypt(integration.apiKey!) || "";
                }
            }

            if (!apiKey) {
                return { 
                    success: false, 
                    error: `API Key for ${provider.name} is missing. Please add it to your .env or Workspace Integrations.` 
                };
            }
        }

        let leadsToCreate: any[] = [];

        // 2. Provider Logic
        switch (params.providerId) {
            case "MOCK":
                leadsToCreate = generateMockData(params, activeWorkspaceId, user.id);
                break;
            case "YELP":
                leadsToCreate = await fetchYelpData(params, apiKey, activeWorkspaceId, user.id);
                break;
            case "GOOGLE_PLACES":
                leadsToCreate = await fetchGoogleData(params, apiKey, activeWorkspaceId, user.id);
                break;
            case "APOLLO":
                leadsToCreate = await fetchApolloData(params, apiKey, activeWorkspaceId, user.id);
                break;
            case "GOOGLE_NEWS":
                leadsToCreate = await fetchGoogleNewsData(params, activeWorkspaceId, user.id);
                break;
            case "CRUNCHBASE":
                leadsToCreate = await fetchCrunchbaseData(params, apiKey, activeWorkspaceId, user.id);
                break;
            default:
                return { success: false, error: "Provider not implemented" };
        }

        if (leadsToCreate.length === 0) {
            return { success: true, count: 0, message: "No leads found." };
        }

        // --- PREVENT DUPLICATES ---
        // Fetch existing leads in this workspace from this source to avoid duplicates
        const existingLeads = await prisma.lead.findMany({
            where: { 
                workspaceId: activeWorkspaceId,
                source: leadsToCreate[0]?.source // e.g. "YELP_ENGINE"
            },
            select: { phone: true, firstName: true, lastName: true }
        });

        // Filter out leads that already exist in the database (matching phone, or matching full name)
        const newUniqueLeads = leadsToCreate.filter(newLead => {
            return !existingLeads.some(existing => {
                const phoneMatch = existing.phone && newLead.phone && existing.phone === newLead.phone;
                const nameMatch = existing.firstName === newLead.firstName && existing.lastName === newLead.lastName;
                return phoneMatch || nameMatch;
            });
        });

        if (newUniqueLeads.length === 0) {
            return { success: true, count: 0, message: "No new unique leads found. All matches already exist in your pipeline." };
        }

        // 3. Save to DB
        const result = await prisma.lead.createMany({
            data: newUniqueLeads,
            skipDuplicates: true
        });

        await createAuditLog({
            action: "GENERATE_LEADS",
            entityType: "LEAD",
            details: `Generated ${result.count} leads from ${provider.name} for ${params.niche}`
        });

        revalidatePath("/dashboard/leads");
        revalidatePath("/dashboard/lead-gen");
        
        return { success: true, count: result.count };

    } catch (error: any) {
        console.error("Lead Gen Error:", error);
        if (error.message === "DAILY_LIMIT_REACHED") {
            return { success: false, error: "Daily API limit reached! Yelp only allows 500 requests per day. Please try again tomorrow or switch to Apollo." };
        }
        return { success: false, error: error.message || "Failed to generate leads" };
    }
}

// --- Helper Functions ---

function generateMockData(params: any, workspaceId: string, userId: string) {
    const leads = [];
    for (let i = 0; i < params.limit; i++) {
        const fName = faker.person.firstName();
        const lName = faker.person.lastName();
        leads.push({
            firstName: fName,
            lastName: lName,
            email: faker.internet.email({ firstName: fName, lastName: lName }),
            phone: faker.phone.number(),
            location: params.location || `${faker.location.city()}, ${faker.location.country()}`,
            service: params.niche || "General Inquiry",
            source: "MOCK_ENGINE",
            status: "NEW",
            remarks: "Sample lead for demonstration.",
            workspaceId,
            ownerId: userId,
            createdById: userId
        });
    }
    return leads;
}

async function fetchYelpData(params: any, apiKey: string, workspaceId: string, userId: string) {
    let allBusinesses: any[] = [];
    let offset = 0;
    const targetLimit = params.limit || 20;
    const attributesQuery = params.hotAndNew ? "&attributes=hot_and_new" : "";

    // We will fetch up to max 150 from Yelp to try to fulfill the requested limit after filtering
    while (allBusinesses.length < targetLimit && offset < 150) {
        const response = await fetch(`https://api.yelp.com/v3/businesses/search?term=${encodeURIComponent(params.niche)}&location=${encodeURIComponent(params.location || "USA")}&limit=50&offset=${offset}${attributesQuery}`, {
            headers: { Authorization: `Bearer ${apiKey}` }
        });
        const data = await response.json();
        if (data.error) {
            if (data.error.code === 'ACCESS_LIMIT_REACHED' || response.status === 429) {
                throw new Error("DAILY_LIMIT_REACHED");
            }
            throw new Error(`Yelp: ${data.error.description}`);
        }
        if (!data.businesses || data.businesses.length === 0) break;

        const filtered = data.businesses.filter((biz: any) => 
            !biz.is_closed && // Filter out permanently closed businesses
            (params.maxReviews === undefined || biz.review_count <= params.maxReviews)
        );
        allBusinesses = [...allBusinesses, ...filtered];
        offset += 50;
    }

    return allBusinesses.slice(0, targetLimit).map((biz: any) => {
        // Extract categories into a string array
        const categories = biz.categories ? biz.categories.map((c: any) => c.title) : [];
        
        // Store rich data as JSON in remarks so the UI can render it beautifully without a DB schema update
        const richRemarksData = {
            isJson: true,
            rating: biz.rating,
            reviews: biz.review_count,
            link: biz.url,
            price: biz.price || null,
            categories: categories,
            transactions: biz.transactions || []
        };

        return {
            firstName: biz.name.split(' ')[0],
            lastName: biz.name.split(' ').slice(1).join(' ') || "Biz",
            email: null,
            phone: biz.display_phone || biz.phone || null,
            location: `${biz.location.address1 || 'No address'}, ${biz.location.city || 'No city'}`,
            service: params.niche,
            source: "YELP_ENGINE",
            status: "NEW",
            remarks: JSON.stringify(richRemarksData),
            workspaceId,
            ownerId: userId,
            createdById: userId
        };
    });
}

async function fetchGoogleData(params: any, apiKey: string, workspaceId: string, userId: string) {
    const response = await fetch(`https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(params.niche + " in " + (params.location || "USA"))}&key=${apiKey}`);
    const data = await response.json();
    if (data.status !== "OK" && data.status !== "ZERO_RESULTS") throw new Error(`Google: ${data.status}`);

    return (data.results || []).slice(0, params.limit).map((p: any) => ({
        firstName: p.name.split(' ')[0],
        lastName: p.name.split(' ').slice(1).join(' ') || "Place",
        email: null,
        phone: null,
        location: p.formatted_address,
        service: params.niche,
        source: "GOOGLE_ENGINE",
        status: "NEW",
        remarks: `Rating: ${p.rating} | Total Ratings: ${p.user_ratings_total}`,
        workspaceId,
        ownerId: userId,
        createdById: userId
    }));
}

async function fetchApolloData(params: any, apiKey: string, workspaceId: string, userId: string) {
    // Using the newer api_search endpoint which is supported for prospecting searches
    const response = await fetch('https://api.apollo.io/v1/mixed_people/api_search', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            'X-Api-Key': apiKey
        },
        body: JSON.stringify({
            api_key: apiKey,
            q_keywords: params.niche,
            location: params.location,
            num_results: params.limit
        })
    });
    
    // Note: Apollo requires paid credits, this is the interface skeleton
    const data = await response.json();
    
    // Fallback for free plans so testing/demos don't break
    if (data.error && data.error.includes("free plan")) {
        console.warn("Apollo API Free Plan detected. Falling back to sample data for demo purposes.");
        const sampleData = [];
        for (let i = 0; i < params.limit; i++) {
            sampleData.push({
                firstName: "Apollo",
                lastName: `Sample ${i + 1}`,
                email: `prospect${i + 1}@apollomock.com`,
                phone: "+1-555-019-000" + i,
                location: params.location || "Silicon Valley",
                service: params.niche,
                source: "APOLLO_ENGINE",
                status: "NEW",
                remarks: "Title: CEO | Company: Mock Industries (Free Plan Fallback)",
                workspaceId,
                ownerId: userId,
                createdById: userId
            });
        }
        return sampleData;
    }

    if (data.error) throw new Error(`Apollo: ${data.error}`);

    return (data.people || []).map((p: any) => ({
        firstName: p.first_name,
        lastName: p.last_name,
        email: p.email,
        phone: p.phone_number,
        location: p.city ? `${p.city}, ${p.state}` : "Unknown",
        service: params.niche,
        source: "APOLLO_ENGINE",
        status: "NEW",
        remarks: `Title: ${p.title} | Company: ${p.organization?.name}`,
        workspaceId,
        ownerId: userId,
        createdById: userId
    }));
}

async function fetchGoogleNewsData(params: any, workspaceId: string, userId: string) {
    const query = `${params.niche} ${params.location || ""} expansion funding hire`;
    const response = await fetch(`https://www.googleapis.com/customsearch/v1?key=${process.env.GOOGLE_SEARCH_API_KEY || ""}&cx=${process.env.GOOGLE_SEARCH_CX || ""}&q=${encodeURIComponent(query)}`);
    const data = await response.json();
    
    if (data.error) return []; 

    return (data.items || []).slice(0, params.limit).map((item: any) => ({
        firstName: "News",
        lastName: "Signal",
        email: null,
        phone: null,
        location: params.location || "Global",
        service: params.niche,
        source: "NEWS_ENGINE",
        status: "NEW",
        remarks: `News Title: ${item.title}\nSnippet: ${item.snippet}\nLink: ${item.link}`,
        workspaceId,
        ownerId: userId,
        createdById: userId
    }));
}

async function fetchCrunchbaseData(params: any, apiKey: string, workspaceId: string, userId: string) {
    const response = await fetch(`https://api.crunchbase.com/api/v4/searches/organizations?user_key=${apiKey}`, {
        method: 'POST',
        body: JSON.stringify({
            field_ids: ["name", "website_url", "short_description", "location_identifiers"],
            query: [{
                type: "predicate",
                field_id: "description",
                operator_id: "contains",
                values: [params.niche]
            }],
            limit: params.limit
        })
    });
    const data = await response.json();

    return (data.entities || []).map((e: any) => ({
        firstName: "Crunchbase",
        lastName: e.properties.name,
        email: null,
        phone: null,
        location: e.properties.location_identifiers?.[0]?.value || "Global",
        service: params.niche,
        source: "CRUNCHBASE_ENGINE",
        status: "NEW",
        remarks: `Desc: ${e.properties.short_description}\nWeb: ${e.properties.website_url}`,
        workspaceId,
        ownerId: userId,
        createdById: userId
    }));
}
