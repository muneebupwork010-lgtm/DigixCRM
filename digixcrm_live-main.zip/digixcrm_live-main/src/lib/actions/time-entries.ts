"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getVerifiedRecord, getEffectiveRole } from "@/lib/permissions";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";

const timeEntrySchema = z.object({
  hours: z.coerce.number().min(0.1),
  description: z.string().optional(),
  date: z.coerce.date().optional(),
  taskId: z.string()
});

export async function getTaskTimeEntries(taskId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");
    
        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");
    
        const entries = await prisma.timeEntry.findMany({
            where: { taskId },
            include: {
                user: { select: { id: true, name: true, image: true } }
            },
            orderBy: { date: "desc" },
        });
    
        return entries;
    } catch (error) {
        console.error("Failed to fetch time entries:", error);
        return [];
    }
}

export async function createTimeEntry(rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");
    
        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");
    
        const data = timeEntrySchema.parse(rawData);
        
        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const task = await getVerifiedRecord(prisma.task, data.taskId, user.id, effectiveRole, workspaceId);
        if (!task) throw new Error("Task access denied");
    
        const newEntry = await prisma.timeEntry.create({
            data: {
                hours: data.hours,
                description: data.description,
                date: data.date || new Date(),
                taskId: data.taskId,
                userId: user.id
            } as any,
        });

        // Update task actualHours
        const totalHoursResult = await prisma.timeEntry.aggregate({
            where: { taskId: data.taskId },
            _sum: { hours: true }
        });
        
        await prisma.task.update({
            where: { id: data.taskId },
            data: { actualHours: totalHoursResult._sum.hours || 0 }
        });
    
        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${task.projectId}`);
    
        return { success: true, data: newEntry };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to create time entry" };
    }
}

export async function deleteTimeEntry(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const timeEntry = await prisma.timeEntry.findUnique({ where: { id } });
        if (!timeEntry) throw new Error("Time entry not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const task = await getVerifiedRecord(prisma.task, timeEntry.taskId, user.id, effectiveRole, workspaceId);
        if (!task) throw new Error("Task access denied");

        if (timeEntry.userId !== user.id && effectiveRole !== "ADMIN" && effectiveRole !== "MANAGER" && effectiveRole !== "PROJECT_MANAGER") {
            throw new Error("You can only delete your own time entries");
        }

        await prisma.timeEntry.delete({ where: { id } });

        // Update task actualHours
        const totalHoursResult = await prisma.timeEntry.aggregate({
            where: { taskId: timeEntry.taskId },
            _sum: { hours: true }
        });
        
        await prisma.task.update({
            where: { id: timeEntry.taskId },
            data: { actualHours: totalHoursResult._sum.hours || 0 }
        });

        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${task.projectId}`);

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete time entry" };
    }
}
