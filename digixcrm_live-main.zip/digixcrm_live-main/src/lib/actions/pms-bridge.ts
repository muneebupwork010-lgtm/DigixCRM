"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";

const convertDealSchema = z.object({
    dealId: z.string().min(1, "Deal ID is required"),
    options: z.object({
        ownerId: z.string().optional()
    }).default({})
});

export async function convertDealToProject(rawDealId: string, rawOptions: { ownerId?: string } = {}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        // 1. Zod Validation for strict type safety
        const { dealId, options } = convertDealSchema.parse({ dealId: rawDealId, options: rawOptions });

        // 2. Prisma Transaction for absolute Data Integrity
        const newProject = await prisma.$transaction(async (tx) => {
            
            // A. Fetch the Deal with ALL communication activities
            const deal = await tx.deal.findUnique({
                where: { id: dealId },
                include: { 
                    organization: true,
                    activities: {
                        where: { 
                            type: { in: ["NOTE", "CALL", "EMAIL"] } 
                        },
                        orderBy: { createdAt: "asc" }
                    }
                }
            });

            if (!deal) throw new Error("Deal not found");

            const workspaceId = deal.workspaceId;
            if (!workspaceId) throw new Error("Workspace not found for this deal");

            // B. Check if a project already exists for this deal
            const existingProject = await tx.project.findFirst({
                where: { dealId: deal.id }
            });

            if (existingProject) {
                throw new Error(`A project already exists for this deal: ${existingProject.name}`);
            }

            // C. Create the Project
            const proj = await tx.project.create({
                data: {
                    name: deal.title,
                    description: `Project initialized from Sales Deal: ${deal.title}.\nOriginal value: $${deal.value.toLocaleString()}`,
                    budget: deal.value,
                    status: "PLANNING",
                    priority: "MEDIUM",
                    dealId: deal.id,
                    organizationId: deal.organizationId,
                    ownerId: options.ownerId || deal.ownerId || user.id,
                    createdById: user.id,
                    workspaceId: workspaceId,
                } as any
            });

            // D. Duplicate relevant activities as project history
            if (deal.activities.length > 0) {
                await tx.activity.createMany({
                    data: deal.activities.map(activity => ({
                        type: activity.type,
                        notes: `[Sales History] ${activity.notes}`,
                        projectId: proj.id,
                        userId: activity.userId,
                        workspaceId: workspaceId,
                        createdAt: activity.createdAt 
                    }))
                });
            }

            // Add specialized kickoff note
            await tx.activity.create({
                data: {
                    type: "NOTE",
                    notes: `🚀 Project officially launched from Deal conversion. Full pre-sales history (${deal.activities.length} entries) has been successfully migrated.`,
                    projectId: proj.id,
                    userId: user.id,
                    workspaceId: workspaceId
                }
            });

            // E. AUTO-GENERATED: Initial Kickoff Task
            const pmId = options.ownerId || deal.ownerId || user.id;
            await tx.task.create({
                data: {
                    title: "🚀 Project Kickoff & Client Onboarding",
                    description: `Project initialized from Sales Deal: ${deal.title}.\n\nNext Steps:\n1. Review imported [Sales History] in the activity feed.\n2. Schedule introductory kickoff call with client.\n3. Define initial milestones and deliverables.`,
                    status: "TODO",
                    priority: "HIGH",
                    projectId: proj.id,
                    assigneeId: pmId,
                    createdById: user.id,
                    workspaceId: workspaceId,
                    order: 0
                } as any
            });

            // F. Update Deal status to reflect conversion
            await tx.deal.update({
                where: { id: dealId },
                data: { customStage: "ONBOARDED" }
            });

            return proj;
        });

        // 3. Post-transaction Operations
        await createAuditLog({
            action: "CONVERT",
            entityType: "DEAL",
            entityId: dealId,
            details: `Converted deal to project: ${newProject.name} (Project ID: ${newProject.id})`
        });

        await touchWorkspace(newProject.workspaceId!);
        revalidatePath("/dashboard/deals");
        revalidatePath("/dashboard/projects");

        return { success: true, data: newProject };
    } catch (error: any) {
        console.error("Deal Conversion Error:", error);
        return { success: false, error: error.message || "Failed to convert deal to project" };
    }
}
