"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { createNotification } from "./notifications";
import { getVerifiedRecord, getEffectiveRole } from "@/lib/permissions";
import { touchWorkspace } from "./workspaces";
import { z } from "zod";
import { ProjectStatus, Priority, ProjectType } from "@/generated/prisma/client";

const emptyToNull = (val: any) => val === "" ? null : val;

const projectSchema = z.object({
  name: z.string().min(1, "Project name is required"),
  description: z.string().optional(),
  status: z.nativeEnum(ProjectStatus).optional(),
  priority: z.nativeEnum(Priority).optional(),
  startDate: z.coerce.date().optional().nullable(),
  endDate: z.coerce.date().optional().nullable(),
  budget: z.coerce.number().min(0).optional(),
  ownerId: z.preprocess(emptyToNull, z.string().optional().nullable()),
  organizationId: z.preprocess(emptyToNull, z.string().optional().nullable()),
  memberIds: z.array(z.string()).optional(),
  type: z.nativeEnum(ProjectType).optional(),
});

export async function getProjects() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const effectiveRole = await getEffectiveRole(user);
    const workspaceId = (user as any).activeWorkspaceId;

    if (!workspaceId) return [];

    const projects = await prisma.project.findMany({
      where: {
        workspaceId,
        ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
          OR: [
            { ownerId: user.id },
            { members: { some: { userId: user.id } } }
          ]
        } : {})
      },
      include: {
        owner: { select: { id: true, name: true, image: true } },
        organization: { select: { id: true, name: true } },
        _count: { 
          select: { 
            tasks: true,
          } 
        },
        tasks: {
          where: { status: "DONE" },
          select: { id: true }
        }
      },
      orderBy: { updatedAt: "desc" },
    });

    return projects;
  } catch (error) {
    console.error("Failed to fetch projects:", error);
    return [];
  }
}

export async function createProject(rawData: any) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const data = projectSchema.parse(rawData);
    const workspaceId = (user as any).activeWorkspaceId;

    if (!workspaceId) throw new Error("No active workspace found");

    const effectiveRole = await getEffectiveRole(user);
    // Block CLIENT from creating projects
    if (effectiveRole === "CLIENT") {
        throw new Error("Clients cannot create projects. Please contact your project manager.");
    }

    // --- ENFORCE SUBSCRIPTION LIMITS ---
    const { checkWorkspaceCapacity } = await import("@/lib/billing");
    const capacity = await checkWorkspaceCapacity(workspaceId);
    if (capacity.isOverCapacity) {
      throw new Error(`SUBSCRIPTION_LIMIT: ${capacity.reason}`);
    }

    // Find admins and project managers in the workspace to auto-add them
    const elevatedMembers = await prisma.workspaceMember.findMany({
        where: {
            workspaceId,
            OR: [
                { role: "ADMIN" },
                { role: "PROJECT_MANAGER" },
                { user: { role: "ADMIN" } },
                { user: { role: "MANAGER" } }
            ]
        },
        select: { userId: true }
    });

    const projectOwnerId = data.ownerId || user.id;
    const defaultMemberIds = new Set<string>();
    defaultMemberIds.add(user.id); // The creator
    defaultMemberIds.add(projectOwnerId); // The assigned PM
    
    elevatedMembers.forEach(m => defaultMemberIds.add(m.userId));
    if (data.memberIds) {
        data.memberIds.forEach(id => defaultMemberIds.add(id));
    }

    const membersData = Array.from(defaultMemberIds).map(userId => ({
        userId,
        role: userId === projectOwnerId ? "MANAGER" : "MEMBER"
    }));

    const newProject = await prisma.project.create({
      data: {
        name: data.name,
        description: data.description,
        status: data.status || "PLANNING",
        priority: data.priority || "MEDIUM",
        type: data.type || "EXTERNAL",
        startDate: data.startDate,
        endDate: data.endDate,
        budget: data.budget || 0,
        ownerId: projectOwnerId,
        createdById: user.id,
        workspaceId,
        organizationId: data.organizationId,
        members: {
            create: membersData
        }
      } as any,
    });

    await createAuditLog({
      action: "CREATE",
      entityType: "PROJECT",
      entityId: newProject.id,
      details: `Created project: ${newProject.name}`,
    });

    // Notify project owner
    if (newProject.ownerId && newProject.ownerId !== user.id) {
        await createNotification({
            userId: newProject.ownerId,
            title: "New Project Assigned",
            message: `You have been assigned as PM for: ${newProject.name}`,
            type: "PROJECT_ASSIGNED",
            link: `/dashboard/projects/${newProject.id}`,
            workspaceId
        });
    }

    // Trigger Workflows
    import("@/lib/workflow-engine").then((m) => {
      m.executeWorkflows("PROJECT_CREATED", workspaceId, newProject).catch(console.error);
    });

    await touchWorkspace(workspaceId);
    revalidatePath("/dashboard/projects");

    return { success: true, data: newProject };
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to create project" };
  }
}

export async function getProjectById(id: string) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) throw new Error("User not found");

    const effectiveRole = await getEffectiveRole(user);
    const workspaceId = (user as any).activeWorkspaceId;

    const project = await prisma.project.findFirst({
      where: {
        id,
        workspaceId,
        ...(["REP", "STAFF", "CLIENT"].includes(effectiveRole) ? {
          OR: [
            { ownerId: user.id },
            { members: { some: { userId: user.id } } }
          ]
        } : {})
      },
      include: {
        owner: { select: { id: true, name: true, image: true, email: true } },
        organization: { select: { id: true, name: true } },
        members: { include: { user: { select: { id: true, name: true, image: true } } } },
        milestones: { orderBy: { order: "asc" } },
      },
    });

    return project;
  } catch (error) {
    console.error("Failed to fetch project detail:", error);
    return null;
  }
}

export async function updateProject(id: string, rawData: any) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const record = await getVerifiedRecord(prisma.project, id, user.id, effectiveRole, workspaceId);
        if (!record) throw new Error("Project not found or access denied");

        // Block CLIENT from editing projects
        if (effectiveRole === "CLIENT") {
            throw new Error("Clients cannot modify project settings.");
        }

        const data = projectSchema.partial().parse(rawData);

        const updated = await prisma.project.update({
            where: { id },
            data: data as any
        });

        await createAuditLog({
            action: "UPDATE",
            entityType: "PROJECT",
            entityId: id,
            details: `Updated project: ${updated.name}`
        });

        await touchWorkspace(record.workspaceId);
        revalidatePath("/dashboard/projects");
        revalidatePath(`/dashboard/projects/${id}`);

        return { success: true, data: updated };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to update project" };
    }
}

export async function deleteProject(id: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const record = await getVerifiedRecord(prisma.project, id, user.id, effectiveRole, workspaceId);
        if (!record) throw new Error("Project not found or access denied");

        // Block CLIENT from deleting projects
        if (effectiveRole === "CLIENT") {
            throw new Error("Clients cannot delete projects.");
        }

        await prisma.project.delete({ where: { id } });

        await createAuditLog({
            action: "DELETE",
            entityType: "PROJECT",
            entityId: id,
            details: `Deleted project: ${record.name}`
        });

        await touchWorkspace(record.workspaceId);
        revalidatePath("/dashboard/projects");

        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to delete project" };
    }
}

export async function addProjectMember(projectId: string, userId: string, role: string = "MEMBER") {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const record = await getVerifiedRecord(prisma.project, projectId, user.id, effectiveRole, workspaceId);
        if (!record) throw new Error("Project not found or access denied");

        const membership = await prisma.projectMember.create({
            data: {
                projectId,
                userId,
                role: role as any
            },
            include: { user: { select: { name: true } } }
        });

        await createAuditLog({
            action: "MEMBER_ADD",
            entityType: "PROJECT",
            entityId: projectId,
            details: `Added member ${membership.user.name} to project`
        });

        // Notify member
        if (membership.userId !== user.id) {
            await createNotification({
                userId: membership.userId,
                title: "Added to Project",
                message: `You have been added to the project: ${record.name}`,
                type: "PROJECT_MEMBER_ADDED",
                link: `/dashboard/projects/${projectId}`,
                workspaceId
            });
        }

        revalidatePath(`/dashboard/projects/${projectId}`);
        return { success: true, data: membership };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to add project member" };
    }
}

export async function removeProjectMember(projectId: string, userId: string) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;
        const record = await getVerifiedRecord(prisma.project, projectId, user.id, effectiveRole, workspaceId);
        if (!record) throw new Error("Project not found or access denied");

        // Prevent removing the owner if needed, but for now we trust the UI/Manager
        await prisma.projectMember.delete({
            where: {
                projectId_userId: { projectId, userId }
            }
        });

        revalidatePath(`/dashboard/projects/${projectId}`);
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || "Failed to remove member" };
    }
}

export async function getProjectMembers(projectId: string) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as any)?.id;
    if (!userId) throw new Error("Unauthorized");

    const project = await prisma.project.findUnique({
      where: { id: projectId },
      select: {
        owner: { select: { id: true, name: true, email: true, image: true } },
        members: {
          select: {
            user: { select: { id: true, name: true, email: true, image: true } }
          }
        }
      }
    });

    if (!project) return [];

    const memberUsers = project.members.map(m => m.user);
    if (project.owner) {
      memberUsers.unshift(project.owner);
    }

    // Filter unique members by ID
    const uniqueMembers = Array.from(new Map(memberUsers.map(u => [u.id, u])).values());

    return uniqueMembers;
  } catch (error) {
    console.error("GET_PROJECT_MEMBERS_ERROR", error);
    return [];
  }
}
