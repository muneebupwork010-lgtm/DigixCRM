"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { createAuditLog } from "./audit";
import { getVerifiedRecord, getEffectiveRole } from "@/lib/permissions";
import { touchWorkspace } from "./workspaces";
import { TaskStatus, Priority } from "@/generated/prisma/client";

interface ImportedTask {
    title: string;
    description?: string;
    priority: string;
    status: string;
    milestone?: string;
    dueDate?: string;
    estimatedHours?: number;
    tags?: string[];
}

const VALID_PRIORITIES = ["LOW", "MEDIUM", "HIGH", "URGENT"];
const VALID_STATUSES = ["TODO", "IN_PROGRESS", "IN_REVIEW", "BLOCKED", "DONE"];

export async function bulkImportTasks(
    projectId: string,
    tasks: ImportedTask[]
) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) throw new Error("Unauthorized");

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) throw new Error("User not found");

        const effectiveRole = await getEffectiveRole(user);
        const workspaceId = (user as any).activeWorkspaceId;

        // Verify project access
        const project = await getVerifiedRecord(prisma.project, projectId, user.id, effectiveRole, workspaceId);
        if (!project) throw new Error("Project access denied");

        // Check subscription capacity
        const { checkWorkspaceCapacity } = await import("@/lib/billing");
        const capacity = await checkWorkspaceCapacity(workspaceId);
        if (capacity.isOverCapacity) {
            throw new Error(`SUBSCRIPTION_LIMIT: ${capacity.reason}`);
        }

        if (!tasks.length) throw new Error("No tasks to import");
        if (tasks.length > 200) throw new Error("Maximum 200 tasks per import");

        // 1. Collect unique milestone names
        const milestoneNames = [...new Set(
            tasks.map(t => t.milestone?.trim()).filter(Boolean)
        )] as string[];

        // 2. Fetch existing milestones for this project
        const existingMilestones = await prisma.milestone.findMany({
            where: { projectId },
            select: { id: true, title: true }
        });

        const milestoneMap: Record<string, string> = {};
        existingMilestones.forEach(m => {
            milestoneMap[m.title.toLowerCase()] = m.id;
        });

        // 3. Create missing milestones
        let milestonesCreated = 0;
        const lastMilestone = await prisma.milestone.findFirst({
            where: { projectId },
            orderBy: { order: "desc" }
        });
        let milestoneOrder = (lastMilestone?.order ?? -1) + 1;

        for (const name of milestoneNames) {
            if (!milestoneMap[name.toLowerCase()]) {
                const newMilestone = await prisma.milestone.create({
                    data: {
                        title: name,
                        status: "PENDING",
                        projectId,
                        order: milestoneOrder++
                    } as any
                });
                milestoneMap[name.toLowerCase()] = newMilestone.id;
                milestonesCreated++;
            }
        }

        // 4. Get the current max task order
        const lastTask = await prisma.task.findFirst({
            where: { projectId },
            orderBy: { order: "desc" }
        });
        let taskOrder = (lastTask?.order ?? -1) + 1;

        // 5. Batch-create tasks
        let tasksCreated = 0;

        for (const task of tasks) {
            if (!task.title?.trim()) continue; // Skip empty rows

            const priority = VALID_PRIORITIES.includes(task.priority?.toUpperCase())
                ? task.priority.toUpperCase() as Priority
                : "MEDIUM" as Priority;

            const status = VALID_STATUSES.includes(task.status?.toUpperCase())
                ? task.status.toUpperCase() as TaskStatus
                : "TODO" as TaskStatus;

            let dueDate: Date | null = null;
            if (task.dueDate) {
                const parsed = new Date(task.dueDate);
                if (!isNaN(parsed.getTime())) {
                    dueDate = parsed;
                }
            }

            const milestoneId = task.milestone?.trim()
                ? milestoneMap[task.milestone.trim().toLowerCase()] || null
                : null;

            await prisma.task.create({
                data: {
                    title: task.title.trim(),
                    description: task.description?.trim() || null,
                    priority,
                    status,
                    dueDate,
                    estimatedHours: task.estimatedHours || 0,
                    milestoneId,
                    projectId,
                    createdById: user.id,
                    workspaceId,
                    order: taskOrder++,
                    tags: task.tags || [],
                } as any
            });

            tasksCreated++;
        }

        // 6. Audit log
        await createAuditLog({
            action: "CREATE",
            entityType: "TASK",
            entityId: projectId,
            details: `Bulk imported ${tasksCreated} tasks and ${milestonesCreated} milestones into project "${project.name}"`
        });

        await touchWorkspace(workspaceId);
        revalidatePath(`/dashboard/projects/${projectId}`);

        return {
            success: true,
            tasksCreated,
            milestonesCreated
        };
    } catch (error: any) {
        console.error("Bulk import failed:", error);
        return { success: false, error: error.message || "Failed to import tasks" };
    }
}
