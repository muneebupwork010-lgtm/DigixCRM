import { addMinutes } from "date-fns";

// Zoom Server-to-Server OAuth credentials
const ZOOM_ACCOUNT_ID = process.env.ZOOM_ACCOUNT_ID;
const ZOOM_CLIENT_ID = process.env.ZOOM_CLIENT_ID;
const ZOOM_CLIENT_SECRET = process.env.ZOOM_CLIENT_SECRET;

let zoomAccessToken: string | null = null;
let tokenExpiresAt: number = 0;

async function getZoomAccessToken() {
    if (zoomAccessToken && Date.now() < tokenExpiresAt) {
        return zoomAccessToken;
    }

    if (!ZOOM_ACCOUNT_ID || !ZOOM_CLIENT_ID || !ZOOM_CLIENT_SECRET) {
        console.warn("Zoom credentials missing. Skipping meeting creation.");
        return null;
    }

    try {
        const tokenUrl = `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${ZOOM_ACCOUNT_ID}`;
        const basicAuth = Buffer.from(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`).toString("base64");

        const response = await fetch(tokenUrl, {
            method: "POST",
            headers: {
                "Authorization": `Basic ${basicAuth}`,
                "Content-Type": "application/x-www-form-urlencoded",
            },
        });

        const data = await response.json();

        if (data.access_token) {
            zoomAccessToken = data.access_token;
            // Token usually expires in 3599 seconds. Buffer by 5 minutes (300s)
            tokenExpiresAt = Date.now() + (data.expires_in - 300) * 1000;
            return zoomAccessToken;
        } else {
            console.error("Zoom OAuth failed:", data);
            return null;
        }
    } catch (error) {
        console.error("Zoom OAuth error:", error);
        return null;
    }
}

export async function createZoomMeeting({
    topic,
    startTime,
    durationMinutes,
    hostEmail, // Email of the user hosting the meeting. Must exist in the Zoom account.
}: {
    topic: string;
    startTime: string | Date;
    durationMinutes: number;
    hostEmail: string;
}) {
    const token = await getZoomAccessToken();
    
    // If no token or not configured, return a mock/placeholder link or null
    // so it doesn't break the booking flow if they haven't set up Zoom yet.
    if (!token) {
        return {
            joinUrl: `https://zoom.us/j/placeholder-${Math.floor(Math.random() * 100000)}`,
            meetingId: "placeholder",
        };
    }

    try {
        const url = `https://api.zoom.us/v2/users/${encodeURIComponent(hostEmail)}/meetings`;
        
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                topic,
                type: 2, // Scheduled meeting
                start_time: typeof startTime === "string" ? startTime : startTime.toISOString(),
                duration: durationMinutes,
                timezone: "UTC",
                settings: {
                    host_video: true,
                    participant_video: true,
                    join_before_host: false,
                    mute_upon_entry: true,
                    waiting_room: true,
                },
            }),
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("Failed to create Zoom meeting:", data);
            // If the user's email isn't found in the Zoom account, Zoom returns 404.
            // We fallback gracefully so the booking still happens.
            return {
                joinUrl: `https://zoom.us/j/placeholder-${Math.floor(Math.random() * 100000)}`,
                meetingId: "placeholder",
            };
        }

        return {
            joinUrl: data.join_url,
            meetingId: data.id.toString(),
            startUrl: data.start_url, // For the host
        };
    } catch (error) {
        console.error("Zoom meeting creation error:", error);
        return {
            joinUrl: `https://zoom.us/j/placeholder-${Math.floor(Math.random() * 100000)}`,
            meetingId: "placeholder",
        };
    }
}
