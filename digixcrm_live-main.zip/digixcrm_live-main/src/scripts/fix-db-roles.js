const { Pool } = require('pg');

async function fixDb() {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
        console.error("DATABASE_URL not found");
        process.exit(1);
    }

    const pool = new Pool({ connectionString });

    try {
        console.log("Checking and adding missing roles to DB...");
        
        // We use a DO block to safely add enum values only if they don't exist
        // Note: In Postgres, adding enum values is safe but usually cannot be done in a transaction block with other DDLs easily in some contexts.
        // But for a script, individual ALTER TYPE statements are fine.
        
        const roles = ['PROJECT_MANAGER', 'STAFF'];
        
        for (const role of roles) {
            try {
                await pool.query(`ALTER TYPE "Role" ADD VALUE '${role}'`);
                console.log(`Successfully added ${role} to Role enum.`);
            } catch (err) {
                if (err.code === '42710') { // duplicate_object
                    console.log(`${role} already exists in Role enum.`);
                } else {
                    console.error(`Error adding ${role}:`, err.message);
                }
            }
        }

    } catch (err) {
        console.error("Database connection error:", err.message);
    } finally {
        await pool.end();
    }
}

fixDb();
