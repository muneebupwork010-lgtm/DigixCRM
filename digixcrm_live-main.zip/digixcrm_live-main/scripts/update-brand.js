const fs = require('fs');
const path = require('path');

function replaceInDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        if (file === 'node_modules' || file === '.next' || file === '.git' || file === 'android' || file === 'public' || file.endsWith('.png') || file.endsWith('.svg') || file.endsWith('.ico')) continue;
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            replaceInDir(fullPath);
        } else if (file.match(/\.(tsx|ts|md|js|json|css|html|xml)$/)) {
            let content = fs.readFileSync(fullPath, 'utf8');
            if (content.includes('DigixCRM')) {
                content = content.replace(/DigixCRM/g, 'DigixCRM');
                fs.writeFileSync(fullPath, content);
                console.log(`Updated: ${fullPath}`);
            }
        }
    }
}

try {
    replaceInDir('./src');
    replaceInDir('./scripts');
    const rootFiles = ['capacitor.config.ts', 'README.md', 'DEPLOYMENT_GUIDE_PRODUCTION.md', 'DEPLOYMENT_GUIDE_VPS.md', 'package.json', 'guide.md'];
    for (const file of rootFiles) {
        if (fs.existsSync(file)) {
            let content = fs.readFileSync(file, 'utf8');
            if (content.includes('DigixCRM')) {
                content = content.replace(/DigixCRM/g, 'DigixCRM');
                fs.writeFileSync(file, content);
                console.log(`Updated: ${file}`);
            }
        }
    }
    console.log("Brand text replaced successfully.");
} catch (e) {
    console.error(e);
}
