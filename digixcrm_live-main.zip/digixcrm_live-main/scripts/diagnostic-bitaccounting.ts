import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";
import * as dotenv from "dotenv";

dotenv.config();

async function main() {
    const connectionString = process.env.DATABASE_URL;
    const pool = new pg.Pool({ connectionString });
    const adapter = new PrismaPg(pool as any);
    const prisma = new PrismaClient({ adapter } as any);

    try {
        const workspace = await prisma.workspace.findFirst({
            where: { name: "Bitaccounting" },
            include: { account: true, members: true }
        });

        if (!workspace) {
            console.log("Workspace Bitaccounting not found.");
            return;
        }

        console.log("DIAGNOSTIC REPORT:");
        console.log("------------------");
        console.log(`Workspace ID: ${workspace.id}`);
        console.log(`Workspace Name: ${workspace.name}`);
        console.log(`Account ID: ${workspace.accountId}`);
        console.log(`Account Name: ${workspace.account?.name}`);
        console.log(`Account Plan: ${workspace.account?.planTier}`);
        console.log(`Workspace Enabled Modules: ${JSON.stringify((workspace as any).enabledModules)}`);

    } catch (e) {
        console.error(e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
