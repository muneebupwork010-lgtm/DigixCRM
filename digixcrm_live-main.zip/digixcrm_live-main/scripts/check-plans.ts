import { PrismaClient } from "../src/generated/prisma/client";

async function main() {
  const prisma = new PrismaClient();
  try {
    const workspaces = await prisma.workspace.findMany({
      include: { account: true }
    });
    
    console.log("ALL WORKSPACES IN DB:");
    workspaces.forEach((ws: any) => {
      console.log(`- ${ws.name} (ID: ${ws.id}) | Plan: ${ws.account?.planTier || "NONE"} | Modules: ${JSON.stringify((ws as any).enabledModules)}`);
    });

  } catch (e) {
    console.error(e);
  } finally {
    await prisma.$disconnect();
  }
}

main();
