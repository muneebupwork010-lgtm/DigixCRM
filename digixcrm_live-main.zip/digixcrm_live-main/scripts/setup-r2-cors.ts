import { S3Client, PutBucketCorsCommand } from "@aws-sdk/client-s3";
import dotenv from "dotenv";

dotenv.config();

async function main() {
  console.log("Configuring Cloudflare R2 CORS Policy...");

  const s3Client = new S3Client({
    region: "auto",
    endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID || "",
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || "",
    },
    forcePathStyle: true,
  });

  const bucketName = process.env.R2_BUCKET_NAME;

  if (!bucketName) {
    console.error("Missing R2_BUCKET_NAME in .env");
    process.exit(1);
  }

  const command = new PutBucketCorsCommand({
    Bucket: bucketName,
    CORSConfiguration: {
      CORSRules: [
        {
          AllowedHeaders: ["*"],
          AllowedMethods: ["PUT", "POST", "GET", "DELETE", "HEAD"],
          AllowedOrigins: ["http://localhost:3000", "https://*"],
          ExposeHeaders: ["ETag"],
          MaxAgeSeconds: 3000,
        },
      ],
    },
  });

  try {
    await s3Client.send(command);
    console.log(`✅ Successfully applied CORS policy to bucket: ${bucketName}`);
  } catch (error) {
    console.error("❌ Failed to apply CORS policy:", error);
  }
}

main();
