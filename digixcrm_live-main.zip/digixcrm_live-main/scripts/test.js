// c:/Users/SG/Desktop/Projects/digixcrm_live/scripts/test.js
const { PrismaClient } = require('./src/generated/prisma/client/client');
const prisma = new PrismaClient();

async function run() {
    const deals = await prisma.deal.findMany({ 
        orderBy: { createdAt: 'desc' }, 
        take: 5,
        include: { owner: { select: { id: true, name: true } } }
    });
    console.log(JSON.stringify(deals, null, 2));
    
    // Also log the relevant lead
    const leads = await prisma.lead.findMany({
        orderBy: { createdAt: 'desc' },
        take: 2,
        include: { owner: { select: { id: true, name: true } } }
    });
    console.log(JSON.stringify(leads, null, 2));
}

run()
  .catch(e => console.error(e))
  .finally(() => prisma.$disconnect());
