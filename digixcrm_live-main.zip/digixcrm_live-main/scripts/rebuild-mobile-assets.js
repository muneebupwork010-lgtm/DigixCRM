const sharp = require('sharp');
const fs = require('fs');

async function run() {
  try {
    const scaledSplashOverlay = await sharp('public/logo-vertical-dark.png')
      .resize({ width: 1000, height: 1000, fit: 'inside', withoutEnlargement: true })
      .toBuffer();

    const scaledEmblem = await sharp('public/logo-emblem-light.png')
      .resize({ width: 850, height: 850, fit: 'inside', withoutEnlargement: true })
      .toBuffer();

    // Generate App Icon (1024x1024 with premium brand background)
    await sharp({
      create: {
        width: 1024,
        height: 1024,
        channels: 4,
        background: { r: 13, g: 27, b: 75, alpha: 1 } // #0d1b4b
      }
    })
    .composite([{ input: scaledEmblem, gravity: 'center' }])
    .toFile('resources/icon.png');

    // Generate Splash Screen (2732x2732 centered)
    await sharp({
      create: {
        width: 2732,
        height: 2732,
        channels: 4,
        background: { r: 255, g: 255, b: 255, alpha: 1 }
      }
    })
    .composite([{ input: scaledSplashOverlay, gravity: 'center' }])
    .toFile('resources/splash.png');
    
    // Generate Dark Mode Splash Screen (optional, capacitor-assets handles it if suffixed)
    const scaledSplashOverlayLight = await sharp('public/logo-vertical-light.png')
      .resize({ width: 1000, height: 1000, fit: 'inside', withoutEnlargement: true })
      .toBuffer();
    
    await sharp({
      create: {
        width: 2732,
        height: 2732,
        channels: 4,
        background: { r: 10, g: 10, b: 10, alpha: 1 }
      }
    })
    .composite([{ input: scaledSplashOverlayLight, gravity: 'center' }])
    .toFile('resources/splash-dark.png');

    console.log("Base assets successfully generated in resources/ folder.");
  } catch (error) {
    console.error("Error generating assets:", error);
  }
}

run();
