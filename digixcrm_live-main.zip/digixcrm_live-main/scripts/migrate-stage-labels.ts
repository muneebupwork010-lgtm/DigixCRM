/**
 * Migration: Rename first pipeline stage from "New Lead" → "Contacted"
 * and align all workspaces to the new default stage names.
 * 
 * Run with: npx tsx scripts/migrate-stage-labels.ts
 */

import "dotenv/config";
import { PrismaClient } from "../src/generated/prisma/client/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const adapter = new PrismaPg(pool as any);
const prisma = new PrismaClient({ adapter } as any);

const LABEL_REMAP: Record<string, string> = {
    "New Lead":   "Contacted",
    "Contacted":  "Proposal Sent",  // old s2 was 'Contacted', now becomes 'Proposal Sent'
    "Closed-Lost": "Closed Lost",
};

const NEW_DEFAULTS = [
    { id: "s1", value: "QUALIFICATION", label: "Contacted",       color: "slate"  },
    { id: "s2", value: "PROPOSAL",      label: "Proposal Sent",   color: "blue"   },
    { id: "s3", value: "NEGOTIATION",   label: "Negotiation",     color: "amber"  },
    { id: "s4", value: "WON",           label: "Sales Confirmed", color: "indigo" },
    { id: "s5", value: "LOST",          label: "Closed Lost",     color: "red"    },
];

async function main() {
    const workspaces = await (prisma.workspace as any).findMany({
        select: { id: true, name: true, dealStages: true },
    });

    console.log(`Found ${workspaces.length} workspace(s).\n`);

    for (const ws of workspaces) {
        const stages = ws.dealStages as Array<{ id: string; value: string; label: string; color: string }> | null;

        if (!stages || stages.length === 0) {
            await (prisma.workspace as any).update({
                where: { id: ws.id },
                data: { dealStages: NEW_DEFAULTS },
            });
            console.log(`[${ws.name}] → No stages found. Applied new defaults. ✓`);
            continue;
        }

        let changed = false;
        const updated = stages.map((s) => {
            if (LABEL_REMAP[s.label]) {
                console.log(`  Renaming "${s.label}" → "${LABEL_REMAP[s.label]}" (${s.value})`);
                changed = true;
                return { ...s, label: LABEL_REMAP[s.label] };
            }
            return s;
        });

        if (changed) {
            await (prisma.workspace as any).update({
                where: { id: ws.id },
                data: { dealStages: updated },
            });
            console.log(`[${ws.name}] → Stages updated ✓\n`);
        } else {
            console.log(`[${ws.name}] → Already up to date. No changes needed.\n`);
        }
    }

    console.log("Migration complete.");
}

main()
    .catch((e) => { console.error(e); process.exit(1); })
    .finally(async () => { await prisma.$disconnect(); pool.end(); });
