import { PrismaClient } from "../src/generated/prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Enabling PMS module for all workspaces...");
  
  const workspaces = await prisma.workspace.findMany();
  
  for (const workspace of workspaces) {
    const currentModules = (workspace as any).enabledModules || ["CRM"];
    const newModules = Array.from(new Set([...currentModules, "CRM", "PMS"]));
    
    await prisma.workspace.update({
      where: { id: workspace.id },
      data: {
        enabledModules: newModules
      } as any
    });
    
    console.log(`Enabled for: ${workspace.name}`);
  }
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
