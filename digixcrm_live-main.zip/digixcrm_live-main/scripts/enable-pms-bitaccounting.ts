import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";
import * as dotenv from "dotenv";

dotenv.config();

async function main() {
    const connectionString = process.env.DATABASE_URL;
    const pool = new pg.Pool({ connectionString });
    const adapter = new PrismaPg(pool as any);
    const prisma = new PrismaClient({ adapter } as any);

    try {
        const workspace = await prisma.workspace.findFirst({
            where: { name: "Bitaccounting" },
            include: { account: true }
        });

        if (!workspace) {
            console.log("Workspace Bitaccounting not found.");
            return;
        }

        console.log(`Current Plan for ${workspace.name}: ${workspace.account?.planTier}`);
        console.log(`Enabled Modules: ${JSON.stringify((workspace as any).enabledModules)}`);

        // Update Account to PRO if it's FREE or STARTER to allow PMS
        if (workspace.account) {
            await prisma.subscriptionAccount.update({
                where: { id: workspace.account.id },
                data: { planTier: "PRO" }
            });
            console.log("Updated PlanTier to PRO.");
        }

        // Ensure PMS is in enabledModules
        const currentModules = (workspace as any).enabledModules || ["CRM"];
        if (!currentModules.includes("PMS")) {
            await (prisma as any).workspace.update({
                where: { id: workspace.id },
                data: {
                    enabledModules: [...currentModules, "PMS"]
                }
            });
            console.log("Added PMS to enabledModules.");
        }

    } catch (e) {
        console.error(e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
